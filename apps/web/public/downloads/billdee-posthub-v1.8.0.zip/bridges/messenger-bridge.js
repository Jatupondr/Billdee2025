"use strict";
(() => {
  // src/shared/errors.ts
  var ErrorCode = {
    LOGIN_REQUIRED: "LOGIN_REQUIRED",
    CAPTCHA_REQUIRED: "CAPTCHA_REQUIRED",
    PERMISSION_MISSING: "PERMISSION_MISSING",
    SELECTOR_NOT_FOUND: "SELECTOR_NOT_FOUND",
    INPUT_REJECTED: "INPUT_REJECTED",
    PAGE_NOT_READY: "PAGE_NOT_READY",
    WEBSITE_UNAVAILABLE: "WEBSITE_UNAVAILABLE",
    RATE_LIMITED: "RATE_LIMITED",
    QUOTA_EXCEEDED: "QUOTA_EXCEEDED",
    GENERATION_FAILED: "GENERATION_FAILED",
    CONTENT_POLICY_BLOCKED: "CONTENT_POLICY_BLOCKED",
    RESPONSE_PARSE_FAILED: "RESPONSE_PARSE_FAILED",
    TIMEOUT: "TIMEOUT",
    PROGRESS_STALLED: "PROGRESS_STALLED",
    DOWNLOAD_FAILED: "DOWNLOAD_FAILED",
    DOWNLOAD_INTERRUPTED: "DOWNLOAD_INTERRUPTED",
    UPLOAD_FAILED: "UPLOAD_FAILED",
    PUBLISH_UNCONFIRMED: "PUBLISH_UNCONFIRMED",
    SEND_UNCONFIRMED: "SEND_UNCONFIRMED",
    DESTINATION_MISMATCH: "DESTINATION_MISMATCH",
    SEND_FAILED: "SEND_FAILED",
    ACCOUNT_RESTRICTED: "ACCOUNT_RESTRICTED",
    NATIVE_SCHEDULE_UNAVAILABLE: "NATIVE_SCHEDULE_UNAVAILABLE",
    BRIDGE_UNREACHABLE: "BRIDGE_UNREACHABLE",
    TAB_CLOSED: "TAB_CLOSED",
    INTERRUPTED: "INTERRUPTED",
    INVALID_INPUT: "INVALID_INPUT",
    INVALID_STATE: "INVALID_STATE",
    NOT_FOUND: "NOT_FOUND",
    PROVIDER_NOT_CONFIGURED: "PROVIDER_NOT_CONFIGURED",
    LICENSE_REQUIRED: "LICENSE_REQUIRED",
    CANCELLED: "CANCELLED",
    INTERNAL: "INTERNAL"
  };
  var META = {
    LOGIN_REQUIRED: { retryable: false, pause: "LOGIN_REQUIRED", userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 \u2014 \u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    CAPTCHA_REQUIRED: { retryable: false, pause: "CAPTCHA", userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E02\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E15\u0E31\u0E27\u0E15\u0E19 (CAPTCHA) \u2014 \u0E17\u0E33\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    PERMISSION_MISSING: { retryable: false, userMessage: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E40\u0E02\u0E49\u0E32\u0E16\u0E36\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E19\u0E35\u0E49 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    SELECTOR_NOT_FOUND: { retryable: true, userMessage: "\u0E2B\u0E32\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E40\u0E08\u0E2D \u2014 \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u0E25\u0E2D\u0E07\u0E01\u0E14 Diagnose \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    INPUT_REJECTED: { retryable: true, userMessage: "\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E23\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34" },
    PAGE_NOT_READY: { retryable: true, userMessage: "\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E22\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21" },
    WEBSITE_UNAVAILABLE: { retryable: true, userMessage: "\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32" },
    RATE_LIMITED: { retryable: false, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E16\u0E35\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B \u2014 \u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E1E\u0E31\u0E01\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry" },
    QUOTA_EXCEEDED: { retryable: false, userMessage: "\u0E43\u0E0A\u0E49\u0E42\u0E04\u0E27\u0E15\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07" },
    GENERATION_FAILED: { retryable: true, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    CONTENT_POLICY_BLOCKED: { retryable: false, userMessage: "\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E1B\u0E0F\u0E34\u0E40\u0E2A\u0E18 prompt \u0E19\u0E35\u0E49 (\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32) \u2014 \u0E41\u0E01\u0E49 prompt \u0E41\u0E25\u0E49\u0E27 Retry" },
    RESPONSE_PARSE_FAILED: { retryable: true, userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E08\u0E32\u0E01 AI \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07)" },
    TIMEOUT: { retryable: true, userMessage: "\u0E23\u0E2D\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14" },
    PROGRESS_STALLED: { retryable: true, userMessage: "\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E27\u0E32\u0E21\u0E04\u0E37\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B" },
    DOWNLOAD_FAILED: { retryable: true, userMessage: "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    DOWNLOAD_INTERRUPTED: { retryable: true, userMessage: "\u0E01\u0E32\u0E23\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30" },
    UPLOAD_FAILED: { retryable: true, userMessage: "\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    PUBLISH_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E02\u0E36\u0E49\u0E19\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E0B\u0E49\u0E33" },
    SEND_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E0A\u0E17\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33" },
    DESTINATION_MISMATCH: { retryable: false, userMessage: "\u0E41\u0E0A\u0E17\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E44\u0E27\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07" },
    SEND_FAILED: { retryable: false, userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    ACCOUNT_RESTRICTED: { retryable: false, pause: "INTERRUPTED", userMessage: "Facebook \u0E08\u0E33\u0E01\u0E31\u0E14\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E2A\u0E48\u0E07\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u0E15\u0E23\u0E27\u0E08\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A Facebook \u0E41\u0E25\u0E30\u0E23\u0E2D\u0E08\u0E19\u0E02\u0E49\u0E2D\u0E08\u0E33\u0E01\u0E31\u0E14\u0E2B\u0E21\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E15\u0E48\u0E2D" },
    NATIVE_SCHEDULE_UNAVAILABLE: { retryable: false, userMessage: "\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A\u0E02\u0E2D\u0E07 Facebook \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E43\u0E0A\u0E49\u0E15\u0E31\u0E27\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E41\u0E17\u0E19" },
    BRIDGE_UNREACHABLE: { retryable: true, userMessage: "\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D\u0E2A\u0E04\u0E23\u0E34\u0E1B\u0E15\u0E4C\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
    TAB_CLOSED: { retryable: true, userMessage: "\u0E41\u0E17\u0E47\u0E1A\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E16\u0E39\u0E01\u0E1B\u0E34\u0E14\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E17\u0E33\u0E07\u0E32\u0E19" },
    INTERRUPTED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E07\u0E32\u0E19\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30 (browser/\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E23\u0E35\u0E2A\u0E15\u0E32\u0E23\u0E4C\u0E17) \u2014 \u0E15\u0E23\u0E27\u0E08\u0E1C\u0E25\u0E1A\u0E19\u0E40\u0E27\u0E47\u0E1A \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry \u0E2B\u0E23\u0E37\u0E2D Cancel" },
    INVALID_INPUT: { retryable: false, userMessage: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E21\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" },
    INVALID_STATE: { retryable: false, userMessage: "\u0E17\u0E33\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E19\u0E35\u0E49\u0E43\u0E19\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
    NOT_FOUND: { retryable: false, userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E23\u0E30\u0E1A\u0E38" },
    PROVIDER_NOT_CONFIGURED: { retryable: false, userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49 \u2014 \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    LICENSE_REQUIRED: { retryable: false, pause: "LICENSE_REQUIRED", userMessage: "License \u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u2014 \u0E07\u0E32\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E23\u0E34\u0E48\u0E21 \u0E15\u0E23\u0E27\u0E08 License \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    CANCELLED: { retryable: false, userMessage: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27" },
    INTERNAL: { retryable: false, userMessage: "\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E20\u0E32\u0E22\u0E43\u0E19 \u2014 \u0E14\u0E39\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E43\u0E19 Log" }
  };
  var AppError = class extends Error {
    code;
    retryable;
    userMessage;
    detail;
    constructor(code, message, opts = {}) {
      super(message, opts.cause === void 0 ? void 0 : { cause: opts.cause });
      this.name = "AppError";
      this.code = code;
      this.retryable = opts.retryable ?? META[code].retryable;
      this.userMessage = opts.userMessage ?? META[code].userMessage;
      this.detail = opts.detail;
    }
    get pauseReason() {
      return META[this.code].pause;
    }
    toJSON() {
      const json = {
        code: this.code,
        message: this.message,
        userMessage: this.userMessage,
        retryable: this.retryable
      };
      if (this.detail !== void 0) json.detail = this.detail;
      return json;
    }
  };
  function isErrorCode(value) {
    return typeof value === "string" && value in META;
  }
  function toAppError(err, fallback = ErrorCode.INTERNAL) {
    if (err instanceof AppError) return err;
    if (isAppErrorJSON(err)) return fromJSON(err);
    if (err instanceof DOMException && err.name === "AbortError") {
      return new AppError(ErrorCode.CANCELLED, "Operation aborted", { cause: err });
    }
    const message = err instanceof Error ? err.message : String(err);
    return new AppError(fallback, message, { cause: err });
  }
  function isAppErrorJSON(value) {
    if (typeof value !== "object" || value === null) return false;
    const v = value;
    return isErrorCode(v["code"]) && typeof v["message"] === "string";
  }
  function fromJSON(json) {
    const code = isErrorCode(json.code) ? json.code : ErrorCode.INTERNAL;
    return new AppError(code, json.message, {
      userMessage: json.userMessage,
      retryable: json.retryable,
      detail: json.detail
    });
  }

  // src/shared/schema.ts
  function fail(path, expected, value) {
    const got = value === null ? "null" : Array.isArray(value) ? "array" : typeof value;
    throw new AppError(ErrorCode.INVALID_INPUT, `${path || "value"}: expected ${expected}, got ${got}`, {
      detail: { path, expected }
    });
  }
  function string(opts = {}) {
    return (value, path = "") => {
      if (typeof value !== "string") fail(path, "string", value);
      if (opts.min !== void 0 && value.length < opts.min) fail(path, `string length >= ${opts.min}`, value);
      if (opts.max !== void 0 && value.length > opts.max) fail(path, `string length <= ${opts.max}`, value);
      if (opts.pattern && !opts.pattern.test(value)) fail(path, `string matching ${opts.pattern}`, value);
      return value;
    };
  }
  function number(opts = {}) {
    return (value, path = "") => {
      if (typeof value !== "number" || !Number.isFinite(value)) fail(path, "finite number", value);
      if (opts.int && !Number.isInteger(value)) fail(path, "integer", value);
      if (opts.min !== void 0 && value < opts.min) fail(path, `number >= ${opts.min}`, value);
      if (opts.max !== void 0 && value > opts.max) fail(path, `number <= ${opts.max}`, value);
      return value;
    };
  }
  var boolean = (value, path = "") => {
    if (typeof value !== "boolean") fail(path, "boolean", value);
    return value;
  };
  function array(item, opts = {}) {
    return (value, path = "") => {
      if (!Array.isArray(value)) fail(path, "array", value);
      if (opts.max !== void 0 && value.length > opts.max) fail(path, `array length <= ${opts.max}`, value);
      if (opts.min !== void 0 && value.length < opts.min) fail(path, `array length >= ${opts.min}`, value);
      return value.map((v, i) => item(v, `${path}[${i}]`));
    };
  }
  function optional(inner) {
    return (value, path = "") => value === void 0 ? void 0 : inner(value, path);
  }
  function object(shape) {
    return (value, path = "") => {
      if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
      const src = value;
      const out = {};
      for (const [key, validator] of Object.entries(shape)) {
        const v = validator(src[key], path ? `${path}.${key}` : key);
        if (v !== void 0) out[key] = v;
      }
      return out;
    };
  }
  var id = string({ min: 1, max: 64, pattern: /^[A-Za-z0-9_-]+$/ });

  // src/providers/messenger/protocol.ts
  var MESSENGER_PROVIDER_ID = "facebook-messenger-web";
  var MESSENGER_PREFIX = "messenger";
  var MESSENGER_BRIDGE_VERSION = "2";
  var MESSENGER_CMD = {
    /** Reads the open chat's identity (thread id from the URL, title from the header). */
    inspect: `${MESSENGER_PREFIX}.inspect`,
    /** Throws DESTINATION_MISMATCH unless the open chat is the target (thread id; header = composer, ADR-70). */
    verifyTarget: `${MESSENGER_PREFIX}.verifyTarget`,
    /** Refuses to continue when the composer already holds text or files (never mix messages). */
    checkClean: `${MESSENGER_PREFIX}.checkClean`,
    attach: `${MESSENGER_PREFIX}.attach`,
    waitAttached: `${MESSENGER_PREFIX}.waitAttached`,
    setText: `${MESSENGER_PREFIX}.setText`,
    /** Presses send (irreversible). Returns the counts needed to confirm. */
    send: `${MESSENGER_PREFIX}.send`,
    waitSent: `${MESSENGER_PREFIX}.waitSent`
  };

  // src/providers/messenger/chat-name.ts
  var EMOJI = /[\p{Extended_Pictographic}\p{Emoji_Modifier}\p{Regional_Indicator}\u{200D}\u{FE0E}\u{FE0F}\u{20E3}]/gu;
  var spaces = (s) => s.replace(/\s+/g, " ").trim().toLowerCase();
  function chatNameKey(name) {
    const plain = spaces(name.replace(EMOJI, ""));
    return plain || spaces(name);
  }
  function sameChatName(a, b) {
    return chatNameKey(a) === chatNameKey(b);
  }

  // src/providers/messenger/selectors.ts
  var MESSENGER_SELECTORS = {
    composer: [
      { css: "[role='main'] [role='region'] div[role='textbox'][contenteditable='true']" },
      // live 2026-09-25
      { css: "[role='main'] div[role='textbox'][contenteditable='true']" },
      { css: "div[role='textbox'][contenteditable='true'][aria-label]" },
      { role: "textbox", name: /^(message|aa|ข้อความ|พิมพ์ข้อความ|เขียนถึง)/i }
    ],
    /**
     * Conversation title in the chat header. Live (2026-09-25): a visible <h3> inside the header
     * button labelled "การสนทนาชื่อ <name>"; a 1×1 screen-reader <h3> with that prefix comes first,
     * so TITLE_PREFIX is stripped when reading.
     */
    title: [
      { css: "[role='main'] [role='button'][aria-label] h3" },
      { css: "[role='main'] [data-testid='conversation-title']" },
      { css: "[role='main'] [role='banner'] h2" },
      { css: "[role='main'] h2" }
    ],
    fileInput: [
      { css: "[role='main'] [role='region'] input[type='file']" },
      // live: multiple, no accept
      { css: "[role='main'] input[type='file'][multiple]" },
      { css: "[role='main'] input[type='file']" }
    ],
    /** Thumbnails of files attached in the composer (before sending). NOT yet seen live. */
    attachmentPreview: [
      { css: "[role='main'] [role='region'] img[src^='blob:'], [role='main'] [role='region'] video" },
      { css: "[role='main'] [data-testid='composer-attachment']" },
      { css: "[role='main'] form img[src^='blob:']" }
    ],
    /**
     * Shown only while the composer has content (not seen live yet). With an empty composer the
     * same spot is the quick reaction ("ส่ง ✨" / "Send a like") — the exact-name match keeps it out;
     * when nothing matches the bridge presses Enter instead.
     */
    sendButton: [
      { css: "[role='main'] [aria-label='\u0E01\u0E14 Enter \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E2A\u0E48\u0E07']" },
      { css: "[role='main'] [aria-label='Press enter to send']" },
      { css: "[role='main'] [aria-label='Press Enter to send']" },
      { role: "button", name: /^(send|ส่ง)$/i }
    ],
    /** The conversation (message list) — live: role=log "ข้อความในการสนทนาที่ชื่อว่า <name>". */
    messageList: [
      { css: "[role='main'] [role='log']" },
      { css: "[role='main'] [role='grid']" },
      { css: "[role='main'] [aria-label^='\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E43\u0E19\u0E01\u0E32\u0E23\u0E2A\u0E19\u0E17\u0E19\u0E32']" },
      { css: "[role='main'] [aria-label^='Messages in conversation']" }
    ],
    /** Photos inside messages — live: <a href="/messenger_media/…"><img></a> (avatars/emoji excluded). */
    messageImage: [{ css: "[role='main'] [role='log'] a[href^='/messenger_media'] img" }],
    loginForm: [{ css: "form[action*='login']" }, { css: "input[name='email'][type]" }]
  };
  var MESSENGER_TEXT = {
    /** Screen-reader prefix of the header title / its button ("การสนทนาชื่อ <name>"). */
    titlePrefix: /^(การสนทนาชื่อ|conversation titled|conversation with)\s+/i,
    /** Composer label names the chat too ("เขียนถึง <name>") — used as a second identity check. */
    composerTo: /^(เขียนถึง|write to|message)\s+(.+)$/i,
    /** Facebook says the message did not go out. */
    sendError: /couldn['’]t send|failed to send|message not sent|ส่งไม่สำเร็จ|ไม่สามารถส่งข้อความ/i,
    /** Facebook restricts sending (never worked around). */
    restricted: /temporarily blocked|you['’]re blocked|we limit how often|ถูกบล็อกชั่วคราว|จำกัดความถี่|ถูกจำกัดการใช้งาน/i,
    /** Delivery status under our last message (live 2026-09-27: "กำลังส่ง" → "ส่งแล้ว"). */
    sending: /กำลังส่ง|sending/i,
    delivered: /ส่งแล้ว|อ่านแล้ว|เห็นแล้ว|\bsent\b|\bdelivered\b|\bseen\b/i,
    /** Encrypted chats may ask for the PIN to restore history. */
    pinPrompt: /enter your pin|restore your chat history|ป้อน pin|กู้คืนประวัติการแชท/i
  };

  // src/shared/async.ts
  function abortError(signal) {
    const reason = signal?.reason;
    if (reason instanceof AppError) return reason;
    return new AppError(ErrorCode.CANCELLED, "Operation cancelled");
  }
  function throwIfAborted(signal) {
    if (signal?.aborted) throw abortError(signal);
  }
  function withTimeout(promise, ms, what, code = ErrorCode.TIMEOUT) {
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new AppError(code, `${what} timed out after ${ms} ms`, { detail: { ms } })), ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
  }

  // src/bridges/bridge-kit/dom.ts
  var POLL_MS = 400;
  var IMPLICIT_ROLE = {
    button: "button,[role='button'],input[type='button'],input[type='submit']",
    textbox: "textarea,input[type='text'],input:not([type]),[contenteditable='true'],[role='textbox']",
    dialog: "[role='dialog'],dialog",
    link: "a[href],[role='link']",
    img: "img,[role='img']",
    checkbox: "input[type='checkbox'],[role='checkbox']",
    menuitem: "[role='menuitem']",
    tab: "[role='tab']",
    alert: "[role='alert'],[role='alertdialog']",
    combobox: "select,[role='combobox']",
    option: "option,[role='option']",
    heading: "h1,h2,h3,h4,h5,h6,[role='heading']"
  };
  function accessibleName(el) {
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.trim();
    const labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      const text = labelledBy.split(/\s+/).map((id2) => el.ownerDocument.getElementById(id2)?.textContent ?? "").join(" ").trim();
      if (text) return text;
    }
    const attr = el.getAttribute("title") ?? el.getAttribute("placeholder") ?? el.getAttribute("alt");
    if (attr) return attr.trim();
    const placeholder = el.getAttribute("data-placeholder");
    if (placeholder) return placeholder.trim();
    return (el.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function queryCandidate(c, root = document) {
    let els;
    if (c.css && c.role) {
      const roleSel = IMPLICIT_ROLE[c.role] ?? `[role='${c.role}']`;
      els = Array.from(root.querySelectorAll(c.css)).filter((e) => e.matches(roleSel));
    } else if (c.css) {
      els = Array.from(root.querySelectorAll(c.css));
    } else if (c.role) {
      els = Array.from(root.querySelectorAll(IMPLICIT_ROLE[c.role] ?? `[role='${c.role}']`));
    } else {
      els = Array.from(root.querySelectorAll("*"));
    }
    const { name, text } = c;
    if (name) els = els.filter((e) => name.test(accessibleName(e)));
    if (text) els = els.filter((e) => text.test((e.textContent ?? "").replace(/\s+/g, " ").trim()));
    return els;
  }
  function isVisible(el) {
    if (!(el instanceof HTMLElement) && !(el instanceof SVGElement)) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    const style = getComputedStyle(el);
    return !(style.visibility === "hidden" || style.display === "none" || Number(style.opacity) === 0);
  }
  function isEnabled(el) {
    if (el.disabled) return false;
    return el.getAttribute("aria-disabled") !== "true";
  }
  function resolveFirst(list, opts = {}) {
    const root = opts.root ?? document;
    for (let i = 0; i < list.length; i++) {
      const candidate = list[i];
      const el = queryCandidate(candidate, root).find(
        (e) => (opts.visible === false || isVisible(e)) && (!opts.enabled || isEnabled(e))
      );
      if (el) return { el, index: i };
    }
    return null;
  }
  function resolveAll(list, opts = {}) {
    const root = opts.root ?? document;
    const seen = /* @__PURE__ */ new Set();
    for (const candidate of list) {
      for (const el of queryCandidate(candidate, root)) {
        if (opts.visible !== false && !isVisible(el)) continue;
        seen.add(el);
      }
    }
    return [...seen];
  }
  function waitForCondition(check, opts) {
    return new Promise((resolve, reject) => {
      throwIfAborted(opts.signal);
      let settled = false;
      const finish = (fn) => {
        if (settled) return;
        settled = true;
        observer.disconnect();
        clearInterval(poll);
        clearTimeout(deadline);
        opts.signal?.removeEventListener("abort", onAbort);
        fn();
      };
      const evaluate = () => {
        try {
          const value = check();
          if (value !== null && value !== void 0 && value !== false) finish(() => resolve(value));
        } catch (err) {
          finish(() => reject(err instanceof Error ? err : new AppError(ErrorCode.INTERNAL, String(err))));
        }
      };
      const observer = new MutationObserver(evaluate);
      observer.observe(opts.observe ?? document, { childList: true, subtree: true, attributes: true, characterData: true });
      const poll = setInterval(evaluate, POLL_MS);
      const deadline = setTimeout(
        () => finish(
          () => reject(opts.onTimeout?.() ?? new AppError(ErrorCode.TIMEOUT, `${opts.what} not reached in ${opts.timeoutMs} ms`))
        ),
        opts.timeoutMs
      );
      const onAbort = () => {
        const reason = opts.signal?.reason;
        finish(() => reject(reason instanceof AppError ? reason : new AppError(ErrorCode.CANCELLED, "Cancelled")));
      };
      opts.signal?.addEventListener("abort", onAbort, { once: true });
      evaluate();
    });
  }
  function waitFor(key, list, opts) {
    return waitForCondition(() => resolveFirst(list, opts), {
      ...opts,
      what: key,
      onTimeout: () => new AppError(ErrorCode.SELECTOR_NOT_FOUND, `Element "${key}" not found within ${opts.timeoutMs} ms`, {
        detail: { selector: key }
      })
    });
  }
  function diagnoseSelectors(map, keys = Object.keys(map)) {
    return keys.map((key) => {
      const list = map[key] ?? [];
      const found = resolveFirst(list, { visible: false });
      return { key, found: found !== null, matchedIndex: found?.index ?? -1, candidates: list.length };
    });
  }

  // src/bridges/bridge-kit/file-input.ts
  function setInputFiles(input, files) {
    if (input.type !== "file") throw new AppError(ErrorCode.UPLOAD_FAILED, "Target is not a file input");
    const data = new DataTransfer();
    for (const f of files) data.items.add(f);
    input.files = data.files;
    if ((input.files?.length ?? 0) !== files.length) {
      throw new AppError(ErrorCode.UPLOAD_FAILED, "File input rejected the files");
    }
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // src/bridges/bridge-kit/input.ts
  function normalise(s) {
    return s.replace(/\s+/g, " ").trim();
  }
  function currentText(el) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) return el.value;
    return el.innerText ?? el.textContent ?? "";
  }
  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (!setter) throw new AppError(ErrorCode.INPUT_REJECTED, "No native value setter");
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function selectAllIn(el) {
    const selection = el.ownerDocument.getSelection();
    if (!selection) return;
    const range = el.ownerDocument.createRange();
    range.selectNodeContents(el);
    selection.removeAllRanges();
    selection.addRange(range);
  }
  function pasteText(el, text) {
    const data = new DataTransfer();
    data.setData("text/plain", text);
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: data, bubbles: true, cancelable: true }));
  }
  function comparable(s) {
    return s.replace(/[^\p{L}\p{M}\p{N}]+/gu, "");
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function settle(check, ms) {
    const until = Date.now() + ms;
    for (; ; ) {
      if (check()) return true;
      if (Date.now() >= until) return false;
      await sleep(50);
    }
  }
  var SETTLE_MS = 2e3;
  async function selectAll(el) {
    el.focus();
    selectAllIn(el);
    await sleep(60);
  }
  async function clearEditor(el) {
    for (let i = 0; i < 3; i++) {
      if (!comparable(currentText(el))) return true;
      await selectAll(el);
      el.ownerDocument.execCommand("delete", false);
      if (await settle(() => !comparable(currentText(el)), 500)) return true;
      await selectAll(el);
      el.dispatchEvent(new InputEvent("beforeinput", { inputType: "deleteContentBackward", bubbles: true, cancelable: true }));
      if (await settle(() => !comparable(currentText(el)), 500)) return true;
    }
    return !comparable(currentText(el));
  }
  async function replaceText(el, text) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      setNativeValue(el, text);
      if (el.value !== text) throw new AppError(ErrorCode.INPUT_REJECTED, "Input value did not stick");
      return;
    }
    const expected = comparable(text);
    const landed = () => comparable(currentText(el)) === expected;
    const attempts = [
      () => pasteText(el, text),
      () => el.ownerDocument.execCommand("insertText", false, text)
    ];
    for (const attempt of attempts) {
      if (!await clearEditor(el)) break;
      await selectAll(el);
      attempt();
      if (await settle(landed, SETTLE_MS)) return;
    }
    const got = normalise(currentText(el)).slice(0, 120);
    await clearEditor(el);
    throw new AppError(ErrorCode.INPUT_REJECTED, "Editor did not accept the text", { detail: { got } });
  }
  function clickElement(el) {
    if (!(el instanceof HTMLElement)) throw new AppError(ErrorCode.INPUT_REJECTED, "Target is not clickable");
    el.scrollIntoView({ block: "center", inline: "center" });
    const rect = el.getBoundingClientRect();
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      clientX: rect.left + rect.width / 2,
      clientY: rect.top + rect.height / 2,
      button: 0
    };
    el.dispatchEvent(new PointerEvent("pointerdown", { ...init, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mousedown", init));
    el.dispatchEvent(new PointerEvent("pointerup", { ...init, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mouseup", init));
    el.dispatchEvent(new MouseEvent("click", init));
  }
  function pressEnter(el) {
    const init = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
    el.dispatchEvent(new KeyboardEvent("keydown", init));
    el.dispatchEvent(new KeyboardEvent("keypress", init));
    el.dispatchEvent(new KeyboardEvent("keyup", init));
  }

  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 1;
  var counter = 0;
  function newRequestId() {
    counter = (counter + 1) % 1e6;
    return `${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }
  function envelope(type, payload, id2 = newRequestId()) {
    return { v: PROTOCOL_VERSION, id: id2, type, payload };
  }
  function isEnvelope(value) {
    if (typeof value !== "object" || value === null) return false;
    const v = value;
    return v["v"] === PROTOCOL_VERSION && typeof v["id"] === "string" && typeof v["type"] === "string";
  }
  function ok(data) {
    return { ok: true, data };
  }
  function failure(err) {
    return { ok: false, error: toAppError(err).toJSON() };
  }
  var BRIDGE_PROGRESS = "bridge.progress";
  var BRIDGE_CANCEL = "bridge.cancel";
  var PORT_TRANSFER_TO_EXTENSION = "acf-transfer-in:";
  var PORT_TRANSFER_TO_PAGE = "acf-transfer-out:";

  // src/bridges/bridge-kit/server.ts
  function extensionAlive() {
    try {
      return typeof chrome !== "undefined" && Boolean(chrome.runtime?.id);
    } catch {
      return false;
    }
  }
  function startBridge(providerId, version, handlers) {
    const registry = globalThis.__acfBridges ??= {};
    registry[providerId]?.dispose();
    const inflight = /* @__PURE__ */ new Map();
    const listener = (message, sender, sendResponse) => {
      if (!isEnvelope(message) || sender.id !== chrome.runtime.id || sender.tab || sender.url?.startsWith("http")) return false;
      const env = message;
      if (env.type === BRIDGE_CANCEL) {
        const raw = env.payload?.["requestId"];
        const requestId = typeof raw === "string" ? raw : "";
        inflight.get(requestId)?.abort(new AppError(ErrorCode.CANCELLED, "Cancelled by extension"));
        return false;
      }
      const handler = handlers[env.type];
      if (!handler) return false;
      const controller = new AbortController();
      inflight.set(env.id, controller);
      const ctx = {
        signal: controller.signal,
        requestId: env.id,
        progress: (text, data) => {
          if (!extensionAlive()) return;
          const payload = { requestId: env.id, message: text };
          if (data) payload.data = data;
          chrome.runtime.sendMessage(envelope(BRIDGE_PROGRESS, payload)).catch(() => void 0);
        }
      };
      Promise.resolve().then(() => handler(env.payload ?? {}, ctx)).then(
        (data) => sendResponse(ok(data ?? null)),
        (err) => sendResponse(failure(err))
      ).finally(() => inflight.delete(env.id));
      return true;
    };
    chrome.runtime.onMessage.addListener(listener);
    registry[providerId] = {
      version,
      dispose: () => {
        for (const c of inflight.values()) c.abort(new AppError(ErrorCode.CANCELLED, "Bridge replaced"));
        inflight.clear();
        try {
          chrome.runtime.onMessage.removeListener(listener);
        } catch {
        }
      }
    };
  }

  // src/shared/hash.ts
  async function sha256Hex(data) {
    const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
  }

  // src/shared/transfer-codec.ts
  var TRANSFER_CHUNK_BYTES = 1024 * 1024;
  var TRANSFER_MAX_BYTES = 1024 * 1024 * 1024;
  function bytesToBase64(bytes) {
    let binary = "";
    const step = 32768;
    for (let i = 0; i < bytes.length; i += step) {
      binary += String.fromCharCode(...bytes.subarray(i, i + step));
    }
    return btoa(binary);
  }
  function base64ToBytes(b64) {
    const binary = atob(b64);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }
  async function sendBlobOverPort(port, blob, name) {
    if (blob.size > TRANSFER_MAX_BYTES) {
      throw new AppError(ErrorCode.UPLOAD_FAILED, `File too large to transfer (${blob.size} bytes)`);
    }
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const chunks = Math.max(1, Math.ceil(bytes.length / TRANSFER_CHUNK_BYTES));
    const ack = new Promise((resolve, reject) => {
      port.onMessage.addListener((msg) => {
        if (msg.k !== "ack") return;
        if (msg.ok) resolve();
        else reject(new AppError(ErrorCode.UPLOAD_FAILED, `Receiver rejected transfer: ${msg.error}`));
      });
      port.onDisconnect.addListener(
        () => reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer port disconnected before ack"))
      );
    });
    port.postMessage({ k: "meta", size: bytes.length, mime: blob.type, name, chunks });
    for (let i = 0; i < chunks; i++) {
      const slice2 = bytes.subarray(i * TRANSFER_CHUNK_BYTES, (i + 1) * TRANSFER_CHUNK_BYTES);
      port.postMessage({ k: "chunk", i, b64: bytesToBase64(slice2) });
    }
    port.postMessage({ k: "end", sha256: await sha256Hex(bytes) });
    await ack;
  }
  function receiveBlobFromPort(port) {
    return new Promise((resolve, reject) => {
      let meta = null;
      const parts = [];
      const fail2 = (error) => {
        try {
          port.postMessage({ k: "ack", ok: false, error });
        } catch {
        }
        reject(new AppError(ErrorCode.UPLOAD_FAILED, error));
      };
      port.onDisconnect.addListener(() => {
        if (!meta || parts.length < meta.chunks) reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer interrupted"));
      });
      port.onMessage.addListener((msg) => {
        if (msg.k === "meta") {
          if (msg.size > TRANSFER_MAX_BYTES) return fail2("file too large");
          meta = msg;
          return;
        }
        if (msg.k === "chunk") {
          if (!meta || msg.i !== parts.length) return fail2(`unexpected chunk ${msg.i}`);
          parts.push(base64ToBytes(msg.b64));
          return;
        }
        if (msg.k === "end") {
          const m = meta;
          if (!m || parts.length !== m.chunks) return fail2("missing chunks");
          const file = new File(parts, m.name, { type: m.mime });
          void file.arrayBuffer().then((buf) => sha256Hex(buf)).then((hash) => {
            if (hash !== msg.sha256) return fail2("checksum mismatch");
            port.postMessage({ k: "ack", ok: true });
            resolve(file);
          }, (err) => fail2(String(err)));
        }
      });
    });
  }

  // src/bridges/bridge-kit/transfer.ts
  async function sendBlobToExtension(transferId, blob, name, timeoutMs) {
    const port = chrome.runtime.connect({ name: `${PORT_TRANSFER_TO_EXTENSION}${transferId}` });
    try {
      await withTimeout(sendBlobOverPort(port, blob, name), timeoutMs, "Transfer to extension", ErrorCode.DOWNLOAD_FAILED);
    } finally {
      port.disconnect();
    }
  }
  function expectFileFromExtension(transferId, timeoutMs) {
    const expected = `${PORT_TRANSFER_TO_PAGE}${transferId}`;
    let listener = null;
    const file = new Promise((resolve, reject) => {
      listener = (port) => {
        if (port.name !== expected) return;
        if (port.sender?.id !== chrome.runtime.id) {
          port.disconnect();
          reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer from unexpected sender"));
          return;
        }
        receiveBlobFromPort(port).then(resolve, reject);
      };
      chrome.runtime.onConnect.addListener(listener);
    });
    return withTimeout(file, timeoutMs, "Transfer from extension", ErrorCode.UPLOAD_FAILED).finally(() => {
      if (listener) chrome.runtime.onConnect.removeListener(listener);
    });
  }
  async function fetchInPage(url, signal) {
    const res = await fetch(url, { credentials: "include", ...signal ? { signal } : {} });
    if (!res.ok) throw new AppError(ErrorCode.DOWNLOAD_FAILED, `HTTP ${res.status} for media`, { detail: { status: res.status } });
    return res.blob();
  }
  var pendingReceives = /* @__PURE__ */ new Map();
  function prepareReceive(transferId, timeoutMs) {
    const file = expectFileFromExtension(transferId, timeoutMs);
    file.catch(() => void 0);
    pendingReceives.set(transferId, file);
  }
  async function takeReceived(transferId) {
    const file = pendingReceives.get(transferId);
    if (!file) throw new AppError(ErrorCode.UPLOAD_FAILED, `No transfer prepared for ${transferId}`);
    try {
      return await file;
    } finally {
      pendingReceives.delete(transferId);
    }
  }

  // src/bridges/bridge-kit/standard.ts
  async function slice(sliceMs, signal, wait, progress) {
    try {
      return { done: true, result: await wait(sliceMs, signal) };
    } catch (err) {
      if (err instanceof AppError && (err.code === ErrorCode.TIMEOUT || err.code === ErrorCode.SELECTOR_NOT_FOUND)) {
        const out = { done: false };
        const p = progress?.();
        if (p) out.progress = p;
        return out;
      }
      throw err;
    }
  }
  var CAPTCHA_TITLE = /just a moment|attention required|security check|ตรวจสอบความปลอดภัย/i;
  var CAPTCHA_SELECTORS = [
    { css: "#challenge-form" },
    { css: "iframe[src*='challenges.cloudflare.com']" },
    { css: "iframe[src*='recaptcha']" },
    { css: "iframe[src*='hcaptcha']" },
    { css: "[id*='captcha' i]" }
  ];
  function captchaVisible() {
    return CAPTCHA_TITLE.test(document.title) || resolveFirst(CAPTCHA_SELECTORS) !== null;
  }
  function describePage(selectors) {
    const parts = Object.keys(selectors).slice(0, 6).map((key) => {
      const list = selectors[key] ?? [];
      if (resolveFirst(list)) return `${key}=visible`;
      if (resolveFirst(list, { visible: false })) return `${key}=hidden`;
      return `${key}=missing`;
    });
    return `page not ready [${document.visibilityState}, captcha=${captchaVisible()}] ${parts.join(" ")}`;
  }
  var sliceMsValidator = number({ int: true, min: 100, max: 6e4 });
  function standardHandlers(opts) {
    const { prefix } = opts;
    return {
      [`${prefix}.ping`]: () => ({
        providerId: opts.providerId,
        version: opts.version,
        url: location.href,
        state: opts.detectState()
      }),
      [`${prefix}.waitReady`]: (payload, ctx) => {
        const { sliceMs } = object({ sliceMs: sliceMsValidator })(payload);
        return slice(
          sliceMs,
          ctx.signal,
          (timeoutMs, signal) => waitForCondition(
            () => {
              const state = opts.detectState();
              return state === "loading" ? null : state;
            },
            { timeoutMs, signal, what: "page ready" }
          ),
          () => describePage(opts.selectors)
        );
      },
      [`${prefix}.diagnose`]: () => diagnoseSelectors(opts.selectors),
      [`${prefix}.prepareReceive`]: (payload) => {
        const { transferId, timeoutMs } = object({
          transferId: id,
          timeoutMs: number({ int: true, min: 1e3, max: 36e5 })
        })(payload);
        prepareReceive(transferId, timeoutMs);
        return { prepared: true };
      },
      [`${prefix}.fetchMedia`]: async (payload, ctx) => {
        const { src, transferId, timeoutMs } = object({
          src: string({ min: 1, max: 8e3, pattern: /^(https:|blob:)/ }),
          transferId: id,
          timeoutMs: number({ int: true, min: 1e3, max: 36e5 })
        })(payload);
        const blob = await fetchInPage(src, ctx.signal);
        await sendBlobToExtension(transferId, blob, "media", timeoutMs);
        return { size: blob.size, mime: blob.type };
      }
    };
  }

  // src/bridges/messenger-bridge.ts
  var ELEMENT_WAIT_MS = 15e3;
  var THREAD = /\/messages\/(?:e2ee\/)?t\/([A-Za-z0-9._-]+)/;
  var norm = (s) => s.replace(/\s+/g, " ").trim().toLowerCase();
  function pageText() {
    const main = document.querySelector("[role='main']");
    let text = main?.innerText ?? document.body.innerText ?? "";
    const log = resolveFirst(MESSENGER_SELECTORS.messageList)?.el;
    const logText = log?.innerText ?? "";
    if (logText) text = text.replace(logText, " ");
    const overlays = Array.from(document.querySelectorAll("[role='dialog'],[role='alertdialog'],[role='alert']")).filter((el) => !main?.contains(el)).map((el) => el.innerText);
    return [text, ...overlays].join("\n");
  }
  function detectState() {
    if (captchaVisible() || /\/checkpoint\//.test(location.pathname)) return "captcha";
    if (resolveFirst(MESSENGER_SELECTORS.loginForm)) return "login";
    if (MESSENGER_TEXT.pinPrompt.test(pageText().slice(0, 3e3))) return "captcha";
    if (resolveFirst(MESSENGER_SELECTORS.composer)) return "ready";
    return "loading";
  }
  function assertNotRestricted() {
    const text = pageText();
    if (MESSENGER_TEXT.restricted.test(text)) {
      throw new AppError(ErrorCode.ACCOUNT_RESTRICTED, `Facebook restriction: ${text.match(MESSENGER_TEXT.restricted)?.[0] ?? ""}`);
    }
  }
  function identity() {
    const threadId = THREAD.exec(location.pathname)?.[1] ?? "";
    const raw = ((resolveFirst(MESSENGER_SELECTORS.title)?.el.innerText ?? "").split("\n")[0] ?? "").trim();
    const title = raw.replace(MESSENGER_TEXT.titlePrefix, "").trim();
    return { threadId, title, canSend: resolveFirst(MESSENGER_SELECTORS.composer) !== null };
  }
  function composerName() {
    const label = resolveFirst(MESSENGER_SELECTORS.composer)?.el.getAttribute("aria-label") ?? "";
    return MESSENGER_TEXT.composerTo.exec(label.trim())?.[2]?.trim() ?? null;
  }
  function verifyTarget(payload) {
    const { threadId, expectedTitle } = object({ threadId: string({ min: 1, max: 64 }), expectedTitle: string({ min: 1, max: 200 }) })(payload);
    const id2 = identity();
    if (id2.threadId !== threadId) {
      throw new AppError(ErrorCode.DESTINATION_MISMATCH, `Open thread ${id2.threadId || "-"} \u2260 ${threadId}`, {
        userMessage: "\u0E41\u0E0A\u0E17\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E41\u0E0A\u0E17\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07 (\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07) \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07"
      });
    }
    if (!id2.title) {
      throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Chat title not readable", { userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E0A\u0E17\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07" });
    }
    if (!id2.canSend) throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Composer not found", { detail: { selector: "composer" } });
    const to = composerName();
    if (to !== null && !sameChatName(to, id2.title)) {
      throw new AppError(ErrorCode.DESTINATION_MISMATCH, `Composer addresses "${to}" \u2260 header "${id2.title}"`, {
        userMessage: `\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E23\u0E30\u0E1A\u0E38\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E16\u0E36\u0E07 "${to}" \u0E41\u0E15\u0E48\u0E2B\u0E31\u0E27\u0E41\u0E0A\u0E17\u0E04\u0E37\u0E2D "${id2.title}" \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07`
      });
    }
    if (to === null && !sameChatName(id2.title, expectedTitle)) {
      throw new AppError(ErrorCode.DESTINATION_MISMATCH, `Chat title "${id2.title}" \u2260 verified "${expectedTitle}" (no composer label)`, {
        userMessage: `\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E0A\u0E17\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A ("${id2.title}") \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E44\u0E27\u0E49 ("${expectedTitle}") \u0E41\u0E25\u0E30\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E08\u0E32\u0E01\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07 \u0E43\u0E2B\u0E49\u0E01\u0E14 "\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E0A\u0E17" \u0E43\u0E2B\u0E21\u0E48`
      });
    }
    assertNotRestricted();
    return id2;
  }
  function composer() {
    const c = resolveFirst(MESSENGER_SELECTORS.composer);
    if (!c) throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Composer not found", { detail: { selector: "composer" } });
    return c.el;
  }
  function attachments() {
    return resolveAll(MESSENGER_SELECTORS.attachmentPreview).length;
  }
  function checkClean() {
    const leftover = (composer().innerText ?? "").trim();
    if (leftover || attachments() > 0) {
      throw new AppError(ErrorCode.INPUT_REJECTED, "Composer is not empty", {
        retryable: false,
        userMessage: "\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E1F\u0E25\u0E4C\u0E04\u0E49\u0E32\u0E07\u0E2D\u0E22\u0E39\u0E48 \u2014 \u0E25\u0E1A\u0E2D\u0E2D\u0E01\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A Facebook \u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry (\u0E23\u0E30\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07\u0E1B\u0E19\u0E01\u0E31\u0E19)"
      });
    }
    return { clean: true };
  }
  async function attach(payload, signal) {
    const { transferIds } = object({ transferIds: array(id, { min: 1, max: 10 }) })(payload);
    const files = await Promise.all(transferIds.map((id2) => takeReceived(id2)));
    const input = await waitFor("fileInput", MESSENGER_SELECTORS.fileInput, { timeoutMs: ELEMENT_WAIT_MS, signal, visible: false });
    setInputFiles(input.el, files);
    return { attached: files.length };
  }
  function waitAttached(payload, signal) {
    const { count, sliceMs } = object({ count: number({ int: true, min: 1, max: 10 }), sliceMs: sliceMsValidator })(payload);
    let seen = 0;
    return slice(
      sliceMs,
      signal,
      (timeoutMs, sig) => waitForCondition(
        () => {
          assertNotRestricted();
          seen = attachments();
          return seen >= count ? { attached: seen } : null;
        },
        { timeoutMs, signal: sig, what: "attachments" }
      ),
      () => `\u0E41\u0E19\u0E1A\u0E23\u0E39\u0E1B ${seen}/${count}`
    );
  }
  async function setText(payload) {
    const { text } = object({ text: string({ min: 1, max: 2e4 }) })(payload);
    await replaceText(composer(), text);
    return { set: true };
  }
  function occurrences(probe) {
    if (!probe) return 0;
    const list = resolveFirst(MESSENGER_SELECTORS.messageList)?.el;
    const hay = norm(list?.innerText ?? "");
    let n = 0;
    for (let i = hay.indexOf(probe); i >= 0; i = hay.indexOf(probe, i + probe.length)) n++;
    return n;
  }
  function messageImages() {
    return resolveAll(MESSENGER_SELECTORS.messageImage).length;
  }
  function progressBars() {
    const log = resolveFirst(MESSENGER_SELECTORS.messageList)?.el;
    return log ? log.querySelectorAll("[role='progressbar']").length : 0;
  }
  var sentAt = 0;
  var before = /* @__PURE__ */ new WeakSet();
  var seenOwn = 0;
  var sendMarker = null;
  var CONTENT = "a[href^='/messenger_media'], [aria-roledescription], img[src^='blob:'], video, [dir='auto']";
  function newestContent() {
    const log = resolveFirst(MESSENGER_SELECTORS.messageList)?.el;
    if (!log) return null;
    const all = Array.from(log.querySelectorAll(CONTENT)).filter((el) => {
      if (el.matches("[dir='auto']") && !el.closest("[aria-roledescription]")) {
        const t = norm(el.innerText ?? "");
        if (!t || MESSENGER_TEXT.delivered.test(t) || MESSENGER_TEXT.sending.test(t)) return false;
      }
      return true;
    });
    return all[all.length - 1] ?? null;
  }
  var following = (a, b) => Boolean(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) && !a.contains(b);
  function isMessagePhoto(img) {
    if (img.closest("a[href^='/messenger_media']")) return true;
    if (!img.src.startsWith("blob:")) return false;
    const r = img.getBoundingClientRect();
    return Math.max(r.width, r.height, img.naturalWidth) >= 48;
  }
  function messageContainers() {
    const log = resolveFirst(MESSENGER_SELECTORS.messageList)?.el;
    return log ? Array.from(log.querySelectorAll("[aria-roledescription]")) : [];
  }
  function ownPhotos() {
    const log = resolveFirst(MESSENGER_SELECTORS.messageList)?.el;
    if (!log) return 0;
    let n = 0;
    for (const img of Array.from(log.querySelectorAll("img,video"))) {
      if (img instanceof HTMLImageElement && !isMessagePhoto(img)) continue;
      if (img instanceof HTMLVideoElement && !img.closest("[aria-roledescription],a[href^='/messenger_media']")) continue;
      const container = img.closest("[aria-roledescription]");
      if (img.src.startsWith("blob:") || container && !before.has(container)) n++;
    }
    return n;
  }
  function afterMarker() {
    const log = resolveFirst(MESSENGER_SELECTORS.messageList)?.el;
    if (!log || !sendMarker?.isConnected || !log.contains(sendMarker)) return null;
    const range = document.createRange();
    range.setStartAfter(sendMarker);
    range.setEnd(log, log.childNodes.length);
    const images = Array.from(log.querySelectorAll("img,video")).filter((img) => following(sendMarker, img) && (img instanceof HTMLVideoElement || isMessagePhoto(img))).length;
    return { text: norm(range.toString()), images };
  }
  function send(payload) {
    const { threadId, expectedTitle, probe } = object({
      threadId: string({ min: 1, max: 64 }),
      expectedTitle: string({ min: 1, max: 200 }),
      probe: string({ max: 200 })
    })(payload);
    verifyTarget({ threadId, expectedTitle });
    const clicked = { probeBefore: occurrences(norm(probe)), imagesBefore: messageImages() };
    sendMarker = newestContent();
    sentAt = Date.now();
    before = new WeakSet(messageContainers());
    seenOwn = 0;
    const button = resolveFirst(MESSENGER_SELECTORS.sendButton, { enabled: true });
    if (button) clickElement(button.el);
    else {
      const box = composer();
      box.focus();
      pressEnter(box);
    }
    return clicked;
  }
  function waitSent(payload, signal) {
    const { probe, probeBefore, images, sliceMs, fallbackMs, strictMedia } = object({
      probe: string({ max: 200 }),
      probeBefore: number({ int: true, min: 0 }),
      imagesBefore: number({ int: true, min: 0 }),
      images: number({ int: true, min: 0, max: 10 }),
      sliceMs: sliceMsValidator,
      strictMedia: optional(boolean),
      /** Photos: after this long without "กำลังส่ง", count them as sent (user's rule: N sec per photo). */
      fallbackMs: optional(number({ int: true, min: 0, max: 6e5 }))
    })(payload);
    let how = "";
    const p = norm(probe);
    return slice(
      sliceMs,
      signal,
      (timeoutMs, sig) => waitForCondition(
        () => {
          assertNotRestricted();
          const text = pageText();
          if (MESSENGER_TEXT.sendError.test(text)) {
            throw new AppError(ErrorCode.SEND_FAILED, `Facebook: ${text.match(MESSENGER_TEXT.sendError)?.[0] ?? "send failed"}`);
          }
          const composerEmpty = !(resolveFirst(MESSENGER_SELECTORS.composer)?.el.innerText ?? "").trim() && attachments() === 0;
          const after = afterMarker();
          const textShown = !p || occurrences(p) > probeBefore || Boolean(after?.text.includes(p));
          const statusText = after?.text ?? norm((resolveFirst(MESSENGER_SELECTORS.messageList)?.el.innerText ?? "").slice(-300));
          const sending = MESSENGER_TEXT.sending.test(statusText) || progressBars() > 0;
          seenOwn = Math.max(seenOwn, ownPhotos());
          let imagesShown = images === 0;
          if (!imagesShown && !sending && seenOwn > 0) {
            if (seenOwn >= images) {
              imagesShown = true;
              how = "photos in the chat";
            } else if (!strictMedia && after && MESSENGER_TEXT.delivered.test(after.text)) {
              imagesShown = true;
              how = "delivered status";
            } else if (!strictMedia && fallbackMs && sentAt && Date.now() - sentAt >= fallbackMs) {
              imagesShown = true;
              how = "time per photo";
            }
          }
          return composerEmpty && textShown && imagesShown ? { confirmed: true, ...how ? { how } : {} } : null;
        },
        { timeoutMs, signal: sig, what: "sent message" }
      ),
      () => images ? `\u0E23\u0E2D\u0E23\u0E39\u0E1B\u0E2A\u0E48\u0E07\u0E04\u0E23\u0E1A (${seenOwn}/${images})${fallbackMs && sentAt ? ` \xB7 \u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19 ${Math.max(0, Math.ceil((fallbackMs - (Date.now() - sentAt)) / 1e3))} \u0E27\u0E34` : ""}` : "\u0E23\u0E2D\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17"
    );
  }
  startBridge(MESSENGER_PROVIDER_ID, MESSENGER_BRIDGE_VERSION, {
    ...standardHandlers({ providerId: MESSENGER_PROVIDER_ID, prefix: MESSENGER_PREFIX, version: MESSENGER_BRIDGE_VERSION, detectState, selectors: MESSENGER_SELECTORS }),
    [MESSENGER_CMD.inspect]: () => identity(),
    [MESSENGER_CMD.verifyTarget]: (payload) => verifyTarget(payload),
    [MESSENGER_CMD.checkClean]: () => checkClean(),
    [MESSENGER_CMD.attach]: (payload, ctx) => attach(payload, ctx.signal),
    [MESSENGER_CMD.waitAttached]: (payload, ctx) => waitAttached(payload, ctx.signal),
    [MESSENGER_CMD.setText]: (payload) => setText(payload),
    [MESSENGER_CMD.send]: (payload) => send(payload),
    [MESSENGER_CMD.waitSent]: (payload, ctx) => waitSent(payload, ctx.signal)
  });
})();
