"use strict";
(() => {
  // src/shared/errors.ts
  var ErrorCode = {
    LOGIN_REQUIRED: "LOGIN_REQUIRED",
    CAPTCHA_REQUIRED: "CAPTCHA_REQUIRED",
    PERMISSION_MISSING: "PERMISSION_MISSING",
    SELECTOR_NOT_FOUND: "SELECTOR_NOT_FOUND",
    INPUT_REJECTED: "INPUT_REJECTED",
    PAGE_NOT_READY: "PAGE_NOT_READY",
    WEBSITE_UNAVAILABLE: "WEBSITE_UNAVAILABLE",
    RATE_LIMITED: "RATE_LIMITED",
    QUOTA_EXCEEDED: "QUOTA_EXCEEDED",
    GENERATION_FAILED: "GENERATION_FAILED",
    CONTENT_POLICY_BLOCKED: "CONTENT_POLICY_BLOCKED",
    RESPONSE_PARSE_FAILED: "RESPONSE_PARSE_FAILED",
    TIMEOUT: "TIMEOUT",
    PROGRESS_STALLED: "PROGRESS_STALLED",
    DOWNLOAD_FAILED: "DOWNLOAD_FAILED",
    DOWNLOAD_INTERRUPTED: "DOWNLOAD_INTERRUPTED",
    UPLOAD_FAILED: "UPLOAD_FAILED",
    PUBLISH_UNCONFIRMED: "PUBLISH_UNCONFIRMED",
    SEND_UNCONFIRMED: "SEND_UNCONFIRMED",
    DESTINATION_MISMATCH: "DESTINATION_MISMATCH",
    SEND_FAILED: "SEND_FAILED",
    ACCOUNT_RESTRICTED: "ACCOUNT_RESTRICTED",
    NATIVE_SCHEDULE_UNAVAILABLE: "NATIVE_SCHEDULE_UNAVAILABLE",
    BRIDGE_UNREACHABLE: "BRIDGE_UNREACHABLE",
    TAB_CLOSED: "TAB_CLOSED",
    INTERRUPTED: "INTERRUPTED",
    INVALID_INPUT: "INVALID_INPUT",
    INVALID_STATE: "INVALID_STATE",
    NOT_FOUND: "NOT_FOUND",
    PROVIDER_NOT_CONFIGURED: "PROVIDER_NOT_CONFIGURED",
    LICENSE_REQUIRED: "LICENSE_REQUIRED",
    CANCELLED: "CANCELLED",
    INTERNAL: "INTERNAL"
  };
  var META = {
    LOGIN_REQUIRED: { retryable: false, pause: "LOGIN_REQUIRED", userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 \u2014 \u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    CAPTCHA_REQUIRED: { retryable: false, pause: "CAPTCHA", userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E02\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E15\u0E31\u0E27\u0E15\u0E19 (CAPTCHA) \u2014 \u0E17\u0E33\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    PERMISSION_MISSING: { retryable: false, userMessage: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E40\u0E02\u0E49\u0E32\u0E16\u0E36\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E19\u0E35\u0E49 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    SELECTOR_NOT_FOUND: { retryable: true, userMessage: "\u0E2B\u0E32\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E40\u0E08\u0E2D \u2014 \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u0E25\u0E2D\u0E07\u0E01\u0E14 Diagnose \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    INPUT_REJECTED: { retryable: true, userMessage: "\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E23\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34" },
    PAGE_NOT_READY: { retryable: true, userMessage: "\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E22\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21" },
    WEBSITE_UNAVAILABLE: { retryable: true, userMessage: "\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32" },
    RATE_LIMITED: { retryable: false, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E16\u0E35\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B \u2014 \u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E1E\u0E31\u0E01\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry" },
    QUOTA_EXCEEDED: { retryable: false, userMessage: "\u0E43\u0E0A\u0E49\u0E42\u0E04\u0E27\u0E15\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07" },
    GENERATION_FAILED: { retryable: true, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    CONTENT_POLICY_BLOCKED: { retryable: false, userMessage: "\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E1B\u0E0F\u0E34\u0E40\u0E2A\u0E18 prompt \u0E19\u0E35\u0E49 (\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32) \u2014 \u0E41\u0E01\u0E49 prompt \u0E41\u0E25\u0E49\u0E27 Retry" },
    RESPONSE_PARSE_FAILED: { retryable: true, userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E08\u0E32\u0E01 AI \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07)" },
    TIMEOUT: { retryable: true, userMessage: "\u0E23\u0E2D\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14" },
    PROGRESS_STALLED: { retryable: true, userMessage: "\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E27\u0E32\u0E21\u0E04\u0E37\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B" },
    DOWNLOAD_FAILED: { retryable: true, userMessage: "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    DOWNLOAD_INTERRUPTED: { retryable: true, userMessage: "\u0E01\u0E32\u0E23\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30" },
    UPLOAD_FAILED: { retryable: true, userMessage: "\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    PUBLISH_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E02\u0E36\u0E49\u0E19\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E0B\u0E49\u0E33" },
    SEND_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E0A\u0E17\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33" },
    DESTINATION_MISMATCH: { retryable: false, userMessage: "\u0E41\u0E0A\u0E17\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E44\u0E27\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07" },
    SEND_FAILED: { retryable: false, userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    ACCOUNT_RESTRICTED: { retryable: false, pause: "INTERRUPTED", userMessage: "Facebook \u0E08\u0E33\u0E01\u0E31\u0E14\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E2A\u0E48\u0E07\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u0E15\u0E23\u0E27\u0E08\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A Facebook \u0E41\u0E25\u0E30\u0E23\u0E2D\u0E08\u0E19\u0E02\u0E49\u0E2D\u0E08\u0E33\u0E01\u0E31\u0E14\u0E2B\u0E21\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E15\u0E48\u0E2D" },
    NATIVE_SCHEDULE_UNAVAILABLE: { retryable: false, userMessage: "\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A\u0E02\u0E2D\u0E07 Facebook \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E43\u0E0A\u0E49\u0E15\u0E31\u0E27\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E41\u0E17\u0E19" },
    BRIDGE_UNREACHABLE: { retryable: true, userMessage: "\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D\u0E2A\u0E04\u0E23\u0E34\u0E1B\u0E15\u0E4C\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
    TAB_CLOSED: { retryable: true, userMessage: "\u0E41\u0E17\u0E47\u0E1A\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E16\u0E39\u0E01\u0E1B\u0E34\u0E14\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E17\u0E33\u0E07\u0E32\u0E19" },
    INTERRUPTED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E07\u0E32\u0E19\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30 (browser/\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E23\u0E35\u0E2A\u0E15\u0E32\u0E23\u0E4C\u0E17) \u2014 \u0E15\u0E23\u0E27\u0E08\u0E1C\u0E25\u0E1A\u0E19\u0E40\u0E27\u0E47\u0E1A \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry \u0E2B\u0E23\u0E37\u0E2D Cancel" },
    INVALID_INPUT: { retryable: false, userMessage: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E21\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" },
    INVALID_STATE: { retryable: false, userMessage: "\u0E17\u0E33\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E19\u0E35\u0E49\u0E43\u0E19\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
    NOT_FOUND: { retryable: false, userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E23\u0E30\u0E1A\u0E38" },
    PROVIDER_NOT_CONFIGURED: { retryable: false, userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49 \u2014 \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    LICENSE_REQUIRED: { retryable: false, pause: "LICENSE_REQUIRED", userMessage: "License \u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u2014 \u0E07\u0E32\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E23\u0E34\u0E48\u0E21 \u0E15\u0E23\u0E27\u0E08 License \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    CANCELLED: { retryable: false, userMessage: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27" },
    INTERNAL: { retryable: false, userMessage: "\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E20\u0E32\u0E22\u0E43\u0E19 \u2014 \u0E14\u0E39\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E43\u0E19 Log" }
  };
  var AppError = class extends Error {
    code;
    retryable;
    userMessage;
    detail;
    constructor(code, message, opts = {}) {
      super(message, opts.cause === void 0 ? void 0 : { cause: opts.cause });
      this.name = "AppError";
      this.code = code;
      this.retryable = opts.retryable ?? META[code].retryable;
      this.userMessage = opts.userMessage ?? META[code].userMessage;
      this.detail = opts.detail;
    }
    get pauseReason() {
      return META[this.code].pause;
    }
    toJSON() {
      const json = {
        code: this.code,
        message: this.message,
        userMessage: this.userMessage,
        retryable: this.retryable
      };
      if (this.detail !== void 0) json.detail = this.detail;
      return json;
    }
  };
  function isErrorCode(value) {
    return typeof value === "string" && value in META;
  }
  function toAppError(err, fallback = ErrorCode.INTERNAL) {
    if (err instanceof AppError) return err;
    if (isAppErrorJSON(err)) return fromJSON(err);
    if (err instanceof DOMException && err.name === "AbortError") {
      return new AppError(ErrorCode.CANCELLED, "Operation aborted", { cause: err });
    }
    const message = err instanceof Error ? err.message : String(err);
    return new AppError(fallback, message, { cause: err });
  }
  function isAppErrorJSON(value) {
    if (typeof value !== "object" || value === null) return false;
    const v = value;
    return isErrorCode(v["code"]) && typeof v["message"] === "string";
  }
  function fromJSON(json) {
    const code = isErrorCode(json.code) ? json.code : ErrorCode.INTERNAL;
    return new AppError(code, json.message, {
      userMessage: json.userMessage,
      retryable: json.retryable,
      detail: json.detail
    });
  }

  // src/shared/schema.ts
  function fail(path, expected, value) {
    const got = value === null ? "null" : Array.isArray(value) ? "array" : typeof value;
    throw new AppError(ErrorCode.INVALID_INPUT, `${path || "value"}: expected ${expected}, got ${got}`, {
      detail: { path, expected }
    });
  }
  function string(opts = {}) {
    return (value, path = "") => {
      if (typeof value !== "string") fail(path, "string", value);
      if (opts.min !== void 0 && value.length < opts.min) fail(path, `string length >= ${opts.min}`, value);
      if (opts.max !== void 0 && value.length > opts.max) fail(path, `string length <= ${opts.max}`, value);
      if (opts.pattern && !opts.pattern.test(value)) fail(path, `string matching ${opts.pattern}`, value);
      return value;
    };
  }
  function number(opts = {}) {
    return (value, path = "") => {
      if (typeof value !== "number" || !Number.isFinite(value)) fail(path, "finite number", value);
      if (opts.int && !Number.isInteger(value)) fail(path, "integer", value);
      if (opts.min !== void 0 && value < opts.min) fail(path, `number >= ${opts.min}`, value);
      if (opts.max !== void 0 && value > opts.max) fail(path, `number <= ${opts.max}`, value);
      return value;
    };
  }
  function object(shape) {
    return (value, path = "") => {
      if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
      const src = value;
      const out = {};
      for (const [key, validator] of Object.entries(shape)) {
        const v = validator(src[key], path ? `${path}.${key}` : key);
        if (v !== void 0) out[key] = v;
      }
      return out;
    };
  }
  var id = string({ min: 1, max: 64, pattern: /^[A-Za-z0-9_-]+$/ });

  // src/providers/facebook-story/protocol.ts
  var STORY_PROVIDER = "facebook-story-web";
  var STORY_PREFIX = "facebookStory";
  var STORY_CMD = {
    attach: `${STORY_PREFIX}.attach`,
    preview: `${STORY_PREFIX}.preview`,
    owner: `${STORY_PREFIX}.owner`,
    publish: `${STORY_PREFIX}.publish`,
    observe: `${STORY_PREFIX}.observe`,
    nextCard: `${STORY_PREFIX}.nextCard`
  };

  // src/providers/facebook-story/selectors.ts
  var STORY_SELECTORS = {
    photo: [{ role: "button", name: /^สร้างสตอรี่รูปภาพหรือวิดีโอ$/ }],
    file: [{ css: "input[type='file'][accept*='image']" }],
    preview: [{ css: "[role='region'][aria-label='\u0E20\u0E32\u0E1E\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07']" }],
    image: [{ css: "img" }],
    share: [{ role: "button", name: /^แชร์ไปยังสตอรี่$/ }],
    login: [{ css: "input[name='pass']" }, { css: "#login_form" }]
  };

  // src/shared/async.ts
  function abortError(signal) {
    const reason = signal?.reason;
    if (reason instanceof AppError) return reason;
    return new AppError(ErrorCode.CANCELLED, "Operation cancelled");
  }
  function throwIfAborted(signal) {
    if (signal?.aborted) throw abortError(signal);
  }
  function withTimeout(promise, ms, what, code = ErrorCode.TIMEOUT) {
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new AppError(code, `${what} timed out after ${ms} ms`, { detail: { ms } })), ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
  }

  // src/bridges/bridge-kit/dom.ts
  var POLL_MS = 400;
  var IMPLICIT_ROLE = {
    button: "button,[role='button'],input[type='button'],input[type='submit']",
    textbox: "textarea,input[type='text'],input:not([type]),[contenteditable='true'],[role='textbox']",
    dialog: "[role='dialog'],dialog",
    link: "a[href],[role='link']",
    img: "img,[role='img']",
    checkbox: "input[type='checkbox'],[role='checkbox']",
    menuitem: "[role='menuitem']",
    tab: "[role='tab']",
    alert: "[role='alert'],[role='alertdialog']",
    combobox: "select,[role='combobox']",
    option: "option,[role='option']",
    heading: "h1,h2,h3,h4,h5,h6,[role='heading']"
  };
  function accessibleName(el) {
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.trim();
    const labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      const text = labelledBy.split(/\s+/).map((id2) => el.ownerDocument.getElementById(id2)?.textContent ?? "").join(" ").trim();
      if (text) return text;
    }
    const attr = el.getAttribute("title") ?? el.getAttribute("placeholder") ?? el.getAttribute("alt");
    if (attr) return attr.trim();
    const placeholder = el.getAttribute("data-placeholder");
    if (placeholder) return placeholder.trim();
    return (el.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function queryCandidate(c, root = document) {
    let els;
    if (c.css && c.role) {
      const roleSel = IMPLICIT_ROLE[c.role] ?? `[role='${c.role}']`;
      els = Array.from(root.querySelectorAll(c.css)).filter((e) => e.matches(roleSel));
    } else if (c.css) {
      els = Array.from(root.querySelectorAll(c.css));
    } else if (c.role) {
      els = Array.from(root.querySelectorAll(IMPLICIT_ROLE[c.role] ?? `[role='${c.role}']`));
    } else {
      els = Array.from(root.querySelectorAll("*"));
    }
    const { name, text } = c;
    if (name) els = els.filter((e) => name.test(accessibleName(e)));
    if (text) els = els.filter((e) => text.test((e.textContent ?? "").replace(/\s+/g, " ").trim()));
    return els;
  }
  function isVisible(el) {
    if (!(el instanceof HTMLElement) && !(el instanceof SVGElement)) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    const style = getComputedStyle(el);
    return !(style.visibility === "hidden" || style.display === "none" || Number(style.opacity) === 0);
  }
  function isEnabled(el) {
    if (el.disabled) return false;
    return el.getAttribute("aria-disabled") !== "true";
  }
  function resolveFirst(list, opts = {}) {
    const root = opts.root ?? document;
    for (let i = 0; i < list.length; i++) {
      const candidate = list[i];
      const el = queryCandidate(candidate, root).find(
        (e) => (opts.visible === false || isVisible(e)) && (!opts.enabled || isEnabled(e))
      );
      if (el) return { el, index: i };
    }
    return null;
  }
  function resolveAll(list, opts = {}) {
    const root = opts.root ?? document;
    const seen = /* @__PURE__ */ new Set();
    for (const candidate of list) {
      for (const el of queryCandidate(candidate, root)) {
        if (opts.visible !== false && !isVisible(el)) continue;
        seen.add(el);
      }
    }
    return [...seen];
  }
  function waitForCondition(check, opts) {
    return new Promise((resolve, reject) => {
      throwIfAborted(opts.signal);
      let settled = false;
      const finish = (fn) => {
        if (settled) return;
        settled = true;
        observer.disconnect();
        clearInterval(poll);
        clearTimeout(deadline);
        opts.signal?.removeEventListener("abort", onAbort);
        fn();
      };
      const evaluate = () => {
        try {
          const value = check();
          if (value !== null && value !== void 0 && value !== false) finish(() => resolve(value));
        } catch (err) {
          finish(() => reject(err instanceof Error ? err : new AppError(ErrorCode.INTERNAL, String(err))));
        }
      };
      const observer = new MutationObserver(evaluate);
      observer.observe(opts.observe ?? document, { childList: true, subtree: true, attributes: true, characterData: true });
      const poll = setInterval(evaluate, POLL_MS);
      const deadline = setTimeout(
        () => finish(
          () => reject(opts.onTimeout?.() ?? new AppError(ErrorCode.TIMEOUT, `${opts.what} not reached in ${opts.timeoutMs} ms`))
        ),
        opts.timeoutMs
      );
      const onAbort = () => {
        const reason = opts.signal?.reason;
        finish(() => reject(reason instanceof AppError ? reason : new AppError(ErrorCode.CANCELLED, "Cancelled")));
      };
      opts.signal?.addEventListener("abort", onAbort, { once: true });
      evaluate();
    });
  }
  function diagnoseSelectors(map, keys = Object.keys(map)) {
    return keys.map((key) => {
      const list = map[key] ?? [];
      const found = resolveFirst(list, { visible: false });
      return { key, found: found !== null, matchedIndex: found?.index ?? -1, candidates: list.length };
    });
  }

  // src/bridges/bridge-kit/file-input.ts
  function setInputFiles(input, files) {
    if (input.type !== "file") throw new AppError(ErrorCode.UPLOAD_FAILED, "Target is not a file input");
    const data = new DataTransfer();
    for (const f of files) data.items.add(f);
    input.files = data.files;
    if ((input.files?.length ?? 0) !== files.length) {
      throw new AppError(ErrorCode.UPLOAD_FAILED, "File input rejected the files");
    }
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 1;
  var counter = 0;
  function newRequestId() {
    counter = (counter + 1) % 1e6;
    return `${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }
  function envelope(type, payload, id2 = newRequestId()) {
    return { v: PROTOCOL_VERSION, id: id2, type, payload };
  }
  function isEnvelope(value) {
    if (typeof value !== "object" || value === null) return false;
    const v = value;
    return v["v"] === PROTOCOL_VERSION && typeof v["id"] === "string" && typeof v["type"] === "string";
  }
  function ok(data) {
    return { ok: true, data };
  }
  function failure(err) {
    return { ok: false, error: toAppError(err).toJSON() };
  }
  var BRIDGE_PROGRESS = "bridge.progress";
  var BRIDGE_CANCEL = "bridge.cancel";
  var PORT_TRANSFER_TO_EXTENSION = "acf-transfer-in:";
  var PORT_TRANSFER_TO_PAGE = "acf-transfer-out:";

  // src/bridges/bridge-kit/server.ts
  function extensionAlive() {
    try {
      return typeof chrome !== "undefined" && Boolean(chrome.runtime?.id);
    } catch {
      return false;
    }
  }
  function startBridge(providerId, version, handlers) {
    const registry = globalThis.__acfBridges ??= {};
    registry[providerId]?.dispose();
    const inflight = /* @__PURE__ */ new Map();
    const listener = (message, sender, sendResponse) => {
      if (!isEnvelope(message) || sender.id !== chrome.runtime.id || sender.tab || sender.url?.startsWith("http")) return false;
      const env = message;
      if (env.type === BRIDGE_CANCEL) {
        const raw = env.payload?.["requestId"];
        const requestId = typeof raw === "string" ? raw : "";
        inflight.get(requestId)?.abort(new AppError(ErrorCode.CANCELLED, "Cancelled by extension"));
        return false;
      }
      const handler = handlers[env.type];
      if (!handler) return false;
      const controller = new AbortController();
      inflight.set(env.id, controller);
      const ctx = {
        signal: controller.signal,
        requestId: env.id,
        progress: (text, data) => {
          if (!extensionAlive()) return;
          const payload = { requestId: env.id, message: text };
          if (data) payload.data = data;
          chrome.runtime.sendMessage(envelope(BRIDGE_PROGRESS, payload)).catch(() => void 0);
        }
      };
      Promise.resolve().then(() => handler(env.payload ?? {}, ctx)).then(
        (data) => sendResponse(ok(data ?? null)),
        (err) => sendResponse(failure(err))
      ).finally(() => inflight.delete(env.id));
      return true;
    };
    chrome.runtime.onMessage.addListener(listener);
    registry[providerId] = {
      version,
      dispose: () => {
        for (const c of inflight.values()) c.abort(new AppError(ErrorCode.CANCELLED, "Bridge replaced"));
        inflight.clear();
        try {
          chrome.runtime.onMessage.removeListener(listener);
        } catch {
        }
      }
    };
  }

  // src/shared/hash.ts
  async function sha256Hex(data) {
    const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
  }

  // src/shared/transfer-codec.ts
  var TRANSFER_CHUNK_BYTES = 1024 * 1024;
  var TRANSFER_MAX_BYTES = 1024 * 1024 * 1024;
  function bytesToBase64(bytes) {
    let binary = "";
    const step = 32768;
    for (let i = 0; i < bytes.length; i += step) {
      binary += String.fromCharCode(...bytes.subarray(i, i + step));
    }
    return btoa(binary);
  }
  function base64ToBytes(b64) {
    const binary = atob(b64);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }
  async function sendBlobOverPort(port, blob, name) {
    if (blob.size > TRANSFER_MAX_BYTES) {
      throw new AppError(ErrorCode.UPLOAD_FAILED, `File too large to transfer (${blob.size} bytes)`);
    }
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const chunks = Math.max(1, Math.ceil(bytes.length / TRANSFER_CHUNK_BYTES));
    const ack = new Promise((resolve, reject) => {
      port.onMessage.addListener((msg) => {
        if (msg.k !== "ack") return;
        if (msg.ok) resolve();
        else reject(new AppError(ErrorCode.UPLOAD_FAILED, `Receiver rejected transfer: ${msg.error}`));
      });
      port.onDisconnect.addListener(
        () => reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer port disconnected before ack"))
      );
    });
    port.postMessage({ k: "meta", size: bytes.length, mime: blob.type, name, chunks });
    for (let i = 0; i < chunks; i++) {
      const slice2 = bytes.subarray(i * TRANSFER_CHUNK_BYTES, (i + 1) * TRANSFER_CHUNK_BYTES);
      port.postMessage({ k: "chunk", i, b64: bytesToBase64(slice2) });
    }
    port.postMessage({ k: "end", sha256: await sha256Hex(bytes) });
    await ack;
  }
  function receiveBlobFromPort(port) {
    return new Promise((resolve, reject) => {
      let meta = null;
      const parts = [];
      const fail2 = (error) => {
        try {
          port.postMessage({ k: "ack", ok: false, error });
        } catch {
        }
        reject(new AppError(ErrorCode.UPLOAD_FAILED, error));
      };
      port.onDisconnect.addListener(() => {
        if (!meta || parts.length < meta.chunks) reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer interrupted"));
      });
      port.onMessage.addListener((msg) => {
        if (msg.k === "meta") {
          if (msg.size > TRANSFER_MAX_BYTES) return fail2("file too large");
          meta = msg;
          return;
        }
        if (msg.k === "chunk") {
          if (!meta || msg.i !== parts.length) return fail2(`unexpected chunk ${msg.i}`);
          parts.push(base64ToBytes(msg.b64));
          return;
        }
        if (msg.k === "end") {
          const m = meta;
          if (!m || parts.length !== m.chunks) return fail2("missing chunks");
          const file = new File(parts, m.name, { type: m.mime });
          void file.arrayBuffer().then((buf) => sha256Hex(buf)).then((hash) => {
            if (hash !== msg.sha256) return fail2("checksum mismatch");
            port.postMessage({ k: "ack", ok: true });
            resolve(file);
          }, (err) => fail2(String(err)));
        }
      });
    });
  }

  // src/bridges/bridge-kit/transfer.ts
  async function sendBlobToExtension(transferId, blob, name, timeoutMs) {
    const port = chrome.runtime.connect({ name: `${PORT_TRANSFER_TO_EXTENSION}${transferId}` });
    try {
      await withTimeout(sendBlobOverPort(port, blob, name), timeoutMs, "Transfer to extension", ErrorCode.DOWNLOAD_FAILED);
    } finally {
      port.disconnect();
    }
  }
  function expectFileFromExtension(transferId, timeoutMs) {
    const expected = `${PORT_TRANSFER_TO_PAGE}${transferId}`;
    let listener = null;
    const file = new Promise((resolve, reject) => {
      listener = (port) => {
        if (port.name !== expected) return;
        if (port.sender?.id !== chrome.runtime.id) {
          port.disconnect();
          reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer from unexpected sender"));
          return;
        }
        receiveBlobFromPort(port).then(resolve, reject);
      };
      chrome.runtime.onConnect.addListener(listener);
    });
    return withTimeout(file, timeoutMs, "Transfer from extension", ErrorCode.UPLOAD_FAILED).finally(() => {
      if (listener) chrome.runtime.onConnect.removeListener(listener);
    });
  }
  async function fetchInPage(url, signal) {
    const res = await fetch(url, { credentials: "include", ...signal ? { signal } : {} });
    if (!res.ok) throw new AppError(ErrorCode.DOWNLOAD_FAILED, `HTTP ${res.status} for media`, { detail: { status: res.status } });
    return res.blob();
  }
  var pendingReceives = /* @__PURE__ */ new Map();
  function prepareReceive(transferId, timeoutMs) {
    const file = expectFileFromExtension(transferId, timeoutMs);
    file.catch(() => void 0);
    pendingReceives.set(transferId, file);
  }
  async function takeReceived(transferId) {
    const file = pendingReceives.get(transferId);
    if (!file) throw new AppError(ErrorCode.UPLOAD_FAILED, `No transfer prepared for ${transferId}`);
    try {
      return await file;
    } finally {
      pendingReceives.delete(transferId);
    }
  }

  // src/bridges/bridge-kit/standard.ts
  async function slice(sliceMs, signal, wait, progress) {
    try {
      return { done: true, result: await wait(sliceMs, signal) };
    } catch (err) {
      if (err instanceof AppError && (err.code === ErrorCode.TIMEOUT || err.code === ErrorCode.SELECTOR_NOT_FOUND)) {
        const out = { done: false };
        const p = progress?.();
        if (p) out.progress = p;
        return out;
      }
      throw err;
    }
  }
  var CAPTCHA_TITLE = /just a moment|attention required|security check|ตรวจสอบความปลอดภัย/i;
  var CAPTCHA_SELECTORS = [
    { css: "#challenge-form" },
    { css: "iframe[src*='challenges.cloudflare.com']" },
    { css: "iframe[src*='recaptcha']" },
    { css: "iframe[src*='hcaptcha']" },
    { css: "[id*='captcha' i]" }
  ];
  function captchaVisible() {
    return CAPTCHA_TITLE.test(document.title) || resolveFirst(CAPTCHA_SELECTORS) !== null;
  }
  function describePage(selectors) {
    const parts = Object.keys(selectors).slice(0, 6).map((key) => {
      const list = selectors[key] ?? [];
      if (resolveFirst(list)) return `${key}=visible`;
      if (resolveFirst(list, { visible: false })) return `${key}=hidden`;
      return `${key}=missing`;
    });
    return `page not ready [${document.visibilityState}, captcha=${captchaVisible()}] ${parts.join(" ")}`;
  }
  var sliceMsValidator = number({ int: true, min: 100, max: 6e4 });
  function standardHandlers(opts) {
    const { prefix } = opts;
    return {
      [`${prefix}.ping`]: () => ({
        providerId: opts.providerId,
        version: opts.version,
        url: location.href,
        state: opts.detectState()
      }),
      [`${prefix}.waitReady`]: (payload, ctx) => {
        const { sliceMs } = object({ sliceMs: sliceMsValidator })(payload);
        return slice(
          sliceMs,
          ctx.signal,
          (timeoutMs, signal) => waitForCondition(
            () => {
              const state = opts.detectState();
              return state === "loading" ? null : state;
            },
            { timeoutMs, signal, what: "page ready" }
          ),
          () => describePage(opts.selectors)
        );
      },
      [`${prefix}.diagnose`]: () => diagnoseSelectors(opts.selectors),
      [`${prefix}.prepareReceive`]: (payload) => {
        const { transferId, timeoutMs } = object({
          transferId: id,
          timeoutMs: number({ int: true, min: 1e3, max: 36e5 })
        })(payload);
        prepareReceive(transferId, timeoutMs);
        return { prepared: true };
      },
      [`${prefix}.fetchMedia`]: async (payload, ctx) => {
        const { src, transferId, timeoutMs } = object({
          src: string({ min: 1, max: 8e3, pattern: /^(https:|blob:)/ }),
          transferId: id,
          timeoutMs: number({ int: true, min: 1e3, max: 36e5 })
        })(payload);
        const blob = await fetchInPage(src, ctx.signal);
        await sendBlobToExtension(transferId, blob, "media", timeoutMs);
        return { size: blob.size, mime: blob.type };
      }
    };
  }

  // src/bridges/facebook-story-bridge.ts
  var attached = false;
  var previewWasReady = false;
  var publishClicked = false;
  function ownerName() {
    assertRoute();
    const nav = document.querySelector('[role="navigation"][aria-label="\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E01\u0E32\u0E23\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E15\u0E2D\u0E23\u0E35\u0E48"]');
    const heading = nav?.querySelector('h1,[role="heading"]')?.textContent ?? "";
    const name = (nav?.textContent ?? "").replace(heading, "").trim();
    if (!nav || !isVisible(nav) || !name || name.length > 100 || resolveFirst(STORY_SELECTORS.preview)) {
      throw new AppError(ErrorCode.INVALID_STATE, "Story owner unavailable or draft open", { userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E0A\u0E37\u0E48\u0E2D\u0E40\u0E08\u0E49\u0E32\u0E02\u0E2D\u0E07 Story \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E21\u0E35\u0E23\u0E48\u0E32\u0E07\u0E04\u0E49\u0E32\u0E07\u0E2D\u0E22\u0E39\u0E48 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E2B\u0E23\u0E37\u0E2D\u0E17\u0E34\u0E49\u0E07\u0E23\u0E48\u0E32\u0E07\u0E43\u0E19 Facebook \u0E01\u0E48\u0E2D\u0E19" });
    }
    return name;
  }
  function observe(owner) {
    if (!/^\/stories\/(?!create(?:\/|$))/.test(location.pathname)) return null;
    const roots = Array.from(document.querySelectorAll('[role="dialog"],main,[role="main"]')).filter((el) => isVisible(el) && el.getBoundingClientRect().width > 400 && !el.getAttribute("aria-label"));
    const root = roots.find((el) => Array.from(el.querySelectorAll('[aria-label="\u0E2B\u0E22\u0E38\u0E14\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27"],[aria-label="\u0E40\u0E25\u0E48\u0E19"]')).some(isVisible));
    if (!root) return null;
    const links = Array.from(root.querySelectorAll("a[href]")).filter((el) => isVisible(el) && el.textContent?.trim() === owner);
    if (links.length !== 1) return null;
    const controls = Array.from(root.querySelectorAll('[aria-label="\u0E2B\u0E22\u0E38\u0E14\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27"],[aria-label="\u0E40\u0E25\u0E48\u0E19"]')).filter(isVisible);
    if (controls.length !== 1) return null;
    const largeMedia = (el) => {
      const r = el.getBoundingClientRect();
      return isVisible(el) && r.width > 200 && r.height > 250;
    };
    let card = links[0].parentElement;
    while (card && card !== root) {
      if (card.contains(controls[0]) && Array.from(card.querySelectorAll("img,image,video")).some(largeMedia)) break;
      card = card.parentElement;
    }
    if (!card || card === root || !isVisible(card)) return null;
    const pause = Array.from(card.querySelectorAll('[aria-label="\u0E2B\u0E22\u0E38\u0E14\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27"]')).filter(isVisible);
    if (pause.length === 1) pause[0].click();
    const media = Array.from(card.querySelectorAll("img,image")).filter(largeMedia);
    const src = media.length === 1 ? media[0].getAttribute("src") ?? media[0].getAttribute("href") ?? media[0].getAttribute("xlink:href") : null;
    const fresh = Array.from(card.querySelectorAll("abbr")).filter(isVisible).some((el) => /^(เมื่อสักครู่|เมื่อสักครู่นี้|เมื่อกี้|just now|a few seconds ago|\d+\s*วินาที(?:ที่แล้ว)?|\d+\s*seconds? ago)$/i.test((el.getAttribute("aria-label") ?? el.textContent ?? "").trim()));
    const next = Array.from(root.querySelectorAll('[aria-label="\u0E01\u0E32\u0E23\u0E4C\u0E14\u0E16\u0E31\u0E14\u0E44\u0E1B"]')).filter(isVisible);
    return { src, fresh, next: next.length === 1 };
  }
  function assertRoute() {
    if (location.origin !== "https://www.facebook.com" || !/^\/stories\/create\/?$/.test(location.pathname)) {
      throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Not the Story creator", { userMessage: "\u0E2B\u0E19\u0E49\u0E32 Facebook \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E2B\u0E19\u0E49\u0E32\u0E2A\u0E23\u0E49\u0E32\u0E07 Story \u2014 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E23\u0E39\u0E1B" });
    }
  }
  startBridge(STORY_PROVIDER, "1", {
    ...standardHandlers({
      providerId: STORY_PROVIDER,
      prefix: STORY_PREFIX,
      version: "1",
      selectors: STORY_SELECTORS,
      detectState: () => {
        if (captchaVisible() || location.pathname.includes("/checkpoint/")) return "captcha";
        if (resolveFirst(STORY_SELECTORS.login)) return "login";
        return resolveFirst(STORY_SELECTORS.photo) || resolveFirst(STORY_SELECTORS.preview) || resolveFirst(STORY_SELECTORS.share) ? "ready" : "loading";
      }
    }),
    [STORY_CMD.owner]: () => ({ owner: ownerName() }),
    [STORY_CMD.attach]: async (payload) => {
      assertRoute();
      if (attached && !previewWasReady || resolveFirst(STORY_SELECTORS.preview) || resolveFirst(STORY_SELECTORS.share)) {
        throw new AppError(ErrorCode.INVALID_STATE, "Story draft already open", { userMessage: "\u0E40\u0E04\u0E22\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21 Story \u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E19\u0E35\u0E49\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E25\u0E30\u0E41\u0E0A\u0E23\u0E4C\u0E2B\u0E23\u0E37\u0E2D\u0E17\u0E34\u0E49\u0E07\u0E23\u0E48\u0E32\u0E07\u0E43\u0E19 Facebook \u0E01\u0E48\u0E2D\u0E19 \u0E16\u0E49\u0E32\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E48\u0E32\u0E07\u0E41\u0E15\u0E48\u0E22\u0E31\u0E07\u0E15\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48 \u0E43\u0E2B\u0E49\u0E1B\u0E34\u0E14\u0E41\u0E17\u0E47\u0E1A Story \u0E41\u0E25\u0E49\u0E27\u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48" });
      }
      const { transferId } = object({ transferId: id })(payload);
      const photo = resolveAll(STORY_SELECTORS.photo);
      const inputs = resolveAll(STORY_SELECTORS.file, { visible: false });
      if (photo.length !== 1 || inputs.length !== 1) {
        throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Story uploader is missing or ambiguous", { userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E0A\u0E48\u0E2D\u0E07\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E23\u0E39\u0E1B Story \u0E17\u0E35\u0E48\u0E41\u0E19\u0E48\u0E19\u0E2D\u0E19 \u2014 Facebook UI \u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19" });
      }
      const file = await takeReceived(transferId);
      if (!/^image\/(png|jpeg|webp)$/.test(file.type)) throw new AppError(ErrorCode.INVALID_INPUT, "Story requires one supported photo");
      attached = true;
      previewWasReady = false;
      publishClicked = false;
      setInputFiles(inputs[0], [file]);
      return { attached: 1 };
    },
    [STORY_CMD.preview]: (payload, ctx) => {
      assertRoute();
      const { sliceMs } = object({ sliceMs: sliceMsValidator })(payload);
      if (!attached) throw new AppError(ErrorCode.INVALID_STATE, "No photo prepared by this bridge");
      return slice(sliceMs, ctx.signal, (timeoutMs, signal) => waitForCondition(() => {
        assertRoute();
        const region = resolveFirst(STORY_SELECTORS.preview);
        if (!region || !resolveFirst(STORY_SELECTORS.share, { enabled: true })) return null;
        const images = resolveAll(STORY_SELECTORS.image, { root: region.el });
        if (images.length !== 1 || !images[0].complete || images[0].naturalWidth <= 0) return null;
        const source = new URL(images[0].currentSrc || images[0].src);
        if (!(source.protocol === "blob:" && source.origin === location.origin) && !(source.protocol === "https:" && source.hostname.endsWith(".fbcdn.net"))) return null;
        previewWasReady = true;
        return { ready: true, published: false };
      }, { timeoutMs, signal, what: "Story photo preview" }), () => "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E23\u0E39\u0E1B Story \u2014 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48");
    },
    [STORY_CMD.publish]: (payload) => {
      const { owner } = object({ owner: string({ min: 1, max: 100 }) })(payload);
      assertRoute();
      const nav = document.querySelector('[role="navigation"][aria-label="\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E01\u0E32\u0E23\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E15\u0E2D\u0E23\u0E35\u0E48"]');
      const ownerVisible = nav && Array.from(nav.querySelectorAll("*")).some((el) => isVisible(el) && el.textContent?.trim() === owner);
      const shares = resolveAll(STORY_SELECTORS.share, { enabled: true });
      if (!attached || !previewWasReady || publishClicked || !ownerVisible || shares.length !== 1) {
        throw new AppError(ErrorCode.INVALID_STATE, "Story publish guard refused", { userMessage: "\u0E23\u0E39\u0E1B \u0E1A\u0E31\u0E0D\u0E0A\u0E35 \u0E2B\u0E23\u0E37\u0E2D\u0E1B\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E23\u0E4C\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E0A\u0E38\u0E14\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E01\u0E14\u0E41\u0E0A\u0E23\u0E4C\u0E0B\u0E49\u0E33" });
      }
      publishClicked = true;
      shares[0].click();
      return { clicked: true };
    },
    [STORY_CMD.observe]: (payload) => {
      const { owner } = object({ owner: string({ min: 1, max: 100 }) })(payload);
      return observe(owner);
    },
    [STORY_CMD.nextCard]: (payload) => {
      const { owner } = object({ owner: string({ min: 1, max: 100 }) })(payload);
      if (!observe(owner)?.next) return { moved: false };
      const next = Array.from(document.querySelectorAll('[role="dialog"] [aria-label="\u0E01\u0E32\u0E23\u0E4C\u0E14\u0E16\u0E31\u0E14\u0E44\u0E1B"],main [aria-label="\u0E01\u0E32\u0E23\u0E4C\u0E14\u0E16\u0E31\u0E14\u0E44\u0E1B"],[role="main"] [aria-label="\u0E01\u0E32\u0E23\u0E4C\u0E14\u0E16\u0E31\u0E14\u0E44\u0E1B"]')).filter(isVisible);
      if (next.length !== 1) return { moved: false };
      next[0].click();
      return { moved: true };
    }
  });
})();
