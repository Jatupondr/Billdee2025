// src/shared/errors.ts
var ErrorCode = {
  LOGIN_REQUIRED: "LOGIN_REQUIRED",
  CAPTCHA_REQUIRED: "CAPTCHA_REQUIRED",
  PERMISSION_MISSING: "PERMISSION_MISSING",
  SELECTOR_NOT_FOUND: "SELECTOR_NOT_FOUND",
  INPUT_REJECTED: "INPUT_REJECTED",
  PAGE_NOT_READY: "PAGE_NOT_READY",
  WEBSITE_UNAVAILABLE: "WEBSITE_UNAVAILABLE",
  RATE_LIMITED: "RATE_LIMITED",
  QUOTA_EXCEEDED: "QUOTA_EXCEEDED",
  GENERATION_FAILED: "GENERATION_FAILED",
  CONTENT_POLICY_BLOCKED: "CONTENT_POLICY_BLOCKED",
  RESPONSE_PARSE_FAILED: "RESPONSE_PARSE_FAILED",
  TIMEOUT: "TIMEOUT",
  PROGRESS_STALLED: "PROGRESS_STALLED",
  DOWNLOAD_FAILED: "DOWNLOAD_FAILED",
  DOWNLOAD_INTERRUPTED: "DOWNLOAD_INTERRUPTED",
  UPLOAD_FAILED: "UPLOAD_FAILED",
  PUBLISH_UNCONFIRMED: "PUBLISH_UNCONFIRMED",
  SEND_UNCONFIRMED: "SEND_UNCONFIRMED",
  DESTINATION_MISMATCH: "DESTINATION_MISMATCH",
  SEND_FAILED: "SEND_FAILED",
  ACCOUNT_RESTRICTED: "ACCOUNT_RESTRICTED",
  NATIVE_SCHEDULE_UNAVAILABLE: "NATIVE_SCHEDULE_UNAVAILABLE",
  BRIDGE_UNREACHABLE: "BRIDGE_UNREACHABLE",
  TAB_CLOSED: "TAB_CLOSED",
  INTERRUPTED: "INTERRUPTED",
  INVALID_INPUT: "INVALID_INPUT",
  INVALID_STATE: "INVALID_STATE",
  NOT_FOUND: "NOT_FOUND",
  PROVIDER_NOT_CONFIGURED: "PROVIDER_NOT_CONFIGURED",
  LICENSE_REQUIRED: "LICENSE_REQUIRED",
  CANCELLED: "CANCELLED",
  INTERNAL: "INTERNAL"
};
var META = {
  LOGIN_REQUIRED: { retryable: false, pause: "LOGIN_REQUIRED", userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 \u2014 \u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
  CAPTCHA_REQUIRED: { retryable: false, pause: "CAPTCHA", userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E02\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E15\u0E31\u0E27\u0E15\u0E19 (CAPTCHA) \u2014 \u0E17\u0E33\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
  PERMISSION_MISSING: { retryable: false, userMessage: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E40\u0E02\u0E49\u0E32\u0E16\u0E36\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E19\u0E35\u0E49 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
  SELECTOR_NOT_FOUND: { retryable: true, userMessage: "\u0E2B\u0E32\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E40\u0E08\u0E2D \u2014 \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u0E25\u0E2D\u0E07\u0E01\u0E14 Diagnose \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
  INPUT_REJECTED: { retryable: true, userMessage: "\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E23\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34" },
  PAGE_NOT_READY: { retryable: true, userMessage: "\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E22\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21" },
  WEBSITE_UNAVAILABLE: { retryable: true, userMessage: "\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32" },
  RATE_LIMITED: { retryable: false, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E16\u0E35\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B \u2014 \u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E1E\u0E31\u0E01\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry" },
  QUOTA_EXCEEDED: { retryable: false, userMessage: "\u0E43\u0E0A\u0E49\u0E42\u0E04\u0E27\u0E15\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07" },
  GENERATION_FAILED: { retryable: true, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  CONTENT_POLICY_BLOCKED: { retryable: false, userMessage: "\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E1B\u0E0F\u0E34\u0E40\u0E2A\u0E18 prompt \u0E19\u0E35\u0E49 (\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32) \u2014 \u0E41\u0E01\u0E49 prompt \u0E41\u0E25\u0E49\u0E27 Retry" },
  RESPONSE_PARSE_FAILED: { retryable: true, userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E08\u0E32\u0E01 AI \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07)" },
  TIMEOUT: { retryable: true, userMessage: "\u0E23\u0E2D\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14" },
  PROGRESS_STALLED: { retryable: true, userMessage: "\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E27\u0E32\u0E21\u0E04\u0E37\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B" },
  DOWNLOAD_FAILED: { retryable: true, userMessage: "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  DOWNLOAD_INTERRUPTED: { retryable: true, userMessage: "\u0E01\u0E32\u0E23\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30" },
  UPLOAD_FAILED: { retryable: true, userMessage: "\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  PUBLISH_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E02\u0E36\u0E49\u0E19\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E0B\u0E49\u0E33" },
  SEND_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E0A\u0E17\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33" },
  DESTINATION_MISMATCH: { retryable: false, userMessage: "\u0E41\u0E0A\u0E17\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E44\u0E27\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07" },
  SEND_FAILED: { retryable: false, userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  ACCOUNT_RESTRICTED: { retryable: false, pause: "INTERRUPTED", userMessage: "Facebook \u0E08\u0E33\u0E01\u0E31\u0E14\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E2A\u0E48\u0E07\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u0E15\u0E23\u0E27\u0E08\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A Facebook \u0E41\u0E25\u0E30\u0E23\u0E2D\u0E08\u0E19\u0E02\u0E49\u0E2D\u0E08\u0E33\u0E01\u0E31\u0E14\u0E2B\u0E21\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E15\u0E48\u0E2D" },
  NATIVE_SCHEDULE_UNAVAILABLE: { retryable: false, userMessage: "\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A\u0E02\u0E2D\u0E07 Facebook \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E43\u0E0A\u0E49\u0E15\u0E31\u0E27\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E41\u0E17\u0E19" },
  BRIDGE_UNREACHABLE: { retryable: true, userMessage: "\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D\u0E2A\u0E04\u0E23\u0E34\u0E1B\u0E15\u0E4C\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
  TAB_CLOSED: { retryable: true, userMessage: "\u0E41\u0E17\u0E47\u0E1A\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E16\u0E39\u0E01\u0E1B\u0E34\u0E14\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E17\u0E33\u0E07\u0E32\u0E19" },
  INTERRUPTED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E07\u0E32\u0E19\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30 (browser/\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E23\u0E35\u0E2A\u0E15\u0E32\u0E23\u0E4C\u0E17) \u2014 \u0E15\u0E23\u0E27\u0E08\u0E1C\u0E25\u0E1A\u0E19\u0E40\u0E27\u0E47\u0E1A \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry \u0E2B\u0E23\u0E37\u0E2D Cancel" },
  INVALID_INPUT: { retryable: false, userMessage: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E21\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" },
  INVALID_STATE: { retryable: false, userMessage: "\u0E17\u0E33\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E19\u0E35\u0E49\u0E43\u0E19\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
  NOT_FOUND: { retryable: false, userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E23\u0E30\u0E1A\u0E38" },
  PROVIDER_NOT_CONFIGURED: { retryable: false, userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49 \u2014 \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
  LICENSE_REQUIRED: { retryable: false, pause: "LICENSE_REQUIRED", userMessage: "License \u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u2014 \u0E07\u0E32\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E23\u0E34\u0E48\u0E21 \u0E15\u0E23\u0E27\u0E08 License \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
  CANCELLED: { retryable: false, userMessage: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27" },
  INTERNAL: { retryable: false, userMessage: "\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E20\u0E32\u0E22\u0E43\u0E19 \u2014 \u0E14\u0E39\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E43\u0E19 Log" }
};
var AppError = class extends Error {
  code;
  retryable;
  userMessage;
  detail;
  constructor(code, message, opts = {}) {
    super(message, opts.cause === void 0 ? void 0 : { cause: opts.cause });
    this.name = "AppError";
    this.code = code;
    this.retryable = opts.retryable ?? META[code].retryable;
    this.userMessage = opts.userMessage ?? META[code].userMessage;
    this.detail = opts.detail;
  }
  get pauseReason() {
    return META[this.code].pause;
  }
  toJSON() {
    const json = {
      code: this.code,
      message: this.message,
      userMessage: this.userMessage,
      retryable: this.retryable
    };
    if (this.detail !== void 0) json.detail = this.detail;
    return json;
  }
};
function isErrorCode(value) {
  return typeof value === "string" && value in META;
}
function toAppError(err, fallback = ErrorCode.INTERNAL) {
  if (err instanceof AppError) return err;
  if (isAppErrorJSON(err)) return fromJSON(err);
  if (err instanceof DOMException && err.name === "AbortError") {
    return new AppError(ErrorCode.CANCELLED, "Operation aborted", { cause: err });
  }
  const message = err instanceof Error ? err.message : String(err);
  return new AppError(fallback, message, { cause: err });
}
function isAppErrorJSON(value) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  return isErrorCode(v["code"]) && typeof v["message"] === "string";
}
function fromJSON(json) {
  const code = isErrorCode(json.code) ? json.code : ErrorCode.INTERNAL;
  return new AppError(code, json.message, {
    userMessage: json.userMessage,
    retryable: json.retryable,
    detail: json.detail
  });
}

// src/shared/protocol.ts
var PROTOCOL_VERSION = 1;
var counter = 0;
function newRequestId() {
  counter = (counter + 1) % 1e6;
  return `${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function envelope(type, payload, id2 = newRequestId()) {
  return { v: PROTOCOL_VERSION, id: id2, type, payload };
}
function isResult(value) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  if (v["ok"] === true) return "data" in v;
  return v["ok"] === false && isAppErrorJSON(v["error"]);
}
function unwrap(result, context) {
  if (!isResult(result)) {
    throw new AppError(ErrorCode.INTERNAL, `${context}: malformed response`, { detail: { result } });
  }
  if (result.ok) return result.data;
  throw fromJSON(result.error);
}
var PORT_UI_EVENTS = "acf-ui-events";

// src/ui-shared/dom.ts
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === void 0 || value === null || value === false) continue;
    if (key.startsWith("on") && typeof value === "function") {
      el.addEventListener(key.slice(2).toLowerCase(), value);
    } else if (key === "class") {
      el.className = String(value);
    } else if (key in el && typeof value !== "string") {
      el[key] = value;
    } else {
      el.setAttribute(key, value === true ? "" : String(value));
    }
  }
  append(el, ...children);
  return el;
}
function append(parent, ...children) {
  for (const c of children) {
    if (c === null || c === void 0 || c === false) continue;
    parent.append(typeof c === "string" ? document.createTextNode(c) : c);
  }
}
function fill(el, ...children) {
  el.replaceChildren();
  append(el, ...children);
}
function byId(id2) {
  const el = document.getElementById(id2);
  if (!el) throw new Error(`#${id2} missing in page`);
  return el;
}
function toast(message, kind = "info") {
  const host = document.getElementById("toast") ?? document.body.appendChild(h("div", { id: "toast" }));
  const item = h("div", { class: `toast toast-${kind}`, role: kind === "error" ? "alert" : "status" }, message);
  host.append(item);
  setTimeout(() => item.remove(), kind === "error" ? 8e3 : 3500);
}
function ask(message, opts = {}) {
  return new Promise((resolve) => {
    const field = opts.input ? h("input", { type: "text", class: "ask-input" }) : null;
    const dialog = h("dialog", { class: "ask" });
    const done = (value) => {
      dialog.close();
      dialog.remove();
      resolve(value);
    };
    append(
      dialog,
      h("p", {}, message),
      field,
      h(
        "div",
        { class: "row" },
        h("button", { class: "primary", "data-ask": "ok", onclick: () => done(field ? field.value : "ok") }, opts.okLabel ?? "\u0E15\u0E01\u0E25\u0E07"),
        h("button", { "data-ask": "cancel", onclick: () => done(null) }, "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01")
      )
    );
    dialog.addEventListener("cancel", () => done(null));
    document.body.append(dialog);
    dialog.showModal();
    (field ?? dialog.querySelector("[data-ask='ok']"))?.focus();
  });
}

// src/ui-shared/client.ts
async function call(type, payload) {
  const response = await chrome.runtime.sendMessage(envelope(type, payload));
  return unwrap(response, type);
}
async function tryCall(type, payload) {
  try {
    return await call(type, payload);
  } catch (err) {
    const e = err instanceof AppError ? err : toAppError(err);
    toast(e.userMessage, "error");
    return void 0;
  }
}
function subscribe(onEvent) {
  const connect = () => {
    const port = chrome.runtime.connect({ name: PORT_UI_EVENTS });
    port.onMessage.addListener((msg) => onEvent(msg));
    port.onDisconnect.addListener(() => setTimeout(connect, RECONNECT_MS));
  };
  connect();
}
var RECONNECT_MS = 1e3;

// src/ui-shared/license-panel.ts
var OK = ["ACTIVE"];
var WARN = ["OFFLINE_GRACE", "PENDING", "PIN_CHANGE"];
var REFUSED = ["INVALID_KEY", "OTHER_DEVICE", "REVOKED", "EXPIRED"];
var PLAN_LABEL = { "30d": "\u0E23\u0E32\u0E22\u0E40\u0E14\u0E37\u0E2D\u0E19", "90d": "90 \u0E27\u0E31\u0E19", "365d": "\u0E23\u0E32\u0E22\u0E1B\u0E35", forever: "\u0E15\u0E25\u0E2D\u0E14\u0E0A\u0E35\u0E1E" };
var when = (iso) => iso ? new Date(iso).toLocaleString("th-TH", { dateStyle: "medium", timeStyle: "short" }) : "-";
function googleMark() {
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 48 48");
  svg.setAttribute("width", "20");
  svg.setAttribute("height", "20");
  svg.setAttribute("aria-hidden", "true");
  const paths = [
    ["#EA4335", "M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.4 30.2 0 24 0 14.6 0 6.6 5.4 2.6 13.3l7.8 6C12.3 13.6 17.7 9.5 24 9.5z"],
    ["#4285F4", "M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.3-4.6 6.9l7.4 5.7c4.3-4 6.9-9.9 6.9-17.1z"],
    ["#FBBC05", "M10.4 28.7c-.5-1.4-.8-3-.8-4.7s.3-3.2.8-4.7l-7.8-6C1 16.5 0 20.1 0 24s1 7.5 2.6 10.7l7.8-6z"],
    ["#34A853", "M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.4-5.7c-2.1 1.4-4.8 2.3-8.5 2.3-6.3 0-11.7-4.1-13.6-9.8l-7.8 6C6.6 42.6 14.6 48 24 48z"]
  ];
  for (const [fill2, d] of paths) {
    const path = document.createElementNS(ns, "path");
    path.setAttribute("fill", fill2);
    path.setAttribute("d", d);
    svg.append(path);
  }
  return svg;
}
var LicensePanel = class {
  constructor(root) {
    this.root = root;
    root.classList.add("license-panel");
    subscribe((e) => {
      if (e.kind === "license-changed") void this.load();
    });
  }
  view = null;
  editing = false;
  /** Sign-in form shows the License Key box instead of email + PIN (customers who bought a key). */
  useKey = false;
  busy = false;
  revealedKey = null;
  keyRevision = 0;
  async load() {
    this.hideKey();
    this.view = await tryCall("license.get", {}) ?? null;
    this.render();
  }
  async run(action, done) {
    if (this.busy) return;
    this.busy = true;
    this.hideKey();
    this.render();
    try {
      this.view = await action();
      this.editing = false;
      if (done) toast(done);
    } catch (err) {
      toast(toAppError(err).userMessage, "error");
      this.view = await tryCall("license.get", {}) ?? this.view;
    } finally {
      this.busy = false;
      this.render();
    }
  }
  hideKey() {
    this.revealedKey = null;
    this.keyRevision++;
  }
  async showKey() {
    if (this.revealedKey) {
      this.hideKey();
      this.render();
      return;
    }
    const revision = ++this.keyRevision;
    const result = await tryCall("license.reveal", {});
    if (revision !== this.keyRevision) return;
    this.revealedKey = result?.key ?? null;
    this.render();
  }
  async copyKey() {
    const revision = this.keyRevision;
    const result = await tryCall("license.reveal", {});
    if (!result?.key || revision !== this.keyRevision) return;
    try {
      await navigator.clipboard.writeText(result.key);
      toast("\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E23\u0E2B\u0E31\u0E2A\u0E41\u0E25\u0E49\u0E27");
    } catch {
      toast("\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E01\u0E14\u0E14\u0E39\u0E23\u0E2B\u0E31\u0E2A \u0E41\u0E25\u0E49\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E14\u0E49\u0E27\u0E22\u0E15\u0E31\u0E27\u0E40\u0E2D\u0E07", "error");
    }
  }
  switchTo(useKey) {
    this.useKey = useKey;
    this.render();
  }
  keyForm() {
    const input = h("input", { type: "text", id: "license-key", placeholder: "DRFX-XXXXX-XXXXX-XXXXX-XXXXX", autocomplete: "off", spellcheck: false, "aria-label": "\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49" });
    const submit = () => {
      const key = input.value.trim();
      if (!key) {
        toast("\u0E43\u0E2A\u0E48\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E01\u0E48\u0E2D\u0E19", "error");
        return;
      }
      void this.run(() => call("license.activate", { key }), "\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E41\u0E25\u0E49\u0E27");
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") submit();
    });
    return h(
      "div",
      {},
      h("div", { class: "license-form" }, input, h("button", { class: "primary", id: "license-activate", disabled: this.busy, onclick: submit }, this.busy ? "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E15\u0E23\u0E27\u0E08..." : "\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49")),
      h("p", { class: "muted small" }, h("button", { class: "link", id: "license-use-email", onclick: () => this.switchTo(false) }, "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E14\u0E49\u0E27\u0E22 Google \u0E41\u0E17\u0E19"))
    );
  }
  /**
   * Google sign-in (v1.7.0): one button opens Google's own window to pick the account. A new account
   * starts a 7-day free trial on the server (v1.8.0); buying/renewing is on billdee.net. `again` = an older PIN sign-in still waiting for its own PIN.
   */
  googleForm(again = false) {
    const keyLink = h("p", { class: "lic-alt" }, h("button", { class: "link", id: "license-use-key", onclick: () => this.switchTo(true) }, "\u0E21\u0E35 License Key (DRFX-\u2026) \u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27? \u0E43\u0E0A\u0E49\u0E23\u0E2B\u0E31\u0E2A\u0E41\u0E17\u0E19"));
    const signIn = () => void this.run(() => call("license.activateGoogle", {}), "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E41\u0E25\u0E49\u0E27");
    return h(
      "div",
      { class: "lic-card" },
      h("p", { class: "lic-title" }, "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A"),
      h("p", { class: "lic-sub" }, again ? "\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49\u0E40\u0E02\u0E49\u0E32\u0E43\u0E0A\u0E49\u0E14\u0E49\u0E27\u0E22 Google \u0E41\u0E17\u0E19 PIN \u2014 \u0E01\u0E14\u0E1B\u0E38\u0E48\u0E21\u0E14\u0E49\u0E32\u0E19\u0E25\u0E48\u0E32\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E23\u0E34\u0E48\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19" : "\u0E43\u0E0A\u0E49\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Google (Gmail) \u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13"),
      h("button", { class: "lic-google", id: "license-google", disabled: this.busy, onclick: signIn }, googleMark(), h("span", {}, this.busy ? "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A..." : "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E14\u0E49\u0E27\u0E22 Google")),
      again ? null : h("p", { class: "lic-trial", id: "license-trial-note" }, "\u{1F381} \u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01 \u0E17\u0E14\u0E25\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E1F\u0E23\u0E35 7 \u0E27\u0E31\u0E19 \u2014 \u0E01\u0E14\u0E1B\u0E38\u0E48\u0E21\u0E14\u0E49\u0E32\u0E19\u0E1A\u0E19\u0E44\u0E14\u0E49\u0E40\u0E25\u0E22 \u0E44\u0E21\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E2A\u0E21\u0E31\u0E04\u0E23\u0E01\u0E48\u0E2D\u0E19 (\u0E17\u0E14\u0E25\u0E2D\u0E07\u0E44\u0E14\u0E49\u0E04\u0E23\u0E31\u0E49\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27\u0E15\u0E48\u0E2D\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E41\u0E25\u0E30\u0E15\u0E48\u0E2D\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07)"),
      h("p", { class: "lic-hint" }, "1 \u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E43\u0E0A\u0E49\u0E44\u0E14\u0E49 2 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \xB7 \u0E44\u0E21\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E08\u0E33\u0E23\u0E2B\u0E31\u0E2A \xB7 \u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E44\u0E21\u0E48\u0E40\u0E2B\u0E47\u0E19\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19 Google \u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13"),
      keyLink
    );
  }
  deactivateButton(email) {
    const question = email ? "\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E23\u0E30\u0E1A\u0E1A\u0E1A\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49? (\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C 1 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \u2014 \u0E40\u0E02\u0E49\u0E32\u0E43\u0E2B\u0E21\u0E48\u0E44\u0E14\u0E49\u0E14\u0E49\u0E27\u0E22 Google)" : "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49\u0E23\u0E2B\u0E31\u0E2A\u0E19\u0E35\u0E49\u0E1A\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49? (\u0E22\u0E49\u0E32\u0E22\u0E44\u0E1B\u0E43\u0E0A\u0E49\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2D\u0E37\u0E48\u0E19\u0E44\u0E14\u0E49 \u2014 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E08\u0E30\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E08\u0E19\u0E01\u0E27\u0E48\u0E32\u0E08\u0E30\u0E43\u0E2A\u0E48\u0E23\u0E2B\u0E31\u0E2A\u0E43\u0E2B\u0E21\u0E48)";
    const label = email ? "\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E23\u0E30\u0E1A\u0E1A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49" : "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49";
    return h("button", {
      class: "danger",
      id: "license-deactivate",
      disabled: this.busy,
      onclick: () => void ask(question, { okLabel: label }).then((ok) => {
        if (ok !== null) void this.run(() => call("license.deactivate", {}), email ? "\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E23\u0E30\u0E1A\u0E1A\u0E41\u0E25\u0E49\u0E27" : "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E41\u0E25\u0E49\u0E27");
      })
    }, label);
  }
  render() {
    const v = this.view;
    if (!v) {
      fill(this.root, h("h2", {}, "\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 (License)"), h("p", { class: "muted" }, "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14..."));
      return;
    }
    const email = Boolean(v.email);
    const tone = OK.includes(v.status) ? "ok" : WARN.includes(v.status) ? "warn" : v.status === "NONE" ? "neutral" : "bad";
    const signedIn = v.status !== "NONE" && v.status !== "NOT_CONFIGURED";
    const facts = [];
    if (v.email) facts.push(["\u0E2D\u0E35\u0E40\u0E21\u0E25", v.email]);
    if (v.maskedKey) facts.push(["\u0E23\u0E2B\u0E31\u0E2A", this.revealedKey ?? v.maskedKey]);
    if (v.plan) facts.push(["\u0E41\u0E1E\u0E47\u0E01\u0E40\u0E01\u0E08", PLAN_LABEL[v.plan] ?? v.plan]);
    if (v.expiresAt && v.plan !== "forever") facts.push(["\u0E2B\u0E21\u0E14\u0E2D\u0E32\u0E22\u0E38", when(v.expiresAt)]);
    if (v.lastCheckAt) facts.push(["\u0E15\u0E23\u0E27\u0E08\u0E01\u0E31\u0E1A server \u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14", when(v.lastCheckAt)]);
    let form = null;
    if (v.status === "PIN_CHANGE") form = this.googleForm(true);
    else if (v.status !== "NOT_CONFIGURED" && (!signedIn || this.editing || REFUSED.includes(v.status))) {
      const keyMode = this.useKey || Boolean(v.maskedKey) && !this.editing;
      form = keyMode ? this.keyForm() : this.googleForm();
    }
    let actions = null;
    if (signedIn && !this.editing && v.status !== "PIN_CHANGE") {
      actions = email ? h(
        "div",
        { class: "license-actions" },
        h("button", { id: "license-refresh", disabled: this.busy, onclick: () => void this.run(() => call("license.refresh", {}), "\u0E15\u0E23\u0E27\u0E08\u0E41\u0E25\u0E49\u0E27") }, "\u0E15\u0E23\u0E27\u0E08\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49"),
        this.deactivateButton(true)
      ) : h(
        "div",
        { class: "license-actions" },
        h("button", { id: "license-reveal", disabled: this.busy, "aria-pressed": String(Boolean(this.revealedKey)), onclick: () => void this.showKey() }, this.revealedKey ? "\u0E0B\u0E48\u0E2D\u0E19\u0E23\u0E2B\u0E31\u0E2A" : "\u0E14\u0E39\u0E23\u0E2B\u0E31\u0E2A"),
        h("button", { id: "license-copy", disabled: this.busy, onclick: () => void this.copyKey() }, "\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E23\u0E2B\u0E31\u0E2A"),
        h("button", { id: "license-refresh", disabled: this.busy, onclick: () => void this.run(() => call("license.refresh", {}), "\u0E15\u0E23\u0E27\u0E08\u0E41\u0E25\u0E49\u0E27") }, "\u0E15\u0E23\u0E27\u0E08\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49"),
        h("button", {
          id: "license-switch",
          disabled: this.busy,
          onclick: () => {
            this.editing = true;
            this.hideKey();
            this.render();
          }
        }, "\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E23\u0E2B\u0E31\u0E2A / \u0E43\u0E0A\u0E49 Google"),
        this.deactivateButton(false)
      );
    }
    fill(
      this.root,
      h("h2", {}, "\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 (License)"),
      h("p", { class: `license-status ${tone}`, id: "license-status", "data-status": v.status }, v.message),
      facts.length ? h("dl", { class: "license-facts" }, ...facts.flatMap(([k, val]) => [h("dt", {}, k), h("dd", {}, val)])) : null,
      v.lastError && v.status !== "ACTIVE" ? h("p", { class: "muted small" }, `\u0E04\u0E23\u0E31\u0E49\u0E07\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14: ${v.lastError}`) : null,
      form,
      actions,
      signedIn && email ? h("p", { class: "muted small" }, "1 \u0E1A\u0E31\u0E0D\u0E0A\u0E35 Google \u0E43\u0E0A\u0E49\u0E44\u0E14\u0E49 2 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \u2014 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E17\u0E35\u0E48 3: \u0E01\u0E14 \u201C\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E23\u0E30\u0E1A\u0E1A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u201D \u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21\u0E01\u0E48\u0E2D\u0E19 (Export Backup \u0E44\u0E27\u0E49\u0E01\u0E48\u0E2D\u0E19\u0E22\u0E49\u0E32\u0E22\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07)") : null,
      signedIn && !email ? h("p", { class: "muted small" }, "\u0E22\u0E49\u0E32\u0E22\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E23\u0E37\u0E2D\u0E22\u0E49\u0E32\u0E22 Chrome: \u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E23\u0E2B\u0E31\u0E2A\u0E41\u0E25\u0E30 Export Backup \u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 \u201C\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u201D \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E19\u0E33\u0E23\u0E2B\u0E31\u0E2A\u0E44\u0E1B\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E17\u0E35\u0E48\u0E43\u0E2B\u0E21\u0E48") : null,
      h("p", { class: "muted small" }, "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E2A\u0E48\u0E07\u0E44\u0E1B\u0E15\u0E23\u0E27\u0E08\u0E41\u0E04\u0E48\u0E01\u0E32\u0E23\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E08\u0E32\u0E01 Google (\u0E2D\u0E35\u0E40\u0E21\u0E25) \u0E2B\u0E23\u0E37\u0E2D\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49 + \u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E2A\u0E38\u0E48\u0E21\u0E15\u0E2D\u0E19\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07 \u2014 \u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E41\u0E0A\u0E17 \u0E2B\u0E23\u0E37\u0E2D\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Facebook")
    );
  }
};

// src/shared/schema.ts
function fail(path, expected, value) {
  const got = value === null ? "null" : Array.isArray(value) ? "array" : typeof value;
  throw new AppError(ErrorCode.INVALID_INPUT, `${path || "value"}: expected ${expected}, got ${got}`, {
    detail: { path, expected }
  });
}
function string(opts = {}) {
  return (value, path = "") => {
    if (typeof value !== "string") fail(path, "string", value);
    if (opts.min !== void 0 && value.length < opts.min) fail(path, `string length >= ${opts.min}`, value);
    if (opts.max !== void 0 && value.length > opts.max) fail(path, `string length <= ${opts.max}`, value);
    if (opts.pattern && !opts.pattern.test(value)) fail(path, `string matching ${opts.pattern}`, value);
    return value;
  };
}
function number(opts = {}) {
  return (value, path = "") => {
    if (typeof value !== "number" || !Number.isFinite(value)) fail(path, "finite number", value);
    if (opts.int && !Number.isInteger(value)) fail(path, "integer", value);
    if (opts.min !== void 0 && value < opts.min) fail(path, `number >= ${opts.min}`, value);
    if (opts.max !== void 0 && value > opts.max) fail(path, `number <= ${opts.max}`, value);
    return value;
  };
}
var boolean = (value, path = "") => {
  if (typeof value !== "boolean") fail(path, "boolean", value);
  return value;
};
function literal(...values) {
  return (value, path = "") => {
    if (!values.includes(value)) fail(path, `one of ${values.join("|")}`, value);
    return value;
  };
}
function array(item, opts = {}) {
  return (value, path = "") => {
    if (!Array.isArray(value)) fail(path, "array", value);
    if (opts.max !== void 0 && value.length > opts.max) fail(path, `array length <= ${opts.max}`, value);
    if (opts.min !== void 0 && value.length < opts.min) fail(path, `array length >= ${opts.min}`, value);
    return value.map((v, i) => item(v, `${path}[${i}]`));
  };
}
function optional(inner) {
  return (value, path = "") => value === void 0 ? void 0 : inner(value, path);
}
function object(shape) {
  return (value, path = "") => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
    const src = value;
    const out = {};
    for (const [key, validator] of Object.entries(shape)) {
      const v = validator(src[key], path ? `${path}.${key}` : key);
      if (v !== void 0) out[key] = v;
    }
    return out;
  };
}
function record(inner, opts = {}) {
  return (value, path = "") => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
    const entries = Object.entries(value);
    if (opts.maxKeys !== void 0 && entries.length > opts.maxKeys) fail(path, `<= ${opts.maxKeys} keys`, value);
    const out = {};
    for (const [k, v] of entries) out[k] = inner(v, `${path}.${k}`);
    return out;
  };
}
var isoDate = (value, path = "") => {
  const s = string({ max: 40 })(value, path);
  if (Number.isNaN(Date.parse(s))) fail(path, "ISO date", value);
  return s;
};
var id = string({ min: 1, max: 64, pattern: /^[A-Za-z0-9_-]+$/ });

// src/shared/pricing.ts
var NUM = String.raw`\d{1,6}(?:\.\d{1,2})?`;
var CURRENCY = new RegExp(String.raw`(?<p>${NUM})\s*(?:฿|บาท)`);
var EQUALS = new RegExp(String.raw`=\s*(?<p>${NUM})(?!\d)`);
var SIZE = new RegExp(String.raw`\d{1,3}/\d{1,3}(?:\s+|\s*-\s*)(?<p>${NUM})(?=\s|$)`);
var UNIT = new RegExp(String.raw`\d+\s*(?:กรัม|ขีด|ฝา|ไม้|ตัว|แพ็ค|แพค|กก\.?|โล)\s+(?<p>${NUM})\s*$`);
var ONLY = new RegExp(String.raw`^\s*(?<p>${NUM})\s*$`);
var TRAIL = new RegExp(String.raw`[^\d/.\-](?<p>${NUM})\s*(?:\([^)]*\))?\s*$`);
var baht = number({ min: -1e5, max: 1e5 });
var validatePricing = object({
  source: string({ max: 4e3 }),
  plus: baht,
  minus: baht,
  sections: record(object({ plus: baht, minus: baht }), { maxKeys: 200 }),
  lines: record(baht, { maxKeys: 1e3 }),
  pricedAt: optional(isoDate)
});

// src/shared/product-update.ts
var PRODUCT_LIMITS = {
  nameMax: 120,
  descriptionMax: 2e3,
  imagesMax: 10,
  imageBytesMax: 8 * 1024 * 1024,
  videoBytesMax: 25 * 1024 * 1024,
  templateBodyMax: 3e3,
  batchProductsMax: 100,
  batchDestinationsMax: 10
};
var text = (max) => string({ max });
var validateProductInput = object({
  name: string({ min: 1, max: PRODUCT_LIMITS.nameMax }),
  description: text(PRODUCT_LIMITS.descriptionMax),
  price: (value, path = "") => value === null || value === void 0 || value === "" ? null : number({ min: 0, max: 1e8 })(value, path),
  currency: string({ min: 1, max: 8 }),
  unit: optional(string({ max: 20 })),
  images: array(id, { max: PRODUCT_LIMITS.imagesMax }),
  templateId: id,
  active: boolean,
  imagesOnly: optional(boolean),
  pricing: optional(validatePricing)
});
var validateTemplateInput = object({
  name: string({ min: 1, max: 80 }),
  body: string({ min: 1, max: PRODUCT_LIMITS.templateBodyMax }),
  active: boolean
});
var validateDateCardSettings = object({
  enabled: boolean,
  shopName: string({ max: 80 }),
  headline: string({ min: 1, max: 120 }),
  details: text(400),
  style: text(600),
  aspect: literal("1:1", "4:5", "16:9"),
  repeat: number({ int: true, min: 1, max: 10 }),
  autoStyle: boolean,
  business: text(300)
});
var validateDestinationInput = object({
  type: optional(literal("FACEBOOK_GROUP_CHAT", "FACEBOOK_FEED", "FACEBOOK_GROUP", "LINE_OPENCHAT")),
  name: string({ min: 1, max: 100 }),
  /** Facebook: a link (parsers reject anything short) · LINE: the room name as LINE PC shows it. */
  url: string({ min: 1, max: 300 }),
  /** LINE OpenChat only: the room's invite link (optional; lets LINE PC jump straight to the room). */
  roomUrl: optional(string({ max: 300 })),
  enabled: boolean,
  notes: text(500)
});

// src/shared/send-timing.ts
var validateDelayRange = (value, path) => {
  const range = object({ minSec: number({ int: true, min: 5, max: 600 }), maxSec: number({ int: true, min: 5, max: 600 }) })(value, path);
  if (range.minSec > range.maxSec) throw new AppError(ErrorCode.INVALID_INPUT, "Minimum delay exceeds maximum", { userMessage: "\u0E40\u0E27\u0E25\u0E32\u0E15\u0E48\u0E33\u0E2A\u0E38\u0E14\u0E15\u0E49\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32\u0E40\u0E27\u0E25\u0E32\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14" });
  return range;
};
var validateProductUpdateSettings = object({
  sendGapSec: number({ int: true, min: 5, max: 600 }),
  imageSettleSec: number({ int: true, min: 0, max: 10 }),
  channelDelays: optional(object({ chat: optional(validateDelayRange), group: optional(validateDelayRange), feed: optional(validateDelayRange), line: optional(validateDelayRange) })),
  lineLockInput: optional(boolean)
});

// src/shared/backup.ts
var BACKUP_FILE_NAME = "DRFX_PRODUCT_UPDATE_BACKUP.zip";
var BACKUP_PARTS = ["products", "productImages", "templates", "destinations", "dailyUpdate", "imageStyle", "styleHistory", "promptSettings", "preferences", "generatedImages"];
var DEFAULT_BACKUP_PARTS = BACKUP_PARTS.filter((p) => p !== "generatedImages");
var record2 = { schemaVersion: literal(1), id, workspaceId: string({ min: 1, max: 64 }), createdAt: isoDate, updatedAt: isoDate };
var validateDestination = object({
  ...record2,
  name: string({ min: 1, max: 100 }),
  type: literal("FACEBOOK_GROUP_CHAT", "FACEBOOK_FEED", "FACEBOOK_GROUP", "LINE_OPENCHAT"),
  chatReference: object({ url: string({ min: 1, max: 400 }), threadId: string({ max: 64 }) }),
  verifiedTitle: optional(string({ max: 200 })),
  verifiedAt: optional(isoDate),
  enabled: boolean,
  notes: string({ max: 500 }),
  lastUsedAt: optional(isoDate)
});
var dnaText = string({ max: 120 });
var validateDNA = object({ environment: dnaText, timeOfDay: dnaText, weather: dnaText, cameraAngle: dnaText, truckPosition: dnaText, signPosition: dnaText, lighting: dnaText, atmosphere: dnaText });
var short = optional(string({ max: 300 }));
var validateStyle = object({
  date: string({ pattern: /^\d{4}-\d{2}-\d{2}$/ }),
  stylePrompt: string({ max: 1500 }),
  styleDNA: optional(validateDNA),
  scene: short,
  mood: short,
  composition: short,
  camera: short,
  lighting: short,
  source: literal("ai", "edited"),
  locked: boolean,
  retries: number({ int: true, min: 0, max: 10 }),
  createdAt: isoDate,
  updatedAt: isoDate
});
var validateImageRef = object({
  id,
  path: string({ min: 1, max: 200, pattern: /^images\/(products|generated)\/[\w.-]+$/ }),
  sha256: string({ pattern: /^[0-9a-f]{64}$/ }),
  mimeType: string({ pattern: /^(image\/(png|jpeg|webp|gif)|video\/(mp4|webm|quicktime))$/ }),
  size: number({ int: true, min: 0, max: 5e7 }),
  fileName: string({ max: 200 }),
  createdAt: isoDate
});

// src/shared/hash.ts
async function sha256Hex(data) {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}

// src/shared/transfer-codec.ts
var TRANSFER_CHUNK_BYTES = 1024 * 1024;
var TRANSFER_MAX_BYTES = 1024 * 1024 * 1024;
function bytesToBase64(bytes) {
  let binary = "";
  const step = 32768;
  for (let i = 0; i < bytes.length; i += step) {
    binary += String.fromCharCode(...bytes.subarray(i, i + step));
  }
  return btoa(binary);
}

// src/shared/zip.ts
var CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(data) {
  let c = 4294967295;
  for (const b of data) c = CRC_TABLE[(c ^ b) & 255] ^ c >>> 8;
  return (c ^ 4294967295) >>> 0;
}
async function through(data, stream) {
  const out = new Response(new Blob([data]).stream().pipeThrough(stream));
  return new Uint8Array(await out.arrayBuffer());
}
var utf8 = new TextEncoder();
var DOS_DATE = 2026 - 1980 << 9 | 1 << 5 | 1;
async function createZip(entries) {
  const parts = [];
  const central = [];
  let offset = 0;
  for (const e of entries) {
    const name = utf8.encode(e.name);
    const deflate = /\.(json|txt|csv)$/i.test(e.name);
    const body = deflate ? await through(e.data, new CompressionStream("deflate-raw")) : e.data;
    const crc = crc32(e.data);
    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 67324752, true);
    local.setUint16(4, 20, true);
    local.setUint16(6, 2048, true);
    local.setUint16(8, deflate ? 8 : 0, true);
    local.setUint16(12, DOS_DATE, true);
    local.setUint32(14, crc, true);
    local.setUint32(18, body.length, true);
    local.setUint32(22, e.data.length, true);
    local.setUint16(26, name.length, true);
    const cd = new DataView(new ArrayBuffer(46));
    cd.setUint32(0, 33639248, true);
    cd.setUint16(4, 20, true);
    cd.setUint16(6, 20, true);
    cd.setUint16(8, 2048, true);
    cd.setUint16(10, deflate ? 8 : 0, true);
    cd.setUint16(14, DOS_DATE, true);
    cd.setUint32(16, crc, true);
    cd.setUint32(20, body.length, true);
    cd.setUint32(24, e.data.length, true);
    cd.setUint16(28, name.length, true);
    cd.setUint32(42, offset, true);
    parts.push(new Uint8Array(local.buffer), name, body);
    central.push(new Uint8Array(cd.buffer), name);
    offset += 30 + name.length + body.length;
  }
  const size = central.reduce((n, b) => n + b.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 101010256, true);
  end.setUint16(8, entries.length, true);
  end.setUint16(10, entries.length, true);
  end.setUint32(12, size, true);
  end.setUint32(16, offset, true);
  return new Blob([...parts, ...central, new Uint8Array(end.buffer)].map((p) => p), { type: "application/zip" });
}
var ZipError = class extends Error {
};
async function readZip(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let eocd = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (view.getUint32(i, true) === 101010256) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new ZipError("not a ZIP file");
  const count = view.getUint16(eocd + 10, true);
  let p = view.getUint32(eocd + 16, true);
  const entries = /* @__PURE__ */ new Map();
  const broken = [];
  const dec = new TextDecoder();
  for (let i = 0; i < count; i++) {
    if (p + 46 > bytes.length || view.getUint32(p, true) !== 33639248) throw new ZipError("damaged ZIP directory");
    const method = view.getUint16(p + 10, true);
    const crc = view.getUint32(p + 16, true);
    const compSize = view.getUint32(p + 20, true);
    const nameLen = view.getUint16(p + 28, true);
    const extraLen = view.getUint16(p + 30, true);
    const commentLen = view.getUint16(p + 32, true);
    const local = view.getUint32(p + 42, true);
    const name = dec.decode(bytes.subarray(p + 46, p + 46 + nameLen));
    p += 46 + nameLen + extraLen + commentLen;
    if (name.endsWith("/")) continue;
    try {
      if (local + 30 > bytes.length || view.getUint32(local, true) !== 67324752) throw new Error("bad local header");
      const start = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
      const raw = bytes.subarray(start, start + compSize);
      if (raw.length !== compSize) throw new Error("truncated");
      const data = method === 0 ? raw.slice() : method === 8 ? await through(raw, new DecompressionStream("deflate-raw")) : null;
      if (!data) throw new Error(`method ${method}`);
      if (crc32(data) !== crc) throw new Error("checksum");
      entries.set(name, data);
    } catch {
      broken.push(name);
    }
  }
  return { entries, broken };
}

// src/storage/db.ts
var DB_NAME = "ai-content-factory";
var DB_VERSION = 3;
var STORE = {
  jobs: "jobs",
  content: "content",
  assets: "assets",
  assetBlobs: "assetBlobs",
  logs: "logs",
  schedules: "schedules",
  campaigns: "campaigns",
  campaignItems: "campaignItems",
  products: "products",
  msgTemplates: "msgTemplates",
  destinations: "destinations",
  batches: "batches",
  productSends: "productSends"
};
var MIGRATIONS = {
  1: (db) => {
    const jobs = db.createObjectStore(STORE.jobs, { keyPath: "jobId" });
    jobs.createIndex("updatedAt", "updatedAt");
    const content = db.createObjectStore(STORE.content, { keyPath: "id" });
    content.createIndex("status", "status");
    content.createIndex("createdAt", "createdAt");
    const assets = db.createObjectStore(STORE.assets, { keyPath: "id" });
    assets.createIndex("contentId", "contentId");
    db.createObjectStore(STORE.assetBlobs);
    const logs = db.createObjectStore(STORE.logs, { keyPath: "id" });
    logs.createIndex("jobId", "jobId");
    logs.createIndex("ts", "ts");
    const schedules = db.createObjectStore(STORE.schedules, { keyPath: "id" });
    schedules.createIndex("status", "status");
  },
  // v2 (0.10.0): Content Campaigns. Additive only — existing stores untouched.
  2: (db) => {
    const campaigns = db.createObjectStore(STORE.campaigns, { keyPath: "id" });
    campaigns.createIndex("createdAt", "createdAt");
    const items = db.createObjectStore(STORE.campaignItems, { keyPath: "id" });
    items.createIndex("campaignId", "campaignId");
    items.createIndex("jobId", "jobId");
  },
  // v3 (0.14.0): Product Update Bot — its own stores, every record scoped by workspaceId.
  3: (db) => {
    for (const name of [STORE.products, STORE.msgTemplates, STORE.destinations]) {
      db.createObjectStore(name, { keyPath: "id" }).createIndex("workspaceId", "workspaceId");
    }
    const batches = db.createObjectStore(STORE.batches, { keyPath: "id" });
    batches.createIndex("workspaceId", "workspaceId");
    batches.createIndex("createdAt", "createdAt");
    const sends = db.createObjectStore(STORE.productSends, { keyPath: "id" });
    sends.createIndex("batchId", "batchId");
    sends.createIndex("jobId", "jobId");
    sends.createIndex("workspaceId", "workspaceId");
    sends.createIndex("productId", "productId");
  }
};
var dbPromise = null;
function req(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(storageError("request", request.error));
  });
}
function storageError(op, cause) {
  return new AppError(ErrorCode.INTERNAL, `IndexedDB ${op} failed: ${String(cause)}`, {
    cause,
    userMessage: "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01/\u0E2D\u0E48\u0E32\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 (IndexedDB)"
  });
}
function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const open = indexedDB.open(DB_NAME, DB_VERSION);
    open.onupgradeneeded = (event) => {
      const db = open.result;
      const tx = open.transaction;
      if (!tx) return;
      for (let v = event.oldVersion + 1; v <= DB_VERSION; v++) {
        const migrate = MIGRATIONS[v];
        if (!migrate) throw new Error(`Missing IndexedDB migration for version ${v}`);
        migrate(db, tx);
      }
    };
    open.onsuccess = () => {
      const db = open.result;
      db.onversionchange = () => {
        db.close();
        dbPromise = null;
      };
      resolve(db);
    };
    open.onerror = () => {
      dbPromise = null;
      reject(storageError("open", open.error));
    };
    open.onblocked = () => {
      dbPromise = null;
      reject(storageError("open (blocked)", "another context holds an older version open"));
    };
  });
  return dbPromise;
}
async function withStore(names, mode, fn) {
  const db = await openDb();
  const tx = db.transaction(names, mode);
  const done = new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(storageError("transaction", tx.error));
    tx.onabort = () => reject(storageError("transaction aborted", tx.error));
  });
  const result = await fn(tx);
  await done;
  return result;
}
function get(store, key) {
  return withStore(store, "readonly", (tx) => req(tx.objectStore(store).get(key)));
}

// src/ui-shared/asset-preview.ts
async function assetBlob(assetId) {
  return get(STORE.assetBlobs, assetId);
}

// src/ui-shared/backup-panel.ts
var PART_LABEL = {
  products: "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32",
  productImages: "\u0E23\u0E39\u0E1B / \u0E04\u0E25\u0E34\u0E1B\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32",
  templates: "\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 (Templates)",
  destinations: "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 / \u0E40\u0E1E\u0E08",
  dailyUpdate: "\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49 / \u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48",
  imageStyle: "\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E AI",
  styleHistory: "\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E AI",
  promptSettings: "\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32 Prompt",
  preferences: "\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07 / \u0E04\u0E48\u0E32\u0E17\u0E35\u0E48\u0E15\u0E31\u0E49\u0E07\u0E44\u0E27\u0E49",
  generatedImages: "\u0E23\u0E39\u0E1B\u0E1B\u0E49\u0E32\u0E22\u0E17\u0E35\u0E48\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E41\u0E25\u0E49\u0E27 (\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E2B\u0E0D\u0E48)"
};
var COUNT_LABEL = [
  ["products", "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"],
  ["productImages", "\u0E23\u0E39\u0E1B / \u0E04\u0E25\u0E34\u0E1B\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"],
  ["templates", "Templates"],
  ["destinations", "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 / \u0E40\u0E1E\u0E08"],
  ["styleHistory", "\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E2A\u0E44\u0E15\u0E25\u0E4C"],
  ["generatedImages", "\u0E23\u0E39\u0E1B\u0E1B\u0E49\u0E32\u0E22"]
];
function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = h("a", { href: url, download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 6e4);
}
var BackupPanel = class {
  constructor(root, options = {}) {
    this.root = root;
    this.options = options;
    this.render();
  }
  parts = new Set(DEFAULT_BACKUP_PARTS);
  busy = false;
  get isBusy() {
    return this.busy;
  }
  render(status) {
    const file = h("input", { type: "file", id: "backup-file", accept: ".zip,application/zip", disabled: this.busy, "aria-label": "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E1F\u0E25\u0E4C Export Backup" });
    file.addEventListener("change", () => {
      const f = file.files?.[0];
      if (f) void this.openBackup(f);
      file.value = "";
    });
    fill(
      this.root,
      h("h2", { id: "backup-title" }, this.options.importOnly ? "\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E08\u0E32\u0E01\u0E44\u0E1F\u0E25\u0E4C Export" : "\u0E2A\u0E33\u0E23\u0E2D\u0E07 / \u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25 (Backup & Restore)"),
      h("p", { class: "muted small" }, this.options.importOnly ? "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E1F\u0E25\u0E4C ZIP \u0E17\u0E35\u0E48 Export Backup \u0E08\u0E32\u0E01\u0E1A\u0E2D\u0E17\u0E43\u0E19 Chrome \u0E40\u0E14\u0E34\u0E21 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E01\u0E48\u0E2D\u0E19\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E23\u0E39\u0E1B \u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07 \u0E41\u0E25\u0E30\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E44\u0E1F\u0E25\u0E4C" : "\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E40\u0E01\u0E47\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E23\u0E39\u0E1B \u0E41\u0E25\u0E30\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E44\u0E27\u0E49\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E04\u0E38\u0E13 \u2014 \u0E43\u0E0A\u0E49\u0E22\u0E49\u0E32\u0E22\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E09\u0E38\u0E01\u0E40\u0E09\u0E34\u0E19\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E01\u0E47\u0E1A\u0E44\u0E27\u0E49\u0E01\u0E31\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2B\u0E32\u0E22 \xB7 \u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E2B\u0E23\u0E37\u0E2D\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E43\u0E19\u0E44\u0E1F\u0E25\u0E4C"),
      this.options.importOnly ? null : h(
        "div",
        { class: "backup-parts" },
        ...Object.keys(PART_LABEL).map((p) => {
          const cb = h("input", { type: "checkbox", checked: this.parts.has(p), "data-part": p });
          cb.addEventListener("change", () => cb.checked ? this.parts.add(p) : this.parts.delete(p));
          return h("label", { class: "check" }, cb, PART_LABEL[p]);
        })
      ),
      h(
        "div",
        { class: "license-actions" },
        this.options.importOnly ? null : h("button", { class: "primary", id: "backup-export", disabled: this.busy, onclick: () => void this.export() }, "Export Backup"),
        h("label", { class: "button-like", "aria-disabled": String(this.busy) }, this.options.importOnly ? "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E1F\u0E25\u0E4C Export (.zip)" : "Import Backup", file)
      ),
      status ?? h("div", { id: "backup-status" })
    );
  }
  async export() {
    if (this.busy) return;
    this.busy = true;
    this.render(h("div", { id: "backup-status", class: "muted" }, "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u2026"));
    try {
      const manifest = await call("pu.backup.export", { parts: [...this.parts] });
      const files = [];
      const refs = [...manifest.data.images, ...manifest.data.generated.map((g) => g.image)];
      let missing = 0;
      for (const ref of refs) {
        const blob = await assetBlob(ref.id);
        if (!blob) {
          missing++;
          continue;
        }
        files.push({ name: ref.path, data: new Uint8Array(await blob.arrayBuffer()) });
      }
      const json = new TextEncoder().encode(JSON.stringify(manifest, null, 2));
      const zip = await createZip([{ name: "backup.json", data: json }, ...files]);
      download(zip, BACKUP_FILE_NAME.replace(".zip", `_${manifest.exportedAt.slice(0, 10)}.zip`));
      this.busy = false;
      this.render(h("div", { id: "backup-status", class: "ok" }, `\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E41\u0E25\u0E49\u0E27: \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 ${manifest.data.products.length} \xB7 \u0E23\u0E39\u0E1B ${files.length}${missing ? ` (\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E44\u0E1F\u0E25\u0E4C ${missing})` : ""}`));
    } catch (err) {
      this.busy = false;
      toast(err instanceof Error ? err.message : String(err), "error");
      this.render();
    } finally {
      this.busy = false;
    }
  }
  /** Reads and validates the ZIP (nothing is written), then shows the Import Preview. */
  async openBackup(f) {
    if (this.busy) return;
    this.busy = true;
    this.render(h("div", { id: "backup-status", class: "muted" }, "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u2026"));
    let entries;
    let broken;
    let backup;
    try {
      ({ entries, broken } = await readZip(new Uint8Array(await f.arrayBuffer())));
      const json = entries.get("backup.json");
      if (!json) throw new ZipError(broken.includes("backup.json") ? "backup.json \u0E40\u0E2A\u0E35\u0E22\u0E2B\u0E32\u0E22" : "\u0E44\u0E21\u0E48\u0E21\u0E35 backup.json");
      backup = JSON.parse(new TextDecoder().decode(json));
    } catch (err) {
      this.busy = false;
      const msg = err instanceof ZipError ? err.message : "\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07 ZIP";
      this.render(h("div", { id: "backup-status", class: "error-box" }, `\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49: ${msg} \u2014 \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E41\u0E15\u0E30`));
      return;
    }
    const preview = await tryCall("pu.backup.preview", { backup });
    this.busy = false;
    if (!preview) {
      this.render(h("div", { id: "backup-status", class: "error-box" }, "\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E41\u0E15\u0E30"));
      return;
    }
    const merge = h("input", { type: "radio", name: "backup-mode", value: "merge", checked: true, id: "backup-merge" });
    const replace = h("input", { type: "radio", name: "backup-mode", value: "replace", id: "backup-replace" });
    this.render(
      h(
        "div",
        { id: "backup-status", class: "card" },
        h("b", {}, `\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 ${preview.exportedAt.slice(0, 10)}${preview.appVersion ? ` (\u0E40\u0E27\u0E2D\u0E23\u0E4C\u0E0A\u0E31\u0E19 ${preview.appVersion})` : ""}`),
        h("ul", { id: "backup-counts" }, ...COUNT_LABEL.map(([k, label]) => h("li", {}, `${label}: ${preview.counts[k]}`))),
        broken.length ? h("p", { class: "notice small" }, `\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E19\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E40\u0E2A\u0E35\u0E22 ${broken.length} \u0E44\u0E1F\u0E25\u0E4C \u2014 \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2D\u0E37\u0E48\u0E19\u0E22\u0E31\u0E07\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E44\u0E14\u0E49`) : null,
        h("label", { class: "check" }, merge, "\u0E23\u0E27\u0E21\u0E01\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E14\u0E34\u0E21 (Merge \u2014 \u0E44\u0E21\u0E48\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E0B\u0E49\u0E33, \u0E02\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E43\u0E2B\u0E21\u0E48\u0E01\u0E27\u0E48\u0E32\u0E0A\u0E19\u0E30)"),
        h("label", { class: "check" }, replace, "\u0E41\u0E17\u0E19\u0E17\u0E35\u0E48\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E14\u0E34\u0E21\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 (Replace \u2014 \u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E14\u0E34\u0E21\u0E44\u0E27\u0E49\u0E01\u0E48\u0E2D\u0E19 \u0E16\u0E49\u0E32\u0E1E\u0E31\u0E07\u0E08\u0E30\u0E22\u0E49\u0E2D\u0E19\u0E01\u0E25\u0E31\u0E1A)"),
        h("button", { class: "primary", id: "backup-import", onclick: () => void this.import(backup, entries, broken, replace.checked ? "replace" : "merge") }, this.options.importOnly ? "\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25" : "\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19")
      )
    );
  }
  async import(backup, entries, broken, mode) {
    if (this.busy) return;
    if (mode === "replace" && await ask("\u0E41\u0E17\u0E19\u0E17\u0E35\u0E48\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 Templates \u0E41\u0E25\u0E30\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E14\u0E49\u0E27\u0E22\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E08\u0E32\u0E01\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07?", { okLabel: "\u0E41\u0E17\u0E19\u0E17\u0E35\u0E48" }) === null) return;
    this.busy = true;
    this.render(h("div", { id: "backup-status", class: "muted" }, "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u2026"));
    try {
      const data = backup.data ?? {};
      const refs = [...data.images ?? [], ...(data.generated ?? []).map((g) => g.image)];
      const imageMap = {};
      let n = 0;
      for (const ref of refs) {
        n++;
        this.render(h("div", { id: "backup-status", class: "muted" }, `\u0E01\u0E33\u0E25\u0E31\u0E07\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E44\u0E1F\u0E25\u0E4C ${n}/${refs.length}\u2026`));
        const bytes = entries.get(ref.path);
        if (!bytes || broken.includes(ref.path) || await sha256Hex(bytes) !== ref.sha256) {
          imageMap[ref.id] = null;
          continue;
        }
        const added = await tryCall("pu.media.add", { base64: bytesToBase64(bytes), mime: ref.mimeType });
        imageMap[ref.id] = added?.assetId ?? null;
      }
      const report = await call("pu.backup.import", { backup, imageMap, mode });
      const sum = (c) => c.products + c.templates + c.destinations;
      this.busy = false;
      this.render(
        h(
          "div",
          { id: "backup-status", class: "card ok" },
          h("b", { id: "backup-done" }, `\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E41\u0E25\u0E49\u0E27 (${mode === "merge" ? "Merge" : "Replace"}): \u0E40\u0E1E\u0E34\u0E48\u0E21 ${sum(report.added)} \xB7 \u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15 ${sum(report.updated)} \xB7 \u0E44\u0E1F\u0E25\u0E4C ${report.added.productImages}${report.keptLocal ? ` \xB7 \u0E04\u0E07\u0E02\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21\u0E17\u0E35\u0E48\u0E43\u0E2B\u0E21\u0E48\u0E01\u0E27\u0E48\u0E32 ${report.keptLocal}` : ""}`),
          ...report.warnings.map((w) => h("p", { class: "notice small" }, w))
        )
      );
      this.options.onImported?.();
    } catch (err) {
      this.busy = false;
      this.render(h("div", { id: "backup-status", class: "error-box" }, err instanceof Error ? err.message : String(err)));
    } finally {
      this.busy = false;
    }
  }
};

// src/ui-shared/sync-panel.ts
var when2 = (iso) => iso ? new Date(iso).toLocaleString("th-TH", { dateStyle: "medium", timeStyle: "short" }) : "-";
var TONE = { ok: "ok", syncing: "warn", error: "bad", "not-configured": "neutral", off: "neutral" };
var SyncPanel = class {
  constructor(root) {
    this.root = root;
    root.classList.add("license-panel");
    subscribe((e) => {
      if (e.kind === "sync-changed") {
        this.status = e.status;
        this.render();
      }
    });
    void tryCall("sync.status", {}).then((s) => {
      this.status = s ?? null;
      this.render();
    });
  }
  status = null;
  render() {
    const s = this.status;
    fill(
      this.root,
      h("h2", {}, "\u0E0B\u0E34\u0E07\u0E01\u0E4C\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E01\u0E31\u0E1A\u0E1A\u0E31\u0E0D\u0E0A\u0E35 (Cloud)"),
      h("p", { class: "muted small" }, "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E23\u0E39\u0E1B \u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 \u0E41\u0E25\u0E30\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32 \u0E1C\u0E39\u0E01\u0E01\u0E31\u0E1A\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13 \u2014 \u0E43\u0E2A\u0E48\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E14\u0E34\u0E21\u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48 \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E08\u0E30\u0E01\u0E25\u0E31\u0E1A\u0E21\u0E32\u0E40\u0E2D\u0E07"),
      s ? h("p", { class: `license-status ${TONE[s.state]}`, id: "sync-status", "data-state": s.state }, s.message) : null,
      s?.lastSyncAt ? h("p", { class: "muted small" }, `\u0E0B\u0E34\u0E07\u0E01\u0E4C\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14: ${when2(s.lastSyncAt)}`) : null,
      s?.lastError && s.state === "error" ? h("p", { class: "muted small" }, `\u0E2A\u0E32\u0E40\u0E2B\u0E15\u0E38: ${s.lastError}`) : null,
      h(
        "button",
        {
          id: "sync-now",
          disabled: s?.state === "syncing",
          onclick: () => void tryCall("sync.now", {}).then((r) => {
            if (r) this.status = r;
            this.render();
          })
        },
        "\u0E0B\u0E34\u0E07\u0E01\u0E4C\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49"
      )
    );
  }
};

// src/shared/tutorial.ts
var TUTORIAL_STORAGE_KEY = "customerTutorialUrl";
var DEFAULT_TUTORIAL_URL = "";
function youtubeVideoId(raw) {
  try {
    const url = new URL(raw.trim());
    if (url.protocol !== "https:" || url.username || url.password || url.port) return null;
    const host = url.hostname.toLowerCase();
    let id2 = null;
    if (host === "youtu.be") id2 = /^\/([^/]+)\/?$/.exec(url.pathname)?.[1] ?? null;
    else if (["youtube.com", "www.youtube.com", "m.youtube.com", "www.youtube-nocookie.com"].includes(host)) {
      id2 = url.pathname === "/watch" ? url.searchParams.get("v") : /^\/(?:embed|shorts|live)\/([^/]+)\/?$/.exec(url.pathname)?.[1] ?? null;
    }
    return id2 && /^[A-Za-z0-9_-]{11}$/.test(id2) ? id2 : null;
  } catch {
    return null;
  }
}
function normalizeTutorialUrl(raw) {
  const id2 = youtubeVideoId(raw);
  return id2 ? `https://www.youtube.com/watch?v=${id2}` : null;
}

// src/ui-shared/tutorial-panel.ts
async function tutorialUrl() {
  const stored = (await chrome.storage.local.get(TUTORIAL_STORAGE_KEY))[TUTORIAL_STORAGE_KEY];
  return typeof stored === "string" ? stored : DEFAULT_TUTORIAL_URL;
}
function tutorialVideo(raw) {
  const id2 = youtubeVideoId(raw);
  return h(
    "section",
    { class: "tutorial-video", id: "tutorial-video" },
    h("h3", {}, "\u0E27\u0E34\u0E18\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19"),
    id2 ? h("iframe", {
      title: "YouTube \u2014 \u0E27\u0E34\u0E18\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 Billdee PostHub",
      src: `https://www.youtube-nocookie.com/embed/${id2}`,
      referrerpolicy: "strict-origin-when-cross-origin",
      allow: "encrypted-media; fullscreen; picture-in-picture",
      allowfullscreen: true,
      sandbox: "allow-scripts allow-same-origin allow-presentation allow-popups"
    }) : h("div", { class: "tutorial-placeholder" }, "\u25B6 \u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D\u0E27\u0E34\u0E18\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E01\u0E33\u0E25\u0E31\u0E07\u0E08\u0E31\u0E14\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21"),
    id2 ? h("a", { href: `https://www.youtube.com/watch?v=${id2}`, target: "_blank", rel: "noopener", class: "tutorial-watch" }, "\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E19 YouTube \u2197") : null,
    id2 ? h("p", { class: "muted small" }, "\u0E16\u0E49\u0E32\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D\u0E40\u0E25\u0E48\u0E19\u0E43\u0E19\u0E01\u0E23\u0E2D\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E01\u0E14 \u201C\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E19 YouTube\u201D") : null
  );
}
var TutorialPanel = class {
  constructor(root) {
    this.root = root;
    void this.load();
  }
  async load() {
    const input = h("input", { type: "url", id: "tutorial-url", placeholder: "https://www.youtube.com/watch?v=\u2026", value: await tutorialUrl() });
    const preview = h("div", { id: "tutorial-preview" });
    fill(preview, tutorialVideo(input.value));
    const save = h("button", { class: "primary", id: "tutorial-save", onclick: () => {
      const raw = input.value.trim();
      const url = raw ? normalizeTutorialUrl(raw) : "";
      if (url === null) {
        toast("\u0E43\u0E2A\u0E48\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D YouTube \u0E17\u0E35\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 \u0E40\u0E0A\u0E48\u0E19 youtube.com/watch \u0E2B\u0E23\u0E37\u0E2D youtu.be", "error");
        return;
      }
      save.disabled = true;
      void chrome.storage.local.set({ [TUTORIAL_STORAGE_KEY]: url }).then(() => {
        input.value = url;
        fill(preview, tutorialVideo(url));
        toast("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D\u0E41\u0E25\u0E49\u0E27");
      }).catch(() => toast("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E25\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07", "error")).finally(() => {
        save.disabled = false;
      });
    } }, "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E25\u0E34\u0E07\u0E01\u0E4C");
    fill(
      this.root,
      h("h2", {}, "\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D\u0E27\u0E34\u0E18\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19"),
      h("label", { for: "tutorial-url" }, "\u0E25\u0E34\u0E07\u0E01\u0E4C YouTube"),
      h("div", { class: "license-form" }, input, save),
      h("p", { class: "muted small" }, "\u0E41\u0E2A\u0E14\u0E07\u0E17\u0E35\u0E48\u0E2B\u0E19\u0E49\u0E32\u0E43\u0E2A\u0E48\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E43\u0E19 Chrome \u0E19\u0E35\u0E49 \xB7 \u0E40\u0E27\u0E49\u0E19\u0E27\u0E48\u0E32\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E0B\u0E48\u0E2D\u0E19\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D \xB7 \u0E16\u0E49\u0E32\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E43\u0E2B\u0E49\u0E15\u0E34\u0E14\u0E44\u0E1B\u0E01\u0E31\u0E1A\u0E44\u0E1F\u0E25\u0E4C\u0E41\u0E08\u0E01\u0E17\u0E38\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \u0E43\u0E2B\u0E49\u0E41\u0E08\u0E49\u0E07\u0E1C\u0E39\u0E49\u0E1E\u0E31\u0E12\u0E19\u0E32\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E43\u0E19\u0E0A\u0E38\u0E14\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07"),
      preview
    );
  }
};

// src/options/options.ts
function renderForm(s) {
  const gap = h("input", { type: "number", id: "pub-gap", min: 5, max: 600, value: String(s.productUpdate.sendGapSec) });
  const settle = h("input", { type: "number", id: "pub-settle", min: 0, max: 10, value: String(s.productUpdate.imageSettleSec) });
  const form = byId("settings-form");
  form.replaceChildren(
    h(
      "fieldset",
      {},
      h("legend", {}, "\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07"),
      h("label", { for: "pub-gap" }, "\u0E40\u0E27\u0E25\u0E32\u0E40\u0E14\u0E34\u0E21\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E2B\u0E21\u0E27\u0E14\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32 (\u0E27\u0E34\u0E19\u0E32\u0E17\u0E35)"),
      gap,
      h("div", { class: "muted" }, "\u0E15\u0E31\u0E49\u0E07\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E2A\u0E38\u0E48\u0E21\u0E41\u0E22\u0E01\u0E41\u0E15\u0E48\u0E25\u0E30\u0E2B\u0E21\u0E27\u0E14\u0E44\u0E14\u0E49\u0E17\u0E35\u0E48\u0E2B\u0E19\u0E49\u0E32\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 \u0E01\u0E25\u0E38\u0E48\u0E21\u0E40\u0E1F\u0E2A \u0E41\u0E25\u0E30\u0E40\u0E1E\u0E08 / \u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C"),
      h("label", { for: "pub-settle" }, "\u0E23\u0E2D\u0E23\u0E39\u0E1B\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17 (\u0E27\u0E34\u0E19\u0E32\u0E17\u0E35\u0E15\u0E48\u0E2D\u0E23\u0E39\u0E1B)"),
      settle,
      h("div", { class: "muted" }, "\u0E40\u0E19\u0E47\u0E15\u0E0A\u0E49\u0E32 \u0E43\u0E2B\u0E49\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E04\u0E48\u0E32\u0E19\u0E35\u0E49 \u2014 \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E08\u0E30\u0E16\u0E39\u0E01\u0E2A\u0E48\u0E07\u0E2B\u0E25\u0E31\u0E07\u0E23\u0E39\u0E1B\u0E02\u0E36\u0E49\u0E19\u0E04\u0E23\u0E1A\u0E40\u0E2A\u0E21\u0E2D")
    ),
    h("button", { class: "primary", type: "submit" }, "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01")
  );
  form.onsubmit = (ev) => {
    ev.preventDefault();
    void call("settings.get", {}).then((latest) => {
      const next = { ...latest, productUpdate: { ...latest.productUpdate, sendGapSec: Number(gap.value), imageSettleSec: Number(settle.value) } };
      return tryCall("settings.update", { settings: next });
    }).then((saved) => {
      if (!saved) return;
      toast("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27");
      renderForm(saved);
    });
  };
}
void new LicensePanel(byId("license")).load();
new TutorialPanel(byId("tutorial"));
new SyncPanel(byId("sync"));
new BackupPanel(byId("backup"));
void call("settings.get", {}).then(renderForm);
byId("about").textContent = `\u0E40\u0E27\u0E2D\u0E23\u0E4C\u0E0A\u0E31\u0E19 ${chrome.runtime.getManifest().version} \xB7 \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E01\u0E47\u0E1A\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49 \u0E41\u0E25\u0E30\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E44\u0E27\u0E49\u0E43\u0E19\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E02\u0E2D\u0E07\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49 (\u0E14\u0E39 "\u0E0B\u0E34\u0E07\u0E01\u0E4C\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E01\u0E31\u0E1A\u0E1A\u0E31\u0E0D\u0E0A\u0E35")`;
