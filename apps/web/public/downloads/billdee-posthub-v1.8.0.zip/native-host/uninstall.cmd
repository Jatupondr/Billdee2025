@echo off
rem ถอนการติดตั้งตัวเชื่อม LINE OpenChat (ลบ registry + โฟลเดอร์ชั่วคราว)
setlocal EnableExtensions
chcp 65001 >nul
set "BIN=%LOCALAPPDATA%\DRFX\line-host\bin"
if exist "%BIN%\drfx-line-host.exe" "%BIN%\drfx-line-host.exe" --uninstall
reg delete "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.drfx.line_openchat" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.drfx.line_openchat" /f >nul 2>&1
reg delete "HKCU\Software\Chromium\NativeMessagingHosts\com.drfx.line_openchat" /f >nul 2>&1
echo ถอนการลงทะเบียน LINE OpenChat แล้ว
pause
