@echo off
rem DRFX Product Update Bot - LINE OpenChat host installer (compiles the C# host with the Windows
rem in-box C# compiler; no PowerShell, no download of an .exe). Run: install.cmd [extensionId]
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul

set "ID=%~1"
if "%ID%"=="" set /p "ID=วาง Extension ID (จากแท็บ LINE OpenChat ในส่วนขยาย): "
rem trim quotes/spaces
set "ID=%ID: =%"
set "ID=%ID:"=%"

set "BIN=%LOCALAPPDATA%\DRFX\line-host\bin"
if not exist "%BIN%" md "%BIN%"

set "CSC="
for %%V in (v4.0.30319) do (
  if exist "%WINDIR%\Microsoft.NET\Framework64\%%V\csc.exe" set "CSC=%WINDIR%\Microsoft.NET\Framework64\%%V\csc.exe"
  if not defined CSC if exist "%WINDIR%\Microsoft.NET\Framework\%%V\csc.exe" set "CSC=%WINDIR%\Microsoft.NET\Framework\%%V\csc.exe"
)
if not defined CSC (
  echo [X] ไม่พบ C# compiler ^(csc.exe^) ของ .NET Framework 4 บนเครื่องนี้
  echo     ปกติ Windows 10/11 มีให้อยู่แล้ว ลองเปิด Windows Update ให้ติดตั้ง .NET Framework 4.x
  goto :fail
)

rem free the exe in case Chrome still has the host running, else csc cannot overwrite it
taskkill /f /im drfx-line-host.exe >nul 2>&1
echo กำลังคอมไพล์ตัวเชื่อม LINE OpenChat ...
"%CSC%" /nologo /target:winexe /platform:x64 /optimize+ /out:"%BIN%\drfx-line-host.exe" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll "%~dp0drfx-line-host.cs"
if errorlevel 1 (
  echo [X] คอมไพล์ไม่สำเร็จ
  goto :fail
)

rem default config (kept if already tuned on this PC)
if not exist "%BIN%\config.json" copy /y "%~dp0config.json" "%BIN%\config.json" >nul

echo กำลังลงทะเบียนกับ Chrome / Edge ...
"%BIN%\drfx-line-host.exe" --install "%ID%"
if errorlevel 1 (
  echo [X] ลงทะเบียนไม่สำเร็จ ^(ตรวจ Extension ID ให้ถูกต้อง^)
  goto :fail
)

echo.
echo [OK] ติดตั้งตัวเชื่อม LINE OpenChat แล้ว
echo      ไฟล์: %BIN%
echo      Extension ID: %ID%
echo.
echo ขั้นต่อไป: ปิด Chrome/Edge ทุกหน้าต่างแล้วเปิดใหม่ 1 ครั้ง แล้วกด "ตรวจการเชื่อมต่อ" ในแท็บ LINE OpenChat
echo.
pause
exit /b 0

:fail
echo.
pause
exit /b 1
