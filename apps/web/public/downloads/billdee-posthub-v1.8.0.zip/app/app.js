// src/platform/entitlements.ts
function hasAll(e, keys) {
  return keys.every((k) => e.granted.includes(k));
}

// src/platform/tools.ts
var TOOLS = [
  {
    id: "PRODUCT_UPDATE_BOT",
    name: "PRODUCT UPDATE BOT",
    description: "\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E40\u0E02\u0E49\u0E32\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 \u0E41\u0E25\u0E30\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E1A\u0E19\u0E40\u0E1E\u0E08/\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E19\u0E04\u0E25\u0E34\u0E01\u0E40\u0E14\u0E35\u0E22\u0E27",
    icon: "box",
    capabilities: ["Products", "Group Chat", "Page Post", "Date Card", "History"],
    status: "AVAILABLE",
    route: "product-update",
    enabled: true,
    order: 10,
    requiredEntitlements: ["tool.product_update_bot"],
    sections: ["\u0E2A\u0E48\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49", "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32", "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17", "\u0E2A\u0E16\u0E32\u0E19\u0E30", "\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34"]
  }
];
function toolCards(entitlements, tools = TOOLS) {
  return [...tools].filter((t) => t.status !== "DISABLED").sort((a, b) => a.order - b.order).map((t) => {
    if (t.status === "COMING_SOON" || !t.enabled) return { ...t, usable: false, reason: "\u0E40\u0E23\u0E47\u0E27 \u0E46 \u0E19\u0E35\u0E49" };
    if (!hasAll(entitlements, t.requiredEntitlements)) return { ...t, usable: false, reason: entitlements.denyReason ?? (entitlements.granted.length ? "License \u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E23\u0E27\u0E21\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E21\u0E37\u0E2D\u0E19\u0E35\u0E49" : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19") };
    return { ...t, usable: true };
  });
}
var JOB_TYPE_TOOL = { product_send: "product-update", date_card: "product-update", date_style: "product-update" };
var SOURCE_TOOL = [
  [/^product-update\b/, "product-update"],
  [/^(campaign|library|scheduler)\b/, "content-factory"]
];
function toolOfJobType(type) {
  return JOB_TYPE_TOOL[type] ?? "content-factory";
}
function toolOfLog(entry) {
  if (entry.jobType) return toolOfJobType(entry.jobType);
  if (entry.jobId && /^engine\/(pace|send_message)\b/.test(entry.source)) return "product-update";
  for (const [re, tool2] of SOURCE_TOOL) if (re.test(entry.source)) return tool2;
  return entry.jobId ? "content-factory" : "system";
}
function logBelongsTo(entry, tool2) {
  const owner = toolOfLog(entry);
  return owner === tool2 || tool2 === "content-factory" && owner === "system";
}

// src/shared/errors.ts
var ErrorCode = {
  LOGIN_REQUIRED: "LOGIN_REQUIRED",
  CAPTCHA_REQUIRED: "CAPTCHA_REQUIRED",
  PERMISSION_MISSING: "PERMISSION_MISSING",
  SELECTOR_NOT_FOUND: "SELECTOR_NOT_FOUND",
  INPUT_REJECTED: "INPUT_REJECTED",
  PAGE_NOT_READY: "PAGE_NOT_READY",
  WEBSITE_UNAVAILABLE: "WEBSITE_UNAVAILABLE",
  RATE_LIMITED: "RATE_LIMITED",
  QUOTA_EXCEEDED: "QUOTA_EXCEEDED",
  GENERATION_FAILED: "GENERATION_FAILED",
  CONTENT_POLICY_BLOCKED: "CONTENT_POLICY_BLOCKED",
  RESPONSE_PARSE_FAILED: "RESPONSE_PARSE_FAILED",
  TIMEOUT: "TIMEOUT",
  PROGRESS_STALLED: "PROGRESS_STALLED",
  DOWNLOAD_FAILED: "DOWNLOAD_FAILED",
  DOWNLOAD_INTERRUPTED: "DOWNLOAD_INTERRUPTED",
  UPLOAD_FAILED: "UPLOAD_FAILED",
  PUBLISH_UNCONFIRMED: "PUBLISH_UNCONFIRMED",
  SEND_UNCONFIRMED: "SEND_UNCONFIRMED",
  DESTINATION_MISMATCH: "DESTINATION_MISMATCH",
  SEND_FAILED: "SEND_FAILED",
  ACCOUNT_RESTRICTED: "ACCOUNT_RESTRICTED",
  NATIVE_SCHEDULE_UNAVAILABLE: "NATIVE_SCHEDULE_UNAVAILABLE",
  BRIDGE_UNREACHABLE: "BRIDGE_UNREACHABLE",
  TAB_CLOSED: "TAB_CLOSED",
  INTERRUPTED: "INTERRUPTED",
  INVALID_INPUT: "INVALID_INPUT",
  INVALID_STATE: "INVALID_STATE",
  NOT_FOUND: "NOT_FOUND",
  PROVIDER_NOT_CONFIGURED: "PROVIDER_NOT_CONFIGURED",
  LICENSE_REQUIRED: "LICENSE_REQUIRED",
  CANCELLED: "CANCELLED",
  INTERNAL: "INTERNAL"
};
var META = {
  LOGIN_REQUIRED: { retryable: false, pause: "LOGIN_REQUIRED", userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 \u2014 \u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
  CAPTCHA_REQUIRED: { retryable: false, pause: "CAPTCHA", userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E02\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E15\u0E31\u0E27\u0E15\u0E19 (CAPTCHA) \u2014 \u0E17\u0E33\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
  PERMISSION_MISSING: { retryable: false, userMessage: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E40\u0E02\u0E49\u0E32\u0E16\u0E36\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E19\u0E35\u0E49 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
  SELECTOR_NOT_FOUND: { retryable: true, userMessage: "\u0E2B\u0E32\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E40\u0E08\u0E2D \u2014 \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u0E25\u0E2D\u0E07\u0E01\u0E14 Diagnose \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
  INPUT_REJECTED: { retryable: true, userMessage: "\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E23\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34" },
  PAGE_NOT_READY: { retryable: true, userMessage: "\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E22\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21" },
  WEBSITE_UNAVAILABLE: { retryable: true, userMessage: "\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32" },
  RATE_LIMITED: { retryable: false, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E16\u0E35\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B \u2014 \u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E1E\u0E31\u0E01\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry" },
  QUOTA_EXCEEDED: { retryable: false, userMessage: "\u0E43\u0E0A\u0E49\u0E42\u0E04\u0E27\u0E15\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07" },
  GENERATION_FAILED: { retryable: true, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  CONTENT_POLICY_BLOCKED: { retryable: false, userMessage: "\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E1B\u0E0F\u0E34\u0E40\u0E2A\u0E18 prompt \u0E19\u0E35\u0E49 (\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32) \u2014 \u0E41\u0E01\u0E49 prompt \u0E41\u0E25\u0E49\u0E27 Retry" },
  RESPONSE_PARSE_FAILED: { retryable: true, userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E08\u0E32\u0E01 AI \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07)" },
  TIMEOUT: { retryable: true, userMessage: "\u0E23\u0E2D\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14" },
  PROGRESS_STALLED: { retryable: true, userMessage: "\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E27\u0E32\u0E21\u0E04\u0E37\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B" },
  DOWNLOAD_FAILED: { retryable: true, userMessage: "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  DOWNLOAD_INTERRUPTED: { retryable: true, userMessage: "\u0E01\u0E32\u0E23\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30" },
  UPLOAD_FAILED: { retryable: true, userMessage: "\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  PUBLISH_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E02\u0E36\u0E49\u0E19\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E0B\u0E49\u0E33" },
  SEND_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E0A\u0E17\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33" },
  DESTINATION_MISMATCH: { retryable: false, userMessage: "\u0E41\u0E0A\u0E17\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E44\u0E27\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07" },
  SEND_FAILED: { retryable: false, userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  ACCOUNT_RESTRICTED: { retryable: false, pause: "INTERRUPTED", userMessage: "Facebook \u0E08\u0E33\u0E01\u0E31\u0E14\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E2A\u0E48\u0E07\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u0E15\u0E23\u0E27\u0E08\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A Facebook \u0E41\u0E25\u0E30\u0E23\u0E2D\u0E08\u0E19\u0E02\u0E49\u0E2D\u0E08\u0E33\u0E01\u0E31\u0E14\u0E2B\u0E21\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E15\u0E48\u0E2D" },
  NATIVE_SCHEDULE_UNAVAILABLE: { retryable: false, userMessage: "\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A\u0E02\u0E2D\u0E07 Facebook \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E43\u0E0A\u0E49\u0E15\u0E31\u0E27\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E41\u0E17\u0E19" },
  BRIDGE_UNREACHABLE: { retryable: true, userMessage: "\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D\u0E2A\u0E04\u0E23\u0E34\u0E1B\u0E15\u0E4C\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
  TAB_CLOSED: { retryable: true, userMessage: "\u0E41\u0E17\u0E47\u0E1A\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E16\u0E39\u0E01\u0E1B\u0E34\u0E14\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E17\u0E33\u0E07\u0E32\u0E19" },
  INTERRUPTED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E07\u0E32\u0E19\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30 (browser/\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E23\u0E35\u0E2A\u0E15\u0E32\u0E23\u0E4C\u0E17) \u2014 \u0E15\u0E23\u0E27\u0E08\u0E1C\u0E25\u0E1A\u0E19\u0E40\u0E27\u0E47\u0E1A \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry \u0E2B\u0E23\u0E37\u0E2D Cancel" },
  INVALID_INPUT: { retryable: false, userMessage: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E21\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" },
  INVALID_STATE: { retryable: false, userMessage: "\u0E17\u0E33\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E19\u0E35\u0E49\u0E43\u0E19\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
  NOT_FOUND: { retryable: false, userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E23\u0E30\u0E1A\u0E38" },
  PROVIDER_NOT_CONFIGURED: { retryable: false, userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49 \u2014 \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
  LICENSE_REQUIRED: { retryable: false, pause: "LICENSE_REQUIRED", userMessage: "License \u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u2014 \u0E07\u0E32\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E23\u0E34\u0E48\u0E21 \u0E15\u0E23\u0E27\u0E08 License \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
  CANCELLED: { retryable: false, userMessage: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27" },
  INTERNAL: { retryable: false, userMessage: "\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E20\u0E32\u0E22\u0E43\u0E19 \u2014 \u0E14\u0E39\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E43\u0E19 Log" }
};
var AppError = class extends Error {
  code;
  retryable;
  userMessage;
  detail;
  constructor(code, message, opts = {}) {
    super(message, opts.cause === void 0 ? void 0 : { cause: opts.cause });
    this.name = "AppError";
    this.code = code;
    this.retryable = opts.retryable ?? META[code].retryable;
    this.userMessage = opts.userMessage ?? META[code].userMessage;
    this.detail = opts.detail;
  }
  get pauseReason() {
    return META[this.code].pause;
  }
  toJSON() {
    const json = {
      code: this.code,
      message: this.message,
      userMessage: this.userMessage,
      retryable: this.retryable
    };
    if (this.detail !== void 0) json.detail = this.detail;
    return json;
  }
};
function isErrorCode(value) {
  return typeof value === "string" && value in META;
}
function toAppError(err, fallback = ErrorCode.INTERNAL) {
  if (err instanceof AppError) return err;
  if (isAppErrorJSON(err)) return fromJSON(err);
  if (err instanceof DOMException && err.name === "AbortError") {
    return new AppError(ErrorCode.CANCELLED, "Operation aborted", { cause: err });
  }
  const message = err instanceof Error ? err.message : String(err);
  return new AppError(fallback, message, { cause: err });
}
function isAppErrorJSON(value) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  return isErrorCode(v["code"]) && typeof v["message"] === "string";
}
function fromJSON(json) {
  const code = isErrorCode(json.code) ? json.code : ErrorCode.INTERNAL;
  return new AppError(code, json.message, {
    userMessage: json.userMessage,
    retryable: json.retryable,
    detail: json.detail
  });
}

// src/storage/db.ts
var DB_NAME = "ai-content-factory";
var DB_VERSION = 3;
var STORE = {
  jobs: "jobs",
  content: "content",
  assets: "assets",
  assetBlobs: "assetBlobs",
  logs: "logs",
  schedules: "schedules",
  campaigns: "campaigns",
  campaignItems: "campaignItems",
  products: "products",
  msgTemplates: "msgTemplates",
  destinations: "destinations",
  batches: "batches",
  productSends: "productSends"
};
var MIGRATIONS = {
  1: (db) => {
    const jobs = db.createObjectStore(STORE.jobs, { keyPath: "jobId" });
    jobs.createIndex("updatedAt", "updatedAt");
    const content = db.createObjectStore(STORE.content, { keyPath: "id" });
    content.createIndex("status", "status");
    content.createIndex("createdAt", "createdAt");
    const assets = db.createObjectStore(STORE.assets, { keyPath: "id" });
    assets.createIndex("contentId", "contentId");
    db.createObjectStore(STORE.assetBlobs);
    const logs = db.createObjectStore(STORE.logs, { keyPath: "id" });
    logs.createIndex("jobId", "jobId");
    logs.createIndex("ts", "ts");
    const schedules = db.createObjectStore(STORE.schedules, { keyPath: "id" });
    schedules.createIndex("status", "status");
  },
  // v2 (0.10.0): Content Campaigns. Additive only — existing stores untouched.
  2: (db) => {
    const campaigns = db.createObjectStore(STORE.campaigns, { keyPath: "id" });
    campaigns.createIndex("createdAt", "createdAt");
    const items = db.createObjectStore(STORE.campaignItems, { keyPath: "id" });
    items.createIndex("campaignId", "campaignId");
    items.createIndex("jobId", "jobId");
  },
  // v3 (0.14.0): Product Update Bot — its own stores, every record scoped by workspaceId.
  3: (db) => {
    for (const name of [STORE.products, STORE.msgTemplates, STORE.destinations]) {
      db.createObjectStore(name, { keyPath: "id" }).createIndex("workspaceId", "workspaceId");
    }
    const batches = db.createObjectStore(STORE.batches, { keyPath: "id" });
    batches.createIndex("workspaceId", "workspaceId");
    batches.createIndex("createdAt", "createdAt");
    const sends = db.createObjectStore(STORE.productSends, { keyPath: "id" });
    sends.createIndex("batchId", "batchId");
    sends.createIndex("jobId", "jobId");
    sends.createIndex("workspaceId", "workspaceId");
    sends.createIndex("productId", "productId");
  }
};
var dbPromise = null;
function req(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(storageError("request", request.error));
  });
}
function storageError(op, cause) {
  return new AppError(ErrorCode.INTERNAL, `IndexedDB ${op} failed: ${String(cause)}`, {
    cause,
    userMessage: "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01/\u0E2D\u0E48\u0E32\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 (IndexedDB)"
  });
}
function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const open = indexedDB.open(DB_NAME, DB_VERSION);
    open.onupgradeneeded = (event) => {
      const db = open.result;
      const tx = open.transaction;
      if (!tx) return;
      for (let v = event.oldVersion + 1; v <= DB_VERSION; v++) {
        const migrate = MIGRATIONS[v];
        if (!migrate) throw new Error(`Missing IndexedDB migration for version ${v}`);
        migrate(db, tx);
      }
    };
    open.onsuccess = () => {
      const db = open.result;
      db.onversionchange = () => {
        db.close();
        dbPromise = null;
      };
      resolve(db);
    };
    open.onerror = () => {
      dbPromise = null;
      reject(storageError("open", open.error));
    };
    open.onblocked = () => {
      dbPromise = null;
      reject(storageError("open (blocked)", "another context holds an older version open"));
    };
  });
  return dbPromise;
}
async function withStore(names, mode2, fn) {
  const db = await openDb();
  const tx = db.transaction(names, mode2);
  const done = new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(storageError("transaction", tx.error));
    tx.onabort = () => reject(storageError("transaction aborted", tx.error));
  });
  const result = await fn(tx);
  await done;
  return result;
}
function get(store, key) {
  return withStore(store, "readonly", (tx) => req(tx.objectStore(store).get(key)));
}

// src/ui-shared/dom.ts
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === void 0 || value === null || value === false) continue;
    if (key.startsWith("on") && typeof value === "function") {
      el.addEventListener(key.slice(2).toLowerCase(), value);
    } else if (key === "class") {
      el.className = String(value);
    } else if (key in el && typeof value !== "string") {
      el[key] = value;
    } else {
      el.setAttribute(key, value === true ? "" : String(value));
    }
  }
  append(el, ...children);
  return el;
}
function append(parent, ...children) {
  for (const c of children) {
    if (c === null || c === void 0 || c === false) continue;
    parent.append(typeof c === "string" ? document.createTextNode(c) : c);
  }
}
function fill(el, ...children) {
  el.replaceChildren();
  append(el, ...children);
}
function byId(id2) {
  const el = document.getElementById(id2);
  if (!el) throw new Error(`#${id2} missing in page`);
  return el;
}
function toast(message, kind = "info") {
  const host = document.getElementById("toast") ?? document.body.appendChild(h("div", { id: "toast" }));
  const item = h("div", { class: `toast toast-${kind}`, role: kind === "error" ? "alert" : "status" }, message);
  host.append(item);
  setTimeout(() => item.remove(), kind === "error" ? 8e3 : 3500);
}
function ask(message, opts = {}) {
  return new Promise((resolve) => {
    const field = opts.input ? h("input", { type: "text", class: "ask-input" }) : null;
    const dialog = h("dialog", { class: "ask" });
    const done = (value) => {
      dialog.close();
      dialog.remove();
      resolve(value);
    };
    append(
      dialog,
      h("p", {}, message),
      field,
      h(
        "div",
        { class: "row" },
        h("button", { class: "primary", "data-ask": "ok", onclick: () => done(field ? field.value : "ok") }, opts.okLabel ?? "\u0E15\u0E01\u0E25\u0E07"),
        h("button", { "data-ask": "cancel", onclick: () => done(null) }, "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01")
      )
    );
    dialog.addEventListener("cancel", () => done(null));
    document.body.append(dialog);
    dialog.showModal();
    (field ?? dialog.querySelector("[data-ask='ok']"))?.focus();
  });
}

// src/ui-shared/asset-preview.ts
var urls = /* @__PURE__ */ new Map();
async function urlFor(assetId) {
  const cached = urls.get(assetId);
  if (cached) return cached;
  const blob = await get(STORE.assetBlobs, assetId);
  if (!blob) return null;
  const url = URL.createObjectURL(blob);
  urls.set(assetId, url);
  return url;
}
async function assetThumb(assetId, alt, cls = "thumb") {
  const url = await urlFor(assetId);
  if (!url) return h("div", { class: `${cls} missing` }, "?");
  const asset = await assetInfo(assetId);
  return asset?.kind === "video" ? h("video", { src: url, controls: true, muted: true, preload: "metadata", playsInline: true, "aria-label": alt, class: cls }) : h("img", { src: url, alt, class: cls });
}
function assetInfo(assetId) {
  return get(STORE.assets, assetId);
}
async function assetBlob(assetId) {
  return get(STORE.assetBlobs, assetId);
}

// src/app/views/product-update/common.ts
var mode = { simple: false };
function useSimpleMode() {
  mode.simple = true;
}
function isSimple() {
  return mode.simple;
}
function say(full, plain) {
  return mode.simple ? plain : full;
}
var SEND_LABEL = {
  READY: "\u0E23\u0E2D\u0E40\u0E23\u0E34\u0E48\u0E21",
  QUEUED: "\u0E23\u0E2D\u0E04\u0E34\u0E27",
  SENDING: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E48\u0E07",
  PAUSED: "\u0E2B\u0E22\u0E38\u0E14\u0E44\u0E27\u0E49",
  SENT: "\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27",
  PENDING_APPROVAL: "\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34",
  FAILED: "\u0E25\u0E49\u0E21\u0E40\u0E2B\u0E25\u0E27",
  CANCELLED: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01"
};
var ICON = { READY: "\u25CB", QUEUED: "\u25CB", SENDING: "\u25CF", PAUSED: "\u2161", SENT: "\u2713", PENDING_APPROVAL: "\u2713", FAILED: "\u2715", CANCELLED: "\u2013" };
function sendChip(status, needsCheck, channel) {
  const checkLabel = channel === "feed" || channel === "group" ? "\u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E27\u0E08\u0E42\u0E1E\u0E2A\u0E15\u0E4C" : channel === "line" ? "\u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E27\u0E08 LINE" : "\u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E27\u0E08\u0E41\u0E0A\u0E17";
  return h("span", { class: `pu-status ps-${needsCheck ? "CHECK" : status}` }, `${needsCheck ? "!" : ICON[status]} ${needsCheck ? checkLabel : SEND_LABEL[status]}`);
}
function todayYmd() {
  return new Date(Date.now() + 7 * 36e5).toISOString().slice(0, 10);
}
function timeOf(iso) {
  if (!iso) return "";
  return new Date(iso).toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" });
}
function dateOf(iso) {
  if (!iso) return "";
  return new Date(iso).toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" });
}
function thumb(assetId, alt) {
  const box = h("span", { class: "pu-thumb" });
  if (assetId) void assetThumb(assetId, alt).then((img) => box.replaceChildren(img));
  else box.textContent = "\u{1F4E6}";
  return box;
}
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(typeof r.result === "string" ? r.result.replace(/^data:[^,]*,/, "") : "");
    r.onerror = () => reject(r.error ?? new Error("read failed"));
    r.readAsDataURL(file);
  });
}

// src/shared/types.ts
var LOG_LEVEL_ORDER = { DEBUG: 10, INFO: 20, WARN: 30, ERROR: 40 };

// src/shared/protocol.ts
var PROTOCOL_VERSION = 1;
var counter = 0;
function newRequestId() {
  counter = (counter + 1) % 1e6;
  return `${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function envelope(type, payload, id2 = newRequestId()) {
  return { v: PROTOCOL_VERSION, id: id2, type, payload };
}
function isResult(value) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  if (v["ok"] === true) return "data" in v;
  return v["ok"] === false && isAppErrorJSON(v["error"]);
}
function unwrap(result, context) {
  if (!isResult(result)) {
    throw new AppError(ErrorCode.INTERNAL, `${context}: malformed response`, { detail: { result } });
  }
  if (result.ok) return result.data;
  throw fromJSON(result.error);
}
var PORT_UI_EVENTS = "acf-ui-events";

// src/ui-shared/client.ts
async function call(type, payload) {
  const response = await chrome.runtime.sendMessage(envelope(type, payload));
  return unwrap(response, type);
}
async function tryCall(type, payload) {
  try {
    return await call(type, payload);
  } catch (err) {
    const e = err instanceof AppError ? err : toAppError(err);
    toast(e.userMessage, "error");
    return void 0;
  }
}
function subscribe(onEvent) {
  const connect = () => {
    const port = chrome.runtime.connect({ name: PORT_UI_EVENTS });
    port.onMessage.addListener((msg) => onEvent(msg));
    port.onDisconnect.addListener(() => setTimeout(connect, RECONNECT_MS));
  };
  connect();
}
var RECONNECT_MS = 1e3;

// src/app/views/logs.ts
var MAX_LINES = 500;
var LogsView = class {
  constructor(root, tool2 = "content-factory") {
    this.root = root;
    this.tool = tool2;
  }
  level = "INFO";
  list = h("ul", { class: "log-list mono" });
  async refresh() {
    const select = h(
      "select",
      {},
      ...["DEBUG", "INFO", "WARN", "ERROR"].map((l) => h("option", { value: l, selected: l === this.level }, l))
    );
    select.addEventListener("change", () => {
      this.level = select.value;
      void this.refresh();
    });
    const entries = await call("log.query", { minLevel: this.level, limit: MAX_LINES, tool: this.tool });
    this.list = h("ul", { class: "log-list mono" }, ...entries.map(logLine));
    this.root.replaceChildren(
      h(
        "div",
        { class: "row" },
        h("label", { class: "check" }, "\u0E23\u0E30\u0E14\u0E31\u0E1A ", select),
        h("button", { onclick: () => void this.refresh() }, "Refresh"),
        h("button", {
          class: "danger",
          onclick: () => void ask("\u0E25\u0E49\u0E32\u0E07 Log \u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 (\u0E02\u0E2D\u0E07\u0E17\u0E38\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E21\u0E37\u0E2D)?", { okLabel: "\u0E25\u0E49\u0E32\u0E07" }).then(async (ok) => {
            if (ok !== null && await tryCall("log.clear", {})) await this.refresh();
          })
        }, "Clear")
      ),
      this.list
    );
  }
  onLog(entry) {
    if (LOG_LEVEL_ORDER[entry.level] < LOG_LEVEL_ORDER[this.level]) return;
    if (!logBelongsTo(entry, this.tool)) return;
    this.list.prepend(logLine(entry));
    while (this.list.children.length > MAX_LINES) this.list.lastElementChild?.remove();
  }
};
function logLine(e) {
  const time = new Date(e.ts).toLocaleTimeString("th-TH", { hour12: false });
  return h("li", { class: `lv-${e.level}` }, `[${time}] ${e.level} ${e.source}: ${e.message}`);
}

// src/shared/schema.ts
function fail(path, expected, value) {
  const got = value === null ? "null" : Array.isArray(value) ? "array" : typeof value;
  throw new AppError(ErrorCode.INVALID_INPUT, `${path || "value"}: expected ${expected}, got ${got}`, {
    detail: { path, expected }
  });
}
function string(opts = {}) {
  return (value, path = "") => {
    if (typeof value !== "string") fail(path, "string", value);
    if (opts.min !== void 0 && value.length < opts.min) fail(path, `string length >= ${opts.min}`, value);
    if (opts.max !== void 0 && value.length > opts.max) fail(path, `string length <= ${opts.max}`, value);
    if (opts.pattern && !opts.pattern.test(value)) fail(path, `string matching ${opts.pattern}`, value);
    return value;
  };
}
function number(opts = {}) {
  return (value, path = "") => {
    if (typeof value !== "number" || !Number.isFinite(value)) fail(path, "finite number", value);
    if (opts.int && !Number.isInteger(value)) fail(path, "integer", value);
    if (opts.min !== void 0 && value < opts.min) fail(path, `number >= ${opts.min}`, value);
    if (opts.max !== void 0 && value > opts.max) fail(path, `number <= ${opts.max}`, value);
    return value;
  };
}
var boolean = (value, path = "") => {
  if (typeof value !== "boolean") fail(path, "boolean", value);
  return value;
};
function literal(...values) {
  return (value, path = "") => {
    if (!values.includes(value)) fail(path, `one of ${values.join("|")}`, value);
    return value;
  };
}
function array(item, opts = {}) {
  return (value, path = "") => {
    if (!Array.isArray(value)) fail(path, "array", value);
    if (opts.max !== void 0 && value.length > opts.max) fail(path, `array length <= ${opts.max}`, value);
    if (opts.min !== void 0 && value.length < opts.min) fail(path, `array length >= ${opts.min}`, value);
    return value.map((v, i) => item(v, `${path}[${i}]`));
  };
}
function optional(inner) {
  return (value, path = "") => value === void 0 ? void 0 : inner(value, path);
}
function object(shape) {
  return (value, path = "") => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
    const src = value;
    const out = {};
    for (const [key, validator] of Object.entries(shape)) {
      const v = validator(src[key], path ? `${path}.${key}` : key);
      if (v !== void 0) out[key] = v;
    }
    return out;
  };
}
function record(inner, opts = {}) {
  return (value, path = "") => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
    const entries = Object.entries(value);
    if (opts.maxKeys !== void 0 && entries.length > opts.maxKeys) fail(path, `<= ${opts.maxKeys} keys`, value);
    const out = {};
    for (const [k, v] of entries) out[k] = inner(v, `${path}.${k}`);
    return out;
  };
}
var isoDate = (value, path = "") => {
  const s = string({ max: 40 })(value, path);
  if (Number.isNaN(Date.parse(s))) fail(path, "ISO date", value);
  return s;
};
var id = string({ min: 1, max: 64, pattern: /^[A-Za-z0-9_-]+$/ });

// src/shared/pricing.ts
var NUM = String.raw`\d{1,6}(?:\.\d{1,2})?`;
var CURRENCY = new RegExp(String.raw`(?<p>${NUM})\s*(?:฿|บาท)`);
var EQUALS = new RegExp(String.raw`=\s*(?<p>${NUM})(?!\d)`);
var SIZE = new RegExp(String.raw`\d{1,3}/\d{1,3}(?:\s+|\s*-\s*)(?<p>${NUM})(?=\s|$)`);
var UNIT = new RegExp(String.raw`\d+\s*(?:กรัม|ขีด|ฝา|ไม้|ตัว|แพ็ค|แพค|กก\.?|โล)\s+(?<p>${NUM})\s*$`);
var ONLY = new RegExp(String.raw`^\s*(?<p>${NUM})\s*$`);
var TRAIL = new RegExp(String.raw`[^\d/.\-](?<p>${NUM})\s*(?:\([^)]*\))?\s*$`);
var ORDERED = [CURRENCY, EQUALS, SIZE, UNIT, ONLY, TRAIL];
var MIN_ORDER = /ขั้นต่ำ|หิ้ว|คละ/;
var DATE = /\d{1,2}\/\d{1,2}\/\d{2,4}|\d{1,2}-\d{1,2}-\d{2,4}|วันที่\s*\d/;
var REMARK = /^(?:📌|‼️|❗|✨|✅|✖️|⚠️|\*|\(|•\s*\()/u;
var SEPARATOR = /^[\s\-_—=~.·*]+$/;
function sectionName(line) {
  return line.replace(/[\uFE0E\uFE0F\u200D]/g, "").replace(/[^\p{L}\p{M}\p{N}\s()/\-.]/gu, " ").replace(/\s+/g, " ").trim().slice(0, 60);
}
function lineKey(section, label) {
  return `${section}|${label}`;
}
function formatPrice(n) {
  return Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100);
}
function findPrice(line) {
  const t = line.trim();
  if (!t || SEPARATOR.test(t)) return null;
  if (DATE.test(t)) return null;
  const currency = CURRENCY.exec(line);
  if (MIN_ORDER.test(t) && !currency) return null;
  for (const rx of ORDERED) {
    const m = rx === CURRENCY ? currency : rx.exec(line);
    const p = m?.groups?.["p"];
    if (!m || p === void 0) continue;
    const start = m.index + m[0].indexOf(p, rx === TRAIL ? 1 : 0);
    return { start, end: start + p.length, price: Number(p) };
  }
  return null;
}
function classify(line) {
  const t = line.trim();
  if (!t || SEPARATOR.test(t)) return "blank";
  if (DATE.test(t) || MIN_ORDER.test(t) || REMARK.test(t)) return "note";
  return "heading";
}
function labelOf(line, f) {
  const rest = `${line.slice(0, f.start)} ${line.slice(f.end)}`.replace(/(?:฿|บาท)/g, " ").replace(/\([^)]*\)/g, " ");
  const name = sectionName(rest).replace(/[=\-\s]+$/g, "").replace(/^[=\-\s]+/g, "");
  return name || "\u2014";
}
var EMPTY_PRICING = { plus: 0, minus: 0, sections: {}, lines: {} };
function applyPricing(source, settings = EMPTY_PRICING) {
  const lines = source.split("\n");
  const out = [];
  const rows = [];
  const sections = [];
  let current = "";
  let blankBefore = true;
  const sectionOf = (name) => {
    let s = sections.find((x) => x.name === name);
    if (!s) {
      const own = settings.sections[name];
      s = { name, plus: own ? own.plus : settings.plus, minus: own ? own.minus : settings.minus, own: Boolean(own), rows: [] };
      sections.push(s);
    }
    return s;
  };
  for (const [i, line] of lines.entries()) {
    const f = findPrice(line);
    if (!f) {
      const kind = classify(line);
      if (kind === "heading") current = sectionName(line) || current;
      blankBefore = kind === "blank";
      out.push(line);
      continue;
    }
    let label = labelOf(line, f);
    const named = new RegExp("\\p{L}{2,}", "u").test(label) && !/\d/.test(label.replace(/\d+\s*(?:กรัม|ขีด|ฝา|ไม้|ตัว|แพ็ค|แพค|โล)/g, ""));
    let name = current;
    if (!current || blankBefore && named) {
      name = label;
      label = "\u2014";
    }
    blankBefore = false;
    const sec = sectionOf(name || "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23");
    const key = lineKey(sec.name, label);
    const extra = Number.isFinite(settings.lines[key]) ? settings.lines[key] : 0;
    const sale = Math.max(0, f.price + sec.plus + extra);
    const cost = Math.max(0, f.price - sec.minus);
    const row = { line: i, section: sec.name, label, key, price: f.price, sale, cost, extra };
    rows.push(row);
    sec.rows.push(row);
    out.push(sale === f.price ? line : line.slice(0, f.start) + formatPrice(sale) + line.slice(f.end));
  }
  return { output: out.join("\n"), rows, sections: sections.filter((s) => s.rows.length) };
}
function supplierOf(productName) {
  const words = productName.trim().split(/\s+/);
  return words.length > 1 ? words[words.length - 1] : "";
}
var baht = number({ min: -1e5, max: 1e5 });
var validatePricing = object({
  source: string({ max: 4e3 }),
  plus: baht,
  minus: baht,
  sections: record(object({ plus: baht, minus: baht }), { maxKeys: 200 }),
  lines: record(baht, { maxKeys: 1e3 }),
  pricedAt: optional(isoDate)
});

// src/shared/product-update.ts
var PRODUCT_LIMITS = {
  nameMax: 120,
  descriptionMax: 2e3,
  imagesMax: 10,
  imageBytesMax: 8 * 1024 * 1024,
  videoBytesMax: 25 * 1024 * 1024,
  templateBodyMax: 3e3,
  batchProductsMax: 100,
  batchDestinationsMax: 10
};
function isLine(d) {
  return d.type === "LINE_OPENCHAT";
}
function isGroup(d) {
  return d.type === "FACEBOOK_GROUP";
}
function isPost(d) {
  return isFeed(d) || isGroup(d);
}
function isFeed(d) {
  return d.type === "FACEBOOK_FEED";
}
var text = (max) => string({ max });
var validateProductInput = object({
  name: string({ min: 1, max: PRODUCT_LIMITS.nameMax }),
  description: text(PRODUCT_LIMITS.descriptionMax),
  price: (value, path = "") => value === null || value === void 0 || value === "" ? null : number({ min: 0, max: 1e8 })(value, path),
  currency: string({ min: 1, max: 8 }),
  unit: optional(string({ max: 20 })),
  images: array(id, { max: PRODUCT_LIMITS.imagesMax }),
  templateId: id,
  active: boolean,
  imagesOnly: optional(boolean),
  pricing: optional(validatePricing)
});
var validateTemplateInput = object({
  name: string({ min: 1, max: 80 }),
  body: string({ min: 1, max: PRODUCT_LIMITS.templateBodyMax }),
  active: boolean
});
var validateDateCardSettings = object({
  enabled: boolean,
  shopName: string({ max: 80 }),
  headline: string({ min: 1, max: 120 }),
  details: text(400),
  style: text(600),
  aspect: literal("1:1", "4:5", "16:9"),
  repeat: number({ int: true, min: 1, max: 10 }),
  autoStyle: boolean,
  business: text(300)
});
var validateDestinationInput = object({
  type: optional(literal("FACEBOOK_GROUP_CHAT", "FACEBOOK_FEED", "FACEBOOK_GROUP", "LINE_OPENCHAT")),
  name: string({ min: 1, max: 100 }),
  /** Facebook: a link (parsers reject anything short) · LINE: the room name as LINE PC shows it. */
  url: string({ min: 1, max: 300 }),
  /** LINE OpenChat only: the room's invite link (optional; lets LINE PC jump straight to the room). */
  roomUrl: optional(string({ max: 300 })),
  enabled: boolean,
  notes: text(500)
});

// src/tools/product-update/date-card.ts
var TH_MONTHS = ["\u0E21\u0E01\u0E23\u0E32\u0E04\u0E21", "\u0E01\u0E38\u0E21\u0E20\u0E32\u0E1E\u0E31\u0E19\u0E18\u0E4C", "\u0E21\u0E35\u0E19\u0E32\u0E04\u0E21", "\u0E40\u0E21\u0E29\u0E32\u0E22\u0E19", "\u0E1E\u0E24\u0E29\u0E20\u0E32\u0E04\u0E21", "\u0E21\u0E34\u0E16\u0E38\u0E19\u0E32\u0E22\u0E19", "\u0E01\u0E23\u0E01\u0E0E\u0E32\u0E04\u0E21", "\u0E2A\u0E34\u0E07\u0E2B\u0E32\u0E04\u0E21", "\u0E01\u0E31\u0E19\u0E22\u0E32\u0E22\u0E19", "\u0E15\u0E38\u0E25\u0E32\u0E04\u0E21", "\u0E1E\u0E24\u0E28\u0E08\u0E34\u0E01\u0E32\u0E22\u0E19", "\u0E18\u0E31\u0E19\u0E27\u0E32\u0E04\u0E21"];
function thaiLongDate(ymd) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd);
  if (!m) return ymd;
  const month = TH_MONTHS[Number(m[2]) - 1];
  return month ? `${Number(m[3])} ${month} ${Number(m[1]) + 543}` : ymd;
}

// src/shared/send-timing.ts
var validateDelayRange = (value, path) => {
  const range = object({ minSec: number({ int: true, min: 5, max: 600 }), maxSec: number({ int: true, min: 5, max: 600 }) })(value, path);
  if (range.minSec > range.maxSec) throw new AppError(ErrorCode.INVALID_INPUT, "Minimum delay exceeds maximum", { userMessage: "\u0E40\u0E27\u0E25\u0E32\u0E15\u0E48\u0E33\u0E2A\u0E38\u0E14\u0E15\u0E49\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32\u0E40\u0E27\u0E25\u0E32\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14" });
  return range;
};
var validateProductUpdateSettings = object({
  sendGapSec: number({ int: true, min: 5, max: 600 }),
  imageSettleSec: number({ int: true, min: 0, max: 10 }),
  channelDelays: optional(object({ chat: optional(validateDelayRange), group: optional(validateDelayRange), feed: optional(validateDelayRange), line: optional(validateDelayRange) })),
  lineLockInput: optional(boolean)
});
function delayRange(settings, channel) {
  return settings.productUpdate.channelDelays?.[channel] ?? { minSec: settings.productUpdate.sendGapSec, maxSec: settings.productUpdate.sendGapSec };
}

// src/shared/backup.ts
var BACKUP_FILE_NAME = "DRFX_PRODUCT_UPDATE_BACKUP.zip";
var BACKUP_PARTS = ["products", "productImages", "templates", "destinations", "dailyUpdate", "imageStyle", "styleHistory", "promptSettings", "preferences", "generatedImages"];
var DEFAULT_BACKUP_PARTS = BACKUP_PARTS.filter((p) => p !== "generatedImages");
var record2 = { schemaVersion: literal(1), id, workspaceId: string({ min: 1, max: 64 }), createdAt: isoDate, updatedAt: isoDate };
var validateDestination = object({
  ...record2,
  name: string({ min: 1, max: 100 }),
  type: literal("FACEBOOK_GROUP_CHAT", "FACEBOOK_FEED", "FACEBOOK_GROUP", "LINE_OPENCHAT"),
  chatReference: object({ url: string({ min: 1, max: 400 }), threadId: string({ max: 64 }) }),
  verifiedTitle: optional(string({ max: 200 })),
  verifiedAt: optional(isoDate),
  enabled: boolean,
  notes: string({ max: 500 }),
  lastUsedAt: optional(isoDate)
});
var dnaText = string({ max: 120 });
var validateDNA = object({ environment: dnaText, timeOfDay: dnaText, weather: dnaText, cameraAngle: dnaText, truckPosition: dnaText, signPosition: dnaText, lighting: dnaText, atmosphere: dnaText });
var short = optional(string({ max: 300 }));
var validateStyle = object({
  date: string({ pattern: /^\d{4}-\d{2}-\d{2}$/ }),
  stylePrompt: string({ max: 1500 }),
  styleDNA: optional(validateDNA),
  scene: short,
  mood: short,
  composition: short,
  camera: short,
  lighting: short,
  source: literal("ai", "edited"),
  locked: boolean,
  retries: number({ int: true, min: 0, max: 10 }),
  createdAt: isoDate,
  updatedAt: isoDate
});
var validateImageRef = object({
  id,
  path: string({ min: 1, max: 200, pattern: /^images\/(products|generated)\/[\w.-]+$/ }),
  sha256: string({ pattern: /^[0-9a-f]{64}$/ }),
  mimeType: string({ pattern: /^(image\/(png|jpeg|webp|gif)|video\/(mp4|webm|quicktime))$/ }),
  size: number({ int: true, min: 0, max: 5e7 }),
  fileName: string({ max: 200 }),
  createdAt: isoDate
});

// src/shared/hash.ts
async function sha256Hex(data) {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}

// src/shared/transfer-codec.ts
var TRANSFER_CHUNK_BYTES = 1024 * 1024;
var TRANSFER_MAX_BYTES = 1024 * 1024 * 1024;
function bytesToBase64(bytes) {
  let binary = "";
  const step = 32768;
  for (let i = 0; i < bytes.length; i += step) {
    binary += String.fromCharCode(...bytes.subarray(i, i + step));
  }
  return btoa(binary);
}

// src/shared/zip.ts
var CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(data) {
  let c = 4294967295;
  for (const b of data) c = CRC_TABLE[(c ^ b) & 255] ^ c >>> 8;
  return (c ^ 4294967295) >>> 0;
}
async function through(data, stream) {
  const out = new Response(new Blob([data]).stream().pipeThrough(stream));
  return new Uint8Array(await out.arrayBuffer());
}
var utf8 = new TextEncoder();
var DOS_DATE = 2026 - 1980 << 9 | 1 << 5 | 1;
async function createZip(entries) {
  const parts = [];
  const central = [];
  let offset = 0;
  for (const e of entries) {
    const name = utf8.encode(e.name);
    const deflate = /\.(json|txt|csv)$/i.test(e.name);
    const body = deflate ? await through(e.data, new CompressionStream("deflate-raw")) : e.data;
    const crc = crc32(e.data);
    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 67324752, true);
    local.setUint16(4, 20, true);
    local.setUint16(6, 2048, true);
    local.setUint16(8, deflate ? 8 : 0, true);
    local.setUint16(12, DOS_DATE, true);
    local.setUint32(14, crc, true);
    local.setUint32(18, body.length, true);
    local.setUint32(22, e.data.length, true);
    local.setUint16(26, name.length, true);
    const cd = new DataView(new ArrayBuffer(46));
    cd.setUint32(0, 33639248, true);
    cd.setUint16(4, 20, true);
    cd.setUint16(6, 20, true);
    cd.setUint16(8, 2048, true);
    cd.setUint16(10, deflate ? 8 : 0, true);
    cd.setUint16(14, DOS_DATE, true);
    cd.setUint32(16, crc, true);
    cd.setUint32(20, body.length, true);
    cd.setUint32(24, e.data.length, true);
    cd.setUint16(28, name.length, true);
    cd.setUint32(42, offset, true);
    parts.push(new Uint8Array(local.buffer), name, body);
    central.push(new Uint8Array(cd.buffer), name);
    offset += 30 + name.length + body.length;
  }
  const size = central.reduce((n, b) => n + b.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 101010256, true);
  end.setUint16(8, entries.length, true);
  end.setUint16(10, entries.length, true);
  end.setUint32(12, size, true);
  end.setUint32(16, offset, true);
  return new Blob([...parts, ...central, new Uint8Array(end.buffer)].map((p) => p), { type: "application/zip" });
}
var ZipError = class extends Error {
};
async function readZip(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let eocd = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (view.getUint32(i, true) === 101010256) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new ZipError("not a ZIP file");
  const count = view.getUint16(eocd + 10, true);
  let p = view.getUint32(eocd + 16, true);
  const entries = /* @__PURE__ */ new Map();
  const broken = [];
  const dec = new TextDecoder();
  for (let i = 0; i < count; i++) {
    if (p + 46 > bytes.length || view.getUint32(p, true) !== 33639248) throw new ZipError("damaged ZIP directory");
    const method = view.getUint16(p + 10, true);
    const crc = view.getUint32(p + 16, true);
    const compSize = view.getUint32(p + 20, true);
    const nameLen = view.getUint16(p + 28, true);
    const extraLen = view.getUint16(p + 30, true);
    const commentLen = view.getUint16(p + 32, true);
    const local = view.getUint32(p + 42, true);
    const name = dec.decode(bytes.subarray(p + 46, p + 46 + nameLen));
    p += 46 + nameLen + extraLen + commentLen;
    if (name.endsWith("/")) continue;
    try {
      if (local + 30 > bytes.length || view.getUint32(local, true) !== 67324752) throw new Error("bad local header");
      const start = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
      const raw = bytes.subarray(start, start + compSize);
      if (raw.length !== compSize) throw new Error("truncated");
      const data = method === 0 ? raw.slice() : method === 8 ? await through(raw, new DecompressionStream("deflate-raw")) : null;
      if (!data) throw new Error(`method ${method}`);
      if (crc32(data) !== crc) throw new Error("checksum");
      entries.set(name, data);
    } catch {
      broken.push(name);
    }
  }
  return { entries, broken };
}

// src/ui-shared/backup-panel.ts
var PART_LABEL = {
  products: "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32",
  productImages: "\u0E23\u0E39\u0E1B / \u0E04\u0E25\u0E34\u0E1B\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32",
  templates: "\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 (Templates)",
  destinations: "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 / \u0E40\u0E1E\u0E08",
  dailyUpdate: "\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49 / \u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48",
  imageStyle: "\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E AI",
  styleHistory: "\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E AI",
  promptSettings: "\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32 Prompt",
  preferences: "\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07 / \u0E04\u0E48\u0E32\u0E17\u0E35\u0E48\u0E15\u0E31\u0E49\u0E07\u0E44\u0E27\u0E49",
  generatedImages: "\u0E23\u0E39\u0E1B\u0E1B\u0E49\u0E32\u0E22\u0E17\u0E35\u0E48\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E41\u0E25\u0E49\u0E27 (\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E2B\u0E0D\u0E48)"
};
var COUNT_LABEL = [
  ["products", "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"],
  ["productImages", "\u0E23\u0E39\u0E1B / \u0E04\u0E25\u0E34\u0E1B\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"],
  ["templates", "Templates"],
  ["destinations", "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 / \u0E40\u0E1E\u0E08"],
  ["styleHistory", "\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E2A\u0E44\u0E15\u0E25\u0E4C"],
  ["generatedImages", "\u0E23\u0E39\u0E1B\u0E1B\u0E49\u0E32\u0E22"]
];
function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = h("a", { href: url, download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 6e4);
}
var BackupPanel = class {
  constructor(root, options = {}) {
    this.root = root;
    this.options = options;
    this.render();
  }
  parts = new Set(DEFAULT_BACKUP_PARTS);
  busy = false;
  get isBusy() {
    return this.busy;
  }
  render(status) {
    const file = h("input", { type: "file", id: "backup-file", accept: ".zip,application/zip", disabled: this.busy, "aria-label": "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E1F\u0E25\u0E4C Export Backup" });
    file.addEventListener("change", () => {
      const f = file.files?.[0];
      if (f) void this.openBackup(f);
      file.value = "";
    });
    fill(
      this.root,
      h("h2", { id: "backup-title" }, this.options.importOnly ? "\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E08\u0E32\u0E01\u0E44\u0E1F\u0E25\u0E4C Export" : "\u0E2A\u0E33\u0E23\u0E2D\u0E07 / \u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25 (Backup & Restore)"),
      h("p", { class: "muted small" }, this.options.importOnly ? "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E1F\u0E25\u0E4C ZIP \u0E17\u0E35\u0E48 Export Backup \u0E08\u0E32\u0E01\u0E1A\u0E2D\u0E17\u0E43\u0E19 Chrome \u0E40\u0E14\u0E34\u0E21 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E01\u0E48\u0E2D\u0E19\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E23\u0E39\u0E1B \u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07 \u0E41\u0E25\u0E30\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E44\u0E1F\u0E25\u0E4C" : "\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E40\u0E01\u0E47\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E23\u0E39\u0E1B \u0E41\u0E25\u0E30\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E44\u0E27\u0E49\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E04\u0E38\u0E13 \u2014 \u0E43\u0E0A\u0E49\u0E22\u0E49\u0E32\u0E22\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E09\u0E38\u0E01\u0E40\u0E09\u0E34\u0E19\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E01\u0E47\u0E1A\u0E44\u0E27\u0E49\u0E01\u0E31\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2B\u0E32\u0E22 \xB7 \u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E2B\u0E23\u0E37\u0E2D\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E43\u0E19\u0E44\u0E1F\u0E25\u0E4C"),
      this.options.importOnly ? null : h(
        "div",
        { class: "backup-parts" },
        ...Object.keys(PART_LABEL).map((p) => {
          const cb = h("input", { type: "checkbox", checked: this.parts.has(p), "data-part": p });
          cb.addEventListener("change", () => cb.checked ? this.parts.add(p) : this.parts.delete(p));
          return h("label", { class: "check" }, cb, PART_LABEL[p]);
        })
      ),
      h(
        "div",
        { class: "license-actions" },
        this.options.importOnly ? null : h("button", { class: "primary", id: "backup-export", disabled: this.busy, onclick: () => void this.export() }, "Export Backup"),
        h("label", { class: "button-like", "aria-disabled": String(this.busy) }, this.options.importOnly ? "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E1F\u0E25\u0E4C Export (.zip)" : "Import Backup", file)
      ),
      status ?? h("div", { id: "backup-status" })
    );
  }
  async export() {
    if (this.busy) return;
    this.busy = true;
    this.render(h("div", { id: "backup-status", class: "muted" }, "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u2026"));
    try {
      const manifest = await call("pu.backup.export", { parts: [...this.parts] });
      const files = [];
      const refs = [...manifest.data.images, ...manifest.data.generated.map((g) => g.image)];
      let missing = 0;
      for (const ref of refs) {
        const blob = await assetBlob(ref.id);
        if (!blob) {
          missing++;
          continue;
        }
        files.push({ name: ref.path, data: new Uint8Array(await blob.arrayBuffer()) });
      }
      const json = new TextEncoder().encode(JSON.stringify(manifest, null, 2));
      const zip = await createZip([{ name: "backup.json", data: json }, ...files]);
      download(zip, BACKUP_FILE_NAME.replace(".zip", `_${manifest.exportedAt.slice(0, 10)}.zip`));
      this.busy = false;
      this.render(h("div", { id: "backup-status", class: "ok" }, `\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E41\u0E25\u0E49\u0E27: \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 ${manifest.data.products.length} \xB7 \u0E23\u0E39\u0E1B ${files.length}${missing ? ` (\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E44\u0E1F\u0E25\u0E4C ${missing})` : ""}`));
    } catch (err) {
      this.busy = false;
      toast(err instanceof Error ? err.message : String(err), "error");
      this.render();
    } finally {
      this.busy = false;
    }
  }
  /** Reads and validates the ZIP (nothing is written), then shows the Import Preview. */
  async openBackup(f) {
    if (this.busy) return;
    this.busy = true;
    this.render(h("div", { id: "backup-status", class: "muted" }, "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u2026"));
    let entries;
    let broken;
    let backup;
    try {
      ({ entries, broken } = await readZip(new Uint8Array(await f.arrayBuffer())));
      const json = entries.get("backup.json");
      if (!json) throw new ZipError(broken.includes("backup.json") ? "backup.json \u0E40\u0E2A\u0E35\u0E22\u0E2B\u0E32\u0E22" : "\u0E44\u0E21\u0E48\u0E21\u0E35 backup.json");
      backup = JSON.parse(new TextDecoder().decode(json));
    } catch (err) {
      this.busy = false;
      const msg = err instanceof ZipError ? err.message : "\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07 ZIP";
      this.render(h("div", { id: "backup-status", class: "error-box" }, `\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49: ${msg} \u2014 \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E41\u0E15\u0E30`));
      return;
    }
    const preview = await tryCall("pu.backup.preview", { backup });
    this.busy = false;
    if (!preview) {
      this.render(h("div", { id: "backup-status", class: "error-box" }, "\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E41\u0E15\u0E30"));
      return;
    }
    const merge = h("input", { type: "radio", name: "backup-mode", value: "merge", checked: true, id: "backup-merge" });
    const replace = h("input", { type: "radio", name: "backup-mode", value: "replace", id: "backup-replace" });
    this.render(
      h(
        "div",
        { id: "backup-status", class: "card" },
        h("b", {}, `\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 ${preview.exportedAt.slice(0, 10)}${preview.appVersion ? ` (\u0E40\u0E27\u0E2D\u0E23\u0E4C\u0E0A\u0E31\u0E19 ${preview.appVersion})` : ""}`),
        h("ul", { id: "backup-counts" }, ...COUNT_LABEL.map(([k, label]) => h("li", {}, `${label}: ${preview.counts[k]}`))),
        broken.length ? h("p", { class: "notice small" }, `\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E19\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E40\u0E2A\u0E35\u0E22 ${broken.length} \u0E44\u0E1F\u0E25\u0E4C \u2014 \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2D\u0E37\u0E48\u0E19\u0E22\u0E31\u0E07\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E44\u0E14\u0E49`) : null,
        h("label", { class: "check" }, merge, "\u0E23\u0E27\u0E21\u0E01\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E14\u0E34\u0E21 (Merge \u2014 \u0E44\u0E21\u0E48\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E0B\u0E49\u0E33, \u0E02\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E43\u0E2B\u0E21\u0E48\u0E01\u0E27\u0E48\u0E32\u0E0A\u0E19\u0E30)"),
        h("label", { class: "check" }, replace, "\u0E41\u0E17\u0E19\u0E17\u0E35\u0E48\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E14\u0E34\u0E21\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 (Replace \u2014 \u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E14\u0E34\u0E21\u0E44\u0E27\u0E49\u0E01\u0E48\u0E2D\u0E19 \u0E16\u0E49\u0E32\u0E1E\u0E31\u0E07\u0E08\u0E30\u0E22\u0E49\u0E2D\u0E19\u0E01\u0E25\u0E31\u0E1A)"),
        h("button", { class: "primary", id: "backup-import", onclick: () => void this.import(backup, entries, broken, replace.checked ? "replace" : "merge") }, this.options.importOnly ? "\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25" : "\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19")
      )
    );
  }
  async import(backup, entries, broken, mode2) {
    if (this.busy) return;
    if (mode2 === "replace" && await ask("\u0E41\u0E17\u0E19\u0E17\u0E35\u0E48\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 Templates \u0E41\u0E25\u0E30\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E14\u0E49\u0E27\u0E22\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E08\u0E32\u0E01\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07?", { okLabel: "\u0E41\u0E17\u0E19\u0E17\u0E35\u0E48" }) === null) return;
    this.busy = true;
    this.render(h("div", { id: "backup-status", class: "muted" }, "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u2026"));
    try {
      const data = backup.data ?? {};
      const refs = [...data.images ?? [], ...(data.generated ?? []).map((g) => g.image)];
      const imageMap = {};
      let n = 0;
      for (const ref of refs) {
        n++;
        this.render(h("div", { id: "backup-status", class: "muted" }, `\u0E01\u0E33\u0E25\u0E31\u0E07\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E44\u0E1F\u0E25\u0E4C ${n}/${refs.length}\u2026`));
        const bytes = entries.get(ref.path);
        if (!bytes || broken.includes(ref.path) || await sha256Hex(bytes) !== ref.sha256) {
          imageMap[ref.id] = null;
          continue;
        }
        const added = await tryCall("pu.media.add", { base64: bytesToBase64(bytes), mime: ref.mimeType });
        imageMap[ref.id] = added?.assetId ?? null;
      }
      const report = await call("pu.backup.import", { backup, imageMap, mode: mode2 });
      const sum = (c) => c.products + c.templates + c.destinations;
      this.busy = false;
      this.render(
        h(
          "div",
          { id: "backup-status", class: "card ok" },
          h("b", { id: "backup-done" }, `\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E41\u0E25\u0E49\u0E27 (${mode2 === "merge" ? "Merge" : "Replace"}): \u0E40\u0E1E\u0E34\u0E48\u0E21 ${sum(report.added)} \xB7 \u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15 ${sum(report.updated)} \xB7 \u0E44\u0E1F\u0E25\u0E4C ${report.added.productImages}${report.keptLocal ? ` \xB7 \u0E04\u0E07\u0E02\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21\u0E17\u0E35\u0E48\u0E43\u0E2B\u0E21\u0E48\u0E01\u0E27\u0E48\u0E32 ${report.keptLocal}` : ""}`),
          ...report.warnings.map((w) => h("p", { class: "notice small" }, w))
        )
      );
      this.options.onImported?.();
    } catch (err) {
      this.busy = false;
      this.render(h("div", { id: "backup-status", class: "error-box" }, err instanceof Error ? err.message : String(err)));
    } finally {
      this.busy = false;
    }
  }
};
function openBackupImport(onImported) {
  if (document.getElementById("backup-home-dialog")) return;
  const dialog = h("dialog", { id: "backup-home-dialog", class: "ask backup-import-dialog", "aria-labelledby": "backup-title" });
  const root = h("div");
  const panel = new BackupPanel(root, { importOnly: true, onImported });
  const close = () => {
    if (panel.isBusy) {
      toast("\u0E01\u0E33\u0E25\u0E31\u0E07\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32 \u2014 \u0E23\u0E2D\u0E43\u0E2B\u0E49\u0E40\u0E2A\u0E23\u0E47\u0E08\u0E01\u0E48\u0E2D\u0E19\u0E1B\u0E34\u0E14");
      return;
    }
    dialog.close();
    dialog.remove();
  };
  dialog.addEventListener("cancel", (event) => {
    event.preventDefault();
    close();
  });
  dialog.append(root, h("button", { id: "backup-close", onclick: close }, "\u0E1B\u0E34\u0E14"));
  document.body.append(dialog);
  dialog.showModal();
}

// src/ui-shared/send-timing-panel.ts
function timingChannel(type) {
  return type === "FACEBOOK_GROUP" ? "group" : type === "FACEBOOK_FEED" ? "feed" : type === "LINE_OPENCHAT" ? "line" : "chat";
}
var SendTimingPanel = class {
  constructor(channel) {
    this.channel = channel;
    this.min = h("input", { type: "number", min: 5, max: 600, step: 1, required: true, "data-delay-min": channel });
    this.max = h("input", { type: "number", min: 5, max: 600, step: 1, required: true, "data-delay-max": channel });
    for (const input of [this.min, this.max]) input.addEventListener("input", () => {
      this.dirty = true;
      this.max.setCustomValidity("");
      this.status.textContent = "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01";
    });
    const save = h("button", { type: "submit", class: "small-btn" }, "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E40\u0E27\u0E25\u0E32");
    const form = h(
      "form",
      { class: "send-timing", "data-send-timing": channel },
      h("b", {}, "\u0E2A\u0E38\u0E48\u0E21\u0E2B\u0E19\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23 (\u0E27\u0E34\u0E19\u0E32\u0E17\u0E35)"),
      h(
        "div",
        { class: "send-timing-fields" },
        h("label", {}, "\u0E15\u0E48\u0E33\u0E2A\u0E38\u0E14", this.min),
        h("label", {}, "\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14", this.max)
      ),
      h("p", { class: "muted small" }, "5\u2013600 \u0E27\u0E34\u0E19\u0E32\u0E17\u0E35 \xB7 \u0E1E\u0E31\u0E01\u0E2B\u0E25\u0E31\u0E07\u0E2A\u0E48\u0E07\u0E2B\u0E23\u0E37\u0E2D\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E15\u0E48\u0E25\u0E30\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E43\u0E19\u0E2B\u0E21\u0E27\u0E14\u0E19\u0E35\u0E49 \xB7 \u0E04\u0E48\u0E32\u0E40\u0E17\u0E48\u0E32\u0E01\u0E31\u0E19 = \u0E40\u0E27\u0E25\u0E32\u0E04\u0E07\u0E17\u0E35\u0E48"),
      h("div", { class: "row" }, save, this.status)
    );
    form.addEventListener("submit", (ev) => {
      ev.preventDefault();
      if (Number(this.min.value) > Number(this.max.value)) {
        this.max.setCustomValidity("\u0E40\u0E27\u0E25\u0E32\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14\u0E15\u0E49\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E40\u0E27\u0E25\u0E32\u0E15\u0E48\u0E33\u0E2A\u0E38\u0E14");
        this.max.reportValidity();
        return;
      }
      const range = { minSec: Number(this.min.value), maxSec: Number(this.max.value) };
      save.disabled = true;
      void tryCall("settings.sendTiming.update", { channel, range }).then((settings) => {
        if (!settings) return;
        if (Number(this.min.value) === range.minSec && Number(this.max.value) === range.maxSec) {
          this.dirty = false;
          this.apply(settings);
        }
        toast("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E40\u0E27\u0E25\u0E32\u0E02\u0E2D\u0E07\u0E2B\u0E21\u0E27\u0E14\u0E19\u0E35\u0E49\u0E41\u0E25\u0E49\u0E27");
      }).finally(() => {
        save.disabled = false;
      });
    });
    this.element = form;
  }
  element;
  min;
  max;
  status = h("span", { class: "muted small", role: "status" });
  dirty = false;
  async load() {
    const settings = await tryCall("settings.get", {});
    if (settings) this.apply(settings);
  }
  apply(settings) {
    if (this.dirty) return;
    const range = delayRange(settings, this.channel);
    this.min.value = String(range.minSec);
    this.max.value = String(range.maxSec);
    this.status.textContent = settings.productUpdate.channelDelays?.[this.channel] ? `\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27: ${range.minSec}\u2013${range.maxSec} \u0E27\u0E34\u0E19\u0E32\u0E17\u0E35` : `\u0E43\u0E0A\u0E49\u0E40\u0E27\u0E25\u0E32\u0E40\u0E14\u0E34\u0E21 ${range.minSec} \u0E27\u0E34\u0E19\u0E32\u0E17\u0E35 \u2014 \u0E01\u0E14\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E43\u0E0A\u0E49\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E02\u0E2D\u0E07\u0E2B\u0E21\u0E27\u0E14\u0E19\u0E35\u0E49`;
  }
};

// src/app/views/product-update/daily.ts
var DESTINATION_CATEGORIES = [
  { type: "FACEBOOK_GROUP_CHAT", label: "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17", icon: "\u{1F4AC}" },
  { type: "FACEBOOK_GROUP", label: "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E40\u0E1F\u0E2A", icon: "\u{1F465}" },
  { type: "FACEBOOK_FEED", label: "\u0E40\u0E1E\u0E08 / \u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C", icon: "\u{1F4E3}" },
  { type: "LINE_OPENCHAT", label: "LINE OpenChat", icon: "\u{1F7E2}" }
];
var DailyView = class {
  constructor(root, go, channel) {
    this.root = root;
    this.go = go;
    this.channel = channel;
    if (channel) this.withCard = false;
  }
  timings = /* @__PURE__ */ new Map();
  ctx = null;
  date = todayYmd();
  products = /* @__PURE__ */ new Set();
  destinations = /* @__PURE__ */ new Set();
  preview = null;
  initialised = false;
  card = null;
  /** The day's AI visual style (ADR-64). */
  style = null;
  /** Send the date card before the products (null = follow the card settings). */
  withCard = null;
  fieldId(id2) {
    return this.channel ? `${id2}-${this.channel}` : id2;
  }
  selector(selector) {
    return selector.replace(/#([\w-]+)/g, (_match, id2) => `#${this.fieldId(id2)}`);
  }
  async refresh() {
    const styleCmd = !this.channel && this.date === todayYmd() ? "pu.dateStyle.ensure" : "pu.dateStyle.get";
    const [ctx, card, style] = await Promise.all([tryCall("pu.daily.context", {}), tryCall("pu.dateCard.get", { date: this.date }), tryCall(styleCmd, { date: this.date })]);
    if (!ctx) return;
    if (this.channel) ctx.destinations = ctx.destinations.filter((d) => d.type === this.channel);
    this.ctx = ctx;
    this.card = card ?? null;
    this.style = style ?? null;
    const activeIds = new Set(ctx.products.map((p) => p.id));
    const destIds = new Set(ctx.destinations.map((d) => d.id));
    if (!this.initialised) {
      this.initialised = true;
      const lastP = ctx.last?.productIds.filter((id2) => activeIds.has(id2)) ?? [];
      this.products = new Set(lastP.length ? lastP : ctx.products.map((p) => p.id));
      const lastD = ctx.last?.destinationIds.filter((id2) => destIds.has(id2)) ?? [];
      this.destinations = new Set(lastD.length ? lastD : ctx.destinations.slice(0, 1).map((d) => d.id));
    } else {
      this.products = new Set([...this.products].filter((id2) => activeIds.has(id2)));
      this.destinations = new Set([...this.destinations].filter((id2) => destIds.has(id2)));
    }
    await Promise.all(DESTINATION_CATEGORIES.filter((c) => !this.channel || c.type === this.channel).map((c) => this.timing(c.type).load()));
    this.render();
  }
  timing(type) {
    let panel = this.timings.get(type);
    if (!panel) {
      panel = new SendTimingPanel(timingChannel(type));
      this.timings.set(type, panel);
    }
    return panel;
  }
  render() {
    const ctx = this.ctx;
    if (!ctx) return;
    if (!ctx.products.length || !ctx.destinations.length) {
      fill(
        this.root,
        h("h2", {}, this.channel ? "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E25\u0E30\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07" : say("Today's Update", "\u0E2A\u0E48\u0E07\u0E02\u0E2D\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49")),
        this.importShortcut(),
        h("p", {}, "\u0E40\u0E23\u0E34\u0E48\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 2 \u0E02\u0E31\u0E49\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E35\u0E49\u0E08\u0E30\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E2A\u0E48\u0E07\u0E17\u0E38\u0E01\u0E27\u0E31\u0E19:"),
        h(
          "ol",
          {},
          h("li", {}, ctx.products.length ? "\u2713 \u0E21\u0E35\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E25\u0E49\u0E27" : h("button", { class: "link", onclick: () => this.go("products") }, "\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32")),
          h("li", {}, ctx.destinations.length ? "\u2713 \u0E21\u0E35\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E41\u0E25\u0E49\u0E27" : h("button", { class: "link", onclick: () => this.go("destinations") }, "\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07"))
        )
      );
      return;
    }
    const date = h("input", { type: "date", id: this.fieldId("du-date"), value: this.date });
    date.addEventListener("change", () => {
      this.date = date.value || todayYmd();
      this.preview = null;
      void this.refreshCard();
    });
    const destChips = h(
      "div",
      { class: "du-destination-groups", id: this.fieldId("du-destinations") },
      ...DESTINATION_CATEGORIES.map((category) => {
        const destinations = ctx.destinations.filter((d) => d.type === category.type);
        if (!destinations.length) return null;
        const headingId = this.fieldId(`du-destination-heading-${category.type}`);
        const selected = destinations.filter((d) => this.destinations.has(d.id)).length;
        return h(
          "section",
          { class: "du-destination-category", "data-destination-type": category.type, "aria-labelledby": headingId },
          h(
            "div",
            { class: "row between du-destination-heading" },
            h("h4", { id: headingId }, h("span", { "aria-hidden": "true" }, category.icon), ` ${category.label}`),
            h("span", { class: "muted small" }, `\u0E40\u0E25\u0E37\u0E2D\u0E01 ${selected}/${destinations.length}`)
          ),
          this.timing(category.type).element,
          h("div", { class: "chips" }, ...destinations.map((d) => {
            const on = this.destinations.has(d.id);
            return h(
              "button",
              {
                class: "chip tag",
                "aria-pressed": String(on),
                "data-destination": d.id,
                title: isPost(d) ? `\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E1A\u0E19 ${d.chatReference.url}` : isLine(d) ? d.verifiedTitle ? `\u0E2B\u0E49\u0E2D\u0E07 LINE "${d.verifiedTitle}"` : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07" : d.verifiedTitle ? `\u0E41\u0E0A\u0E17 "${d.verifiedTitle}"` : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E0A\u0E17",
                onclick: () => {
                  if (on) this.destinations.delete(d.id);
                  else this.destinations.add(d.id);
                  this.preview = null;
                  this.render();
                }
              },
              h("span", { "aria-hidden": "true" }, `${on ? "\u2713 " : ""}${category.icon}`),
              ` ${d.name}${isFeed(d) || d.verifiedTitle ? "" : isGroup(d) ? " (\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E01\u0E25\u0E38\u0E48\u0E21)" : isLine(d) ? " (\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07)" : say(" (!)", " (\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E23\u0E27\u0E08\u0E41\u0E0A\u0E17)")}`
            );
          }))
        );
      })
    );
    const list = h(
      "div",
      { class: "pu-list", id: this.fieldId("du-products") },
      ...ctx.products.map((p, i) => {
        const cb = h("input", { type: "checkbox", checked: this.products.has(p.id), "aria-label": p.name });
        cb.addEventListener("change", () => {
          if (cb.checked) this.products.add(p.id);
          else this.products.delete(p.id);
          this.preview = null;
          this.renderSummary();
        });
        return h(
          "label",
          { class: "pu-row pu-pick", "data-product": p.id },
          cb,
          thumb(p.images[0], p.name),
          h("span", { class: "pu-main" }, h("b", { class: "pu-name" }, `${String(i + 1).padStart(2, "0")} ${p.name}`), h("span", { class: "muted small" }, p.imagesOnly ? `\u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E39\u0E1B/\u0E04\u0E25\u0E34\u0E1B ${p.images.length} \u0E44\u0E1F\u0E25\u0E4C` : `\u0E23\u0E39\u0E1B/\u0E04\u0E25\u0E34\u0E1B ${p.images.length} \u0E44\u0E1F\u0E25\u0E4C${p.description.trim() ? " + \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21" : ""}`))
        );
      })
    );
    const setAll = (ids) => {
      this.products = new Set(ids);
      this.preview = null;
      this.render();
    };
    const setDestinations = (ids) => {
      this.destinations = new Set(ids);
      this.preview = null;
      this.render();
    };
    fill(
      this.root,
      h("div", { class: "row between du-head" }, h("h2", {}, this.channel ? "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E25\u0E30\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07" : say("Today's Update", "\u0E2A\u0E48\u0E07\u0E02\u0E2D\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49")), date),
      this.importShortcut(),
      h(
        "div",
        { class: "du-layout" },
        h(
          "div",
          { class: "du-steps" },
          h("section", { class: "du-step" }, h("h3", { class: "du-step-title" }, h("span", { class: "du-step-no" }, "1"), "\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48"), h("div", { id: this.fieldId("du-card"), class: "du-card" })),
          h(
            "section",
            { class: "du-step" },
            h(
              "div",
              { class: "row between du-destination-toolbar" },
              h("h3", { class: "du-step-title" }, h("span", { class: "du-step-no" }, "2"), "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07"),
              h(
                "div",
                { class: "row" },
                h("button", { class: "small-btn", id: this.fieldId("du-destinations-all"), disabled: ctx.destinations.every((d) => this.destinations.has(d.id)), onclick: () => setDestinations(ctx.destinations.map((d) => d.id)) }, "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14"),
                h("button", { class: "small-btn", id: this.fieldId("du-destinations-clear"), disabled: this.destinations.size === 0, onclick: () => setDestinations([]) }, "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14")
              )
            ),
            destChips
          ),
          h(
            "section",
            { class: "du-step" },
            h(
              "div",
              { class: "row between" },
              h("label", { class: "du-step-title" }, h("span", { class: "du-step-no" }, "3"), "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"),
              h(
                "div",
                { class: "row" },
                h("button", { class: "small-btn", id: this.fieldId("du-all"), onclick: () => setAll(ctx.products.map((p) => p.id)) }, "\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14"),
                ctx.last ? h("button", { class: "small-btn", id: this.fieldId("du-last"), onclick: () => setAll(ctx.last.productIds) }, "\u0E40\u0E2B\u0E21\u0E37\u0E2D\u0E19\u0E04\u0E23\u0E31\u0E49\u0E07\u0E01\u0E48\u0E2D\u0E19") : null,
                h("button", { class: "small-btn", onclick: () => setAll([]) }, "\u0E25\u0E49\u0E32\u0E07")
              )
            ),
            list
          ),
          h("div", { id: this.fieldId("du-preview") })
        ),
        h("aside", { class: "du-side" }, h("div", { class: "du-side-title" }, "\u0E2A\u0E23\u0E38\u0E1B\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07"), h("div", { class: "sticky-actions", id: this.fieldId("du-actions") }), h("p", { class: "du-side-note" }, this.channel === "FACEBOOK_FEED" || this.channel === "FACEBOOK_GROUP" ? "\u0E41\u0E19\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E25\u0E30\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E43\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E40\u0E14\u0E35\u0E22\u0E27\u0E15\u0E48\u0E2D\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32" : this.channel === "LINE_OPENCHAT" ? "\u0E2A\u0E48\u0E07\u0E23\u0E39\u0E1B\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E15\u0E32\u0E21\u0E14\u0E49\u0E27\u0E22\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \u0E1C\u0E48\u0E32\u0E19 LINE PC \xB7 \u0E2D\u0E22\u0E48\u0E32\u0E41\u0E15\u0E30\u0E40\u0E21\u0E32\u0E2A\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E2A\u0E48\u0E07" : "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17\u0E2A\u0E48\u0E07\u0E23\u0E39\u0E1B\u0E01\u0E48\u0E2D\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \xB7 \u0E40\u0E1E\u0E08\u0E41\u0E25\u0E30\u0E01\u0E25\u0E38\u0E48\u0E21\u0E40\u0E1F\u0E2A\u0E41\u0E19\u0E1A\u0E23\u0E39\u0E1B\u0E01\u0E31\u0E1A\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E43\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E40\u0E14\u0E35\u0E22\u0E27"))
      )
    );
    this.renderCard();
    this.renderSummary();
  }
  importShortcut() {
    if (this.channel) return null;
    return h(
      "div",
      { class: "home-import" },
      h("button", { id: "daily-import", onclick: () => openBackupImport(() => {
        this.initialised = false;
        this.preview = null;
        void this.refresh();
      }) }, "\u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E08\u0E32\u0E01\u0E44\u0E1F\u0E25\u0E4C Export"),
      h("p", { class: "muted small" }, "\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E08\u0E32\u0E01 Chrome \u0E40\u0E14\u0E34\u0E21? \u0E19\u0E33\u0E40\u0E02\u0E49\u0E32\u0E44\u0E1F\u0E25\u0E4C Export Backup (.zip) \u0E44\u0E14\u0E49\u0E17\u0E35\u0E48\u0E19\u0E35\u0E48")
    );
  }
  get sendCard() {
    const s = this.card?.settings;
    if (!s?.enabled) return false;
    return this.withCard ?? true;
  }
  /** Live updates (card being made): only the card box and the summary, never the whole form. */
  async refreshCard() {
    const [card, style] = await Promise.all([tryCall("pu.dateCard.get", { date: this.date }), tryCall("pu.dateStyle.get", { date: this.date })]);
    if (!card) return;
    this.card = card;
    this.style = style ?? this.style;
    this.renderCard();
    this.renderSummary();
  }
  renderCard() {
    const box = this.root.querySelector(this.selector("#du-card"));
    const state = this.card;
    if (!box || !state) return;
    const s = state.settings;
    const editing = box.querySelector(this.selector("details#du-card-settings"))?.open;
    const status = box.querySelector(this.selector("#du-card-status"));
    if (editing && status && s.enabled) {
      status.textContent = state.generating ? `\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u2026 ${state.generating.progress ?? ""}` : state.card ? "\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E2A\u0E48\u0E07" : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E23\u0E49\u0E32\u0E07";
      this.renderStyleLive(box);
      return;
    }
    const form = this.cardSettingsForm(s);
    if (!s.enabled) {
      fill(box, h("details", { id: this.fieldId("du-card-settings") }, h("summary", {}, "\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 (\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48) \u2014 \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32"), form));
      return;
    }
    const busy = Boolean(state.generating);
    const include = h("input", { type: "checkbox", id: this.fieldId("du-with-card"), checked: this.sendCard });
    include.addEventListener("change", () => {
      this.withCard = include.checked;
      this.preview = null;
      this.renderSummary();
    });
    fill(
      box,
      h(
        "div",
        { class: "pu-row" },
        state.card ? thumb(state.card.assetId, "\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48") : h("span", { class: "pu-thumb" }, "\u{1F5D3}"),
        h(
          "div",
          { class: "pu-main" },
          h("b", {}, `\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 ${thaiLongDate(this.date)}`),
          h(
            "span",
            { class: "muted small", id: this.fieldId("du-card-status") },
            busy ? `\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u2026 ${state.generating?.progress ?? ""}` : state.card ? "\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E2A\u0E48\u0E07" : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E23\u0E49\u0E32\u0E07 \u2014 \u0E01\u0E14 SEND TODAY \u0E41\u0E25\u0E49\u0E27\u0E23\u0E30\u0E1A\u0E1A\u0E08\u0E30\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E43\u0E2B\u0E49\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07"
          )
        ),
        h(
          "button",
          { class: "small-btn", id: this.fieldId("du-card-generate"), disabled: busy, onclick: () => void tryCall("pu.dateCard.generate", { date: this.date }).then((r) => r && (toast("\u0E2A\u0E31\u0E48\u0E07 ChatGPT \u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E41\u0E25\u0E49\u0E27"), void this.refreshCard())) },
          state.card ? "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E43\u0E2B\u0E21\u0E48" : "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22"
        )
      ),
      state.lastError ? h("div", { class: "error-box small" }, state.lastError) : null,
      h("label", { class: "check" }, include, `\u0E2A\u0E48\u0E07\u0E1B\u0E49\u0E32\u0E22 \xD7${s.repeat} \u0E01\u0E48\u0E2D\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32`),
      h("details", { id: this.fieldId("du-card-settings") }, h("summary", {}, "\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48"), form)
    );
  }
  /** Status + "สร้างสไตล์ใหม่" / lock of the day's AI style. */
  styleControls() {
    const st = this.style;
    const locked = Boolean(st?.style?.locked);
    const busy = Boolean(st?.generating);
    return h(
      "div",
      { class: "du-style", id: this.fieldId("dc-style-box") },
      h("div", { class: "muted small", id: this.fieldId("dc-style-status") }, this.styleStatus()),
      h(
        "div",
        { class: "row" },
        h(
          "button",
          {
            class: "small-btn",
            id: this.fieldId("dc-style-generate"),
            disabled: busy || locked,
            title: locked ? "\u0E1B\u0E25\u0E14\u0E25\u0E47\u0E2D\u0E01\u0E01\u0E48\u0E2D\u0E19" : "",
            onclick: () => void tryCall("pu.dateStyle.generate", { date: this.date }).then((r) => r && (toast("\u0E01\u0E33\u0E25\u0E31\u0E07\u0E43\u0E2B\u0E49 AI \u0E04\u0E34\u0E14\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E43\u0E2B\u0E21\u0E48 \u2014 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B"), void this.refreshCard()))
          },
          "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E43\u0E2B\u0E21\u0E48"
        ),
        h(
          "button",
          { class: "small-btn", id: this.fieldId("dc-style-lock"), onclick: () => void tryCall("pu.dateStyle.lock", { date: this.date, locked: !locked }).then((r) => r && (this.style = r, this.rerenderForm())) },
          locked ? "\u0E1B\u0E25\u0E14\u0E25\u0E47\u0E2D\u0E01\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49" : "\u0E25\u0E47\u0E2D\u0E01\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49"
        )
      )
    );
  }
  styleStatus() {
    const st = this.style;
    if (!st) return "";
    if (st.generating) return `\u0E01\u0E33\u0E25\u0E31\u0E07\u0E43\u0E2B\u0E49 AI \u0E04\u0E34\u0E14\u0E2A\u0E44\u0E15\u0E25\u0E4C\u2026 ${st.generating.progress ?? ""}`;
    const from = { today: "\u0E02\u0E2D\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49", latest: "\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14 (\u0E27\u0E31\u0E19\u0E01\u0E48\u0E2D\u0E19)", manual: "\u0E17\u0E35\u0E48\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E44\u0E27\u0E49", default: "\u0E40\u0E23\u0E34\u0E48\u0E21\u0E15\u0E49\u0E19" }[st.effective.from];
    const lock = st.style?.locked ? " \xB7 \u{1F512} \u0E25\u0E47\u0E2D\u0E01\u0E41\u0E25\u0E49\u0E27" : "";
    const who = st.style ? st.style.source === "ai" ? "AI" : "\u0E41\u0E01\u0E49\u0E40\u0E2D\u0E07" : "";
    if (st.lastError) return `\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08: ${st.lastError} \u2014 \u0E43\u0E0A\u0E49\u0E2A\u0E44\u0E15\u0E25\u0E4C${from}\u0E41\u0E17\u0E19${lock}`;
    return `\u0E43\u0E0A\u0E49\u0E2A\u0E44\u0E15\u0E25\u0E4C${from}${who ? ` (${who})` : ""}${lock}`;
  }
  /** While the settings are open: refresh the style status, and the text when a new style arrives (unless being typed in). */
  renderStyleLive(box) {
    const status = box.querySelector(this.selector("#dc-style-status"));
    if (status) status.textContent = this.styleStatus();
    const gen = box.querySelector(this.selector("#dc-style-generate"));
    if (gen) gen.disabled = Boolean(this.style?.generating) || Boolean(this.style?.style?.locked);
    const text2 = box.querySelector(this.selector("#dc-style"));
    const latest = this.style?.style?.stylePrompt;
    if (text2 && latest && text2.dataset["dirty"] !== "1" && this.card?.settings.autoStyle && text2.value !== latest) text2.value = latest;
  }
  /** Re-renders the card box keeping the settings open. */
  rerenderForm() {
    const box = this.root.querySelector(this.selector("#du-card"));
    const wasOpen = box?.querySelector(this.selector("details#du-card-settings"))?.open;
    const details = box?.querySelector(this.selector("details#du-card-settings"));
    if (details) details.open = false;
    this.renderCard();
    const again = box?.querySelector(this.selector("details#du-card-settings"));
    if (again && wasOpen) again.open = true;
  }
  cardSettingsForm(s) {
    const enabled = h("input", { type: "checkbox", id: this.fieldId("dc-enabled"), checked: s.enabled });
    const shop = h("input", { type: "text", id: this.fieldId("dc-shop"), maxlength: 80, value: s.shopName, placeholder: "\u0E40\u0E0A\u0E48\u0E19 Jatupon Seafoods" });
    const headline = h("input", { type: "text", id: this.fieldId("dc-headline"), maxlength: 120, value: s.headline });
    const details = h("textarea", { id: this.fieldId("dc-details"), rows: 3, maxlength: 400, placeholder: "\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E25\u0E30 1 \u0E2D\u0E22\u0E48\u0E32\u0E07 \u0E40\u0E0A\u0E48\u0E19 \u0E42\u0E17\u0E23 09x-xxx-xxxx / LINE @xxxx" });
    details.value = s.details;
    const st = this.style;
    const autoStyle = h("input", { type: "checkbox", id: this.fieldId("dc-auto-style"), checked: s.autoStyle });
    const business = h("input", { type: "text", id: this.fieldId("dc-business"), maxlength: 300, value: s.business, placeholder: "\u0E40\u0E27\u0E49\u0E19\u0E27\u0E48\u0E32\u0E07 = \u0E02\u0E32\u0E22\u0E2A\u0E48\u0E07/\u0E08\u0E31\u0E14\u0E2A\u0E48\u0E07\u0E2D\u0E32\u0E2B\u0E32\u0E23\u0E17\u0E30\u0E40\u0E25 \u0E43\u0E19\u0E44\u0E17\u0E22" });
    const style = h("textarea", { id: this.fieldId("dc-style"), rows: 4, maxlength: s.autoStyle ? 1500 : 600, placeholder: "\u0E40\u0E27\u0E49\u0E19\u0E27\u0E48\u0E32\u0E07 = \u0E1B\u0E49\u0E32\u0E22\u0E23\u0E49\u0E32\u0E19\u0E2D\u0E32\u0E2B\u0E32\u0E23\u0E17\u0E30\u0E40\u0E25 \u0E42\u0E17\u0E19\u0E1F\u0E49\u0E32-\u0E19\u0E49\u0E33\u0E40\u0E07\u0E34\u0E19 \u0E21\u0E35\u0E20\u0E32\u0E1E\u0E2D\u0E32\u0E2B\u0E32\u0E23\u0E17\u0E30\u0E40\u0E25" });
    style.value = s.autoStyle ? st?.style?.stylePrompt ?? st?.effective.text ?? s.style : s.style;
    style.addEventListener("input", () => style.dataset["dirty"] = "1");
    const shownStyle = style.value;
    const aspect = h("select", { id: this.fieldId("dc-aspect") }, ...["16:9", "1:1", "4:5"].map((a) => h("option", { value: a, selected: s.aspect === a }, { "16:9": "\u0E41\u0E19\u0E27\u0E19\u0E2D\u0E19 16:9", "1:1": "\u0E08\u0E31\u0E15\u0E38\u0E23\u0E31\u0E2A 1:1", "4:5": "\u0E41\u0E19\u0E27\u0E15\u0E31\u0E49\u0E07 4:5" }[a])));
    const repeat = h("input", { type: "number", id: this.fieldId("dc-repeat"), min: 1, max: 10, value: String(s.repeat) });
    const save = async () => {
      const next = {
        enabled: enabled.checked,
        shopName: shop.value.trim(),
        headline: headline.value.trim() || "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 {date}",
        details: details.value,
        // Auto on: the typed (manual) style stays as it was; the box edits the day's style instead.
        style: autoStyle.checked && s.autoStyle ? s.style : style.value,
        aspect: aspect.value,
        repeat: Math.min(10, Math.max(1, Math.round(Number(repeat.value) || 1))),
        autoStyle: autoStyle.checked,
        business: business.value.trim()
      };
      if (autoStyle.checked && s.autoStyle && style.value.trim() && style.value !== shownStyle) {
        await tryCall("pu.dateStyle.save", { date: this.date, text: style.value });
      }
      if (await tryCall("pu.dateCard.save", { settings: next })) {
        toast("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E1B\u0E49\u0E32\u0E22\u0E41\u0E25\u0E49\u0E27");
        this.preview = null;
        await this.refreshCard();
      }
    };
    return h(
      "div",
      { class: "du-card-form" },
      h("label", { class: "check" }, enabled, "\u0E43\u0E0A\u0E49\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 (ChatGPT \u0E2A\u0E23\u0E49\u0E32\u0E07\u0E20\u0E32\u0E1E\u0E43\u0E2B\u0E49\u0E17\u0E38\u0E01\u0E27\u0E31\u0E19)"),
      h("label", { for: this.fieldId("dc-shop") }, "\u0E0A\u0E37\u0E48\u0E2D\u0E23\u0E49\u0E32\u0E19\u0E1A\u0E19\u0E1B\u0E49\u0E32\u0E22"),
      shop,
      h("label", { for: this.fieldId("dc-headline") }, "\u0E2B\u0E31\u0E27\u0E02\u0E49\u0E2D ({date} = \u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 \u0E40\u0E0A\u0E48\u0E19 26 \u0E01\u0E31\u0E19\u0E22\u0E32\u0E22\u0E19 2569)"),
      headline,
      h("label", { for: this.fieldId("dc-details") }, "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E40\u0E15\u0E34\u0E21\u0E1A\u0E19\u0E1B\u0E49\u0E32\u0E22"),
      details,
      h("label", { for: this.fieldId("dc-style") }, "\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E"),
      h("label", { class: "check" }, autoStyle, "AI \u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E43\u0E2B\u0E21\u0E48\u0E17\u0E38\u0E01\u0E27\u0E31\u0E19 (\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E1A\u0E19\u0E1B\u0E49\u0E32\u0E22\u0E22\u0E31\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E15\u0E32\u0E21\u0E17\u0E35\u0E48\u0E15\u0E31\u0E49\u0E07\u0E44\u0E27\u0E49)"),
      style,
      s.autoStyle ? this.styleControls() : h("p", { class: "muted small" }, '\u0E40\u0E1B\u0E34\u0E14 "AI \u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E43\u0E2B\u0E21\u0E48\u0E17\u0E38\u0E01\u0E27\u0E31\u0E19" \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01 \u2014 \u0E20\u0E32\u0E1E\u0E1B\u0E49\u0E32\u0E22\u0E08\u0E30\u0E44\u0E21\u0E48\u0E0B\u0E49\u0E33\u0E40\u0E14\u0E34\u0E21\u0E17\u0E38\u0E01\u0E27\u0E31\u0E19'),
      h("label", { for: this.fieldId("dc-business") }, "\u0E18\u0E38\u0E23\u0E01\u0E34\u0E08\u0E02\u0E2D\u0E07\u0E23\u0E49\u0E32\u0E19 (\u0E43\u0E2B\u0E49 AI \u0E43\u0E0A\u0E49\u0E04\u0E34\u0E14\u0E09\u0E32\u0E01 \u0E44\u0E21\u0E48\u0E40\u0E02\u0E35\u0E22\u0E19\u0E1A\u0E19\u0E1B\u0E49\u0E32\u0E22)"),
      business,
      h("div", { class: "row" }, h("div", { style: "flex:1" }, h("label", { for: this.fieldId("dc-aspect") }, "\u0E2A\u0E31\u0E14\u0E2A\u0E48\u0E27\u0E19"), aspect), h("div", { style: "flex:1" }, h("label", { for: this.fieldId("dc-repeat") }, "\u0E2A\u0E48\u0E07\u0E01\u0E35\u0E48\u0E04\u0E23\u0E31\u0E49\u0E07"), repeat)),
      h("p", { class: "muted small" }, '\u0E1B\u0E49\u0E32\u0E22\u0E44\u0E21\u0E48\u0E21\u0E35 QR code (AI \u0E27\u0E32\u0E14 QR \u0E17\u0E35\u0E48\u0E2A\u0E41\u0E01\u0E19\u0E44\u0E14\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49) \xB7 \u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23\u0E44\u0E17\u0E22\u0E17\u0E35\u0E48 AI \u0E40\u0E02\u0E35\u0E22\u0E19\u0E2D\u0E32\u0E08\u0E1C\u0E34\u0E14\u0E1A\u0E49\u0E32\u0E07 \u2014 \u0E01\u0E14 "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E43\u0E2B\u0E21\u0E48" \u0E44\u0E14\u0E49'),
      h("button", { class: "primary", id: this.fieldId("dc-save"), onclick: () => void save() }, "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E1B\u0E49\u0E32\u0E22")
    );
  }
  /** Summary + actions (preview first, then SEND TODAY). */
  renderSummary() {
    const actions = this.root.querySelector(this.selector("#du-actions"));
    const previewBox = this.root.querySelector(this.selector("#du-preview"));
    if (!actions || !previewBox) return;
    const n = this.products.size;
    const d = this.destinations.size;
    const cards = this.sendCard ? this.card?.settings.repeat ?? 0 : 0;
    const feeds = this.ctx?.destinations.filter((x) => this.destinations.has(x.id) && isPost(x)).length ?? 0;
    const chats = d - feeds;
    fill(
      actions,
      h(
        "span",
        { class: "small du-count", id: this.fieldId("du-count") },
        feeds ? `${n} \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u2192 ${chats ? `${n * chats} \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21${cards ? ` + \u0E1B\u0E49\u0E32\u0E22 ${cards * chats}` : ""} \xB7 ` : ""}${n * feeds} \u0E42\u0E1E\u0E2A\u0E15\u0E4C` : `${n} \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \xD7 ${d} \u0E01\u0E25\u0E38\u0E48\u0E21 = ${n * d} \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21${cards ? ` + \u0E1B\u0E49\u0E32\u0E22 ${cards * d}` : ""}`
      )
    );
    if (!this.preview) {
      fill(previewBox);
      if (isSimple()) {
        actions.append(
          h("button", { class: "link small", id: this.fieldId("du-preview-btn"), disabled: n === 0 || d === 0, onclick: () => void this.loadPreview() }, "\u0E14\u0E39\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E01\u0E48\u0E2D\u0E19"),
          h("button", { class: "primary big", id: this.fieldId("du-send-now"), disabled: n === 0 || d === 0, onclick: () => void this.sendNow() }, "\u0E2A\u0E48\u0E07\u0E40\u0E25\u0E22")
        );
        return;
      }
      actions.append(h("button", { class: "primary", id: this.fieldId("du-preview-btn"), disabled: n === 0 || d === 0, onclick: () => void this.loadPreview() }, "\u0E14\u0E39\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21"));
      return;
    }
    const p = this.preview;
    fill(
      previewBox,
      h("h3", {}, `\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07 (${p.sends.length} \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21)`),
      p.issues.length ? h("ul", { class: "issues" }, ...p.issues.map((i) => h("li", {}, i.message))) : null,
      ...p.sends.slice(0, 50).map(
        (s) => h(
          "details",
          { class: "pu-msg", "data-seq": s.sequence },
          h("summary", {}, `#${String(s.sequence).padStart(2, "0")} ${s.productName} \u2192 ${s.destinationName}${s.kind === "date_card" ? s.imageAssetIds.length ? " \xB7 \u0E23\u0E39\u0E1B\u0E1B\u0E49\u0E32\u0E22" : " \xB7 \u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E15\u0E2D\u0E19\u0E2A\u0E48\u0E07" : s.imageAssetIds.length ? ` \xB7 \u0E23\u0E39\u0E1B ${s.imageAssetIds.length}` : ""}${s.message ? "" : s.kind === "date_card" ? "" : " \xB7 \u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21"}`),
          h("div", { class: "pu-msg-images" }, ...s.imageAssetIds.map((a, i) => thumb(a, `\u0E23\u0E39\u0E1B ${i + 1}`))),
          s.message ? h("pre", { class: "pu-preview" }, s.message) : null
        )
      )
    );
    actions.append(
      isSimple() ? "" : h("button", { class: "small-btn", id: this.fieldId("du-create"), disabled: p.issues.length > 0, onclick: () => void this.create(false) }, "\u0E2A\u0E23\u0E49\u0E32\u0E07 Batch (\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07)"),
      h("button", { class: isSimple() ? "primary big" : "primary", id: this.fieldId("du-send"), disabled: p.issues.length > 0, onclick: () => void this.create(true) }, say("SEND TODAY", "\u0E2A\u0E48\u0E07\u0E40\u0E25\u0E22"))
    );
  }
  /** Simple mode: preview checks, then send (or show what must be fixed first). */
  async sendNow() {
    await this.loadPreview();
    if (this.preview && !this.preview.issues.length) await this.create(true);
  }
  async loadPreview() {
    const p = await tryCall("pu.batch.preview", { productIds: [...this.products], destinationIds: [...this.destinations], date: this.date, dateCard: this.sendCard });
    if (!p) return;
    this.preview = p;
    this.renderSummary();
  }
  async create(send) {
    const n = this.preview?.sends.length ?? 0;
    if (send) {
      let warn = `\u0E2A\u0E48\u0E07 ${n} \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \u0E17\u0E35\u0E25\u0E30\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23 (\u0E40\u0E27\u0E49\u0E19\u0E23\u0E30\u0E22\u0E30\u0E15\u0E32\u0E21\u0E17\u0E35\u0E48\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32)? \u0E2B\u0E49\u0E32\u0E21\u0E1B\u0E34\u0E14 Chrome \u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E2A\u0E48\u0E07`;
      if (this.channel === "LINE_OPENCHAT") {
        const st = await tryCall("settings.get", {});
        const lock = st?.productUpdate.lineLockInput === true;
        warn = `\u0E2A\u0E48\u0E07 ${n} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E02\u0E49\u0E32 LINE OpenChat \u0E1C\u0E48\u0E32\u0E19 LINE PC \xB7 ${lock ? "\u0E40\u0E21\u0E32\u0E2A\u0E4C/\u0E04\u0E35\u0E22\u0E4C\u0E1A\u0E2D\u0E23\u0E4C\u0E14\u0E08\u0E30\u0E16\u0E39\u0E01\u0E25\u0E47\u0E2D\u0E01\u0E08\u0E19\u0E2A\u0E48\u0E07\u0E40\u0E2A\u0E23\u0E47\u0E08 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E09\u0E38\u0E01\u0E40\u0E09\u0E34\u0E19: \u0E01\u0E14 Ctrl+Alt+Del" : "\u0E2D\u0E22\u0E48\u0E32\u0E41\u0E15\u0E30\u0E40\u0E21\u0E32\u0E2A\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E2A\u0E48\u0E07 \u2014 \u0E16\u0E49\u0E32\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E2B\u0E22\u0E38\u0E14 \u0E04\u0E25\u0E34\u0E01\u0E17\u0E35\u0E48\u0E2D\u0E37\u0E48\u0E19\u0E19\u0E2D\u0E01 LINE \u0E41\u0E25\u0E49\u0E27\u0E07\u0E32\u0E19\u0E08\u0E30\u0E2B\u0E22\u0E38\u0E14\u0E23\u0E2D\u0E43\u0E2B\u0E49\u0E01\u0E14\u0E15\u0E48\u0E2D"} \xB7 \u0E2B\u0E49\u0E32\u0E21\u0E1B\u0E34\u0E14 Chrome`;
      }
      if (await ask(warn, { okLabel: "\u0E40\u0E23\u0E34\u0E48\u0E21\u0E2A\u0E48\u0E07" }) === null) return;
    }
    const batch = await tryCall("pu.batch.create", { date: this.date, productIds: [...this.products], destinationIds: [...this.destinations], dateCard: this.sendCard });
    if (!batch) return;
    this.preview = null;
    if (send) {
      const started = await tryCall("pu.batch.start", { batchId: batch.id });
      if (started) toast(started.generating ? "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 \u2014 \u0E08\u0E30\u0E40\u0E23\u0E34\u0E48\u0E21\u0E2A\u0E48\u0E07\u0E40\u0E2D\u0E07\u0E40\u0E21\u0E37\u0E48\u0E2D\u0E1B\u0E49\u0E32\u0E22\u0E40\u0E2A\u0E23\u0E47\u0E08" : say(`\u0E40\u0E02\u0E49\u0E32\u0E04\u0E34\u0E27\u0E41\u0E25\u0E49\u0E27 ${started.queued} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23`, `\u0E40\u0E23\u0E34\u0E48\u0E21\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27 ${started.queued} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23`));
    } else toast("\u0E2A\u0E23\u0E49\u0E32\u0E07 Batch \u0E41\u0E25\u0E49\u0E27 \u2014 \u0E01\u0E14 START SEND \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Queue \u0E40\u0E21\u0E37\u0E48\u0E2D\u0E1E\u0E23\u0E49\u0E2D\u0E21");
    this.go("queue", batch.id);
  }
};

// src/app/views/product-update/destinations.ts
var DestinationsView = class {
  constructor(root, type) {
    this.root = root;
    this.type = type;
  }
  items = [];
  fieldId(id2) {
    return this.type && this.type !== "FACEBOOK_GROUP_CHAT" ? `${id2}-${this.type}` : id2;
  }
  async refresh() {
    const d = await tryCall("pu.destinations.list", {});
    if (!d) return;
    this.items = this.type ? d.filter((x) => x.type === this.type) : d;
    this.renderList();
  }
  renderList() {
    fill(
      this.root,
      h(
        "div",
        { class: "row pu-toolbar" },
        !this.type || this.type === "FACEBOOK_GROUP_CHAT" ? h("button", { class: "primary", id: "pu-add-destination", onclick: () => this.edit(null, "FACEBOOK_GROUP_CHAT") }, "+ \u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17") : null,
        !this.type || this.type === "FACEBOOK_FEED" ? h("button", { class: "primary", id: "pu-add-feed", onclick: () => this.edit(null, "FACEBOOK_FEED") }, "+ \u0E40\u0E1E\u0E08 / \u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C") : null,
        !this.type || this.type === "FACEBOOK_GROUP" ? h("button", { class: "primary", id: "pu-add-group", onclick: () => this.edit(null, "FACEBOOK_GROUP") }, "+ \u0E01\u0E25\u0E38\u0E48\u0E21\u0E40\u0E1F\u0E2A") : null,
        !this.type || this.type === "LINE_OPENCHAT" ? h("button", { class: "primary", id: "pu-add-line", onclick: () => this.edit(null, "LINE_OPENCHAT") }, "+ \u0E2B\u0E49\u0E2D\u0E07 OpenChat") : null
      ),
      h(
        "p",
        { class: "muted small" },
        this.type === "FACEBOOK_FEED" ? "1 \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 = 1 \u0E42\u0E1E\u0E2A\u0E15\u0E4C \xB7 \u0E15\u0E49\u0E2D\u0E07\u0E43\u0E0A\u0E49 Facebook \u0E43\u0E19\u0E19\u0E32\u0E21\u0E40\u0E1E\u0E08\u0E19\u0E31\u0E49\u0E19/\u0E15\u0E31\u0E27\u0E40\u0E2D\u0E07\u0E15\u0E32\u0E21\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07" : this.type === "FACEBOOK_GROUP" ? "\u0E27\u0E32\u0E07\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E2B\u0E19\u0E49\u0E32\u0E01\u0E25\u0E38\u0E48\u0E21 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E01\u0E25\u0E38\u0E48\u0E21\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07 \xB7 1 \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 = 1 \u0E42\u0E1E\u0E2A\u0E15\u0E4C" : this.type === "LINE_OPENCHAT" ? "\u0E43\u0E2A\u0E48\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E2B\u0E49\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E43\u0E19 LINE PC \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07 \xB7 \u0E1A\u0E2D\u0E17\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07\u0E1C\u0E48\u0E32\u0E19\u0E0A\u0E48\u0E2D\u0E07\u0E04\u0E49\u0E19\u0E2B\u0E32\u0E02\u0E2D\u0E07 LINE PC \u0E41\u0E25\u0E30\u0E43\u0E2B\u0E49\u0E04\u0E38\u0E13\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E08\u0E32\u0E01\u0E20\u0E32\u0E1E\u0E2B\u0E19\u0E49\u0E32\u0E08\u0E2D" : "\u0E23\u0E30\u0E1A\u0E38\u0E14\u0E49\u0E27\u0E22\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E41\u0E0A\u0E17 (facebook.com/messages/t/\u2026) \u2014 \u0E01\u0E14\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E0A\u0E17\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07 \u0E23\u0E30\u0E1A\u0E1A\u0E15\u0E23\u0E27\u0E08\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E41\u0E25\u0E30\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E23\u0E31\u0E1A\u0E17\u0E38\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07"
      ),
      h(
        "div",
        { class: "pu-list", id: "pu-destinations" },
        ...this.items.length ? this.items.map(
          (d) => h(
            "div",
            { class: `pu-card ${d.enabled ? "" : "off"}`, "data-destination": d.id },
            h(
              "div",
              { class: "row between" },
              h("b", {}, `${isGroup(d) ? "\u{1F465}" : isFeed(d) ? "\u{1F4E3}" : isLine(d) ? "\u{1F7E2}" : "\u{1F4AC}"} ${d.name}`),
              isFeed(d) ? h("span", { class: "pu-status" }, "\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32 Facebook") : d.verifiedTitle ? h("span", { class: "pu-status ps-SENT" }, "\u2713 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E25\u0E49\u0E27") : h("span", { class: "pu-status ps-CHECK" }, "! \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E15\u0E23\u0E27\u0E08")
            ),
            h("div", { class: "muted small mono" }, isLine(d) ? `\u0E2B\u0E49\u0E2D\u0E07: ${d.chatReference.url}${d.chatReference.threadId ? ` \xB7 ${d.chatReference.threadId}` : ""}` : d.chatReference.url),
            d.verifiedTitle ? h("div", { class: "muted small" }, isLine(d) ? `\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07\u0E41\u0E25\u0E49\u0E27: "${d.verifiedTitle}" \xB7 ${dateOf(d.verifiedAt)}` : `\u0E0A\u0E37\u0E48\u0E2D${isGroup(d) ? "\u0E01\u0E25\u0E38\u0E48\u0E21" : "\u0E41\u0E0A\u0E17"}\u0E1A\u0E19 Facebook: "${d.verifiedTitle}" \xB7 ${dateOf(d.verifiedAt)}`) : null,
            d.notes ? h("div", { class: "small" }, d.notes) : null,
            h(
              "div",
              { class: "row" },
              isFeed(d) ? null : h("button", { class: d.verifiedTitle ? "small-btn" : "small-btn primary", "data-verify": d.id, onclick: () => void this.verify(d) }, isGroup(d) ? "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E01\u0E25\u0E38\u0E48\u0E21" : isLine(d) ? "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07" : "\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E0A\u0E17"),
              h("button", { class: "small-btn", onclick: () => this.edit(d, d.type) }, "\u0E41\u0E01\u0E49\u0E44\u0E02"),
              h("button", {
                class: "small-btn danger",
                onclick: () => void ask(`\u0E25\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07 "${d.name}"? (\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E22\u0E31\u0E07\u0E2D\u0E22\u0E39\u0E48)`, { okLabel: "\u0E25\u0E1A" }).then((ok) => ok !== null && void tryCall("pu.destination.delete", { id: d.id }).then((r) => r && this.refresh()))
              }, "\u0E25\u0E1A")
            )
          )
        ) : [h("p", { class: "muted" }, "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07")]
      )
    );
  }
  async verify(d) {
    toast(isGroup(d) ? "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E15\u0E23\u0E27\u0E08\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E25\u0E30 Composer (\u0E44\u0E21\u0E48\u0E42\u0E1E\u0E2A\u0E15\u0E4C)\u2026" : isLine(d) ? "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E19 LINE PC (\u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21) \u2014 \u0E2D\u0E22\u0E48\u0E32\u0E41\u0E15\u0E30\u0E40\u0E21\u0E32\u0E2A\u0E4C\u0E2A\u0E31\u0E01\u0E04\u0E23\u0E39\u0E48\u2026" : "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E1B\u0E34\u0E14\u0E41\u0E0A\u0E17\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A (\u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21)\u2026");
    const res = await tryCall("pu.destination.verify", { id: d.id });
    if (!res) return;
    if (res.pending) {
      this.confirmLine(d, res.pending.screenshot);
      return;
    }
    toast(`\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19: ${isGroup(d) ? "\u0E01\u0E25\u0E38\u0E48\u0E21" : isLine(d) ? "\u0E2B\u0E49\u0E2D\u0E07" : "\u0E41\u0E0A\u0E17"} "${res.title}"`);
    await this.refresh();
  }
  /**
   * LINE did not expose the room title: the user looks at the screenshot the host took after
   * opening the room and confirms it is the right one (the bot never guesses, ADR-78).
   */
  confirmLine(d, screenshot) {
    fill(
      this.root,
      h("div", { class: "view-head" }, h("button", { class: "link", onclick: () => void this.refresh() }, "\u2190 \u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07"), h("h2", {}, `\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E2B\u0E49\u0E2D\u0E07 "${d.chatReference.url}"`)),
      h("p", { class: "notice small" }, "LINE PC \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07\u0E15\u0E32\u0E21\u0E0A\u0E37\u0E48\u0E2D\u0E17\u0E35\u0E48\u0E04\u0E49\u0E19\u0E2B\u0E32\u0E41\u0E25\u0E49\u0E27 \u0E41\u0E15\u0E48\u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07\u0E01\u0E25\u0E31\u0E1A\u0E21\u0E32\u0E43\u0E2B\u0E49\u0E15\u0E23\u0E27\u0E08\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34 \u2014 \u0E14\u0E39\u0E20\u0E32\u0E1E\u0E14\u0E49\u0E32\u0E19\u0E25\u0E48\u0E32\u0E07\u0E27\u0E48\u0E32\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E49\u0E2D\u0E07 OpenChat \u0E17\u0E35\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E08\u0E23\u0E34\u0E07 \u0E16\u0E49\u0E32\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48 \u0E43\u0E2B\u0E49\u0E41\u0E01\u0E49\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E2B\u0E49\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E43\u0E19 LINE PC \u0E41\u0E25\u0E49\u0E27\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E43\u0E2B\u0E21\u0E48"),
      screenshot ? h("img", { src: `data:image/jpeg;base64,${screenshot}`, alt: "\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07 LINE PC \u0E2B\u0E25\u0E31\u0E07\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07", "data-line-screenshot": "", style: "max-width:100%;border:1px solid var(--line);border-radius:8px" }) : h("p", { class: "muted" }, "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E20\u0E32\u0E1E\u0E2B\u0E19\u0E49\u0E32\u0E08\u0E2D \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E14\u0E39\u0E43\u0E19 LINE PC \u0E40\u0E2D\u0E07\u0E27\u0E48\u0E32\u0E2B\u0E49\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07"),
      h(
        "div",
        { class: "sticky-actions" },
        h("button", { class: "primary", "data-line-confirm": d.id, onclick: () => void tryCall("pu.destination.confirmLine", { id: d.id }).then((r) => r && (toast(`\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E2B\u0E49\u0E2D\u0E07 "${r.chatReference.url}" \u0E41\u0E25\u0E49\u0E27 \u2014 \u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E2A\u0E48\u0E07`), this.refresh())) }, "\u0E43\u0E0A\u0E48 \u0E2B\u0E49\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07"),
        h("button", { onclick: () => this.edit(d, d.type) }, "\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48 \u2014 \u0E41\u0E01\u0E49\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07")
      )
    );
  }
  edit(d, type) {
    const feed = type === "FACEBOOK_FEED";
    const group = type === "FACEBOOK_GROUP";
    const line = type === "LINE_OPENCHAT";
    const name = h("input", { type: "text", id: this.fieldId("de-name"), maxlength: 100, value: d?.name ?? "", placeholder: feed ? "\u0E40\u0E0A\u0E48\u0E19 \u0E40\u0E1E\u0E08 JATUPON SEAFOOD / \u0E40\u0E1F\u0E2A\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E31\u0E27" : line ? "\u0E40\u0E0A\u0E48\u0E19 \u0E25\u0E39\u0E01\u0E04\u0E49\u0E32\u0E02\u0E32\u0E22\u0E2A\u0E48\u0E07 (LINE)" : "\u0E40\u0E0A\u0E48\u0E19 JATUPON SEAFOODS" });
    const url = h("input", { type: line ? "text" : "url", id: this.fieldId("de-url"), maxlength: line ? 100 : 300, value: d?.chatReference.url ?? "", placeholder: line ? "\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07 OpenChat \u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E43\u0E19 LINE PC" : group ? "https://www.facebook.com/groups/\u2026" : feed ? "https://www.facebook.com/\u0E0A\u0E37\u0E48\u0E2D\u0E40\u0E1E\u0E08" : "https://www.facebook.com/messages/t/\u2026" });
    const roomUrl = h("input", { type: "url", id: this.fieldId("de-room-url"), maxlength: 300, value: line ? d?.chatReference.threadId ?? "" : "", placeholder: "https://line.me/ti/g2/\u2026 (\u0E44\u0E21\u0E48\u0E1A\u0E31\u0E07\u0E04\u0E31\u0E1A)" });
    const notes = h("input", { type: "text", id: this.fieldId("de-notes"), maxlength: 500, value: d?.notes ?? "" });
    const enabled = h("input", { type: "checkbox", id: this.fieldId("de-enabled"), checked: d?.enabled ?? true });
    fill(
      this.root,
      h("div", { class: "view-head" }, h("button", { class: "link", onclick: () => this.renderList() }, "\u2190 \u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07"), h("h2", {}, `${d ? "\u0E41\u0E01\u0E49\u0E44\u0E02" : "\u0E40\u0E1E\u0E34\u0E48\u0E21"}${group ? " Facebook Group" : feed ? "\u0E40\u0E1E\u0E08 / \u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C" : line ? "\u0E2B\u0E49\u0E2D\u0E07 LINE OpenChat" : "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17"}`)),
      h("label", { for: this.fieldId("de-name") }, "\u0E0A\u0E37\u0E48\u0E2D\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A"),
      name,
      h("label", { for: this.fieldId("de-url") }, group ? "\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21 Facebook" : feed ? "\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E40\u0E1E\u0E08\u0E2B\u0E23\u0E37\u0E2D\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C" : line ? "\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07 OpenChat" : "\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E41\u0E0A\u0E17"),
      url,
      line ? h("label", { for: this.fieldId("de-room-url") }, "\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E40\u0E0A\u0E34\u0E0D\u0E02\u0E2D\u0E07\u0E2B\u0E49\u0E2D\u0E07 (\u0E16\u0E49\u0E32\u0E21\u0E35)") : null,
      line ? roomUrl : null,
      h(
        "p",
        { class: "muted small" },
        line ? "\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E2B\u0E49\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E17\u0E35\u0E48\u0E41\u0E2A\u0E14\u0E07\u0E43\u0E19 LINE PC \u0E17\u0E38\u0E01\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23 (\u0E1A\u0E2D\u0E17\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E0A\u0E37\u0E48\u0E2D\u0E19\u0E35\u0E49\u0E43\u0E19\u0E0A\u0E48\u0E2D\u0E07\u0E04\u0E49\u0E19\u0E2B\u0E32\u0E41\u0E25\u0E49\u0E27\u0E40\u0E1B\u0E34\u0E14\u0E1C\u0E25\u0E41\u0E23\u0E01) \xB7 \u0E43\u0E2A\u0E48\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E40\u0E0A\u0E34\u0E0D https://line.me/ti/g2/\u2026 \u0E14\u0E49\u0E27\u0E22\u0E08\u0E30\u0E43\u0E2B\u0E49 LINE \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E27\u0E48\u0E32 \xB7 \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E02\u0E49\u0E32\u0E23\u0E48\u0E27\u0E21\u0E2B\u0E49\u0E2D\u0E07\u0E44\u0E27\u0E49\u0E41\u0E25\u0E49\u0E27 \u0E41\u0E25\u0E30\u0E01\u0E14\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01" : group ? "\u0E27\u0E32\u0E07\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E2B\u0E19\u0E49\u0E32\u0E01\u0E25\u0E38\u0E48\u0E21\u0E44\u0E14\u0E49\u0E42\u0E14\u0E22\u0E15\u0E23\u0E07 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E01\u0E25\u0E38\u0E48\u0E21\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07 \xB7 \u0E43\u0E0A\u0E49\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E41\u0E25\u0E30\u0E23\u0E39\u0E1B\u0E40\u0E14\u0E34\u0E21 \u0E01\u0E25\u0E38\u0E48\u0E21\u0E17\u0E35\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E08\u0E30\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E41\u0E2A\u0E14\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E17\u0E31\u0E19\u0E17\u0E35" : feed ? "\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08 (\u0E2B\u0E23\u0E37\u0E2D\u0E2B\u0E19\u0E49\u0E32\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13) \u0E41\u0E25\u0E49\u0E27\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E25\u0E34\u0E07\u0E01\u0E4C \xB7 \u0E15\u0E2D\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C Facebook \u0E15\u0E49\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E43\u0E19\u0E19\u0E32\u0E21\u0E40\u0E1E\u0E08\u0E19\u0E31\u0E49\u0E19 (\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E40\u0E1E\u0E08) \u0E2B\u0E23\u0E37\u0E2D\u0E43\u0E19\u0E19\u0E32\u0E21\u0E15\u0E31\u0E27\u0E40\u0E2D\u0E07 (\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C) \u2014 \u0E23\u0E30\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E2A\u0E25\u0E31\u0E1A\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E2B\u0E49 \u0E16\u0E49\u0E32\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E08\u0E30\u0E2B\u0E22\u0E38\u0E14\u0E23\u0E2D\u0E43\u0E2B\u0E49\u0E2A\u0E25\u0E31\u0E1A\u0E40\u0E2D\u0E07" : "\u0E40\u0E1B\u0E34\u0E14\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17\u0E43\u0E19 www.facebook.com/messages \u0E41\u0E25\u0E49\u0E27\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E08\u0E32\u0E01\u0E41\u0E16\u0E1A\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48"
      ),
      h("label", { for: this.fieldId("de-notes") }, "\u0E2B\u0E21\u0E32\u0E22\u0E40\u0E2B\u0E15\u0E38"),
      notes,
      h("label", { class: "check" }, enabled, "\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19"),
      h(
        "div",
        { class: "sticky-actions" },
        h("button", {
          class: "primary",
          id: this.fieldId("de-save"),
          onclick: () => {
            const input = { type, name: name.value.trim(), url: url.value.trim(), enabled: enabled.checked, notes: notes.value, ...line ? { roomUrl: roomUrl.value.trim() } : {} };
            if (!input.name) return toast("\u0E15\u0E31\u0E49\u0E07\u0E0A\u0E37\u0E48\u0E2D\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07", "error");
            if (line && !input.url) return toast("\u0E43\u0E2A\u0E48\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07 OpenChat", "error");
            void tryCall("pu.destination.save", d ? { id: d.id, input } : { input }).then((saved) => saved && (toast(group ? "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E01\u0E14\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E01\u0E25\u0E38\u0E48\u0E21\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01" : feed ? "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27" : line ? '\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E01\u0E14 "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07" \u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01' : '\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E01\u0E14 "\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E0A\u0E17" \u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01'), this.refresh()));
          }
        }, "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01")
      )
    );
  }
};

// src/shared/line-installer.ts
var LINE_INSTALLER_FILENAME = "\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07-LINE-OpenChat.cmd";
var CRLF = "\r\n";
function escapeEchoLine(text2) {
  let s = text2.replace(/\^/g, "^^");
  s = s.replace(/[&<>|()"]/g, (c) => "^" + c);
  s = s.replace(/%/g, "%%");
  return s;
}
function echoLines(text2, destVar) {
  return text2.replace(/^﻿/, "").replace(/\r\n/g, "\n").split("\n").map((raw) => {
    const line = raw.replace(/\s+$/, "").replace(/^\s+/, "");
    return line.length === 0 ? `echo.>>"%${destVar}%"` : `echo ${escapeEchoLine(line)}>>"%${destVar}%"`;
  });
}
function lineInstallerCmd(extensionId, files) {
  if (!/^[a-p]{32}$/.test(extensionId)) throw new Error(`not an extension id: ${extensionId}`);
  const lines = [
    "@echo off",
    "rem Billdee PostHub - LINE OpenChat host installer (generated by the extension).",
    `rem Extension ID: ${extensionId}`,
    "rem Writes the C# host source as plain text, compiles it with the in-box csc.exe and registers it.",
    "rem Plain batch and the C# compiler only - nothing is decoded or run through a script engine.",
    "chcp 65001 >nul",
    "setlocal EnableExtensions",
    `set "ID=${extensionId}"`,
    'set "SRC=%LOCALAPPDATA%\\DRFX\\line-host\\src"',
    'set "BIN=%LOCALAPPDATA%\\DRFX\\line-host\\bin"',
    'if not exist "%SRC%" md "%SRC%"',
    'if not exist "%BIN%" md "%BIN%"',
    'set "CS=%SRC%\\drfx-line-host.cs"',
    'set "CFG=%SRC%\\config.json"',
    'break>"%CS%"',
    ...echoLines(files.source, "CS"),
    'break>"%CFG%"',
    ...echoLines(files.config, "CFG"),
    "",
    'set "CSC="',
    'if exist "%WINDIR%\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe" set "CSC=%WINDIR%\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe"',
    'if not defined CSC if exist "%WINDIR%\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe" set "CSC=%WINDIR%\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe"',
    "if not defined CSC (",
    "  echo [X] \u0E44\u0E21\u0E48\u0E1E\u0E1A C# compiler ^(csc.exe^) \u0E02\u0E2D\u0E07 .NET Framework 4 \u0E1A\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49",
    "  goto :fail",
    ")",
    "rem free the exe in case Chrome still has the host running, else csc cannot overwrite it",
    "taskkill /f /im drfx-line-host.exe >nul 2>&1",
    "echo \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E2D\u0E21\u0E44\u0E1E\u0E25\u0E4C\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE OpenChat ...",
    '"%CSC%" /nologo /target:winexe /platform:x64 /optimize+ /out:"%BIN%\\drfx-line-host.exe" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll "%CS%"',
    "if errorlevel 1 ( echo [X] \u0E04\u0E2D\u0E21\u0E44\u0E1E\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 & goto :fail )",
    'if not exist "%BIN%\\config.json" copy /y "%CFG%" "%BIN%\\config.json" >nul',
    "echo \u0E01\u0E33\u0E25\u0E31\u0E07\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E01\u0E31\u0E1A Chrome / Edge ...",
    '"%BIN%\\drfx-line-host.exe" --install "%ID%"',
    "if errorlevel 1 ( echo [X] \u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 ^(\u0E15\u0E23\u0E27\u0E08 Extension ID^) & goto :fail )",
    "echo.",
    "echo [OK] \u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE OpenChat \u0E41\u0E25\u0E49\u0E27",
    "echo      \u0E44\u0E1F\u0E25\u0E4C: %BIN%",
    "echo      Extension ID: %ID%",
    "echo.",
    'echo \u0E02\u0E31\u0E49\u0E19\u0E15\u0E48\u0E2D\u0E44\u0E1B: \u0E1B\u0E34\u0E14 Chrome/Edge \u0E17\u0E38\u0E01\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07\u0E41\u0E25\u0E49\u0E27\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E21\u0E48 1 \u0E04\u0E23\u0E31\u0E49\u0E07 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 "\u0E15\u0E23\u0E27\u0E08\u0E01\u0E32\u0E23\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D" \u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A LINE OpenChat',
    "echo.",
    "pause",
    "exit /b 0",
    "",
    ":fail",
    "echo.",
    "pause",
    "exit /b 1",
    ""
  ];
  return lines.join(CRLF);
}

// src/app/views/product-update/line-host-panel.ts
var LineHostPanel = class {
  element = h("section", { class: "card line-host", "data-line-host": "" });
  status = null;
  busy = false;
  /** Mode A (lock mouse/keyboard while sending). Off = mode B (touch pauses safely). */
  lock = false;
  constructor() {
    this.render();
  }
  async load() {
    const [status, settings] = await Promise.all([tryCall("pu.line.status", {}), tryCall("settings.get", {})]);
    this.status = status ?? null;
    if (settings) this.lock = settings.productUpdate.lineLockInput === true;
    this.render();
  }
  async setLock(on) {
    const settings = await tryCall("settings.get", {});
    if (!settings) return;
    settings.productUpdate.lineLockInput = on;
    const saved = await tryCall("settings.update", { settings });
    if (saved) {
      this.lock = on;
      toast(on ? "\u0E25\u0E47\u0E2D\u0E01\u0E40\u0E21\u0E32\u0E2A\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E2A\u0E48\u0E07: \u0E40\u0E1B\u0E34\u0E14" : "\u0E25\u0E47\u0E2D\u0E01\u0E40\u0E21\u0E32\u0E2A\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E2A\u0E48\u0E07: \u0E1B\u0E34\u0E14");
      this.render();
    }
  }
  render() {
    const s = this.status;
    const extId = s?.extensionId ?? chrome.runtime.id;
    const state = !s ? h("span", { class: "pu-status" }, "\u2026 \u0E01\u0E33\u0E25\u0E31\u0E07\u0E15\u0E23\u0E27\u0E08") : s.connected && s.lineRunning ? h("span", { class: "pu-status ps-SENT" }, `\u2713 \u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E41\u0E25\u0E49\u0E27 \xB7 LINE PC \u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48 \xB7 host v${s.hostVersion}`) : s.connected ? h("span", { class: "pu-status ps-CHECK" }, `! \u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E41\u0E25\u0E49\u0E27 \u0E41\u0E15\u0E48 LINE PC \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E34\u0E14 (host v${s.hostVersion})`) : h("span", { class: "pu-status ps-FAILED" }, "\u2715 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE PC");
    const check = h("button", { class: "small-btn", "data-line-check": "", disabled: this.busy, onclick: () => void this.load() }, "\u0E15\u0E23\u0E27\u0E08\u0E01\u0E32\u0E23\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D");
    const copyId = h("button", { class: "small-btn", onclick: () => void navigator.clipboard.writeText(extId).then(() => toast("\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01 Extension ID \u0E41\u0E25\u0E49\u0E27")) }, "\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01 ID");
    const installer = h("button", { class: "primary", "data-line-installer": "", disabled: this.busy, onclick: () => void this.downloadInstaller(extId) }, "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E15\u0E31\u0E27\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07");
    const diagnose = h("button", {
      class: "small-btn",
      "data-line-diagnose": "",
      disabled: this.busy || !s?.connected,
      onclick: () => void this.diagnose()
    }, "\u0E27\u0E34\u0E19\u0E34\u0E08\u0E09\u0E31\u0E22 (\u0E40\u0E1B\u0E34\u0E14 LINE + \u0E20\u0E32\u0E1E\u0E2B\u0E19\u0E49\u0E32\u0E08\u0E2D)");
    fill(
      this.element,
      h("div", { class: "row between" }, h("b", {}, "\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE PC"), state),
      h("p", { class: "muted small" }, "LINE \u0E44\u0E21\u0E48\u0E21\u0E35 API \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A OpenChat \u2014 \u0E1A\u0E2D\u0E17\u0E08\u0E30\u0E01\u0E14\u0E41\u0E17\u0E19\u0E04\u0E19\u0E43\u0E19\u0E42\u0E1B\u0E23\u0E41\u0E01\u0E23\u0E21 LINE PC: \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07 \u2192 \u0E27\u0E32\u0E07\u0E23\u0E39\u0E1B\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 \u2192 Enter \u2192 \u0E27\u0E32\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \u2192 Enter \xB7 \u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E2A\u0E48\u0E07 \u0E40\u0E21\u0E32\u0E2A\u0E4C\u0E41\u0E25\u0E30\u0E04\u0E35\u0E22\u0E4C\u0E1A\u0E2D\u0E23\u0E4C\u0E14\u0E16\u0E39\u0E01\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27 \u0E2D\u0E22\u0E48\u0E32\u0E41\u0E15\u0E30\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E08\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E2A\u0E23\u0E47\u0E08"),
      s && !s.connected ? h(
        "div",
        { class: "notice small" },
        h("b", {}, "\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27 (\u0E44\u0E21\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19 Admin):"),
        h(
          "ol",
          { class: "small" },
          h("li", {}, "\u0E40\u0E1B\u0E34\u0E14 LINE PC \u0E41\u0E25\u0E30\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 (\u0E15\u0E49\u0E2D\u0E07\u0E40\u0E02\u0E49\u0E32\u0E23\u0E48\u0E27\u0E21\u0E2B\u0E49\u0E2D\u0E07 OpenChat \u0E44\u0E27\u0E49\u0E41\u0E25\u0E49\u0E27)"),
          h("li", {}, "\u0E01\u0E14 ", installer, " \u0E41\u0E25\u0E49\u0E27\u0E40\u0E1B\u0E34\u0E14\u0E44\u0E1F\u0E25\u0E4C ", h("code", {}, LINE_INSTALLER_FILENAME), " \u0E17\u0E35\u0E48\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E21\u0E32 (\u0E16\u0E49\u0E32 Chrome \u0E16\u0E32\u0E21 \u0E01\u0E14 \u201C\u0E40\u0E01\u0E47\u0E1A\u0E44\u0E27\u0E49 / Keep\u201D; SmartScreen \u0E40\u0E15\u0E37\u0E2D\u0E19 \u0E01\u0E14 More info \u2192 Run anyway) \u2014 \u0E23\u0E2B\u0E31\u0E2A\u0E02\u0E2D\u0E07\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E1D\u0E31\u0E07\u0E21\u0E32\u0E41\u0E25\u0E49\u0E27 \u0E44\u0E21\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E2D\u0E30\u0E44\u0E23"),
          h("li", {}, "\u0E1B\u0E34\u0E14 Chrome/Edge \u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E21\u0E48 1 \u0E04\u0E23\u0E31\u0E49\u0E07 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 \u201C\u0E15\u0E23\u0E27\u0E08\u0E01\u0E32\u0E23\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u201D")
        ),
        h("div", { class: "muted small" }, "Extension ID: ", h("code", { class: "mono", "data-extension-id": "" }, extId), " ", copyId),
        h(
          "details",
          { class: "small" },
          h("summary", {}, "\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E40\u0E2D\u0E07 (\u0E2A\u0E33\u0E23\u0E2D\u0E07)"),
          h("p", {}, "\u0E40\u0E1B\u0E34\u0E14\u0E42\u0E1F\u0E25\u0E40\u0E14\u0E2D\u0E23\u0E4C\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22 \u2192 ", h("code", {}, "native-host"), " \u2192 \u0E14\u0E31\u0E1A\u0E40\u0E1A\u0E34\u0E25\u0E04\u0E25\u0E34\u0E01 ", h("code", {}, "install.cmd"), " \u0E41\u0E25\u0E49\u0E27\u0E27\u0E32\u0E07 Extension ID \u0E14\u0E49\u0E32\u0E19\u0E1A\u0E19")
        ),
        s.error ? h("div", { class: "muted small mono" }, `Chrome: ${s.error}`) : null
      ) : null,
      s?.connected && !s.lineRunning ? h("p", { class: "notice small" }, "\u0E40\u0E1B\u0E34\u0E14\u0E42\u0E1B\u0E23\u0E41\u0E01\u0E23\u0E21 LINE PC \u0E41\u0E25\u0E30\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 \u201C\u0E15\u0E23\u0E27\u0E08\u0E01\u0E32\u0E23\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u201D \u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07") : null,
      s?.connected ? h(
        "label",
        { class: "check small", "data-line-lock-toggle": "" },
        h("input", { type: "checkbox", checked: this.lock, onchange: (ev) => void this.setLock(ev.target.checked) }),
        " \u0E25\u0E47\u0E2D\u0E01\u0E40\u0E21\u0E32\u0E2A\u0E4C/\u0E04\u0E35\u0E22\u0E4C\u0E1A\u0E2D\u0E23\u0E4C\u0E14\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E2A\u0E48\u0E07 (\u0E01\u0E31\u0E19\u0E40\u0E1C\u0E25\u0E2D\u0E41\u0E15\u0E30 \u2014 \u0E40\u0E2B\u0E21\u0E32\u0E30\u0E40\u0E27\u0E25\u0E32\u0E40\u0E14\u0E34\u0E19\u0E44\u0E1B\u0E17\u0E33\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E2D\u0E37\u0E48\u0E19)"
      ) : null,
      s?.connected ? h("p", { class: "notice small", "data-line-lock-note": "" }, this.lock ? "\u0E42\u0E2B\u0E21\u0E14\u0E25\u0E47\u0E2D\u0E01: \u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E2A\u0E48\u0E07 \u0E40\u0E21\u0E32\u0E2A\u0E4C/\u0E04\u0E35\u0E22\u0E4C\u0E1A\u0E2D\u0E23\u0E4C\u0E14\u0E16\u0E39\u0E01\u0E25\u0E47\u0E2D\u0E01 \xB7 \u0E1B\u0E25\u0E14\u0E25\u0E47\u0E2D\u0E01\u0E09\u0E38\u0E01\u0E40\u0E09\u0E34\u0E19 \u0E01\u0E14 Ctrl+Alt+Del \u2014 \u0E07\u0E32\u0E19\u0E08\u0E30\u0E2B\u0E22\u0E38\u0E14\u0E23\u0E2D \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 \u201C\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D\u201D \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E2A\u0E16\u0E32\u0E19\u0E30" : "\u0E42\u0E2B\u0E21\u0E14\u0E44\u0E21\u0E48\u0E25\u0E47\u0E2D\u0E01 (\u0E08\u0E2D\u0E40\u0E14\u0E35\u0E22\u0E27): \u0E02\u0E22\u0E31\u0E1A\u0E40\u0E21\u0E32\u0E2A\u0E4C\u0E40\u0E09\u0E22\u0E46 \u0E44\u0E21\u0E48\u0E40\u0E1B\u0E47\u0E19\u0E44\u0E23 \xB7 \u0E16\u0E49\u0E32\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E2B\u0E22\u0E38\u0E14 \u0E04\u0E25\u0E34\u0E01\u0E17\u0E35\u0E48\u0E2D\u0E37\u0E48\u0E19\u0E19\u0E2D\u0E01 LINE \u2014 \u0E07\u0E32\u0E19\u0E08\u0E30\u0E2B\u0E22\u0E38\u0E14\u0E23\u0E2D \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 \u201C\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D\u201D \xB7 \u0E0A\u0E48\u0E27\u0E07\u0E04\u0E49\u0E19\u0E2B\u0E32\u0E2B\u0E49\u0E2D\u0E07\u0E16\u0E49\u0E32\u0E40\u0E1C\u0E25\u0E2D\u0E41\u0E15\u0E30 \u0E23\u0E30\u0E1A\u0E1A\u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E43\u0E2B\u0E49\u0E01\u0E48\u0E2D\u0E19 2 \u0E04\u0E23\u0E31\u0E49\u0E07") : null,
      s?.connected && s.uia === false ? h("p", { class: "muted small" }, "Windows UI Automation \u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E1A\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49 \u2014 \u0E01\u0E32\u0E23\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07\u0E08\u0E30\u0E43\u0E0A\u0E49\u0E20\u0E32\u0E1E\u0E2B\u0E19\u0E49\u0E32\u0E08\u0E2D\u0E43\u0E2B\u0E49\u0E04\u0E38\u0E13\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E40\u0E2D\u0E07") : null,
      h("div", { class: "row" }, check, diagnose, s?.connected ? h("span", { class: "muted small mono" }, s.hostDir ?? "") : null),
      h("div", { "data-line-diagnosis": "" })
    );
  }
  /** Builds the self-contained installer from the host files shipped in this extension + this extension's id. */
  async downloadInstaller(extensionId) {
    try {
      const read = async (name) => {
        const res = await fetch(chrome.runtime.getURL(`native-host/${name}`));
        if (!res.ok) throw new Error(`${name}: ${res.status}`);
        return (await res.text()).replace(/^\uFEFF/, "");
      };
      const [source, config] = await Promise.all([read("drfx-line-host.cs"), read("config.json")]);
      const cmd = lineInstallerCmd(extensionId, { source, config });
      const url = URL.createObjectURL(new Blob([cmd], { type: "application/octet-stream" }));
      const a = h("a", { href: url, download: LINE_INSTALLER_FILENAME, hidden: true });
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        a.remove();
        URL.revokeObjectURL(url);
      }, 1e4);
      toast(`\u0E01\u0E33\u0E25\u0E31\u0E07\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14 ${LINE_INSTALLER_FILENAME} \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E19\u0E35\u0E49\u0E08\u0E32\u0E01\u0E41\u0E16\u0E1A\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14 \u0E41\u0E25\u0E49\u0E27\u0E40\u0E1B\u0E34\u0E14 Chrome \u0E43\u0E2B\u0E21\u0E48`);
    } catch (err) {
      toast(`\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E15\u0E31\u0E27\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49: ${err instanceof Error ? err.message : String(err)}`, "error");
    }
  }
  async diagnose() {
    this.busy = true;
    this.render();
    toast("\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E1B\u0E34\u0E14 LINE PC \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E27\u0E34\u0E19\u0E34\u0E08\u0E09\u0E31\u0E22 (\u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21) \u2014 \u0E2D\u0E22\u0E48\u0E32\u0E41\u0E15\u0E30\u0E40\u0E21\u0E32\u0E2A\u0E4C\u0E2A\u0E31\u0E01\u0E04\u0E23\u0E39\u0E48");
    const d = await tryCall("pu.line.diagnose", {});
    this.busy = false;
    this.render();
    const box = this.element.querySelector("[data-line-diagnosis]");
    if (!box || !d) return;
    fill(
      box,
      h(
        "details",
        { open: true },
        h("summary", {}, `\u0E1C\u0E25\u0E27\u0E34\u0E19\u0E34\u0E08\u0E09\u0E31\u0E22: LINE ${d.lineRunning ? "\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48" : "\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1B\u0E34\u0E14"} \xB7 UIA ${d.uia ? "\u0E43\u0E0A\u0E49\u0E44\u0E14\u0E49" : "\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49"} \xB7 \u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E17\u0E35\u0E48\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E14\u0E49 ${d.elements?.length ?? 0}`),
        d.screenshot ? h("img", { src: `data:image/jpeg;base64,${d.screenshot}`, alt: "\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07 LINE PC", style: "max-width:100%;border:1px solid var(--line);border-radius:8px" }) : null,
        d.elements?.length ? h("pre", { class: "small", style: "max-height:240px;overflow:auto" }, d.elements.map((e) => `${e.type}	${e.name}${e.id ? `	#${e.id}` : ""}`).join("\n")) : h("p", { class: "muted small" }, "LINE \u0E44\u0E21\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E1C\u0E22\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E43\u0E2B\u0E49 UI Automation \u2014 \u0E1A\u0E2D\u0E17\u0E43\u0E0A\u0E49\u0E15\u0E33\u0E41\u0E2B\u0E19\u0E48\u0E07\u0E04\u0E25\u0E34\u0E01\u0E08\u0E32\u0E01 native-host/config.json")
      )
    );
  }
};

// src/app/views/product-update/channel.ts
var ChannelView = class {
  body = h("div", {});
  destinations;
  sender;
  sending = false;
  timing;
  /** LINE OpenChat only: host status + install steps (ADR-78). */
  lineHost;
  constructor(root, type, label, go) {
    this.timing = new SendTimingPanel(timingChannel(type));
    this.lineHost = type === "LINE_OPENCHAT" ? new LineHostPanel() : null;
    const send = h("button", { class: "primary", "data-channel-send": type, onclick: () => {
      this.sending = true;
      void this.refresh();
    } }, `\u0E2A\u0E48\u0E07\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E1B${label}`);
    const manage = h("button", { "data-channel-manage": type, onclick: () => {
      this.sending = false;
      void this.refresh();
    } }, "\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07");
    const note = type === "LINE_OPENCHAT" ? "\u0E17\u0E33\u0E07\u0E32\u0E19\u0E41\u0E22\u0E01\u0E08\u0E32\u0E01\u0E0A\u0E48\u0E2D\u0E07\u0E17\u0E32\u0E07\u0E2D\u0E37\u0E48\u0E19 \xB7 \u0E2A\u0E48\u0E07\u0E15\u0E32\u0E21\u0E25\u0E33\u0E14\u0E31\u0E1A\u0E20\u0E32\u0E22\u0E43\u0E19\u0E0A\u0E48\u0E2D\u0E07\u0E17\u0E32\u0E07\u0E19\u0E35\u0E49 \xB7 \u0E43\u0E0A\u0E49\u0E42\u0E1B\u0E23\u0E41\u0E01\u0E23\u0E21 LINE PC \u0E1A\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49 (\u0E22\u0E36\u0E14\u0E40\u0E21\u0E32\u0E2A\u0E4C\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27\u0E15\u0E2D\u0E19\u0E2A\u0E48\u0E07)" : "\u0E17\u0E33\u0E07\u0E32\u0E19\u0E41\u0E22\u0E01\u0E08\u0E32\u0E01\u0E0A\u0E48\u0E2D\u0E07\u0E17\u0E32\u0E07\u0E2D\u0E37\u0E48\u0E19 \xB7 \u0E2A\u0E48\u0E07\u0E15\u0E32\u0E21\u0E25\u0E33\u0E14\u0E31\u0E1A\u0E20\u0E32\u0E22\u0E43\u0E19\u0E0A\u0E48\u0E2D\u0E07\u0E17\u0E32\u0E07\u0E19\u0E35\u0E49 \xB7 \u0E40\u0E1B\u0E34\u0E14\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E33\u0E07\u0E32\u0E19\u0E40\u0E1A\u0E37\u0E49\u0E2D\u0E07\u0E2B\u0E25\u0E31\u0E07";
    fill(root, h("h2", {}, label), h("p", { class: "muted small" }, note), h("div", { class: "row pu-toolbar" }, send, manage), this.lineHost?.element ?? "", this.timing.element, this.body);
    this.destinations = new DestinationsView(this.body, type);
    this.sender = new DailyView(this.body, (tab, batchId) => {
      if (tab === "destinations") {
        this.sending = false;
        void this.refresh();
      } else go(tab, batchId);
    }, type);
  }
  async refresh() {
    this.timing.element.hidden = this.sending;
    if (this.lineHost) this.lineHost.element.hidden = this.sending;
    if (this.sending) await this.sender.refresh();
    else await Promise.all([this.timing.load(), this.destinations.refresh(), this.lineHost?.load()]);
  }
  onChanged() {
    if (this.sending) void this.sender.refreshCard();
  }
};

// src/app/views/product-update/history.ts
var HistoryView = class {
  constructor(root) {
    this.root = root;
  }
  async refresh() {
    const list = await tryCall("pu.history", { limit: 300 });
    if (!list) return;
    const byDay = /* @__PURE__ */ new Map();
    for (const e of list) {
      const day = dateOf(e.sentAt ?? e.updatedAt);
      byDay.set(day, [...byDay.get(day) ?? [], e]);
    }
    fill(
      this.root,
      h("h2", {}, "History"),
      ...list.length ? [...byDay].map(
        ([day, entries]) => h(
          "section",
          { class: "pu-day" },
          h("div", { class: "agenda-date" }, day),
          ...entries.map(
            (e) => h(
              "details",
              { class: "pu-send", "data-history": e.id },
              h(
                "summary",
                { class: "pu-row" },
                thumb(e.snapshot.imageAssetIds[0], e.snapshot.productName),
                h("span", { class: "pu-main" }, h("b", { class: "pu-name" }, e.snapshot.productName), h("span", { class: "muted small" }, `${e.snapshot.destinationName} \xB7 ${timeOf(e.sentAt ?? e.updatedAt)} \xB7 ${e.batchName}`)),
                sendChip(e.view, e.needsCheck, e.snapshot.channel)
              ),
              h("div", { class: "muted small" }, `\u0E23\u0E32\u0E04\u0E32\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07: ${e.snapshot.price ?? "-"} \xB7 ${e.snapshot.channel === "group" ? "\u0E43\u0E0A\u0E49\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32" : `Template: ${e.snapshot.templateName}`}${e.confirmedBy === "dom" ? e.snapshot.channel === "group" ? " \xB7 \u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21" : e.snapshot.channel === "feed" ? " \xB7 \u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C" : " \xB7 \u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E08\u0E32\u0E01\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E43\u0E19\u0E41\u0E0A\u0E17" : e.confirmedBy === "host" ? " \xB7 \u0E2A\u0E48\u0E07\u0E1C\u0E48\u0E32\u0E19 LINE PC (\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2D\u0E48\u0E32\u0E19\u0E2B\u0E49\u0E2D\u0E07\u0E01\u0E25\u0E31\u0E1A)" : e.view === "SENT" || e.view === "PENDING_APPROVAL" ? " \xB7 \u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19" : ""}`),
              e.error ? h("div", { class: "error-box small" }, e.error.userMessage) : null,
              h("pre", { class: "pu-preview" }, e.snapshot.message)
            )
          )
        )
      ) : [h("p", { class: "muted" }, "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07")]
    );
  }
};

// src/shared/product-media.ts
function productMediaKind(mime) {
  if (/^image\/(png|jpeg|webp|gif)$/.test(mime)) return "image";
  if (/^video\/(mp4|webm|quicktime)$/.test(mime)) return "video";
  return void 0;
}
var PRODUCT_MEDIA_ACCEPT = "image/png,image/jpeg,image/webp,image/gif,video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov";
function productFileMime(file) {
  if (productMediaKind(file.type)) return file.type;
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  const video = { mp4: "video/mp4", webm: "video/webm", mov: "video/quicktime" };
  return video[ext] ?? file.type;
}

// src/app/views/product-update/products.ts
var ymdOf = (iso) => new Date(Date.parse(iso) + 7 * 36e5).toISOString().slice(0, 10);
var pricedToday = (p) => Boolean(p.pricing?.pricedAt && ymdOf(p.pricing.pricedAt) === todayYmd());
var signed = (n, sign) => `${sign}${n}`;
var num = (el) => {
  const n = Number(el.value);
  return Number.isFinite(n) ? n : 0;
};
function toInput(p) {
  const input = { name: p.name, description: p.description, price: p.price, currency: p.currency, images: [...p.images], templateId: p.templateId, active: p.active, imagesOnly: p.imagesOnly === true };
  if (p.unit) input.unit = p.unit;
  if (p.pricing) input.pricing = p.pricing;
  return input;
}
var ProductsView = class {
  constructor(root, goDaily = () => void 0) {
    this.root = root;
    this.goDaily = goDaily;
  }
  products = [];
  templates = [];
  search = "";
  filter = "all";
  /** The card open for editing ("new" = the add card on top). */
  open = null;
  async refresh() {
    const [products, templates] = await Promise.all([tryCall("pu.products.list", {}), tryCall("pu.templates.list", {})]);
    if (!products || !templates) return;
    this.products = products;
    this.templates = templates;
    if (this.open && this.open !== "new" && !products.some((p) => p.id === this.open)) this.open = null;
    this.render();
  }
  render() {
    const search = h("input", { type: "text", id: "pu-search", placeholder: "\u0E04\u0E49\u0E19\u0E2B\u0E32\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32", value: this.search });
    search.addEventListener("input", () => {
      this.search = search.value;
      renderRows();
    });
    const filter = h(
      "select",
      { id: "pu-filter", "aria-label": "\u0E01\u0E23\u0E2D\u0E07" },
      ...["all", "active", "inactive"].map((f) => h("option", { value: f, selected: this.filter === f }, { all: "\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14", active: "\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19", inactive: "\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48" }[f]))
    );
    filter.addEventListener("change", () => {
      this.filter = filter.value;
      renderRows();
    });
    const rows = h("div", { class: "pu-list pc-list", id: "pu-products" });
    const renderRows = () => {
      const q = this.search.trim().toLowerCase();
      const shown = this.products.filter((p) => (this.filter === "all" || this.filter === "active" === p.active) && (!q || p.name.toLowerCase().includes(q)));
      fill(
        rows,
        this.open === "new" ? this.editor(null) : null,
        ...shown.length ? shown.map((p) => this.open === p.id ? this.editor(p) : this.card(p, Boolean(q) || this.filter !== "all")) : [this.open === "new" ? null : h("p", { class: "muted" }, this.products.length ? "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E04\u0E49\u0E19\u0E2B\u0E32" : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u2014 \u0E01\u0E14 + \u0E40\u0E1E\u0E34\u0E48\u0E21\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32")]
      );
    };
    const priced = this.products.filter((p) => p.active && p.pricing);
    const done = priced.filter(pricedToday).length;
    fill(
      this.root,
      h(
        "div",
        { class: "pc-head" },
        h("div", { class: "pc-head-text" }, h("h2", {}, "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"), h("p", { class: "muted small" }, "\u0E27\u0E32\u0E07\u0E23\u0E32\u0E04\u0E32\u0E08\u0E32\u0E01\u0E41\u0E1E \u0E41\u0E01\u0E49\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E17\u0E33\u0E44\u0E14\u0E49\u0E43\u0E19\u0E01\u0E32\u0E23\u0E4C\u0E14\u0E40\u0E14\u0E35\u0E22\u0E27 \xB7 \u0E41\u0E1E\u0E44\u0E2B\u0E19\u0E23\u0E32\u0E04\u0E32\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u0E44\u0E21\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E41\u0E15\u0E30")),
        priced.length ? h("span", { class: "pc-sum", id: "pu-priced-summary" }, `\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E41\u0E25\u0E49\u0E27 ${done} / ${priced.length}`) : null,
        h("button", { class: "small-btn", id: "pu-go-daily", onclick: () => this.goDaily() }, "\u0E44\u0E1B\u0E2B\u0E19\u0E49\u0E32\u0E2A\u0E48\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49")
      ),
      h(
        "div",
        { class: "row pu-toolbar" },
        h("button", { class: "primary", id: "pu-add-product", onclick: () => (this.open = "new", renderRows(), this.root.querySelector("#pe-name")?.focus()) }, "+ \u0E40\u0E1E\u0E34\u0E48\u0E21\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"),
        search,
        filter
      ),
      rows
    );
    renderRows();
  }
  /** A closed card. */
  card(p, ordering) {
    const i = this.products.indexOf(p);
    const pr = p.pricing;
    const supplier = supplierOf(p.name);
    const facts = [
      pr ? `${signed(pr.plus, "+")} / ${signed(pr.minus, "\u2212")}` : "",
      pr ? `${applyPricing(pr.source, pr).rows.length} \u0E23\u0E32\u0E04\u0E32` : "",
      p.images.length ? `\u0E23\u0E39\u0E1B/\u0E04\u0E25\u0E34\u0E1B ${p.images.length}` : "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B/\u0E04\u0E25\u0E34\u0E1B",
      supplier ? `\u0E41\u0E1E: ${supplier}` : "",
      p.imagesOnly || !p.description.trim() ? "\u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E39\u0E1B/\u0E04\u0E25\u0E34\u0E1B" : "",
      p.active ? "" : "\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48"
    ].filter(Boolean);
    const status = !pr ? null : pricedToday(p) ? h("span", { class: "pc-chip ok" }, `\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E41\u0E25\u0E49\u0E27 ${timeOf(pr.pricedAt)}`) : h("span", { class: "pc-chip warn" }, pr.pricedAt ? `\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15 \xB7 \u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14 ${dateOf(pr.pricedAt)}` : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15");
    return h(
      "div",
      { class: `pu-row pc ${p.active ? "" : "off"}`, "data-product": p.id },
      thumb(p.images[0], p.name),
      h("div", { class: "pu-main" }, h("b", { class: "pu-name" }, `${String(i + 1).padStart(2, "0")} ${p.name}`), h("span", { class: "muted small" }, facts.join(" \xB7 "))),
      status,
      h(
        "div",
        { class: "pu-actions" },
        pr && !pricedToday(p) ? h("button", { class: "small-btn", "data-keep-price": p.id, onclick: () => void this.keepPrice(p) }, "\u0E43\u0E0A\u0E49\u0E23\u0E32\u0E04\u0E32\u0E40\u0E14\u0E34\u0E21\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49") : null,
        h("button", { class: "small-btn", onclick: () => (this.open = p.id, this.render()) }, "\u0E41\u0E01\u0E49\u0E44\u0E02"),
        h("button", { class: "icon", "aria-label": `\u0E02\u0E36\u0E49\u0E19 ${p.name}`, disabled: i === 0 || ordering, onclick: () => void this.move(p.id, -1) }, "\u2191"),
        h("button", { class: "icon", "aria-label": `\u0E25\u0E07 ${p.name}`, disabled: i === this.products.length - 1 || ordering, onclick: () => void this.move(p.id, 1) }, "\u2193"),
        h("button", { class: "small-btn", onclick: () => void tryCall("pu.product.duplicate", { id: p.id }).then((c) => c && (toast("\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E41\u0E25\u0E49\u0E27"), this.refresh())) }, "Duplicate"),
        h("button", { class: "small-btn", onclick: () => void tryCall("pu.product.setActive", { id: p.id, active: !p.active }).then(() => this.refresh()) }, p.active ? "Disable" : "Enable")
      )
    );
  }
  /** "ใช้ราคาเดิมวันนี้": nothing changes but today's prices count as checked. */
  async keepPrice(p) {
    if (!p.pricing) return;
    const input = toInput(p);
    input.pricing = { ...p.pricing, pricedAt: (/* @__PURE__ */ new Date()).toISOString() };
    if (await tryCall("pu.product.save", { id: p.id, input })) await this.refresh();
  }
  async move(id2, dir) {
    const ids = this.products.map((p) => p.id);
    const i = ids.indexOf(id2);
    const j = i + dir;
    if (j < 0 || j >= ids.length) return;
    [ids[i], ids[j]] = [ids[j], ids[i]];
    const saved = await tryCall("pu.product.reorder", { ids });
    if (saved) {
      this.products = saved;
      this.render();
    }
  }
  /** The open card (p = null: a new product). */
  editor(p) {
    const images = p ? [...p.images] : [];
    const pricing = {
      plus: p?.pricing?.plus ?? 0,
      minus: p?.pricing?.minus ?? 0,
      sections: { ...p?.pricing?.sections ?? {} },
      lines: { ...p?.pricing?.lines ?? {} }
    };
    let uploading = false;
    const close = () => {
      this.open = null;
      this.render();
    };
    const numInput = (id2, value, label) => h("input", { type: "number", id: id2 || void 0, class: "pc-num", step: "1", value: String(value), "aria-label": label });
    const name = h("input", { type: "text", id: "pe-name", maxlength: PRODUCT_LIMITS.nameMax, value: p?.name ?? "", placeholder: "\u0E40\u0E0A\u0E48\u0E19 \u0E01\u0E38\u0E49\u0E07 \u0E01\u0E31\u0E19\u0E22\u0E4C" });
    const plus = numInput("pe-plus", pricing.plus, "\u0E1A\u0E27\u0E01\u0E23\u0E32\u0E04\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C \u0E17\u0E31\u0E49\u0E07\u0E41\u0E1E");
    const minus = numInput("pe-minus", pricing.minus, "\u0E41\u0E1E\u0E2B\u0E31\u0E01\u0E15\u0E2D\u0E19\u0E08\u0E48\u0E32\u0E22 \u0E17\u0E31\u0E49\u0E07\u0E41\u0E1E");
    const example = h("p", { class: "pc-example", id: "pe-example" });
    const desc = h("textarea", { id: "pe-desc", rows: 18, maxlength: 4e3, placeholder: "\u0E27\u0E32\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E23\u0E32\u0E04\u0E32\u0E08\u0E32\u0E01\u0E41\u0E1E\u0E17\u0E31\u0E49\u0E07\u0E01\u0E49\u0E2D\u0E19 \u2014 \u0E44\u0E21\u0E48\u0E15\u0E31\u0E49\u0E07 +/\u2212 \u0E08\u0E30\u0E2A\u0E48\u0E07\u0E15\u0E32\u0E21\u0E19\u0E35\u0E49\u0E17\u0E38\u0E01\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23 \xB7 \u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 = \u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E39\u0E1B/\u0E04\u0E25\u0E34\u0E1B" });
    desc.value = p?.pricing?.source ?? p?.description ?? "";
    const tpl = h("select", { id: "pe-template" }, ...this.templates.map((t) => h("option", { value: t.id, selected: (p?.templateId ?? this.templates[0]?.id) === t.id }, t.name)));
    const active = h("input", { type: "checkbox", id: "pe-active", checked: p?.active ?? true });
    const imagesOnly = p?.imagesOnly ? h("input", { type: "checkbox", id: "pe-images-only", checked: true }) : null;
    const imageBox = h("div", { class: "pe-images", id: "pe-images" });
    const picker = h("input", { type: "file", id: "pe-file", accept: PRODUCT_MEDIA_ACCEPT, multiple: true, hidden: true });
    const table = h("div", { class: "pc-prices", id: "pe-prices" });
    const output = h("pre", { class: "pu-preview pc-output", id: "pe-output", hidden: true });
    const showOutput = h("button", { class: "small-btn", id: "pe-show-output", onclick: () => (output.hidden = !output.hidden, showOutput.textContent = output.hidden ? "\u0E14\u0E39\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E08\u0E30\u0E42\u0E1E\u0E2A\u0E15\u0E4C" : "\u0E0B\u0E48\u0E2D\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E08\u0E30\u0E42\u0E1E\u0E2A\u0E15\u0E4C") }, "\u0E14\u0E39\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E08\u0E30\u0E42\u0E1E\u0E2A\u0E15\u0E4C");
    const renderPrices = () => {
      pricing.plus = num(plus);
      pricing.minus = num(minus);
      example.textContent = `\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07: \u0E23\u0E32\u0E04\u0E32\u0E41\u0E1E 245 \u2192 \u0E42\u0E1E\u0E2A\u0E15\u0E4C ${245 + pricing.plus} \xB7 \u0E17\u0E38\u0E19 (\u0E08\u0E48\u0E32\u0E22\u0E41\u0E1E) ${245 - pricing.minus} \xB7 \u0E01\u0E33\u0E44\u0E23 ${pricing.plus + pricing.minus} \u0E1A\u0E32\u0E17/\u0E2B\u0E19\u0E48\u0E27\u0E22`;
      const r = applyPricing(desc.value, pricing);
      output.textContent = r.output || "(\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \u2014 \u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E39\u0E1B/\u0E04\u0E25\u0E34\u0E1B)";
      if (!r.rows.length) {
        fill(table, h("p", { class: "muted small" }, desc.value.trim() ? "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E23\u0E32\u0E04\u0E32\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \u2014 \u0E08\u0E30\u0E2A\u0E48\u0E07\u0E15\u0E32\u0E21\u0E17\u0E35\u0E48\u0E27\u0E32\u0E07\u0E44\u0E27\u0E49" : "\u0E27\u0E32\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E08\u0E32\u0E01\u0E41\u0E1E \u0E41\u0E25\u0E49\u0E27\u0E23\u0E32\u0E04\u0E32\u0E17\u0E35\u0E48\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E14\u0E49\u0E08\u0E30\u0E02\u0E36\u0E49\u0E19\u0E15\u0E23\u0E07\u0E19\u0E35\u0E49"));
        return;
      }
      fill(
        table,
        h("div", { class: "pc-prices-head" }, h("b", {}, "\u0E23\u0E32\u0E04\u0E32\u0E17\u0E35\u0E48\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E14\u0E49"), h("span", { class: "pc-chip ok", id: "pe-count" }, `\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E14\u0E49 ${r.rows.length} \u0E23\u0E32\u0E04\u0E32`)),
        h("div", { class: "pc-grid pc-grid-head", "aria-hidden": "true" }, h("span", {}, "\u0E44\u0E0B\u0E0B\u0E4C"), h("span", {}, "\u0E23\u0E32\u0E04\u0E32\u0E41\u0E1E"), h("span", {}, "\u0E42\u0E1E\u0E2A\u0E15\u0E4C"), h("span", {}, "\u0E17\u0E38\u0E19")),
        ...r.sections.map((s) => {
          const sPlus = numInput("", s.plus, `\u0E1A\u0E27\u0E01\u0E23\u0E32\u0E04\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C \u0E2B\u0E31\u0E27\u0E02\u0E49\u0E2D ${s.name}`);
          const sMinus = numInput("", s.minus, `\u0E41\u0E1E\u0E2B\u0E31\u0E01\u0E15\u0E2D\u0E19\u0E08\u0E48\u0E32\u0E22 \u0E2B\u0E31\u0E27\u0E02\u0E49\u0E2D ${s.name}`);
          const setOwn = () => {
            pricing.sections[s.name] = { plus: num(sPlus), minus: num(sMinus) };
            renderPrices();
          };
          sPlus.addEventListener("change", setOwn);
          sMinus.addEventListener("change", setOwn);
          return h(
            "div",
            { class: "pc-section", "data-section": s.name },
            h(
              "div",
              { class: "pc-section-head" },
              h("b", { class: "pc-section-name" }, s.name),
              s.own ? h("button", { class: "pc-chip warn", title: "\u0E01\u0E25\u0E31\u0E1A\u0E44\u0E1B\u0E43\u0E0A\u0E49\u0E04\u0E48\u0E32\u0E02\u0E2D\u0E07\u0E41\u0E1E", onclick: () => (delete pricing.sections[s.name], renderPrices()) }, "\u0E15\u0E31\u0E49\u0E07\u0E41\u0E22\u0E01\u0E2B\u0E31\u0E27\u0E02\u0E49\u0E2D\u0E19\u0E35\u0E49 \xB7 \u0E04\u0E37\u0E19\u0E04\u0E48\u0E32") : h("span", { class: "muted small" }, "\u0E15\u0E32\u0E21\u0E41\u0E1E"),
              h("span", { class: "pc-pm" }, h("span", { class: "pc-plus" }, "+"), sPlus, h("span", { class: "pc-minus" }, "\u2212"), sMinus)
            ),
            ...s.rows.map((row) => {
              const sale = h("input", { type: "number", class: `pc-num pc-sale ${row.extra ? "edited" : ""}`, value: String(row.sale), "aria-label": `\u0E23\u0E32\u0E04\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C ${s.name} ${row.label}`, "data-key": row.key });
              sale.addEventListener("change", () => {
                const extra = num(sale) - (row.price + s.plus);
                if (extra) pricing.lines[row.key] = extra;
                else delete pricing.lines[row.key];
                renderPrices();
              });
              return h(
                "div",
                { class: "pc-grid", "data-line": row.key },
                h(
                  "span",
                  { class: "pc-label" },
                  row.label,
                  row.extra ? h("span", { class: "pc-chip warn" }, `${row.extra > 0 ? "+" : ""}${row.extra} \u0E40\u0E09\u0E1E\u0E32\u0E30\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E19\u0E35\u0E49`, h("button", { class: "pc-reset", onclick: () => (delete pricing.lines[row.key], renderPrices()) }, "\u0E04\u0E37\u0E19\u0E04\u0E48\u0E32")) : null
                ),
                h("span", { class: "pc-price" }, String(row.price)),
                h("span", {}, sale),
                h("span", { class: "pc-cost" }, String(row.cost))
              );
            })
          );
        })
      );
    };
    let timer2;
    desc.addEventListener("input", () => {
      clearTimeout(timer2);
      timer2 = setTimeout(renderPrices, 250);
    });
    plus.addEventListener("input", renderPrices);
    minus.addEventListener("input", renderPrices);
    const renderImages = () => {
      fill(
        imageBox,
        ...images.map(
          (id2, i) => h(
            "div",
            { class: "pe-image", "data-asset": id2 },
            thumb(id2, `\u0E44\u0E1F\u0E25\u0E4C ${i + 1}`),
            h(
              "div",
              { class: "row" },
              h("button", { class: "icon", "aria-label": `\u0E40\u0E25\u0E37\u0E48\u0E2D\u0E19\u0E44\u0E1F\u0E25\u0E4C ${i + 1} \u0E02\u0E36\u0E49\u0E19`, disabled: i === 0, onclick: () => ([images[i - 1], images[i]] = [images[i], images[i - 1]], renderImages()) }, "\u2191"),
              h("button", { class: "icon", "aria-label": `\u0E25\u0E1A\u0E44\u0E1F\u0E25\u0E4C ${i + 1}`, onclick: () => (images.splice(i, 1), renderImages()) }, "\xD7")
            )
          )
        ),
        images.length < PRODUCT_LIMITS.imagesMax ? h("button", { class: "pe-add-image", id: "pe-add-image", onclick: () => picker.click(), disabled: uploading }, uploading ? "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E44\u0E1F\u0E25\u0E4C\u2026" : "\u0E2D\u0E31\u0E1E\u0E23\u0E39\u0E1B") : null
      );
    };
    picker.addEventListener("change", () => {
      if (uploading) return;
      uploading = true;
      saveBtn.disabled = true;
      renderImages();
      void (async () => {
        try {
          for (const file of Array.from(picker.files ?? [])) {
            if (images.length >= PRODUCT_LIMITS.imagesMax) break;
            const mime = productFileMime(file);
            const kind = productMediaKind(mime);
            if (!kind) {
              toast("\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E23\u0E39\u0E1B PNG / JPG / WEBP / GIF \u0E41\u0E25\u0E30\u0E04\u0E25\u0E34\u0E1B MP4 / WEBM / MOV", "error");
              continue;
            }
            const limit = kind === "video" ? PRODUCT_LIMITS.videoBytesMax : PRODUCT_LIMITS.imageBytesMax;
            if (file.size > limit) {
              toast(`${file.name}: \u0E43\u0E2B\u0E0D\u0E48\u0E40\u0E01\u0E34\u0E19 ${limit / 1024 / 1024} MB`, "error");
              continue;
            }
            const res = await tryCall("pu.media.add", { base64: await fileToBase64(file), mime });
            if (res && !images.includes(res.assetId)) images.push(res.assetId);
          }
        } catch {
          toast("\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 \u2014 \u0E25\u0E2D\u0E07\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E2B\u0E21\u0E48", "error");
        } finally {
          uploading = false;
          picker.value = "";
          saveBtn.disabled = false;
          renderImages();
        }
      })();
    });
    const save = async () => {
      if (uploading) return;
      const source = desc.value.replace(/\r\n?/g, "\n");
      const input = {
        name: name.value.trim(),
        description: source,
        price: null,
        currency: "THB",
        images,
        templateId: tpl.value,
        active: active.checked,
        imagesOnly: imagesOnly?.checked === true
      };
      if (p?.unit) input.unit = p.unit;
      if (source.trim()) input.pricing = { source, ...pricing, plus: num(plus), minus: num(minus), pricedAt: (/* @__PURE__ */ new Date()).toISOString() };
      if (!input.name) return toast("\u0E01\u0E23\u0E2D\u0E01\u0E0A\u0E37\u0E48\u0E2D\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32", "error");
      const saved = await tryCall("pu.product.save", p ? { id: p.id, input } : { input });
      if (saved) {
        toast("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E49\u0E27");
        this.open = null;
        await this.refresh();
      }
    };
    const saveBtn = h("button", { class: "primary", id: "pe-save", onclick: () => void save() }, "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E23\u0E32\u0E04\u0E32\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49");
    const collapse = (id2) => h("button", { class: "small-btn pc-collapse", id: id2, onclick: close }, "\u0E22\u0E48\u0E2D\u0E01\u0E32\u0E23\u0E4C\u0E14 \u25B2");
    const card = h(
      "section",
      { class: "pu-card pc-open", ...p ? { "data-product-edit": p.id } : { id: "pe-new" } },
      h(
        "div",
        { class: "pc-top" },
        h("label", { class: "pc-field pc-grow", for: "pe-name" }, "\u0E0A\u0E37\u0E48\u0E2D\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 (\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 + \u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E1E)", name),
        h("label", { class: "pc-field", for: "pe-plus" }, "\u0E1A\u0E27\u0E01\u0E23\u0E32\u0E04\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C (\u0E17\u0E31\u0E49\u0E07\u0E41\u0E1E)", h("span", { class: "pc-pm" }, h("span", { class: "pc-plus" }, "+"), plus)),
        h("label", { class: "pc-field", for: "pe-minus" }, "\u0E41\u0E1E\u0E2B\u0E31\u0E01\u0E15\u0E2D\u0E19\u0E08\u0E48\u0E32\u0E22 (\u0E17\u0E31\u0E49\u0E07\u0E41\u0E1E)", h("span", { class: "pc-pm" }, h("span", { class: "pc-minus" }, "\u2212"), minus)),
        collapse("pe-collapse")
      ),
      example,
      h(
        "div",
        { class: "pc-media" },
        h("div", { class: "pc-field" }, h("span", {}, `\u0E23\u0E39\u0E1B / \u0E04\u0E25\u0E34\u0E1B (\u0E40\u0E23\u0E35\u0E22\u0E07\u0E15\u0E32\u0E21\u0E25\u0E33\u0E14\u0E31\u0E1A\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07 \xB7 \u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14 ${PRODUCT_LIMITS.imagesMax} \u0E44\u0E1F\u0E25\u0E4C)`), imageBox, picker),
        h(
          "div",
          { class: "pc-field" },
          h("label", { class: "check" }, active, "\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19"),
          imagesOnly ? h("label", { class: "check" }, imagesOnly, "\u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E39\u0E1B / \u0E04\u0E25\u0E34\u0E1B") : null,
          h("span", { class: "muted small" }, "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 = \u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E39\u0E1B\u0E43\u0E2B\u0E49\u0E40\u0E2D\u0E07")
        ),
        this.templates.length > 1 ? h("details", { class: "pc-more" }, h("summary", {}, "\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E40\u0E15\u0E34\u0E21"), h("label", { for: "pe-template" }, "Template \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21"), tpl) : h("span", { hidden: true }, tpl)
      ),
      h(
        "div",
        { class: "pc-body" },
        h("div", { class: "pc-paste" }, h("label", { for: "pe-desc" }, "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E08\u0E32\u0E01\u0E41\u0E1E (\u0E27\u0E32\u0E07\u0E17\u0E31\u0E49\u0E07\u0E01\u0E49\u0E2D\u0E19)"), desc, h("div", { class: "row" }, showOutput), output),
        table
      ),
      h(
        "div",
        { class: "pc-foot" },
        h("span", { class: "muted small" }, "\u0E17\u0E38\u0E19\u0E08\u0E30\u0E16\u0E39\u0E01\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E27\u0E49\u0E43\u0E2B\u0E49 Billdee \u0E43\u0E0A\u0E49\u0E04\u0E34\u0E14\u0E01\u0E33\u0E44\u0E23 \xB7 \u0E25\u0E39\u0E01\u0E04\u0E49\u0E32\u0E44\u0E21\u0E48\u0E40\u0E2B\u0E47\u0E19\u0E17\u0E38\u0E19"),
        h(
          "div",
          { class: "row" },
          collapse("pe-collapse-bottom"),
          p ? h("button", { class: "danger", onclick: () => void ask(`\u0E25\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 "${p.name}"? (\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E22\u0E31\u0E07\u0E2D\u0E22\u0E39\u0E48)`, { okLabel: "\u0E25\u0E1A" }).then((ok) => ok !== null && void tryCall("pu.product.delete", { id: p.id }).then(() => (this.open = null, this.refresh()))) }, "\u0E25\u0E1A") : null,
          h("button", { onclick: close }, "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01"),
          saveBtn
        )
      )
    );
    renderImages();
    renderPrices();
    return card;
  }
};

// src/app/views/product-update/queue.ts
var STATE_FULL = {
  READY: "READY",
  RUNNING: "SENDING",
  PAUSED: "PAUSED",
  DONE: "DONE",
  DONE_WITH_ERRORS: "DONE (\u0E21\u0E35\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E25\u0E49\u0E21\u0E40\u0E2B\u0E25\u0E27)",
  CANCELLED: "CANCELLED"
};
var STATE_PLAIN = {
  READY: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E23\u0E34\u0E48\u0E21\u0E2A\u0E48\u0E07",
  RUNNING: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E48\u0E07",
  PAUSED: "\u0E2B\u0E22\u0E38\u0E14\u0E44\u0E27\u0E49",
  DONE: "\u0E2A\u0E48\u0E07\u0E04\u0E23\u0E1A\u0E41\u0E25\u0E49\u0E27",
  DONE_WITH_ERRORS: "\u0E2A\u0E48\u0E07\u0E40\u0E2A\u0E23\u0E47\u0E08 (\u0E21\u0E35\u0E1A\u0E32\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08)",
  CANCELLED: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27"
};
var stateLabel = (s) => say(STATE_FULL[s], STATE_PLAIN[s]);
var QueueView = class {
  constructor(root) {
    this.root = root;
  }
  openBatch = null;
  /** True while a batch is on screen and may still change (live refresh). */
  get isLive() {
    return !this.root.hidden;
  }
  open(batchId) {
    this.openBatch = batchId;
  }
  async refresh() {
    if (this.openBatch) {
      const v = await tryCall("pu.batch.get", { batchId: this.openBatch });
      if (v) this.renderBatch(v);
      else this.openBatch = null;
      if (v) return;
    }
    const list = await tryCall("pu.batch.list", {});
    if (!list) return;
    fill(
      this.root,
      h("h2", {}, say("Queue", "\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07")),
      ...list.length ? list.map(
        (b) => h(
          "button",
          { class: "pu-card pu-batch", "data-batch": b.batch.id, onclick: () => (this.openBatch = b.batch.id, void this.refresh()) },
          h("div", { class: "row between" }, h("b", {}, b.batch.name), h("span", { class: `pu-state st-${b.state}` }, stateLabel(b.state))),
          progress(b)
        )
      ) : [h("p", { class: "muted" }, say("\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35 Batch \u2014 \u0E2A\u0E23\u0E49\u0E32\u0E07\u0E08\u0E32\u0E01\u0E2B\u0E19\u0E49\u0E32 Daily Update", '\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07 \u2014 \u0E01\u0E14 "\u0E2A\u0E48\u0E07\u0E40\u0E25\u0E22" \u0E17\u0E35\u0E48\u0E2B\u0E19\u0E49\u0E32 \u0E2A\u0E48\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49'))]
    );
  }
  renderBatch(b) {
    const id2 = b.batch.id;
    const act = (cmd) => void tryCall(cmd, { batchId: id2 }).then(() => this.refresh());
    const buttons = [];
    const card = b.batch.dateCard;
    const generating = card?.status === "GENERATING";
    if (!generating && (b.state === "READY" || b.counts.READY > 0)) buttons.push(h("button", { class: "primary", id: "qb-start", onclick: () => act("pu.batch.start") }, card?.status === "FAILED" ? say("\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E43\u0E2B\u0E21\u0E48 + START", "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E43\u0E2B\u0E21\u0E48\u0E41\u0E25\u0E49\u0E27\u0E2A\u0E48\u0E07") : say("START SEND", "\u0E40\u0E23\u0E34\u0E48\u0E21\u0E2A\u0E48\u0E07")));
    if (b.state === "RUNNING" && !generating) buttons.push(h("button", { id: "qb-pause", onclick: () => act("pu.batch.pause") }, say("PAUSE", "\u0E2B\u0E22\u0E38\u0E14\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27")));
    if (b.state === "PAUSED" && b.sends.some((s) => s.view === "PAUSED" && !s.needsCheck)) buttons.push(h("button", { class: "primary", id: "qb-resume", onclick: () => act("pu.batch.resume") }, say("RESUME", "\u0E2A\u0E48\u0E07\u0E15\u0E48\u0E2D")));
    if (["READY", "RUNNING", "PAUSED"].includes(b.state)) {
      buttons.push(h("button", { class: "danger", id: "qb-cancel", onclick: () => void ask("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07? (\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19)", { okLabel: say("\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01 Batch", "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E25\u0E37\u0E2D") }).then((ok) => ok !== null && act("pu.batch.cancel")) }, say("CANCEL", "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01")));
    }
    fill(
      this.root,
      h("div", { class: "view-head" }, h("button", { class: "link", onclick: () => (this.openBatch = null, void this.refresh()) }, say("\u2190 Queue", "\u2190 \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07")), h("h2", { id: "qb-title" }, b.batch.name)),
      stats(b),
      h(
        "div",
        { class: "card" },
        h("div", { class: "row between" }, h("b", { id: "qb-state" }, stateLabel(b.state)), h("span", { class: "muted small" }, `${b.batch.productIds.length} \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \xB7 ${b.batch.destinationIds.length} \u0E01\u0E25\u0E38\u0E48\u0E21`)),
        progress(b),
        generating ? h("div", { class: "small", id: "qb-card" }, "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E14\u0E49\u0E27\u0E22 ChatGPT \u2014 \u0E08\u0E30\u0E40\u0E23\u0E34\u0E48\u0E21\u0E2A\u0E48\u0E07\u0E40\u0E2D\u0E07\u0E40\u0E21\u0E37\u0E48\u0E2D\u0E1B\u0E49\u0E32\u0E22\u0E40\u0E2A\u0E23\u0E47\u0E08") : null,
        card?.status === "FAILED" ? h(
          "div",
          { id: "qb-card" },
          h("div", { class: "error-box small" }, `\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08: ${card.error ?? ""} \u2014 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07\u0E2D\u0E30\u0E44\u0E23`),
          h("button", { class: "small-btn", id: "qb-skip-card", onclick: () => void tryCall("pu.batch.skipCard", { batchId: id2 }).then(() => this.refresh()) }, "\u0E2A\u0E48\u0E07\u0E42\u0E14\u0E22\u0E44\u0E21\u0E48\u0E21\u0E35\u0E1B\u0E49\u0E32\u0E22")
        ) : null,
        b.current ? h(
          "div",
          { class: "qb-current", id: "qb-current", role: "group", "aria-label": "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E17\u0E35\u0E48\u0E01\u0E33\u0E25\u0E31\u0E07\u0E17\u0E33" },
          h("span", { class: "qb-current-label" }, h("span", { "aria-hidden": "true" }, "\u25CF"), "\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49"),
          h(
            "div",
            { class: "qb-current-route" },
            h("strong", {}, b.current.snapshot.productName),
            h("span", { class: "qb-current-arrow", "aria-hidden": "true" }, "\u2192"),
            h("strong", {}, b.current.snapshot.destinationName)
          ),
          b.current.progress ? h("div", { class: "qb-current-progress" }, b.current.progress) : null
        ) : null
      ),
      h("div", { class: "pu-list", id: "qb-sends" }, ...b.sends.map((s) => this.sendRow(s))),
      h("div", { class: "sticky-actions" }, ...buttons)
    );
  }
  sendRow(s) {
    const extra = [];
    if (s.needsCheck || s.view === "FAILED" && s.error?.mayHaveSent) {
      const group = s.snapshot.channel === "group";
      const feed = s.snapshot.channel === "feed";
      const line = s.snapshot.channel === "line";
      const post = group || feed;
      const hasImages = s.snapshot.imageAssetIds.length > 0 && !post;
      const resolve = (outcome) => void tryCall("pu.send.resolve", { sendId: s.id, outcome }).then(() => this.refresh());
      extra.push(
        h("p", { class: "notice small" }, group ? "\u0E15\u0E23\u0E27\u0E08\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E19\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E25\u0E30\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E01\u0E48\u0E2D\u0E19 \u2014 \u0E2B\u0E49\u0E32\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E0B\u0E49\u0E33\u0E16\u0E49\u0E32\u0E01\u0E33\u0E25\u0E31\u0E07\u0E23\u0E2D\u0E41\u0E2D\u0E14\u0E21\u0E34\u0E19" : feed ? "\u0E2D\u0E32\u0E08\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1F\u0E2A/\u0E40\u0E1E\u0E08\u0E15\u0E23\u0E27\u0E08\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33" : line ? s.imagesSentAt ? "\u0E23\u0E39\u0E1B\u0E2A\u0E48\u0E07\u0E40\u0E02\u0E49\u0E32\u0E2B\u0E49\u0E2D\u0E07 LINE \u0E41\u0E25\u0E49\u0E27 \u2014 \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E2D\u0E32\u0E08\u0E2A\u0E48\u0E07\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27 \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E19 LINE PC \u0E14\u0E39\u0E01\u0E48\u0E2D\u0E19" : "\u0E2D\u0E32\u0E08\u0E2A\u0E48\u0E07\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E19 LINE PC \u0E14\u0E39\u0E01\u0E48\u0E2D\u0E19" : s.imagesSentAt ? "\u0E23\u0E39\u0E1B\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E2D\u0E32\u0E08\u0E2A\u0E48\u0E07\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27 \u0E40\u0E1B\u0E34\u0E14\u0E41\u0E0A\u0E17\u0E14\u0E39\u0E01\u0E48\u0E2D\u0E19" : "\u0E2D\u0E32\u0E08\u0E2A\u0E48\u0E07\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E41\u0E0A\u0E17\u0E14\u0E39\u0E01\u0E48\u0E2D\u0E19"),
        h(
          "div",
          { class: "row" },
          h("button", { class: "small-btn", onclick: () => resolve("sent") }, post ? "\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E02\u0E36\u0E49\u0E19\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27" : "\u0E02\u0E36\u0E49\u0E19\u0E04\u0E23\u0E1A\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27"),
          group ? h("button", { class: "small-btn", "data-pending-approval": s.id, onclick: () => void ask("\u0E15\u0E23\u0E27\u0E08\u0E1E\u0E1A\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E19\u0E35\u0E49\u0E43\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E41\u0E25\u0E49\u0E27? \u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E41\u0E25\u0E30\u0E17\u0E33\u0E04\u0E34\u0E27\u0E15\u0E48\u0E2D\u0E42\u0E14\u0E22\u0E44\u0E21\u0E48\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E0B\u0E49\u0E33", { okLabel: "\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34" }).then((ok) => ok !== null && resolve("pending_approval")) }, "\u0E1E\u0E1A\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34 \u2014 \u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E30\u0E17\u0E33\u0E15\u0E48\u0E2D") : null,
          hasImages && !s.imagesSentAt ? h("button", { class: "small-btn", "data-images-only": s.id, onclick: () => void ask("\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E27\u0E48\u0E32\u0E23\u0E39\u0E1B\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E04\u0E23\u0E1A\u0E41\u0E25\u0E49\u0E27 \u0E41\u0E15\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \u2014 \u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21?", { okLabel: "\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21" }).then((ok) => ok !== null && resolve("images_only")) }, "\u0E23\u0E39\u0E1B\u0E02\u0E36\u0E49\u0E19\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21") : null,
          h(
            "button",
            { class: "small-btn", onclick: () => void ask(group ? "\u0E15\u0E23\u0E27\u0E08\u0E17\u0E31\u0E49\u0E07 Feed \u0E41\u0E25\u0E30\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E41\u0E25\u0E49\u0E27 \u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E27\u0E48\u0E32\u0E44\u0E21\u0E48\u0E21\u0E35\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E19\u0E35\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48?" : feed ? "\u0E15\u0E23\u0E27\u0E08\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1F\u0E2A/\u0E40\u0E1E\u0E08\u0E41\u0E25\u0E49\u0E27 \u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E27\u0E48\u0E32\u0E44\u0E21\u0E48\u0E21\u0E35\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E19\u0E35\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48?" : s.imagesSentAt ? "\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E27\u0E48\u0E32\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E19\u0E35\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21?" : "\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E27\u0E48\u0E32\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B\u0E41\u0E25\u0E30\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E19\u0E35\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E2A\u0E48\u0E07\u0E43\u0E2B\u0E21\u0E48?", { okLabel: post ? "\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48" : "\u0E2A\u0E48\u0E07\u0E43\u0E2B\u0E21\u0E48" }).then((ok) => ok !== null && resolve("not_sent")) },
            post ? "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E42\u0E1E\u0E2A\u0E15\u0E4C \u2014 \u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48" : s.imagesSentAt ? "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E02\u0E36\u0E49\u0E19 \u2014 \u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21" : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E02\u0E36\u0E49\u0E19\u0E40\u0E25\u0E22 \u2014 \u0E2A\u0E48\u0E07\u0E43\u0E2B\u0E21\u0E48"
          )
        )
      );
    } else if (s.view === "FAILED" || s.view === "CANCELLED") {
      extra.push(h("button", { class: "small-btn", "data-retry": s.id, onclick: () => void tryCall("pu.send.retry", { sendId: s.id }).then((r) => r && (toast("\u0E2A\u0E48\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49"), this.refresh())) }, "Retry"));
    }
    return h(
      "details",
      { class: `pu-send v-${s.view}`, "data-send": s.id, "data-seq": s.sequence },
      h(
        "summary",
        { class: "pu-row" },
        thumb(s.snapshot.imageAssetIds[0], s.snapshot.productName),
        h("span", { class: "pu-main" }, h("b", { class: "pu-name" }, `${String(s.sequence).padStart(2, "0")} ${s.snapshot.productName}`), h("span", { class: "muted small" }, `\u2192 ${s.snapshot.destinationName}${s.sentAt ? ` \xB7 ${timeOf(s.sentAt)}` : ""}`)),
        sendChip(s.view, s.needsCheck, s.snapshot.channel)
      ),
      s.error ? h(
        "div",
        { class: "error-box small" },
        s.error.userMessage,
        h("details", {}, h("summary", {}, "\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14"), h("pre", { class: "small" }, `${s.error.code}: ${s.error.message}`))
      ) : null,
      ...extra,
      h("pre", { class: "pu-preview" }, s.snapshot.message)
    );
  }
};
function stats(b) {
  const check = b.sends.filter((s) => s.needsCheck || s.view === "FAILED" && s.error?.mayHaveSent).length;
  const tile = (label, n, tone) => h("div", { class: `stat stat-${tone}` }, h("span", { class: "stat-label" }, label), h("span", { class: "stat-value" }, String(n)));
  return h(
    "div",
    { class: "stats", id: "qb-stats" },
    tile("\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27", b.counts.SENT, "ok"),
    ...b.counts.PENDING_APPROVAL ? [tile("\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34", b.counts.PENDING_APPROVAL, "ok")] : [],
    tile("\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E48\u0E07", b.counts.SENDING, "run"),
    tile("\u0E23\u0E2D\u0E04\u0E34\u0E27", b.counts.QUEUED + b.counts.READY + b.counts.PAUSED, "wait"),
    tile(check ? "\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E2B\u0E49\u0E04\u0E38\u0E13\u0E14\u0E39" : "\u0E25\u0E49\u0E21\u0E40\u0E2B\u0E25\u0E27", check || b.counts.FAILED, check ? "warn" : b.counts.FAILED ? "bad" : "wait")
  );
}
function progress(b) {
  const total = b.sends.length || 1;
  const done = b.counts.SENT + b.counts.PENDING_APPROVAL;
  return h(
    "div",
    { class: "prog" },
    h("div", { class: "prog-head" }, h("span", { class: "qb-progress" }, `${done} / ${b.sends.length}${b.counts.PENDING_APPROVAL ? ` \xB7 \u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34 ${b.counts.PENDING_APPROVAL}` : ""}`), b.counts.FAILED ? h("span", { class: "muted small" }, `\u0E25\u0E49\u0E21\u0E40\u0E2B\u0E25\u0E27 ${b.counts.FAILED}`) : null),
    h("div", { class: "prog-bar" }, h("div", { style: `width:${Math.round(done / total * 100)}%` }))
  );
}

// src/tools/product-update/template.ts
var TEMPLATE_FIELDS = [
  { key: "productName", label: "\u0E0A\u0E37\u0E48\u0E2D\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32" },
  { key: "price", label: "\u0E23\u0E32\u0E04\u0E32 (\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E2B\u0E19\u0E48\u0E27\u0E22)" },
  { key: "description", label: "\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14" },
  { key: "date", label: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E02\u0E2D\u0E07\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15" },
  { key: "destinationName", label: "\u0E0A\u0E37\u0E48\u0E2D\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17" }
];
var PLACEHOLDER = /\{\{|\}\}|\{([A-Za-z]+)\}/g;
var KNOWN = new Set(TEMPLATE_FIELDS.map((f) => f.key));
function unknownPlaceholders(body) {
  const out = /* @__PURE__ */ new Set();
  for (const m of body.matchAll(PLACEHOLDER)) if (m[1] && !KNOWN.has(m[1])) out.add(m[1]);
  return [...out];
}
function renderTemplate(body, data) {
  const lines = body.replace(/\r\n?/g, "\n").split("\n").flatMap((line) => {
    let placeholders = 0;
    let filled = 0;
    const rendered = line.replace(PLACEHOLDER, (all, key) => {
      if (all === "{{") return "{";
      if (all === "}}") return "}";
      if (!key || !KNOWN.has(key)) return all;
      placeholders++;
      const value = data[key].trim();
      if (value) filled++;
      return value;
    });
    return placeholders > 0 && filled === 0 ? [] : [rendered.replace(/[ \t]+$/, "")];
  });
  return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}
var CURRENCY_LABEL = { THB: "\u0E1A\u0E32\u0E17", USD: "USD" };
function formatPrice2(price, currency, unit) {
  if (price === null || !Number.isFinite(price)) return "";
  const amount = price.toLocaleString("en-US", { maximumFractionDigits: 2 });
  const cur = CURRENCY_LABEL[currency] ?? currency;
  return `${amount} ${cur}${unit ? `/${unit}` : ""}`;
}
function formatDate(ymd) {
  const d = /* @__PURE__ */ new Date(`${ymd}T00:00:00Z`);
  return Number.isNaN(d.getTime()) ? ymd : d.toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
}

// src/app/views/product-update/templates.ts
var SAMPLE = { productName: "\u0E01\u0E38\u0E49\u0E07\u0E02\u0E32\u0E27 60 \u0E15\u0E31\u0E27/\u0E01\u0E01.", price: formatPrice2(350, "THB", "\u0E01\u0E01."), description: "\u0E2A\u0E14\u0E08\u0E32\u0E01\u0E1A\u0E48\u0E2D \u0E2A\u0E48\u0E07\u0E17\u0E38\u0E01\u0E40\u0E0A\u0E49\u0E32", date: formatDate(todayYmd()), destinationName: "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32" };
var TemplatesView = class {
  constructor(root) {
    this.root = root;
  }
  templates = [];
  async refresh() {
    const t = await tryCall("pu.templates.list", {});
    if (!t) return;
    this.templates = t;
    this.renderList();
  }
  renderList() {
    fill(
      this.root,
      h("div", { class: "row pu-toolbar" }, h("button", { class: "primary", id: "pu-add-template", onclick: () => this.edit(null) }, "+ New Template")),
      h(
        "div",
        { class: "pu-list", id: "pu-templates" },
        ...this.templates.map(
          (t) => h(
            "div",
            { class: `pu-card ${t.active ? "" : "off"}`, "data-template": t.id },
            h("div", { class: "row between" }, h("b", {}, t.name), h("span", { class: "muted small" }, `\u0E43\u0E0A\u0E49\u0E01\u0E31\u0E1A ${t.usedBy} \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \xB7 ${t.active ? "\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19" : "\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48"}`)),
            h("pre", { class: "pu-preview" }, renderTemplate(t.body, SAMPLE)),
            h(
              "div",
              { class: "row" },
              h("button", { class: "small-btn", onclick: () => this.edit(t) }, "Edit"),
              h("button", { class: "small-btn", onclick: () => void tryCall("pu.template.duplicate", { id: t.id }).then(() => this.refresh()) }, "Duplicate"),
              h("button", { class: "small-btn danger", onclick: () => void this.remove(t) }, "Delete")
            )
          )
        )
      )
    );
  }
  /** A template in use can only go by moving its products to another template first. */
  async remove(t) {
    if (t.usedBy === 0) {
      if (await ask(`\u0E25\u0E1A Template "${t.name}"?`, { okLabel: "\u0E25\u0E1A" }) === null) return;
      if (await tryCall("pu.template.delete", { id: t.id })) await this.refresh();
      return;
    }
    const others = this.templates.filter((x) => x.id !== t.id);
    if (!others.length) return toast("Template \u0E19\u0E35\u0E49\u0E43\u0E0A\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E30\u0E44\u0E21\u0E48\u0E21\u0E35 Template \u0E2D\u0E37\u0E48\u0E19\u0E43\u0E2B\u0E49\u0E22\u0E49\u0E32\u0E22\u0E44\u0E1B \u2014 \u0E2A\u0E23\u0E49\u0E32\u0E07 Template \u0E43\u0E2B\u0E21\u0E48\u0E01\u0E48\u0E2D\u0E19", "error");
    const choice = await ask(`Template \u0E19\u0E35\u0E49\u0E43\u0E0A\u0E49\u0E01\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 ${t.usedBy} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23 \u2014 \u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E2B\u0E21\u0E32\u0E22\u0E40\u0E25\u0E02 Template \u0E17\u0E35\u0E48\u0E08\u0E30\u0E22\u0E49\u0E32\u0E22\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E1B \u0E41\u0E25\u0E49\u0E27\u0E25\u0E1A:
${others.map((o, i) => `${i + 1}. ${o.name}`).join("\n")}`, { input: true, okLabel: "\u0E22\u0E49\u0E32\u0E22\u0E41\u0E25\u0E49\u0E27\u0E25\u0E1A" });
    const target = choice ? others[Number(choice) - 1] : void 0;
    if (!target) return;
    const res = await tryCall("pu.template.delete", { id: t.id, reassignTo: target.id });
    if (res) {
      toast(`\u0E22\u0E49\u0E32\u0E22\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 ${res.moved} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E44\u0E1B "${target.name}" \u0E41\u0E25\u0E49\u0E27\u0E25\u0E1A`);
      await this.refresh();
    }
  }
  edit(t) {
    const name = h("input", { type: "text", id: "te-name", maxlength: 80, value: t?.name ?? "" });
    const body = h("textarea", { id: "te-body", rows: 9, maxlength: PRODUCT_LIMITS.templateBodyMax });
    body.value = t?.body ?? "{productName}\n\n\u0E23\u0E32\u0E04\u0E32 {price}\n\n{description}";
    const active = h("input", { type: "checkbox", id: "te-active", checked: t?.active ?? true });
    const preview = h("pre", { class: "pu-preview", id: "te-preview" });
    const warn = h("div", { class: "field-warn", id: "te-warn" });
    const update = () => {
      const unknown = unknownPlaceholders(body.value);
      warn.textContent = unknown.length ? `\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${unknown.map((u) => `{${u}}`).join(", ")}` : "";
      preview.textContent = renderTemplate(body.value, SAMPLE);
    };
    body.addEventListener("input", update);
    const insert = (key) => {
      const at = body.selectionStart ?? body.value.length;
      body.value = `${body.value.slice(0, at)}{${key}}${body.value.slice(body.selectionEnd ?? at)}`;
      body.focus();
      update();
    };
    fill(
      this.root,
      h("div", { class: "view-head" }, h("button", { class: "link", onclick: () => this.renderList() }, "\u2190 Templates"), h("h2", {}, t ? "\u0E41\u0E01\u0E49\u0E44\u0E02 Template" : "Template \u0E43\u0E2B\u0E21\u0E48")),
      h("label", { for: "te-name" }, "\u0E0A\u0E37\u0E48\u0E2D Template"),
      name,
      h("label", { for: "te-body" }, "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21"),
      h("div", { class: "chips" }, ...TEMPLATE_FIELDS.map((f) => h("button", { class: "chip tag", type: "button", onclick: () => insert(f.key) }, `{${f.key}} ${f.label}`))),
      body,
      warn,
      h("p", { class: "muted small" }, "\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E17\u0E35\u0E48\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E27\u0E48\u0E32\u0E07 (\u0E40\u0E0A\u0E48\u0E19 \u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14/\u0E23\u0E32\u0E04\u0E32) \u0E08\u0E30\u0E16\u0E39\u0E01\u0E15\u0E31\u0E14\u0E2D\u0E2D\u0E01\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34 \xB7 \u0E43\u0E0A\u0E49 {{ }} \u0E16\u0E49\u0E32\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E27\u0E07\u0E40\u0E25\u0E47\u0E1A\u0E1B\u0E35\u0E01\u0E01\u0E32\u0E08\u0E23\u0E34\u0E07"),
      h("label", {}, "\u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07"),
      preview,
      h("label", { class: "check" }, active, "\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19"),
      h(
        "div",
        { class: "sticky-actions" },
        h("button", {
          class: "primary",
          id: "te-save",
          onclick: () => {
            const input = { name: name.value.trim(), body: body.value, active: active.checked };
            if (!input.name) return toast("\u0E15\u0E31\u0E49\u0E07\u0E0A\u0E37\u0E48\u0E2D Template", "error");
            void tryCall("pu.template.save", t ? { id: t.id, input } : { input }).then((saved) => saved && (toast("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01 Template \u0E41\u0E25\u0E49\u0E27"), this.refresh()));
          }
        }, "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01")
      )
    );
    update();
  }
};

// src/app/views/product-update/story.ts
var ITEM_LABEL = { WAITING: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07", PREPARING: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E23\u0E39\u0E1B", PUBLISHING: "\u0E01\u0E14\u0E41\u0E0A\u0E23\u0E4C\u0E41\u0E25\u0E49\u0E27 \u0E01\u0E33\u0E25\u0E31\u0E07\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19", PUBLISHED: "\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48\u0E41\u0E25\u0E49\u0E27", FAILED: "\u0E2B\u0E22\u0E38\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E41\u0E0A\u0E23\u0E4C", UNCONFIRMED: "\u0E23\u0E2D\u0E15\u0E23\u0E27\u0E08\u0E43\u0E19 Facebook \u2014 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33" };
var StoryView = class {
  constructor(root) {
    this.root = root;
    setInterval(() => {
      if (this.root.isConnected && this.batch?.status === "RUNNING" && !this.polling && !this.busy) void this.poll();
    }, 1e3);
  }
  products = [];
  selected = /* @__PURE__ */ new Set();
  batch = null;
  busy = false;
  previewReady = false;
  previewFailed = false;
  polling = false;
  key(productId, assetId) {
    return `${productId}:${assetId}`;
  }
  choices() {
    return this.products.flatMap((p) => p.images.filter((id2) => this.selected.has(this.key(p.id, id2))).map((assetId) => ({ productId: p.id, assetId })));
  }
  async refresh() {
    if (this.busy) return;
    const [products, batch] = await Promise.all([tryCall("pu.products.list", {}), tryCall("pu.story.batch.get", {})]);
    if (products) {
      const ids = [...new Set(products.flatMap((p) => p.images))];
      const photos = new Set((await Promise.all(ids.map(async (id2) => (await assetInfo(id2))?.kind === "image" ? id2 : null))).filter((id2) => id2 !== null));
      this.products = products.map((p) => ({ ...p, images: p.images.filter((id2) => photos.has(id2)) })).filter((p) => p.images.length > 0);
    }
    if (batch !== void 0) this.batch = batch;
    const valid = new Set(this.products.flatMap((p) => p.images.map((id2) => this.key(p.id, id2))));
    this.selected = new Set([...this.selected].filter((key) => valid.has(key)));
    this.render();
  }
  async poll() {
    this.polling = true;
    try {
      const batch = await tryCall("pu.story.batch.get", {});
      if (batch !== void 0) {
        this.batch = batch;
        this.render();
      }
    } finally {
      this.polling = false;
    }
  }
  changed() {
    this.previewReady = false;
    this.previewFailed = false;
    if (this.batch?.status === "REVIEW") this.batch = null;
    this.render();
  }
  render() {
    const choices = this.choices();
    const unique = new Set(choices.map((item) => item.assetId)).size;
    const count = new Set(choices.map((item) => item.productId)).size;
    const locked = this.busy || this.batch?.status === "RUNNING";
    const review = this.batch?.status === "REVIEW";
    fill(
      this.root,
      h("h2", {}, "Facebook Story"),
      h("p", {}, "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E2B\u0E25\u0E32\u0E22\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E41\u0E25\u0E30\u0E2B\u0E25\u0E32\u0E22\u0E23\u0E39\u0E1B \u0E15\u0E23\u0E27\u0E08\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14\u0E04\u0E23\u0E31\u0E49\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27 \u0E41\u0E25\u0E49\u0E27\u0E43\u0E2B\u0E49\u0E1A\u0E2D\u0E17\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48\u0E40\u0E23\u0E35\u0E22\u0E07\u0E15\u0E32\u0E21\u0E25\u0E33\u0E14\u0E31\u0E1A \u0E23\u0E39\u0E1B\u0E25\u0E30 1 Story"),
      h("p", { class: "muted" }, "\u0E23\u0E38\u0E48\u0E19\u0E17\u0E14\u0E2A\u0E2D\u0E1A: \u0E01\u0E32\u0E23\u0E25\u0E07\u0E2B\u0E25\u0E32\u0E22\u0E23\u0E39\u0E1B\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E1A\u0E19 Facebook \u0E08\u0E23\u0E34\u0E07 \u0E2B\u0E32\u0E01\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E23\u0E39\u0E1B\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E23\u0E30\u0E1A\u0E1A\u0E08\u0E30\u0E2B\u0E22\u0E38\u0E14\u0E0A\u0E38\u0E14\u0E43\u0E2B\u0E49\u0E15\u0E23\u0E27\u0E08"),
      h(
        "section",
        { class: "du-step" },
        h("h3", {}, "1. \u0E40\u0E25\u0E37\u0E2D\u0E01\u0E23\u0E39\u0E1B\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14"),
        h(
          "div",
          { class: "row" },
          h("button", { id: "story-select-all", disabled: locked, onclick: () => {
            this.selected = new Set(this.products.flatMap((p) => p.images.map((id2) => this.key(p.id, id2))));
            this.changed();
          } }, "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E17\u0E38\u0E01\u0E23\u0E39\u0E1B"),
          h("button", { id: "story-clear", disabled: locked, onclick: () => {
            this.selected.clear();
            this.changed();
          } }, "\u0E25\u0E49\u0E32\u0E07\u0E17\u0E35\u0E48\u0E40\u0E25\u0E37\u0E2D\u0E01")
        ),
        h("p", { id: "story-selection-count" }, `${count} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23 \u2022 ${choices.length} \u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E40\u0E25\u0E37\u0E2D\u0E01 \u2022 ${unique} Story${unique < choices.length ? " (\u0E23\u0E39\u0E1B\u0E40\u0E14\u0E35\u0E22\u0E27\u0E01\u0E31\u0E19\u0E43\u0E0A\u0E49\u0E0B\u0E49\u0E33\u0E2B\u0E25\u0E32\u0E22\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E08\u0E30\u0E25\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27)" : ""}`),
        ...this.products.map((p) => h(
          "section",
          { class: "story-product", "data-story-product": p.id },
          h(
            "div",
            { class: "row" },
            h("h4", {}, `${p.name}${p.active ? "" : " (\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19)"}`),
            h("button", { "data-story-product-all": p.id, disabled: locked, onclick: () => {
              const all = p.images.every((id2) => this.selected.has(this.key(p.id, id2)));
              p.images.forEach((id2) => all ? this.selected.delete(this.key(p.id, id2)) : this.selected.add(this.key(p.id, id2)));
              this.changed();
            } }, p.images.every((id2) => this.selected.has(this.key(p.id, id2))) ? "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E17\u0E31\u0E49\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23" : "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E17\u0E38\u0E01\u0E23\u0E39\u0E1B\u0E43\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23")
          ),
          h(
            "div",
            { class: "story-images", role: "group", "aria-label": `\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E23\u0E39\u0E1B ${p.name}` },
            ...p.images.map((id2, i) => {
              const key = this.key(p.id, id2);
              return h("button", {
                class: "story-image",
                "data-story-image": id2,
                "aria-pressed": String(this.selected.has(key)),
                disabled: locked,
                onclick: () => {
                  if (this.selected.has(key)) this.selected.delete(key);
                  else this.selected.add(key);
                  this.changed();
                }
              }, thumb(id2, `\u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48 ${i + 1}`), h("span", {}, `${this.selected.has(key) ? "\u2713 " : ""}\u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48 ${i + 1}`));
            })
          )
        )),
        !this.products.length ? h("p", {}, "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B \u2014 \u0E40\u0E1E\u0E34\u0E48\u0E21\u0E23\u0E39\u0E1B\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E01\u0E48\u0E2D\u0E19") : null,
        choices.length > 200 ? h("p", {}, "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E14\u0E49\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14 200 \u0E23\u0E39\u0E1B\u0E15\u0E48\u0E2D\u0E0A\u0E38\u0E14 \u2014 \u0E25\u0E14\u0E08\u0E33\u0E19\u0E27\u0E19\u0E23\u0E39\u0E1B\u0E01\u0E48\u0E2D\u0E19\u0E15\u0E23\u0E27\u0E08\u0E0A\u0E38\u0E14") : null,
        h("button", { class: "primary", id: "story-review", disabled: !choices.length || choices.length > 200 || locked || review, onclick: () => {
          void this.review();
        } }, this.busy ? "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u2026" : "\u0E15\u0E23\u0E27\u0E08\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48")
      ),
      this.batch ? h(
        "section",
        { class: "du-step", id: "story-batch" },
        h("h3", {}, review ? "2. \u0E15\u0E23\u0E27\u0E08\u0E23\u0E39\u0E1B\u0E41\u0E25\u0E30\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14" : "\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48\u0E0A\u0E38\u0E14\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14"),
        h("p", { id: "story-owner" }, `\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Facebook: ${this.batch.owner}`),
        h("p", { id: "story-batch-count" }, `\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48\u0E41\u0E25\u0E49\u0E27 ${this.batch.items.filter((i) => i.status === "PUBLISHED").length}/${this.batch.items.length} Story`),
        h("div", { class: "story-batch-images" }, ...this.batch.items.map((item, i) => h(
          "article",
          { class: "story-batch-item", "data-story-result": item.assetId },
          thumb(item.assetId, `${i + 1}. ${item.productName} \u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48 ${item.imageNumber}`),
          h("p", {}, `${i + 1}. ${item.productName} \u2014 \u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48 ${item.imageNumber}`),
          h("p", { class: "muted" }, ITEM_LABEL[item.status]),
          item.message ? h("p", {}, item.message) : null
        ))),
        h("p", { role: "status", id: "story-batch-status" }, this.batch.message),
        review ? h("button", { class: "primary", id: "story-publish-batch", disabled: locked, onclick: () => {
          void this.start();
        } }, `\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14 ${this.batch.items.length} Story`) : null,
        this.batch.status === "RUNNING" ? h("button", { id: "story-stop-batch", disabled: this.busy || this.batch.stopRequested, onclick: () => {
          void this.stop();
        } }, "\u0E2B\u0E22\u0E38\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E23\u0E39\u0E1B\u0E16\u0E31\u0E14\u0E44\u0E1B") : null,
        this.batch.status === "STOPPED" ? h("p", {}, "\u0E15\u0E23\u0E27\u0E08\u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E23\u0E2D\u0E15\u0E23\u0E27\u0E08\u0E43\u0E19 Facebook \u0E01\u0E48\u0E2D\u0E19\u0E40\u0E23\u0E34\u0E48\u0E21\u0E0A\u0E38\u0E14\u0E43\u0E2B\u0E21\u0E48 \u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07 \u0E41\u0E25\u0E30\u0E44\u0E21\u0E48\u0E21\u0E35\u0E01\u0E32\u0E23\u0E40\u0E23\u0E34\u0E48\u0E21\u0E0A\u0E38\u0E14\u0E40\u0E14\u0E34\u0E21\u0E0B\u0E49\u0E33\u0E40\u0E2D\u0E07") : null
      ) : null,
      h("p", { class: "muted", id: "story-cta-note" }, "\u0E1B\u0E38\u0E48\u0E21\u0E17\u0E31\u0E01\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21: \u0E22\u0E31\u0E07\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E43\u0E19 Facebook Web \u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08 \u2014 \u0E25\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E39\u0E1B \u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E2B\u0E23\u0E37\u0E2D\u0E1B\u0E38\u0E48\u0E21\u0E17\u0E31\u0E1A\u0E20\u0E32\u0E1E"),
      h(
        "details",
        { open: choices.length === 1 },
        h("summary", {}, "\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21 Preview \u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27 (\u0E44\u0E21\u0E48\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48)"),
        h("p", {}, "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E40\u0E1E\u0E35\u0E22\u0E07 1 \u0E23\u0E39\u0E1B\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E1B\u0E34\u0E14\u0E15\u0E23\u0E27\u0E08\u0E43\u0E19 Facebook \u0E2B\u0E32\u0E01\u0E21\u0E35\u0E23\u0E48\u0E32\u0E07\u0E04\u0E49\u0E32\u0E07 \u0E43\u0E2B\u0E49\u0E41\u0E0A\u0E23\u0E4C\u0E2B\u0E23\u0E37\u0E2D\u0E17\u0E34\u0E49\u0E07\u0E23\u0E48\u0E32\u0E07\u0E01\u0E48\u0E2D\u0E19\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14"),
        h("button", { id: "story-prepare", disabled: choices.length !== 1 || locked || this.previewReady, onclick: () => {
          void this.prepare();
        } }, "\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21 Story \u0E41\u0E25\u0E30\u0E40\u0E1B\u0E34\u0E14 Preview"),
        h("p", { role: "status", id: "story-status" }, this.previewReady ? "\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21 Preview \u0E41\u0E25\u0E49\u0E27 \u2014 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48 \u0E15\u0E23\u0E27\u0E08\u0E43\u0E19 Facebook \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14\u0E41\u0E0A\u0E23\u0E4C\u0E40\u0E2D\u0E07" : this.previewFailed ? "\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21 Preview \u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E23\u0E48\u0E32\u0E07\u0E43\u0E19 Facebook \u0E01\u0E48\u0E2D\u0E19\u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48" : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48")
      )
    );
  }
  async review() {
    if (this.busy) return;
    this.busy = true;
    this.render();
    try {
      this.batch = await tryCall("pu.story.batch.create", { items: this.choices() }) ?? this.batch;
    } finally {
      this.busy = false;
      this.render();
    }
  }
  async start() {
    if (this.busy || this.batch?.status !== "REVIEW") return;
    this.busy = true;
    this.render();
    try {
      this.batch = await tryCall("pu.story.batch.start", { batchId: this.batch.id }) ?? this.batch;
    } finally {
      this.busy = false;
      this.render();
    }
  }
  async stop() {
    if (this.busy || this.batch?.status !== "RUNNING") return;
    this.busy = true;
    this.render();
    try {
      this.batch = await tryCall("pu.story.batch.stop", { batchId: this.batch.id }) ?? this.batch;
    } finally {
      this.busy = false;
      this.render();
    }
  }
  async prepare() {
    const choices = this.choices();
    if (this.busy || choices.length !== 1 || this.previewReady) return;
    this.busy = true;
    this.render();
    try {
      const result = await tryCall("pu.story.prepare", choices[0]);
      this.previewReady = result?.ready === true;
      this.previewFailed = !this.previewReady;
    } finally {
      this.busy = false;
      this.render();
    }
  }
};

// src/app/views/product-update/index.ts
var PU_TABS = ["daily", "products", "story", "templates", "destinations", "feeds", "groups", "line", "queue", "history", "log"];
var LABEL = { daily: "Daily Update", products: "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32", story: "Story", templates: "Templates", destinations: "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17", feeds: "\u0E40\u0E1E\u0E08 / \u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C", groups: "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E40\u0E1F\u0E2A", line: "LINE OpenChat", queue: "Queue", history: "History", log: "Log" };
var ProductUpdateView = class {
  constructor(root, onTab, layout = { main: PU_TABS, more: [], labels: {} }) {
    this.onTab = onTab;
    this.panels = Object.fromEntries(PU_TABS.map((t) => [t, h("section", { class: "tab-panel", id: `pu-tab-${t}`, hidden: true })]));
    const tabButton = (t) => h("button", { role: "tab", "data-pu-tab": t, "aria-selected": "false", onclick: () => this.show(t) }, layout.labels[t] ?? LABEL[t]);
    const more = layout.more.length ? h("details", { class: "pu-more" }, h("summary", {}, "\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E40\u0E15\u0E34\u0E21"), h("div", { class: "pu-more-menu" }, ...layout.more.map(tabButton))) : "";
    this.nav = h("nav", { class: "tabs pu-tabs", role: "tablist" }, ...layout.main.map(tabButton), more);
    fill(root, this.nav, h("main", {}, ...PU_TABS.map((t) => this.panels[t])));
    const go = (tab, batchId) => {
      if (tab === "queue") this.queue.open(batchId ?? null);
      this.show(tab);
    };
    this.daily = new DailyView(this.panels.daily, go);
    this.products = new ProductsView(this.panels.products, () => this.show("daily"));
    this.story = new StoryView(this.panels.story);
    this.templates = new TemplatesView(this.panels.templates);
    this.destinations = new ChannelView(this.panels.destinations, "FACEBOOK_GROUP_CHAT", "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17", go);
    this.feeds = new ChannelView(this.panels.feeds, "FACEBOOK_FEED", "\u0E40\u0E1E\u0E08 / \u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C", go);
    this.groups = new ChannelView(this.panels.groups, "FACEBOOK_GROUP", "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E40\u0E1F\u0E2A", go);
    this.line = new ChannelView(this.panels.line, "LINE_OPENCHAT", "LINE OpenChat", go);
    this.queue = new QueueView(this.panels.queue);
    this.history = new HistoryView(this.panels.history);
    this.log = new LogsView(this.panels.log, "product-update");
  }
  current = "daily";
  panels;
  nav;
  daily;
  products;
  story;
  templates;
  destinations;
  feeds;
  groups;
  line;
  queue;
  history;
  /** This tool's own log (sends, checks, pacing) — not mixed into the AI Content Factory log. */
  log;
  onLog(entry) {
    if (this.current === "log") this.log.onLog(entry);
  }
  show(tab) {
    this.current = tab;
    for (const b of this.nav.querySelectorAll("[data-pu-tab]")) b.setAttribute("aria-selected", String(b.dataset["puTab"] === tab));
    const menu = this.nav.querySelector(".pu-more");
    if (menu) menu.open = false;
    for (const t of PU_TABS) this.panels[t].hidden = t !== tab;
    this.onTab(tab);
    void this.refresh();
  }
  get tab() {
    return this.current;
  }
  /** Live updates: only the visible screen that shows changing state is refreshed. */
  onChanged() {
    if (this.current === "queue" || this.current === "history") void this.refresh();
    else if (this.current === "daily") void this.daily.refreshCard();
    else if (this.current === "destinations" || this.current === "feeds" || this.current === "groups" || this.current === "line") ({ destinations: this.destinations, feeds: this.feeds, groups: this.groups, line: this.line })[this.current].onChanged();
  }
  refresh() {
    const views = { daily: this.daily, products: this.products, story: this.story, templates: this.templates, destinations: this.destinations, feeds: this.feeds, groups: this.groups, line: this.line, queue: this.queue, history: this.history, log: this.log };
    return views[this.current].refresh();
  }
};

// src/ui-shared/license-panel.ts
var OK = ["ACTIVE"];
var WARN = ["OFFLINE_GRACE", "PENDING", "PIN_CHANGE"];
var REFUSED = ["INVALID_KEY", "OTHER_DEVICE", "REVOKED", "EXPIRED"];
var PLAN_LABEL = { "30d": "\u0E23\u0E32\u0E22\u0E40\u0E14\u0E37\u0E2D\u0E19", "90d": "90 \u0E27\u0E31\u0E19", "365d": "\u0E23\u0E32\u0E22\u0E1B\u0E35", forever: "\u0E15\u0E25\u0E2D\u0E14\u0E0A\u0E35\u0E1E" };
var when = (iso) => iso ? new Date(iso).toLocaleString("th-TH", { dateStyle: "medium", timeStyle: "short" }) : "-";
function googleMark() {
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 48 48");
  svg.setAttribute("width", "20");
  svg.setAttribute("height", "20");
  svg.setAttribute("aria-hidden", "true");
  const paths = [
    ["#EA4335", "M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.4 30.2 0 24 0 14.6 0 6.6 5.4 2.6 13.3l7.8 6C12.3 13.6 17.7 9.5 24 9.5z"],
    ["#4285F4", "M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.3-4.6 6.9l7.4 5.7c4.3-4 6.9-9.9 6.9-17.1z"],
    ["#FBBC05", "M10.4 28.7c-.5-1.4-.8-3-.8-4.7s.3-3.2.8-4.7l-7.8-6C1 16.5 0 20.1 0 24s1 7.5 2.6 10.7l7.8-6z"],
    ["#34A853", "M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.4-5.7c-2.1 1.4-4.8 2.3-8.5 2.3-6.3 0-11.7-4.1-13.6-9.8l-7.8 6C6.6 42.6 14.6 48 24 48z"]
  ];
  for (const [fill2, d] of paths) {
    const path = document.createElementNS(ns, "path");
    path.setAttribute("fill", fill2);
    path.setAttribute("d", d);
    svg.append(path);
  }
  return svg;
}
var LicensePanel = class {
  constructor(root) {
    this.root = root;
    root.classList.add("license-panel");
    subscribe((e) => {
      if (e.kind === "license-changed") void this.load();
    });
  }
  view = null;
  editing = false;
  /** Sign-in form shows the License Key box instead of email + PIN (customers who bought a key). */
  useKey = false;
  busy = false;
  revealedKey = null;
  keyRevision = 0;
  async load() {
    this.hideKey();
    this.view = await tryCall("license.get", {}) ?? null;
    this.render();
  }
  async run(action, done) {
    if (this.busy) return;
    this.busy = true;
    this.hideKey();
    this.render();
    try {
      this.view = await action();
      this.editing = false;
      if (done) toast(done);
    } catch (err) {
      toast(toAppError(err).userMessage, "error");
      this.view = await tryCall("license.get", {}) ?? this.view;
    } finally {
      this.busy = false;
      this.render();
    }
  }
  hideKey() {
    this.revealedKey = null;
    this.keyRevision++;
  }
  async showKey() {
    if (this.revealedKey) {
      this.hideKey();
      this.render();
      return;
    }
    const revision = ++this.keyRevision;
    const result = await tryCall("license.reveal", {});
    if (revision !== this.keyRevision) return;
    this.revealedKey = result?.key ?? null;
    this.render();
  }
  async copyKey() {
    const revision = this.keyRevision;
    const result = await tryCall("license.reveal", {});
    if (!result?.key || revision !== this.keyRevision) return;
    try {
      await navigator.clipboard.writeText(result.key);
      toast("\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E23\u0E2B\u0E31\u0E2A\u0E41\u0E25\u0E49\u0E27");
    } catch {
      toast("\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E01\u0E14\u0E14\u0E39\u0E23\u0E2B\u0E31\u0E2A \u0E41\u0E25\u0E49\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E14\u0E49\u0E27\u0E22\u0E15\u0E31\u0E27\u0E40\u0E2D\u0E07", "error");
    }
  }
  switchTo(useKey) {
    this.useKey = useKey;
    this.render();
  }
  keyForm() {
    const input = h("input", { type: "text", id: "license-key", placeholder: "DRFX-XXXXX-XXXXX-XXXXX-XXXXX", autocomplete: "off", spellcheck: false, "aria-label": "\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49" });
    const submit = () => {
      const key = input.value.trim();
      if (!key) {
        toast("\u0E43\u0E2A\u0E48\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E01\u0E48\u0E2D\u0E19", "error");
        return;
      }
      void this.run(() => call("license.activate", { key }), "\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E41\u0E25\u0E49\u0E27");
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") submit();
    });
    return h(
      "div",
      {},
      h("div", { class: "license-form" }, input, h("button", { class: "primary", id: "license-activate", disabled: this.busy, onclick: submit }, this.busy ? "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E15\u0E23\u0E27\u0E08..." : "\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49")),
      h("p", { class: "muted small" }, h("button", { class: "link", id: "license-use-email", onclick: () => this.switchTo(false) }, "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E14\u0E49\u0E27\u0E22 Google \u0E41\u0E17\u0E19"))
    );
  }
  /**
   * Google sign-in (v1.7.0): one button opens Google's own window to pick the account. A new account
   * starts a 7-day free trial on the server (v1.8.0); buying/renewing is on billdee.net. `again` = an older PIN sign-in still waiting for its own PIN.
   */
  googleForm(again = false) {
    const keyLink = h("p", { class: "lic-alt" }, h("button", { class: "link", id: "license-use-key", onclick: () => this.switchTo(true) }, "\u0E21\u0E35 License Key (DRFX-\u2026) \u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27? \u0E43\u0E0A\u0E49\u0E23\u0E2B\u0E31\u0E2A\u0E41\u0E17\u0E19"));
    const signIn = () => void this.run(() => call("license.activateGoogle", {}), "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E41\u0E25\u0E49\u0E27");
    return h(
      "div",
      { class: "lic-card" },
      h("p", { class: "lic-title" }, "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A"),
      h("p", { class: "lic-sub" }, again ? "\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49\u0E40\u0E02\u0E49\u0E32\u0E43\u0E0A\u0E49\u0E14\u0E49\u0E27\u0E22 Google \u0E41\u0E17\u0E19 PIN \u2014 \u0E01\u0E14\u0E1B\u0E38\u0E48\u0E21\u0E14\u0E49\u0E32\u0E19\u0E25\u0E48\u0E32\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E23\u0E34\u0E48\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19" : "\u0E43\u0E0A\u0E49\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Google (Gmail) \u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13"),
      h("button", { class: "lic-google", id: "license-google", disabled: this.busy, onclick: signIn }, googleMark(), h("span", {}, this.busy ? "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A..." : "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E14\u0E49\u0E27\u0E22 Google")),
      again ? null : h("p", { class: "lic-trial", id: "license-trial-note" }, "\u{1F381} \u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01 \u0E17\u0E14\u0E25\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E1F\u0E23\u0E35 7 \u0E27\u0E31\u0E19 \u2014 \u0E01\u0E14\u0E1B\u0E38\u0E48\u0E21\u0E14\u0E49\u0E32\u0E19\u0E1A\u0E19\u0E44\u0E14\u0E49\u0E40\u0E25\u0E22 \u0E44\u0E21\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E2A\u0E21\u0E31\u0E04\u0E23\u0E01\u0E48\u0E2D\u0E19 (\u0E17\u0E14\u0E25\u0E2D\u0E07\u0E44\u0E14\u0E49\u0E04\u0E23\u0E31\u0E49\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27\u0E15\u0E48\u0E2D\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E41\u0E25\u0E30\u0E15\u0E48\u0E2D\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07)"),
      h("p", { class: "lic-hint" }, "1 \u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E43\u0E0A\u0E49\u0E44\u0E14\u0E49 2 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \xB7 \u0E44\u0E21\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E08\u0E33\u0E23\u0E2B\u0E31\u0E2A \xB7 \u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E44\u0E21\u0E48\u0E40\u0E2B\u0E47\u0E19\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19 Google \u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13"),
      keyLink
    );
  }
  deactivateButton(email) {
    const question = email ? "\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E23\u0E30\u0E1A\u0E1A\u0E1A\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49? (\u0E04\u0E37\u0E19\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C 1 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \u2014 \u0E40\u0E02\u0E49\u0E32\u0E43\u0E2B\u0E21\u0E48\u0E44\u0E14\u0E49\u0E14\u0E49\u0E27\u0E22 Google)" : "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49\u0E23\u0E2B\u0E31\u0E2A\u0E19\u0E35\u0E49\u0E1A\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49? (\u0E22\u0E49\u0E32\u0E22\u0E44\u0E1B\u0E43\u0E0A\u0E49\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2D\u0E37\u0E48\u0E19\u0E44\u0E14\u0E49 \u2014 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E08\u0E30\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E08\u0E19\u0E01\u0E27\u0E48\u0E32\u0E08\u0E30\u0E43\u0E2A\u0E48\u0E23\u0E2B\u0E31\u0E2A\u0E43\u0E2B\u0E21\u0E48)";
    const label = email ? "\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E23\u0E30\u0E1A\u0E1A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49" : "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49";
    return h("button", {
      class: "danger",
      id: "license-deactivate",
      disabled: this.busy,
      onclick: () => void ask(question, { okLabel: label }).then((ok) => {
        if (ok !== null) void this.run(() => call("license.deactivate", {}), email ? "\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E23\u0E30\u0E1A\u0E1A\u0E41\u0E25\u0E49\u0E27" : "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E41\u0E25\u0E49\u0E27");
      })
    }, label);
  }
  render() {
    const v = this.view;
    if (!v) {
      fill(this.root, h("h2", {}, "\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 (License)"), h("p", { class: "muted" }, "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14..."));
      return;
    }
    const email = Boolean(v.email);
    const tone = OK.includes(v.status) ? "ok" : WARN.includes(v.status) ? "warn" : v.status === "NONE" ? "neutral" : "bad";
    const signedIn = v.status !== "NONE" && v.status !== "NOT_CONFIGURED";
    const facts = [];
    if (v.email) facts.push(["\u0E2D\u0E35\u0E40\u0E21\u0E25", v.email]);
    if (v.maskedKey) facts.push(["\u0E23\u0E2B\u0E31\u0E2A", this.revealedKey ?? v.maskedKey]);
    if (v.plan) facts.push(["\u0E41\u0E1E\u0E47\u0E01\u0E40\u0E01\u0E08", PLAN_LABEL[v.plan] ?? v.plan]);
    if (v.expiresAt && v.plan !== "forever") facts.push(["\u0E2B\u0E21\u0E14\u0E2D\u0E32\u0E22\u0E38", when(v.expiresAt)]);
    if (v.lastCheckAt) facts.push(["\u0E15\u0E23\u0E27\u0E08\u0E01\u0E31\u0E1A server \u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14", when(v.lastCheckAt)]);
    let form = null;
    if (v.status === "PIN_CHANGE") form = this.googleForm(true);
    else if (v.status !== "NOT_CONFIGURED" && (!signedIn || this.editing || REFUSED.includes(v.status))) {
      const keyMode = this.useKey || Boolean(v.maskedKey) && !this.editing;
      form = keyMode ? this.keyForm() : this.googleForm();
    }
    let actions = null;
    if (signedIn && !this.editing && v.status !== "PIN_CHANGE") {
      actions = email ? h(
        "div",
        { class: "license-actions" },
        h("button", { id: "license-refresh", disabled: this.busy, onclick: () => void this.run(() => call("license.refresh", {}), "\u0E15\u0E23\u0E27\u0E08\u0E41\u0E25\u0E49\u0E27") }, "\u0E15\u0E23\u0E27\u0E08\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49"),
        this.deactivateButton(true)
      ) : h(
        "div",
        { class: "license-actions" },
        h("button", { id: "license-reveal", disabled: this.busy, "aria-pressed": String(Boolean(this.revealedKey)), onclick: () => void this.showKey() }, this.revealedKey ? "\u0E0B\u0E48\u0E2D\u0E19\u0E23\u0E2B\u0E31\u0E2A" : "\u0E14\u0E39\u0E23\u0E2B\u0E31\u0E2A"),
        h("button", { id: "license-copy", disabled: this.busy, onclick: () => void this.copyKey() }, "\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E23\u0E2B\u0E31\u0E2A"),
        h("button", { id: "license-refresh", disabled: this.busy, onclick: () => void this.run(() => call("license.refresh", {}), "\u0E15\u0E23\u0E27\u0E08\u0E41\u0E25\u0E49\u0E27") }, "\u0E15\u0E23\u0E27\u0E08\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49"),
        h("button", {
          id: "license-switch",
          disabled: this.busy,
          onclick: () => {
            this.editing = true;
            this.hideKey();
            this.render();
          }
        }, "\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E23\u0E2B\u0E31\u0E2A / \u0E43\u0E0A\u0E49 Google"),
        this.deactivateButton(false)
      );
    }
    fill(
      this.root,
      h("h2", {}, "\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 (License)"),
      h("p", { class: `license-status ${tone}`, id: "license-status", "data-status": v.status }, v.message),
      facts.length ? h("dl", { class: "license-facts" }, ...facts.flatMap(([k, val]) => [h("dt", {}, k), h("dd", {}, val)])) : null,
      v.lastError && v.status !== "ACTIVE" ? h("p", { class: "muted small" }, `\u0E04\u0E23\u0E31\u0E49\u0E07\u0E25\u0E48\u0E32\u0E2A\u0E38\u0E14: ${v.lastError}`) : null,
      form,
      actions,
      signedIn && email ? h("p", { class: "muted small" }, "1 \u0E1A\u0E31\u0E0D\u0E0A\u0E35 Google \u0E43\u0E0A\u0E49\u0E44\u0E14\u0E49 2 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \u2014 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E17\u0E35\u0E48 3: \u0E01\u0E14 \u201C\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E23\u0E30\u0E1A\u0E1A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u201D \u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21\u0E01\u0E48\u0E2D\u0E19 (Export Backup \u0E44\u0E27\u0E49\u0E01\u0E48\u0E2D\u0E19\u0E22\u0E49\u0E32\u0E22\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07)") : null,
      signedIn && !email ? h("p", { class: "muted small" }, "\u0E22\u0E49\u0E32\u0E22\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E23\u0E37\u0E2D\u0E22\u0E49\u0E32\u0E22 Chrome: \u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E23\u0E2B\u0E31\u0E2A\u0E41\u0E25\u0E30 Export Backup \u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 \u201C\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u201D \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E19\u0E33\u0E23\u0E2B\u0E31\u0E2A\u0E44\u0E1B\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E17\u0E35\u0E48\u0E43\u0E2B\u0E21\u0E48") : null,
      h("p", { class: "muted small" }, "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E2A\u0E48\u0E07\u0E44\u0E1B\u0E15\u0E23\u0E27\u0E08\u0E41\u0E04\u0E48\u0E01\u0E32\u0E23\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E08\u0E32\u0E01 Google (\u0E2D\u0E35\u0E40\u0E21\u0E25) \u0E2B\u0E23\u0E37\u0E2D\u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49 + \u0E23\u0E2B\u0E31\u0E2A\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E2A\u0E38\u0E48\u0E21\u0E15\u0E2D\u0E19\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07 \u2014 \u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E41\u0E0A\u0E17 \u0E2B\u0E23\u0E37\u0E2D\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Facebook")
    );
  }
};

// src/ui-shared/sync-panel.ts
function mountSyncChip(chip) {
  const show = (s) => {
    chip.hidden = !s || s.state !== "error" && s.state !== "syncing";
    chip.textContent = s?.state === "syncing" ? "\u2601 \u0E01\u0E33\u0E25\u0E31\u0E07\u0E0B\u0E34\u0E07\u0E01\u0E4C\u2026" : "\u26A0 \u0E43\u0E0A\u0E49\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 (\u0E0B\u0E34\u0E07\u0E01\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08)";
    chip.title = s?.lastError ?? s?.message ?? "";
    chip.dataset["state"] = s?.state ?? "";
  };
  subscribe((e) => {
    if (e.kind === "sync-changed") show(e.status);
  });
  void tryCall("sync.status", {}).then((s) => show(s));
}

// src/shared/tutorial.ts
var TUTORIAL_STORAGE_KEY = "customerTutorialUrl";
var DEFAULT_TUTORIAL_URL = "";
function youtubeVideoId(raw) {
  try {
    const url = new URL(raw.trim());
    if (url.protocol !== "https:" || url.username || url.password || url.port) return null;
    const host = url.hostname.toLowerCase();
    let id2 = null;
    if (host === "youtu.be") id2 = /^\/([^/]+)\/?$/.exec(url.pathname)?.[1] ?? null;
    else if (["youtube.com", "www.youtube.com", "m.youtube.com", "www.youtube-nocookie.com"].includes(host)) {
      id2 = url.pathname === "/watch" ? url.searchParams.get("v") : /^\/(?:embed|shorts|live)\/([^/]+)\/?$/.exec(url.pathname)?.[1] ?? null;
    }
    return id2 && /^[A-Za-z0-9_-]{11}$/.test(id2) ? id2 : null;
  } catch {
    return null;
  }
}

// src/ui-shared/tutorial-panel.ts
async function tutorialUrl() {
  const stored = (await chrome.storage.local.get(TUTORIAL_STORAGE_KEY))[TUTORIAL_STORAGE_KEY];
  return typeof stored === "string" ? stored : DEFAULT_TUTORIAL_URL;
}
function tutorialVideo(raw) {
  const id2 = youtubeVideoId(raw);
  return h(
    "section",
    { class: "tutorial-video", id: "tutorial-video" },
    h("h3", {}, "\u0E27\u0E34\u0E18\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19"),
    id2 ? h("iframe", {
      title: "YouTube \u2014 \u0E27\u0E34\u0E18\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 Billdee PostHub",
      src: `https://www.youtube-nocookie.com/embed/${id2}`,
      referrerpolicy: "strict-origin-when-cross-origin",
      allow: "encrypted-media; fullscreen; picture-in-picture",
      allowfullscreen: true,
      sandbox: "allow-scripts allow-same-origin allow-presentation allow-popups"
    }) : h("div", { class: "tutorial-placeholder" }, "\u25B6 \u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D\u0E27\u0E34\u0E18\u0E35\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E01\u0E33\u0E25\u0E31\u0E07\u0E08\u0E31\u0E14\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21"),
    id2 ? h("a", { href: `https://www.youtube.com/watch?v=${id2}`, target: "_blank", rel: "noopener", class: "tutorial-watch" }, "\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E19 YouTube \u2197") : null,
    id2 ? h("p", { class: "muted small" }, "\u0E16\u0E49\u0E32\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D\u0E40\u0E25\u0E48\u0E19\u0E43\u0E19\u0E01\u0E23\u0E2D\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E01\u0E14 \u201C\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E19 YouTube\u201D") : null
  );
}
async function loadTutorialVideo(root) {
  const url = await tutorialUrl();
  if (root.closest("#license-gate")?.hidden) return;
  fill(root, tutorialVideo(url));
}

// src/app/main.ts
useSimpleMode();
var gate = byId("license-gate");
var tool = byId("tool-product-update");
var licensePanel = new LicensePanel(byId("license-box"));
var pill = byId("license-pill");
var renew = byId("license-renew");
var pu = new ProductUpdateView(tool, (tab) => history.replaceState(null, "", `#/${tab}`), {
  main: ["daily", "products", "destinations", "feeds", "groups", "line", "queue"],
  more: ["history", "templates", "log", "story"],
  labels: { daily: "\u0E2A\u0E48\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49", products: "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32", destinations: "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17", queue: "\u0E2A\u0E16\u0E32\u0E19\u0E30", history: "\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34", templates: "\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21", log: "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E01\u0E32\u0E23\u0E17\u0E33\u0E07\u0E32\u0E19" }
});
var opened = false;
async function applyLicense() {
  const v = await call("license.get", {}).catch(() => null);
  const ok = v !== null && toolCards(v.entitlements).some((c) => c.route === "product-update" && c.usable);
  gate.hidden = ok;
  tool.hidden = !ok;
  showLicensePill(ok ? v : null);
  if (!ok) {
    void loadTutorialVideo(byId("tutorial-guide"));
    await licensePanel.load();
    return;
  }
  byId("tutorial-guide").replaceChildren();
  if (!opened) {
    opened = true;
    const tab = location.hash.replace(/^#\/?/, "");
    pu.show(PU_TABS.includes(tab) ? tab : "daily");
  }
}
function showLicensePill(v) {
  const exp = v?.expiresAt ? new Date(v.expiresAt) : null;
  pill.hidden = !exp;
  renew.hidden = true;
  if (!exp) return;
  const days = Math.max(0, Math.ceil((exp.getTime() - Date.now() - 36e5) / 864e5));
  pill.textContent = `License \u0E40\u0E2B\u0E25\u0E37\u0E2D ${days} \u0E27\u0E31\u0E19 \xB7 \u0E16\u0E36\u0E07 ${exp.toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" })}`;
  pill.dataset["tone"] = days <= 5 ? "warn" : "ok";
  renew.hidden = days > 5 || exp.getUTCFullYear() >= 2099;
}
subscribe((event) => {
  if (event.kind === "license-changed") void applyLicense();
  else if (event.kind === "log") pu.onLog(event.entry);
  else if (event.kind === "product-update-changed" && !tool.hidden) pu.onChanged();
});
var timer = null;
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[TUTORIAL_STORAGE_KEY] && !gate.hidden) void loadTutorialVideo(byId("tutorial-guide"));
  if (area !== "local" || !changes["jobs:open"] || tool.hidden || timer) return;
  timer = setTimeout(() => {
    timer = null;
    pu.onChanged();
  }, 800);
});
byId("open-options").addEventListener("click", (ev) => {
  ev.preventDefault();
  void chrome.runtime.openOptionsPage();
});
mountSyncChip(byId("sync-chip"));
void call("app.ping", {});
void applyLicense();
