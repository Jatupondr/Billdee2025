// DRFX Product Update Bot - LINE OpenChat native messaging host (ADR-78).
// Compiled on the user's PC by install.cmd with the in-box C# compiler (csc.exe, ships with
// .NET Framework 4 on every Windows 10/11). A locally built .exe is not an AMSI-scanned script
// and carries no mark-of-the-web, so it avoids the antivirus false positives that blocked the
// earlier script-based host. There is no LINE API for OpenChat; this drives the LINE PC app like a
// person and takes
// the mouse/keyboard while a send runs. It never touches the network.
//
// Chrome <-> host framing: 4-byte little-endian length + UTF-8 JSON, over stdin/stdout.
// Modes: no args = native messaging host; "--install <extId>" / "--uninstall" = self (un)register.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

static class Host
{
    const string Version = "1.0.13";
    const string HostName = "com.drfx.line_openchat";
    static string DataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DRFX", "line-host");
    static string StageDir = Path.Combine(DataDir, "stage");
    static string LogFile = Path.Combine(DataDir, "host.log");
    static Stream _in, _out;

    [STAThread]
    static int Main(string[] args)
    {
        try { Directory.CreateDirectory(StageDir); } catch { }
        // Match coordinate spaces: with DPI awareness GetWindowRect, SetWindowPos, SetCursorPos and the
        // screenshot all use the same physical pixels, so the fractional click positions stay valid on
        // scaled displays (125%/150%). Must run before any window work.
        try { SetProcessDPIAware(); } catch { }
        if (args.Length >= 1 && args[0] == "--install") return Install(args.Length >= 2 ? args[1] : "");
        if (args.Length >= 1 && args[0] == "--uninstall") return Uninstall();
        Run();
        return 0;
    }

    // ------------------------------------------------------------------ logging
    static void Log(string msg)
    {
        try { File.AppendAllText(LogFile, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + msg + Environment.NewLine, new UTF8Encoding(false)); }
        catch { }
    }

    // ------------------------------------------------------------------ native messaging loop
    static void Run()
    {
        _in = Console.OpenStandardInput();
        _out = Console.OpenStandardOutput();
        Log("host started v" + Version);
        while (true)
        {
            Dictionary<string, object> msg;
            try { msg = ReadFrame(); }
            catch (Exception e) { Log("read failed: " + e.Message); break; }
            if (msg == null) break;
            object idObj; msg.TryGetValue("id", out idObj);
            double id = idObj is double ? (double)idObj : 0;
            string cmd = Str(msg, "cmd");
            Log("cmd " + cmd + " id=" + id);
            try
            {
                switch (cmd)
                {
                    case "ping": CmdPing(id); break;
                    case "inspect": CmdInspect(id, msg); break;
                    case "diagnose": CmdDiagnose(id); break;
                    case "stageFile": CmdStageFile(id, msg); break;
                    case "cleanup": CmdCleanup(id, msg); break;
                    case "send": CmdSend(id, msg); break;
                    default: Fail(id, "UNKNOWN_COMMAND", "Unknown command '" + cmd + "'"); break;
                }
            }
            catch (HostError he) { Log("cmd " + cmd + " failed: " + he.Code + " " + he.Message); Fail(id, he.Code, he.Message, he.Extra); }
            catch (Exception e) { Log("cmd " + cmd + " crashed: " + e); Fail(id, "HOST_ERROR", e.Message); }
            finally { if (!_keepActive) ReleaseActive(); _keepActive = false; SetBlock(false); }
        }
        Log("host exit");
    }

    static Dictionary<string, object> ReadFrame()
    {
        byte[] len = ReadExact(4);
        if (len == null) return null;
        int size = len[0] | (len[1] << 8) | (len[2] << 16) | (len[3] << 24);
        if (size <= 0 || size > 256 * 1024 * 1024) throw new Exception("bad frame size " + size);
        byte[] buf = ReadExact(size);
        if (buf == null) return null;
        object v = Json.Parse(Encoding.UTF8.GetString(buf));
        return v as Dictionary<string, object>;
    }

    static byte[] ReadExact(int n)
    {
        byte[] b = new byte[n]; int got = 0;
        while (got < n) { int r = _in.Read(b, got, n - got); if (r <= 0) return null; got += r; }
        return b;
    }

    static void WriteFrame(Dictionary<string, object> obj)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(Json.Write(obj));
        byte[] len = new byte[4];
        len[0] = (byte)(bytes.Length & 0xFF); len[1] = (byte)((bytes.Length >> 8) & 0xFF);
        len[2] = (byte)((bytes.Length >> 16) & 0xFF); len[3] = (byte)((bytes.Length >> 24) & 0xFF);
        _out.Write(len, 0, 4); _out.Write(bytes, 0, bytes.Length); _out.Flush();
    }

    static void Reply(double id, Dictionary<string, object> body) { body["id"] = id; body["ok"] = true; WriteFrame(body); }
    static void Fail(double id, string code, string message) { Fail(id, code, message, null); }
    static void Fail(double id, string code, string message, Dictionary<string, object> extra)
    {
        var b = new Dictionary<string, object> { { "id", id }, { "ok", false }, { "code", code }, { "message", message } };
        if (extra != null) foreach (var kv in extra) b[kv.Key] = kv.Value;
        WriteFrame(b);
    }
    static void Event(double id, string phase, Dictionary<string, object> extra)
    {
        var b = new Dictionary<string, object> { { "id", id }, { "event", "phase" }, { "phase", phase } };
        if (extra != null) foreach (var kv in extra) b[kv.Key] = kv.Value;
        WriteFrame(b);
    }

    class HostError : Exception
    {
        public string Code; public Dictionary<string, object> Extra;
        public HostError(string code, string message, Dictionary<string, object> extra) : base(message) { Code = code; Extra = extra; }
    }
    static void Throw(string code, string message) { throw new HostError(code, message, null); }
    static void Throw(string code, string message, Dictionary<string, object> extra) { throw new HostError(code, message, extra); }

    static string Str(Dictionary<string, object> m, string k) { object v; return m != null && m.TryGetValue(k, out v) && v != null ? v.ToString() : ""; }

    // ------------------------------------------------------------------ config (offsets as data)
    class Cfg
    {
        public string processName = "LINE";
        public int winX = 0, winY = 0, winW = 1100, winH = 760;
        public int searchX = 190, searchY = 78, searchSettle = 900;
        public string selectMode = "down-enter"; public int rowX = 190, rowY = 170, selectSettle = 1200;
        public int composerX = 560, composerY = -95;
        // Fractional click positions (0..1 of the window rect). >=0 wins over the pixel offsets above,
        // and is robust to DPI scaling and window size (measured from a diagnose screenshot).
        public double searchFx = -1, searchFy = -1, rowFx = -1, rowFy = -1, composerFx = -1, composerFy = -1;
        public int pasteSettle = 1500, perFile = 400, afterSend = 1500, textSettle = 500;
        // LINE shows an image preview after Ctrl+V: Enter confirms it, a second Enter sends. Wait between.
        public bool imageConfirm = true; public int confirmSettle = 900;
        // Lock the user's physical mouse/keyboard while the bot works (the bot's own input still goes through).
        // Windows releases it automatically on Ctrl+Alt+Del or when this process exits. Default off (mode B):
        // the user can touch; an accidental click pauses the job safely, and the open phase retries first.
        public bool blockInput = false;
        // Re-try the open phase (search + open room) this many times if the user bumps focus before any send.
        public int openRetries = 2;
        // After selecting a room, confirm from the screen that the chat header actually changed to the new
        // room and finished loading before sending. If it never changes, we STOP and send nothing (never
        // post into whatever chat happened to be open). Header band and timings are configurable.
        public int roomReadyMax = 15000, roomReadyStable = 900;
        public double hdrFl = 0.36, hdrFt = 0.02, hdrFr = 0.99, hdrFb = 0.13;
        // Remembered room header ("fingerprint"): the room-name strip of the chat header. Learned the first
        // time a room opens; later sends skip the search when the open chat already matches, and stop if a
        // search opens a chat that does not match. roomMatch/roomMismatch are similarity thresholds (0..1).
        public double fpFl = 0.36, fpFt = 0.03, fpFr = 0.80, fpFb = 0.12;
        public double roomMatch = 0.80, roomMismatch = 0.55;
        public bool requireRoomChange = true;
    }

    static Cfg _cfg;
    static Cfg LoadConfig() { return LoadConfig(null); }
    static Cfg LoadConfig(Dictionary<string, object> ui)
    {
        var c = new Cfg();
        try
        {
            string file = Path.Combine(AppDir(), "config.json");
            if (File.Exists(file))
            {
                var o = Json.Parse(File.ReadAllText(file, Encoding.UTF8)) as Dictionary<string, object>;
                if (o != null)
                {
                    var w = Get(o, "window"); if (w != null) { c.winX = I(w, "x", c.winX); c.winY = I(w, "y", c.winY); c.winW = I(w, "w", c.winW); c.winH = I(w, "h", c.winH); }
                    var s = Get(o, "search"); if (s != null) { var off = Get(s, "offset"); if (off != null) { c.searchX = I(off, "x", c.searchX); c.searchY = I(off, "y", c.searchY); } var fr = Get(s, "frac"); if (fr != null) { c.searchFx = D(fr, "x", c.searchFx); c.searchFy = D(fr, "y", c.searchFy); } c.searchSettle = I(s, "settleMs", c.searchSettle); }
                    var sel = Get(o, "select"); if (sel != null) { c.selectMode = sel.ContainsKey("mode") ? Str(sel, "mode") : c.selectMode; var off = Get(sel, "rowOffset"); if (off != null) { c.rowX = I(off, "x", c.rowX); c.rowY = I(off, "y", c.rowY); } var fr = Get(sel, "rowFrac"); if (fr != null) { c.rowFx = D(fr, "x", c.rowFx); c.rowFy = D(fr, "y", c.rowFy); } c.selectSettle = I(sel, "settleMs", c.selectSettle); }
                    var cm = Get(o, "composer"); if (cm != null) { var off = Get(cm, "offset"); if (off != null) { c.composerX = I(off, "x", c.composerX); c.composerY = I(off, "y", c.composerY); } var fr = Get(cm, "frac"); if (fr != null) { c.composerFx = D(fr, "x", c.composerFx); c.composerFy = D(fr, "y", c.composerFy); } }
                    c.pasteSettle = I(o, "pasteSettleMs", c.pasteSettle); c.perFile = I(o, "perFileSettleMs", c.perFile);
                    c.afterSend = I(o, "afterSendMs", c.afterSend); c.textSettle = I(o, "textSettleMs", c.textSettle);
                    c.confirmSettle = I(o, "confirmSettleMs", c.confirmSettle);
                    c.roomReadyMax = I(o, "roomReadyMaxMs", c.roomReadyMax); c.roomReadyStable = I(o, "roomReadyStableMs", c.roomReadyStable);
                    object rrc; if (o.TryGetValue("requireRoomChange", out rrc) && rrc is bool) c.requireRoomChange = (bool)rrc;
                    var fpb = Get(o, "roomFingerprint"); if (fpb != null) { c.fpFl = D(fpb, "l", c.fpFl); c.fpFt = D(fpb, "t", c.fpFt); c.fpFr = D(fpb, "r", c.fpFr); c.fpFb = D(fpb, "b", c.fpFb); }
                    c.roomMatch = D(o, "roomMatch", c.roomMatch); c.roomMismatch = D(o, "roomMismatch", c.roomMismatch);
                    var hb = Get(o, "roomHeader"); if (hb != null) { c.hdrFl = D(hb, "l", c.hdrFl); c.hdrFt = D(hb, "t", c.hdrFt); c.hdrFr = D(hb, "r", c.hdrFr); c.hdrFb = D(hb, "b", c.hdrFb); }
                    object ic; if (o.TryGetValue("imageConfirm", out ic) && ic is bool) c.imageConfirm = (bool)ic;
                    object bi; if (o.TryGetValue("blockInput", out bi) && bi is bool) c.blockInput = (bool)bi;
                    c.openRetries = I(o, "openRetries", c.openRetries);
                }
            }
        }
        catch (Exception e) { Log("config ignored: " + e.Message); }
        // Per-command override from the extension (the user's lock toggle): ui = { "blockInput": true/false }.
        if (ui != null) { object bi; if (ui.TryGetValue("blockInput", out bi) && bi is bool) c.blockInput = (bool)bi; }
        _cfg = c; return c;
    }
    static Dictionary<string, object> Get(Dictionary<string, object> o, string k) { object v; return o.TryGetValue(k, out v) ? v as Dictionary<string, object> : null; }
    static int I(Dictionary<string, object> o, string k, int d) { object v; if (o.TryGetValue(k, out v) && v is double) return (int)(double)v; return d; }
    static double D(Dictionary<string, object> o, string k, double d) { object v; if (o.TryGetValue(k, out v) && v is double) return (double)v; return d; }

    static string AppDir() { return Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location); }

    // ------------------------------------------------------------------ win32
    delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int max);
    [DllImport("user32.dll")] static extern int GetWindowTextLength(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int ht, uint flags);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] static extern void mouse_event(uint flags, int dx, int dy, uint data, UIntPtr extra);
    [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
    [DllImport("user32.dll")] static extern bool SystemParametersInfo(uint action, uint param, IntPtr ptr, uint ini);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr h, uint flags);
    [DllImport("user32.dll")] static extern void SwitchToThisWindow(IntPtr h, bool altTab);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool attach);
    [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] static extern bool BlockInput(bool fBlock);
    [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; }
    [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(POINT p);
    const int SW_RESTORE = 9, SW_SHOW = 5, SW_MINIMIZE = 6;
    const byte VK_MENU = 0x12; const uint KEYEVENTF_KEYUP = 0x0002;
    const uint SPI_SETFOREGROUNDLOCKTIMEOUT = 0x2001, SPIF_SENDCHANGE = 0x0002;
    const uint SWP_NOZORDER = 0x0004, SWP_SHOWWINDOW = 0x0040, SWP_NOMOVE = 0x0002, SWP_NOSIZE = 0x0001;
    static readonly IntPtr HWND_TOPMOST = new IntPtr(-1), HWND_NOTOPMOST = new IntPtr(-2);
    static readonly IntPtr HWND_BOTTOM = new IntPtr(1);
    const uint SWP_NOACTIVATE = 0x0010;
    const uint MOUSE_LEFTDOWN = 0x0002, MOUSE_LEFTUP = 0x0004;

    static string Title(IntPtr h) { int n = GetWindowTextLength(h); var sb = new StringBuilder(n + 1); GetWindowText(h, sb, sb.Capacity); return sb.ToString(); }

    static bool LineRunning(Cfg c) { try { return System.Diagnostics.Process.GetProcessesByName(c.processName).Length > 0; } catch { return false; } }

    // Launch the LINE executable again. LINE PC is single-instance, so this does NOT open a second copy —
    // it tells the already-running LINE to restore and show its main window (the reliable way to bring it
    // back when the user has minimised it to the tray, where there is no normal window to raise).
    static void LaunchLineApp(Cfg c)
    {
        string path = null;
        try
        {
            foreach (var p in System.Diagnostics.Process.GetProcessesByName(c.processName))
            {
                try { path = p.MainModule.FileName; } catch (Exception e) { Log("MainModule read failed: " + e.Message); }
                if (!string.IsNullOrEmpty(path)) break;
            }
        }
        catch (Exception e) { Log("enum LINE procs failed: " + e.Message); }
        if (string.IsNullOrEmpty(path)) { Log("LINE exe path unknown; cannot relaunch"); return; }
        try { System.Diagnostics.Process.Start(path); Log("launched line.exe to show its window: " + path); }
        catch (Exception e) { Log("launch line.exe failed: " + e.Message); }
    }

    // Returns the best LINE top-level window, and whether it is a real visible, non-iconic one.
    static IntPtr PickLineWindow(HashSet<uint> procPids, out bool goodVisible)
    {
        IntPtr best = IntPtr.Zero; long bestScore = -1; bool bestGood = false;
        EnumWindows((h, l) =>
        {
            uint pid; GetWindowThreadProcessId(h, out pid);
            if (!procPids.Contains(pid)) return true;
            string t = Title(h);
            if (string.IsNullOrEmpty(t) || (t != "LINE" && !t.StartsWith("LINE"))) return true;
            RECT r; GetWindowRect(h, out r);
            bool vis = IsWindowVisible(h); bool ico = IsIconic(h);
            long area = (long)Math.Max(0, r.Right - r.Left) * Math.Max(0, r.Bottom - r.Top);
            bool app = IsMainAppWindow(h);
            int st = GetWindowLong(h, GWL_STYLE), exs = GetWindowLong(h, GWL_EXSTYLE);
            bool minBox = (st & WS_MINIMIZEBOX) != 0;
            Log("line window hwnd=" + h.ToInt64() + " '" + t + "' class=" + ClassName(h) + " app=" + app + " minBox=" + minBox + " style=0x" + st.ToString("X8") + " ex=0x" + exs.ToString("X8") + " vis=" + vis + " iconic=" + ico + " rect " + r.Left + "," + r.Top + "," + r.Right + "," + r.Bottom);
            if (!app) return true; // notification toast / popup / helper: never use it
            bool good = vis && !ico && area > 100000; // a real, on-screen main window
            long score = area; if (good) score += 100000000L; if (good && minBox) score += 200000000L; if (ico) score = 1;
            if (score > bestScore) { bestScore = score; best = h; bestGood = good; }
            return true;
        }, IntPtr.Zero);
        goodVisible = bestGood;
        return best;
    }

    static IntPtr FindLineWindow(Cfg c)
    {
        var procPids = new HashSet<uint>();
        try { foreach (var p in System.Diagnostics.Process.GetProcessesByName(c.processName)) procPids.Add((uint)p.Id); } catch { }
        if (procPids.Count == 0) Throw("LINE_NOT_RUNNING", "LINE PC is not running");
        bool good;
        IntPtr best = PickLineWindow(procPids, out good);
        // If LINE is minimised to the tray / has no real visible window, tell LINE to open itself and look
        // again (up to 3 tries). This is the "just press line.exe" path the owner asked for.
        for (int a = 0; a < 3 && (best == IntPtr.Zero || !good); a++)
        {
            Log("LINE has no visible main window (try " + (a + 1) + "/3) - launching line.exe");
            LaunchLineApp(c);
            System.Threading.Thread.Sleep(1600);
            procPids.Clear();
            try { foreach (var p in System.Diagnostics.Process.GetProcessesByName(c.processName)) procPids.Add((uint)p.Id); } catch { }
            best = PickLineWindow(procPids, out good);
        }
        if (best == IntPtr.Zero) Throw("LINE_WINDOW_NOT_FOUND", "LINE is running but its main window was not found (still logging in?)");
        Log("line window chosen hwnd=" + best.ToInt64() + " good=" + good);
        return best;
    }

    static RECT Rect(IntPtr h) { RECT r; GetWindowRect(h, out r); return r; }

    static IntPtr _activeWin;
    static IntPtr Activate(IntPtr h, Cfg c)
    {
        // Never move/resize anything but LINE's real chat window (not its notification toast).
        if (!IsMainAppWindow(h)) { Log("activate: hwnd=" + h.ToInt64() + " is not the chat window - re-finding"); h = FindLineWindow(c); }
        try { SystemParametersInfo(SPI_SETFOREGROUNDLOCKTIMEOUT, 0, IntPtr.Zero, SPIF_SENDCHANGE); } catch { }
        for (int attempt = 0; attempt < 3; attempt++)
        {
            // Bring LINE to the front WITHOUT touching any other window. Minimise-then-restore is the one
            // sequence Windows always honours to foreground a window; then position it and lock it topmost.
            ShowWindow(h, SW_RESTORE);
            System.Threading.Thread.Sleep(100);
            ShowWindow(h, SW_MINIMIZE);
            System.Threading.Thread.Sleep(120);
            ShowWindow(h, SW_RESTORE);
            System.Threading.Thread.Sleep(150);
            SetWindowPos(h, HWND_TOPMOST, c.winX, c.winY, c.winW, c.winH, SWP_SHOWWINDOW);
            _activeWin = h;
            System.Threading.Thread.Sleep(120);
            RaiseLine(h);
            System.Threading.Thread.Sleep(200);
            RECT ar = Rect(h); Log("activate rect L" + ar.Left + " T" + ar.Top + " R" + ar.Right + " B" + ar.Bottom + " (" + (ar.Right - ar.Left) + "x" + (ar.Bottom - ar.Top) + ")");
            // Ground truth: does LINE own its own centre pixel? ("foreground" lied before — a phantom LINE
            // window can be foreground while the browser is still drawn on top.)
            POINT ctr; ctr.X = ar.Left + (ar.Right - ar.Left) / 2; ctr.Y = ar.Top + (ar.Bottom - ar.Top) / 2;
            IntPtr w = WindowFromPoint(ctr);
            if (OwnedByLine(h, w)) { if (attempt > 0) Log("LINE on top after " + (attempt + 1) + " tries"); return h; }
            // Buried or phantom window. Ask LINE to show its own real window (single-instance: no 2nd copy),
            // then re-find the now-front LINE window and try again. This never disturbs other apps (no MT5,
            // no window shuffling).
            Log("LINE not on top at centre (owner '" + Title(w) + "' class='" + ClassName(w) + "') - launching line.exe (" + (attempt + 1) + "/3)");
            LaunchLineApp(c);
            System.Threading.Thread.Sleep(1600);
            h = FindLineWindow(c);
        }
        Log("WARN: could not confirm LINE on top; proceeding");
        return h;
    }

    static bool _blocked;
    static void SetBlock(bool on)
    {
        if (on == _blocked) return;
        try { BlockInput(on); _blocked = on; } catch { }
    }

    /** Drop the temporary always-on-top so LINE behaves normally after the command. */
    static bool _keepActive;
    static void ReleaseActive()
    {
        if (_activeWin != IntPtr.Zero) { try { SetWindowPos(_activeWin, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE); } catch { } _activeWin = IntPtr.Zero; }
    }

    static HashSet<uint> _linePids;
    static HashSet<uint> LinePids(Cfg c)
    {
        var set = new HashSet<uint>();
        try { foreach (var p in System.Diagnostics.Process.GetProcessesByName(c.processName)) set.Add((uint)p.Id); } catch { }
        return set;
    }

    static bool IsLineForeground(IntPtr h)
    {
        IntPtr fg = GetForegroundWindow();
        if (fg == h) return true;
        if (GetAncestor(fg, 3) == h) return true;
        uint pid; GetWindowThreadProcessId(fg, out pid);
        if (_linePids != null && _linePids.Contains(pid)) return true;
        return false;
    }

    // Any top-level window of the LINE process counts as "still focused" (CEF/Electron apps have
    // several top-level windows: the chat list, a search popup, the room, an emoji picker...).
    static void AssertFocus(IntPtr h, string phase)
    {
        // First, a few quick checks (a transient blip settles on its own).
        for (int attempt = 0; attempt < 4; attempt++)
        {
            if (IsLineForeground(h)) return;
            System.Threading.Thread.Sleep(150);
        }
        // Still not LINE. Try to pull LINE back up to 2 times — this absorbs the browser programmatically
        // stealing the foreground (and a light accidental brush). If LINE comes back, carry on.
        for (int r = 0; r < 2; r++)
        {
            Log("focus lost at '" + phase + "' (fg='" + Title(GetForegroundWindow()) + "') - re-raising LINE " + (r + 1) + "/2");
            RaiseLine(h);
            System.Threading.Thread.Sleep(300);
            if (IsLineForeground(h)) { Log("focus recovered at '" + phase + "'"); return; }
        }
        // Could not get LINE back — the user is holding the foreground (real interaction) or the secure
        // desktop is up (Ctrl+Alt+Del). Stop here so a half-send never happens.
        IntPtr fg2 = GetForegroundWindow();
        string info = "fg='" + Title(fg2) + "' class='" + ClassName(fg2) + "'";
        Throw("FOCUS_LOST", "LINE lost focus during '" + phase + "' (" + info + ")", new Dictionary<string, object> { { "phase", phase }, { "foreground", info } });
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
    static string ClassName(IntPtr h) { var sb = new StringBuilder(256); GetClassName(h, sb, 256); return sb.ToString(); }
    [DllImport("user32.dll", EntryPoint = "GetWindowLongW")] static extern int GetWindowLong(IntPtr h, int idx);
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
    const int GWL_STYLE = -16, GWL_EXSTYLE = -20;
    const int WS_MINIMIZEBOX = 0x00020000, WS_EX_TOOLWINDOW = 0x00000080;
    const uint GW_OWNER = 4;
    // LINE's real chat window is a normal app window (has a minimise box, no owner, not a tool window).
    // Its notification toast is ALSO a top-level "LINE" window in the same process — it must never be
    // chosen, resized or clicked (that is how a notification once opened another room mid-send).
    static bool IsMainAppWindow(IntPtr h)
    {
        int ex = GetWindowLong(h, GWL_EXSTYLE);
        if ((ex & WS_EX_TOOLWINDOW) != 0) return false;
        if (GetWindow(h, GW_OWNER) != IntPtr.Zero) return false;
        return true;
    }

    // Force LINE back on top (Alt-Tab-style), regardless of the foreground lock. Shared by the click
    // guard and the focus check.
    static void RaiseLine(IntPtr h)
    {
        uint cur = GetCurrentThreadId();
        IntPtr fg = GetForegroundWindow(); uint fpid; uint ft = GetWindowThreadProcessId(fg, out fpid);
        bool at = false; if (ft != 0 && ft != cur) at = AttachThreadInput(cur, ft, true);
        try
        {
            ShowWindow(h, SW_SHOW);
            BringWindowToTop(h);
            SetForegroundWindow(h);
            SwitchToThisWindow(h, false);
            SetWindowPos(h, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
        }
        finally { if (at) AttachThreadInput(cur, ft, false); }
    }

    static bool OwnedByLine(IntPtr h, IntPtr w)
    {
        if (w == IntPtr.Zero) return false;
        if (w == h) return true;
        uint pid; GetWindowThreadProcessId(w, out pid);
        return _linePids != null && _linePids.Contains(pid);
    }

    // The real test before a click: does LINE actually own the pixel we are about to click? "Foreground"
    // is not enough — the browser can sit visually on top at that point. If something else owns it, force
    // LINE back on top (Alt-Tab-style) and re-check. Returns true if LINE owns the pixel at the end.
    static bool EnsureLineAtPoint(IntPtr h, int x, int y)
    {
        POINT pt; pt.X = x; pt.Y = y;
        if (OwnedByLine(h, WindowFromPoint(pt))) return true;
        Log("pixel (" + x + "," + y + ") owned by '" + Title(WindowFromPoint(pt)) + "' - re-raising LINE");
        for (int i = 0; i < 3; i++)
        {
            RaiseLine(h);
            System.Threading.Thread.Sleep(220);
            if (OwnedByLine(h, WindowFromPoint(pt))) { Log("pixel (" + x + "," + y + ") now owned by LINE"); return true; }
        }
        // Last resort, still without touching any other window: tell LINE to show its own window.
        LaunchLineApp(_cfg);
        System.Threading.Thread.Sleep(1300);
        RaiseLine(h);
        System.Threading.Thread.Sleep(220);
        IntPtr w2 = WindowFromPoint(pt);
        bool ok = OwnedByLine(h, w2);
        if (ok) Log("pixel (" + x + "," + y + ") now owned by LINE");
        else Log("WARN: pixel (" + x + "," + y + ") still owned by '" + Title(w2) + "' class='" + ClassName(w2) + "'");
        return ok;
    }

    static void ClickAt(IntPtr h, int ox, int oy, bool fromBottom)
    {
        RECT r = Rect(h);
        if (!IsMainAppWindow(h) || (r.Right - r.Left) < 500 || (r.Bottom - r.Top) < 350)
            Throw("LINE_WINDOW_CHANGED", "LINE window is not the chat window any more (" + ClassName(h) + " " + (r.Right - r.Left) + "x" + (r.Bottom - r.Top) + ") - not clicking");
        int x = r.Left + ox;
        int y = fromBottom ? r.Bottom + oy : r.Top + oy;
        EnsureLineAtPoint(h, x, y);
        SetCursorPos(x, y); System.Threading.Thread.Sleep(80);
        mouse_event(MOUSE_LEFTDOWN, 0, 0, 0, UIntPtr.Zero); System.Threading.Thread.Sleep(40);
        mouse_event(MOUSE_LEFTUP, 0, 0, 0, UIntPtr.Zero); System.Threading.Thread.Sleep(150);
    }

    static void ClickFrac(IntPtr h, double fx, double fy)
    {
        RECT r = Rect(h);
        if (!IsMainAppWindow(h) || (r.Right - r.Left) < 500 || (r.Bottom - r.Top) < 350)
            Throw("LINE_WINDOW_CHANGED", "LINE window is not the chat window any more (" + ClassName(h) + " " + (r.Right - r.Left) + "x" + (r.Bottom - r.Top) + ") - not clicking");
        int x = r.Left + (int)Math.Round((r.Right - r.Left) * fx);
        int y = r.Top + (int)Math.Round((r.Bottom - r.Top) * fy);
        Log("clickFrac fx" + fx + " fy" + fy + " -> (" + x + "," + y + ") in rect " + (r.Right - r.Left) + "x" + (r.Bottom - r.Top));
        EnsureLineAtPoint(h, x, y);
        SetCursorPos(x, y); System.Threading.Thread.Sleep(80);
        mouse_event(MOUSE_LEFTDOWN, 0, 0, 0, UIntPtr.Zero); System.Threading.Thread.Sleep(40);
        mouse_event(MOUSE_LEFTUP, 0, 0, 0, UIntPtr.Zero); System.Threading.Thread.Sleep(150);
    }

    static void Keys(string k) { SendKeys.SendWait(k); System.Threading.Thread.Sleep(120); }

    // ------------------------------------------------------------------ clipboard
    static string GetClipText() { try { return Clipboard.ContainsText() ? Clipboard.GetText() : null; } catch { return null; } }
    static void SetClipText(string text)
    {
        for (int i = 0; i < 25; i++) { try { Clipboard.SetText(text, TextDataFormat.UnicodeText); return; } catch { System.Threading.Thread.Sleep(200); } }
        Throw("CLIPBOARD_BUSY", "Could not put the text on the clipboard");
    }
    static void SetClipFiles(string[] paths)
    {
        var col = new System.Collections.Specialized.StringCollection(); col.AddRange(paths);
        for (int i = 0; i < 25; i++) { try { Clipboard.SetFileDropList(col); return; } catch { System.Threading.Thread.Sleep(200); } }
        Throw("CLIPBOARD_BUSY", "Could not put the files on the clipboard");
    }

    // ------------------------------------------------------------------ screenshot
    // A cheap perceptual hash of a fractional region of the LINE window, read straight off the screen
    // (LINE is on top at this point). Quantised so tiny rendering noise does not change it, so two frames
    // of the same loaded content hash equal.
    static long RegionHash(IntPtr h, double fl, double ft, double fr, double fb)
    {
        try
        {
            RECT r = Rect(h); int w = r.Right - r.Left, ht = r.Bottom - r.Top;
            int x = r.Left + (int)(w * fl), y = r.Top + (int)(ht * ft);
            int rw = (int)(w * (fr - fl)), rh = (int)(ht * (fb - ft));
            if (rw <= 2 || rh <= 2) return 0;
            using (var bmp = new Bitmap(rw, rh))
            {
                using (var g = Graphics.FromImage(bmp)) g.CopyFromScreen(x, y, 0, 0, bmp.Size);
                int gw = 40, gh = 16;
                using (var small = new Bitmap(bmp, gw, gh))
                {
                    long hash = unchecked((long)1469598103934665603UL);
                    for (int yy = 0; yy < gh; yy++)
                        for (int xx = 0; xx < gw; xx++)
                        {
                            Color px = small.GetPixel(xx, yy);
                            int v = ((px.R >> 4) << 8) | ((px.G >> 4) << 4) | (px.B >> 4);
                            hash = (hash ^ (long)v) * 1099511628211L;
                        }
                    return hash;
                }
            }
        }
        catch (Exception e) { Log("regionHash failed: " + e.Message); return 0; }
    }

    // After clicking a search result, wait until the chat header changes to the new room AND stops changing
    // (loaded). Throws ROOM_NOT_READY if the header never changes, so a half-loaded or not-opened room never
    // receives the post. "before" is the header hash captured just before the room was selected.
    static bool WaitRoomReady(IntPtr h, long before, Cfg c)
    {
        int step = 400, waited = 0, stableMs = 0;
        long last = before; bool changed = false;
        while (waited < c.roomReadyMax)
        {
            System.Threading.Thread.Sleep(step); waited += step;
            long cur = RegionHash(h, c.hdrFl, c.hdrFt, c.hdrFr, c.hdrFb);
            if (cur != 0 && cur != before) changed = true;
            if (changed && cur == last && cur != 0) { stableMs += step; if (stableMs >= c.roomReadyStable) { Log("room ready (header changed + stable) after " + waited + "ms"); return true; } }
            else stableMs = 0;
            last = cur;
        }
        if (changed) Log("WARN: room header changed but did not settle in " + c.roomReadyMax + "ms; proceeding");
        else Log("room header did not change in " + c.roomReadyMax + "ms");
        return changed;
    }

    // ---------------------------------------------------------------- remembered room header
    static string RoomsFile() { return Path.Combine(DataDir, "rooms.txt"); }
    static string RoomKey(string name) { return Convert.ToBase64String(Encoding.UTF8.GetBytes((name ?? "").Trim())); }
    static int[] LoadRoomFp(string name)
    {
        try
        {
            string f = RoomsFile(); if (!File.Exists(f)) return null;
            string key = RoomKey(name);
            foreach (var line in File.ReadAllLines(f, Encoding.UTF8))
            {
                int tab = line.IndexOf('\t'); if (tab <= 0) continue;
                if (line.Substring(0, tab) != key) continue;
                string hex = line.Substring(tab + 1).Trim();
                if (hex.Length == 0 || hex.Length % 3 != 0) return null;
                var a = new int[hex.Length / 3];
                for (int i = 0; i < a.Length; i++) a[i] = Convert.ToInt32(hex.Substring(i * 3, 3), 16);
                return a;
            }
        }
        catch (Exception e) { Log("load room header failed: " + e.Message); }
        return null;
    }
    static void SaveRoomFp(string name, int[] fp)
    {
        if (fp == null) return;
        try
        {
            string f = RoomsFile(); string key = RoomKey(name);
            var lines = new List<string>();
            if (File.Exists(f)) foreach (var line in File.ReadAllLines(f, Encoding.UTF8)) if (!line.StartsWith(key + "\t")) lines.Add(line);
            var sb = new StringBuilder(); foreach (int v in fp) sb.Append(v.ToString("X3"));
            lines.Add(key + "\t" + sb.ToString());
            Directory.CreateDirectory(DataDir);
            File.WriteAllLines(f, lines.ToArray(), Encoding.UTF8);
        }
        catch (Exception e) { Log("save room header failed: " + e.Message); }
    }
    // The room-name strip of the open chat's header as 60x10 quantised colour cells.
    static int[] HeaderFp(IntPtr h, Cfg c)
    {
        try
        {
            RECT r = Rect(h); int w = r.Right - r.Left, ht = r.Bottom - r.Top;
            int x = r.Left + (int)(w * c.fpFl), y = r.Top + (int)(ht * c.fpFt);
            int rw = (int)(w * (c.fpFr - c.fpFl)), rh = (int)(ht * (c.fpFb - c.fpFt));
            if (rw <= 4 || rh <= 4) return null;
            int gw = 60, gh = 10;
            var a = new int[gw * gh];
            using (var bmp = new Bitmap(rw, rh))
            {
                using (var g = Graphics.FromImage(bmp)) g.CopyFromScreen(x, y, 0, 0, bmp.Size);
                using (var small = new Bitmap(bmp, gw, gh))
                {
                    for (int yy = 0; yy < gh; yy++)
                        for (int xx = 0; xx < gw; xx++)
                        {
                            Color p = small.GetPixel(xx, yy);
                            a[yy * gw + xx] = ((p.R >> 4) << 8) | ((p.G >> 4) << 4) | (p.B >> 4);
                        }
                }
            }
            return a;
        }
        catch (Exception e) { Log("header fingerprint failed: " + e.Message); return null; }
    }
    static bool Near(int a, int b, int tol)
    {
        return Math.Abs((a >> 8) - (b >> 8)) <= tol && Math.Abs(((a >> 4) & 15) - ((b >> 4) & 15)) <= tol && Math.Abs((a & 15) - (b & 15)) <= tol;
    }
    static int Background(int[] a)
    {
        var d = new Dictionary<int, int>(); int best = a[0], n = 0;
        foreach (int v in a) { int k; d.TryGetValue(v, out k); k++; d[v] = k; if (k > n) { n = k; best = v; } }
        return best;
    }
    // 1.0 = same room header; low = a different room name. Compares only "ink" cells (text and icons), not
    // the plain background, so two different names do not look alike just because both are mostly background.
    static double HeaderSimilarity(int[] a, int[] b)
    {
        if (a == null || b == null || a.Length != b.Length || a.Length == 0) return 0;
        int bgA = Background(a), bgB = Background(b);
        int union = 0, same = 0;
        for (int i = 0; i < a.Length; i++)
        {
            bool inkA = !Near(a[i], bgA, 2), inkB = !Near(b[i], bgB, 2);
            if (!inkA && !inkB) continue;
            union++;
            if (inkA && inkB && Near(a[i], b[i], 2)) same++;
        }
        if (union == 0) return Near(bgA, bgB, 1) ? 1.0 : 0.0;
        return (double)same / union;
    }

    static string Screenshot(IntPtr h)
    {
        try
        {
            RECT r = Rect(h); int w = r.Right - r.Left, ht = r.Bottom - r.Top;
            if (w <= 0 || ht <= 0) return "";
            using (var bmp = new Bitmap(w, ht))
            {
                using (var g = Graphics.FromImage(bmp)) g.CopyFromScreen(r.Left, r.Top, 0, 0, bmp.Size);
                double scale = Math.Min(1.0, 900.0 / w);
                Bitmap use = bmp;
                if (scale < 1.0) use = new Bitmap(bmp, (int)(w * scale), (int)(ht * scale));
                using (var ms = new MemoryStream())
                {
                    var codec = GetJpegCodec();
                    var ep = new EncoderParameters(1); ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 70L);
                    use.Save(ms, codec, ep);
                    if (use != bmp) use.Dispose();
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }
        catch (Exception e) { Log("screenshot failed: " + e.Message); return ""; }
    }
    static ImageCodecInfo GetJpegCodec() { foreach (var c in ImageCodecInfo.GetImageEncoders()) if (c.MimeType == "image/jpeg") return c; return null; }

    // ------------------------------------------------------------------ LINE actions
    static IntPtr OpenRoom(double id, Cfg c, string roomName, string roomUrl, bool learn, out string title)
    {
        IntPtr h = FindLineWindow(c);
        _linePids = LinePids(c);
        // The open phase (focus LINE -> search -> open the room) sends nothing, so it is safe to retry when the
        // user bumps focus here. Once a send starts (in CmdSend, after this returns) there is NO retry.
        int attempts = 1 + Math.Max(0, c.openRetries);
        for (int a = 0; a < attempts; a++)
        {
            try
            {
                if (a > 0) h = FindLineWindow(c);
                h = Activate(h, c);
                if (a == 0) Event(id, "line_focused", null);
                if (!string.IsNullOrEmpty(roomUrl))
                {
                    try { System.Diagnostics.Process.Start(roomUrl); } catch (Exception e) { Log("room url failed: " + e.Message); }
                    System.Threading.Thread.Sleep(c.selectSettle + 800);
                    h = Activate(h, c);
                }
                else
                {
                    int[] remembered = LoadRoomFp(roomName);
                    bool alreadyOpen = false;
                    if (remembered != null && !learn)
                    {
                        double s0 = HeaderSimilarity(HeaderFp(h, c), remembered);
                        Log("remembered header for this room; open chat similarity = " + s0.ToString("0.00"));
                        if (s0 >= c.roomMatch) { alreadyOpen = true; Log("target room already open (matches remembered header) - skipping search"); }
                    }
                    if (!alreadyOpen)
                    {
                        if (c.searchFx >= 0) ClickFrac(h, c.searchFx, c.searchFy); else ClickAt(h, c.searchX, c.searchY, false);
                        AssertFocus(h, "search");
                        Keys("^a");
                        SetClipText(roomName);
                        Keys("^v");
                        System.Threading.Thread.Sleep(c.searchSettle);
                        AssertFocus(h, "search-results");
                        long hdrBefore = RegionHash(h, c.hdrFl, c.hdrFt, c.hdrFr, c.hdrFb);
                        if (c.selectMode == "click") { if (c.rowFx >= 0) ClickFrac(h, c.rowFx, c.rowFy); else ClickAt(h, c.rowX, c.rowY, false); }
                        else { Keys("{DOWN}"); Keys("{ENTER}"); }
                        System.Threading.Thread.Sleep(c.selectSettle);
                        // Verify from the screen that the room opened and finished loading, and (once learned)
                        // that it is THIS room. Nothing has been sent yet, so stopping here is always safe.
                        bool changed = WaitRoomReady(h, hdrBefore, c);
                        int[] after = HeaderFp(h, c);
                        double s1 = remembered == null ? -1 : HeaderSimilarity(after, remembered);
                        if (remembered != null) Log("opened chat vs remembered header: similarity " + s1.ToString("0.00"));
                        if (!changed)
                        {
                            if (remembered != null && s1 >= c.roomMatch) Log("header unchanged but it is the remembered room - already open");
                            else if (c.requireRoomChange) Throw("ROOM_NOT_READY", "the chat room did not open (search result still loading or not clicked) - nothing was sent");
                        }
                        if (remembered != null && !learn && s1 < c.roomMismatch)
                            Throw("DESTINATION_MISMATCH", "the opened chat does not look like this room (header similarity " + s1.ToString("0.00") + ") - nothing was sent");
                        if (changed && (remembered == null || learn || s1 >= c.roomMatch))
                        {
                            SaveRoomFp(roomName, after);
                            Log(remembered == null ? "learned header for this room" : (learn ? "re-learned header for this room (Test room)" : "refreshed remembered header"));
                        }
                    }
                }
                AssertFocus(h, "room");
                Event(id, "room_opened", null);
                title = ""; // LINE PC exposes no stable title without UI Automation; the user confirms the screenshot.
                return h;
            }
            catch (HostError he)
            {
                if ((he.Code != "FOCUS_LOST" && he.Code != "ROOM_NOT_READY" && he.Code != "LINE_WINDOW_CHANGED") || a >= attempts - 1) throw;
                Log("open retry " + (a + 1) + "/" + (attempts - 1) + " after " + he.Code + " during open (nothing sent yet)");
                System.Threading.Thread.Sleep(700);
            }
        }
        title = "";
        return h;
    }

    static void FocusComposer(IntPtr h, Cfg c) { if (c.composerFx >= 0) ClickFrac(h, c.composerFx, c.composerFy); else ClickAt(h, c.composerX, c.composerY, true); AssertFocus(h, "composer"); }

    // ------------------------------------------------------------------ commands
    static void CmdPing(double id)
    {
        Cfg c = LoadConfig();
        Reply(id, new Dictionary<string, object> { { "version", Version }, { "lineRunning", LineRunning(c) }, { "uia", false }, { "hostDir", AppDir() } });
    }

    static void CmdInspect(double id, Dictionary<string, object> msg)
    {
        Cfg c = LoadConfig(Get(msg, "ui"));
        if (c.blockInput) SetBlock(true);
        string title; IntPtr h = OpenRoom(id, c, Str(msg, "roomName"), Str(msg, "roomUrl"), true, out title);
        Reply(id, new Dictionary<string, object> { { "title", "" }, { "verifiedBy", "screenshot" }, { "screenshot", Screenshot(h) } });
    }

    static void CmdDiagnose(double id)
    {
        Cfg c = LoadConfig();
        if (!LineRunning(c)) { Reply(id, new Dictionary<string, object> { { "lineRunning", false }, { "uia", false }, { "version", Version } }); return; }
        IntPtr h = FindLineWindow(c); h = Activate(h, c);
        RECT r = Rect(h);
        // Confirm LINE really is on top at its own centre (demotes any window covering it), so the user
        // visibly sees LINE come up when they press Diagnose.
        EnsureLineAtPoint(h, r.Left + (r.Right - r.Left) / 2, r.Top + (r.Bottom - r.Top) / 2);
        _keepActive = true; // leave LINE on top after Diagnose so the user can see it came up
        r = Rect(h);
        Reply(id, new Dictionary<string, object> {
            { "lineRunning", true }, { "uia", false }, { "version", Version }, { "title", Title(h) },
            { "rect", new Dictionary<string, object> { { "left", (double)r.Left }, { "top", (double)r.Top }, { "width", (double)(r.Right - r.Left) }, { "height", (double)(r.Bottom - r.Top) } } },
            { "elements", new List<object>() }, { "screenshot", Screenshot(h) }
        });
    }

    static void CmdStageFile(double id, Dictionary<string, object> msg)
    {
        string session = Clean(Str(msg, "sessionId"));
        if (session.Length == 0) Throw("INVALID_INPUT", "sessionId missing");
        string dir = Path.Combine(StageDir, session); Directory.CreateDirectory(dir);
        string name = CleanName(Str(msg, "name")); if (name.Length == 0) name = "image";
        object idx; int index = msg.TryGetValue("index", out idx) && idx is double ? (int)(double)idx : 0;
        string path = Path.Combine(dir, index.ToString("D2") + "-" + name);
        File.WriteAllBytes(path, Convert.FromBase64String(Str(msg, "dataBase64")));
        Reply(id, new Dictionary<string, object> { { "path", path }, { "bytes", (double)new FileInfo(path).Length } });
    }

    static void CmdCleanup(double id, Dictionary<string, object> msg)
    {
        string session = Clean(Str(msg, "sessionId"));
        if (session.Length > 0) { try { Directory.Delete(Path.Combine(StageDir, session), true); } catch { } }
        Reply(id, new Dictionary<string, object> { { "removed", true } });
    }

    static void CmdSend(double id, Dictionary<string, object> msg)
    {
        Cfg c = LoadConfig(Get(msg, "ui"));
        if (c.blockInput) SetBlock(true);
        string roomName = Str(msg, "roomName"), roomUrl = Str(msg, "roomUrl"), expected = Str(msg, "expectedTitle"), text = Str(msg, "text");
        var files = new List<string>();
        object fo; if (msg.TryGetValue("files", out fo) && fo is List<object>) foreach (var f in (List<object>)fo) files.Add(f == null ? "" : f.ToString());
        foreach (var f in files) if (!File.Exists(f)) Throw("FILE_MISSING", "Staged file missing: " + f);
        if (text.Length == 0 && files.Count == 0) Throw("INVALID_INPUT", "Nothing to send");

        string prevClip = GetClipText();
        string title; IntPtr h = OpenRoom(id, c, roomName, roomUrl, false, out title);
        bool imagesSent = false;
        try
        {
            if (files.Count > 0)
            {
                FocusComposer(h, c);
                SetClipFiles(files.ToArray());
                Keys("^v");
                // Wait for LINE's image preview (confirm dialog) to appear.
                System.Threading.Thread.Sleep(c.pasteSettle);
                AssertFocus(h, "images_pasted");
                Event(id, "images_pasted", new Dictionary<string, object> { { "count", (double)files.Count } });
                // Enter confirms the preview; a second Enter sends. (imageConfirm=false => single Enter.)
                Keys("{ENTER}");
                if (c.imageConfirm) { System.Threading.Thread.Sleep(c.confirmSettle); Keys("{ENTER}"); }
                imagesSent = true;
                // Wait ~3s per image for the upload to finish before the text.
                System.Threading.Thread.Sleep(c.afterSend + c.perFile * files.Count);
                Event(id, "images_sent", new Dictionary<string, object> { { "count", (double)files.Count } });
            }
            if (text.Length > 0)
            {
                // Focus can drift to the browser during the long image-upload wait (seen in both lock modes).
                // Re-grab LINE and retry the paste the same way the open phase does — the text has NOT been sent
                // yet (the Enter that sends is OUTSIDE this loop), so re-grabbing/re-pasting never double-sends.
                // Ctrl+A before each paste selects whatever is already in the composer, so a retry REPLACES it
                // instead of appending a second copy of the text.
                int tAttempts = 1 + Math.Max(0, c.openRetries);
                for (int a = 0; a < tAttempts; a++)
                {
                    try
                    {
                        h = Activate(h, c);
                        FocusComposer(h, c);
                        Keys("^a");
                        SetClipText(text);
                        Keys("^v");
                        System.Threading.Thread.Sleep(c.textSettle);
                        AssertFocus(h, "text_pasted");
                        break;
                    }
                    catch (HostError he)
                    {
                        if (he.Code != "FOCUS_LOST" || a >= tAttempts - 1) throw;
                        Log("text retry " + (a + 1) + "/" + (tAttempts - 1) + " after focus loss before send");
                        System.Threading.Thread.Sleep(700);
                    }
                }
                Keys("{ENTER}");
                System.Threading.Thread.Sleep(c.afterSend);
                Event(id, "text_sent", null);
            }
        }
        catch (HostError he)
        {
            if (imagesSent) { if (he.Extra == null) he.Extra = new Dictionary<string, object>(); he.Extra["mayHaveSent"] = true; he.Extra["imagesSent"] = true; }
            throw;
        }
        finally { if (prevClip != null) { try { SetClipText(prevClip); } catch { } } }
        Reply(id, new Dictionary<string, object> { { "title", "" }, { "imagesSent", files.Count > 0 }, { "textSent", text.Length > 0 }, { "confirmedBy", "host" } });
    }

    static string Clean(string s) { var sb = new StringBuilder(); foreach (char ch in s) if (char.IsLetterOrDigit(ch) || ch == '_' || ch == '-') sb.Append(ch); return sb.ToString(); }
    static string CleanName(string s) { var sb = new StringBuilder(); foreach (char ch in s) sb.Append("\\/:*?\"<>|".IndexOf(ch) >= 0 ? '_' : ch); return sb.ToString(); }

    // ------------------------------------------------------------------ self (un)install
    static int Install(string extensionId)
    {
        try
        {
            if (!IsExtId(extensionId)) { Console.Error.WriteLine("bad extension id"); return 2; }
            string exe = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string manifestPath = Path.Combine(Path.GetDirectoryName(exe), HostName + ".json");
            string json = "{\n"
                + "  \"name\": \"" + HostName + "\",\n"
                + "  \"description\": \"DRFX Product Update Bot - LINE OpenChat sender (drives LINE PC on this computer)\",\n"
                + "  \"path\": \"" + exe.Replace("\\", "\\\\") + "\",\n"
                + "  \"type\": \"stdio\",\n"
                + "  \"allowed_origins\": [ \"chrome-extension://" + extensionId + "/\" ]\n"
                + "}\n";
            File.WriteAllText(manifestPath, json, new UTF8Encoding(false));
            foreach (string root in new[] { @"Software\Google\Chrome\NativeMessagingHosts", @"Software\Microsoft\Edge\NativeMessagingHosts", @"Software\Chromium\NativeMessagingHosts" })
                using (var key = Registry.CurrentUser.CreateSubKey(root + "\\" + HostName)) key.SetValue("", manifestPath);
            Console.WriteLine(manifestPath);
            return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e.Message); return 1; }
    }

    static int Uninstall()
    {
        try
        {
            foreach (string root in new[] { @"Software\Google\Chrome\NativeMessagingHosts", @"Software\Microsoft\Edge\NativeMessagingHosts", @"Software\Chromium\NativeMessagingHosts" })
                try { Registry.CurrentUser.DeleteSubKeyTree(root + "\\" + HostName, false); } catch { }
            try { Directory.Delete(StageDir, true); } catch { }
            return 0;
        }
        catch { return 1; }
    }

    static bool IsExtId(string s) { if (s == null || s.Length != 32) return false; foreach (char ch in s) if (ch < 'a' || ch > 'p') return false; return true; }
}

// ---------------------------------------------------------------------- minimal JSON (objects, arrays, strings, numbers, bool, null)
static class Json
{
    public static object Parse(string s) { int i = 0; object v = ParseValue(s, ref i); return v; }

    static object ParseValue(string s, ref int i)
    {
        SkipWs(s, ref i);
        char ch = s[i];
        if (ch == '{') return ParseObject(s, ref i);
        if (ch == '[') return ParseArray(s, ref i);
        if (ch == '"') return ParseString(s, ref i);
        if (ch == 't') { i += 4; return true; }
        if (ch == 'f') { i += 5; return false; }
        if (ch == 'n') { i += 4; return null; }
        return ParseNumber(s, ref i);
    }

    static Dictionary<string, object> ParseObject(string s, ref int i)
    {
        var o = new Dictionary<string, object>(); i++; SkipWs(s, ref i);
        if (s[i] == '}') { i++; return o; }
        while (true)
        {
            SkipWs(s, ref i);
            string key = ParseString(s, ref i);
            SkipWs(s, ref i); i++; // ':'
            o[key] = ParseValue(s, ref i);
            SkipWs(s, ref i);
            char ch = s[i++];
            if (ch == '}') break;
        }
        return o;
    }

    static List<object> ParseArray(string s, ref int i)
    {
        var a = new List<object>(); i++; SkipWs(s, ref i);
        if (s[i] == ']') { i++; return a; }
        while (true)
        {
            a.Add(ParseValue(s, ref i));
            SkipWs(s, ref i);
            char ch = s[i++];
            if (ch == ']') break;
        }
        return a;
    }

    static string ParseString(string s, ref int i)
    {
        var sb = new StringBuilder(); i++; // opening quote
        while (true)
        {
            char ch = s[i++];
            if (ch == '"') break;
            if (ch == '\\')
            {
                char e = s[i++];
                switch (e)
                {
                    case '"': sb.Append('"'); break;
                    case '\\': sb.Append('\\'); break;
                    case '/': sb.Append('/'); break;
                    case 'b': sb.Append('\b'); break;
                    case 'f': sb.Append('\f'); break;
                    case 'n': sb.Append('\n'); break;
                    case 'r': sb.Append('\r'); break;
                    case 't': sb.Append('\t'); break;
                    case 'u': sb.Append((char)int.Parse(s.Substring(i, 4), NumberStyles.HexNumber)); i += 4; break;
                    default: sb.Append(e); break;
                }
            }
            else sb.Append(ch);
        }
        return sb.ToString();
    }

    static object ParseNumber(string s, ref int i)
    {
        int start = i;
        while (i < s.Length && "-+.eE0123456789".IndexOf(s[i]) >= 0) i++;
        return double.Parse(s.Substring(start, i - start), CultureInfo.InvariantCulture);
    }

    static void SkipWs(string s, ref int i) { while (i < s.Length && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r')) i++; }

    public static string Write(object v)
    {
        var sb = new StringBuilder(); WriteValue(sb, v); return sb.ToString();
    }

    static void WriteValue(StringBuilder sb, object v)
    {
        if (v == null) { sb.Append("null"); return; }
        if (v is bool) { sb.Append((bool)v ? "true" : "false"); return; }
        if (v is string) { WriteString(sb, (string)v); return; }
        if (v is double) { double d = (double)v; sb.Append(d == Math.Floor(d) && !double.IsInfinity(d) ? ((long)d).ToString(CultureInfo.InvariantCulture) : d.ToString("R", CultureInfo.InvariantCulture)); return; }
        if (v is int) { sb.Append(((int)v).ToString(CultureInfo.InvariantCulture)); return; }
        if (v is IDictionary)
        {
            sb.Append('{'); bool first = true;
            foreach (DictionaryEntry kv in (IDictionary)v) { if (!first) sb.Append(','); first = false; WriteString(sb, kv.Key.ToString()); sb.Append(':'); WriteValue(sb, kv.Value); }
            sb.Append('}'); return;
        }
        if (v is IEnumerable)
        {
            sb.Append('['); bool first = true;
            foreach (var item in (IEnumerable)v) { if (!first) sb.Append(','); first = false; WriteValue(sb, item); }
            sb.Append(']'); return;
        }
        WriteString(sb, v.ToString());
    }

    static void WriteString(StringBuilder sb, string s)
    {
        sb.Append('"');
        foreach (char ch in s)
        {
            switch (ch)
            {
                case '"': sb.Append("\\\""); break;
                case '\\': sb.Append("\\\\"); break;
                case '\b': sb.Append("\\b"); break;
                case '\f': sb.Append("\\f"); break;
                case '\n': sb.Append("\\n"); break;
                case '\r': sb.Append("\\r"); break;
                case '\t': sb.Append("\\t"); break;
                default:
                    if (ch < ' ') sb.Append("\\u").Append(((int)ch).ToString("x4"));
                    else sb.Append(ch);
                    break;
            }
        }
        sb.Append('"');
    }
}
