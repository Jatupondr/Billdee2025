"use strict";
(() => {
  // src/shared/errors.ts
  var ErrorCode = {
    LOGIN_REQUIRED: "LOGIN_REQUIRED",
    CAPTCHA_REQUIRED: "CAPTCHA_REQUIRED",
    PERMISSION_MISSING: "PERMISSION_MISSING",
    SELECTOR_NOT_FOUND: "SELECTOR_NOT_FOUND",
    INPUT_REJECTED: "INPUT_REJECTED",
    PAGE_NOT_READY: "PAGE_NOT_READY",
    WEBSITE_UNAVAILABLE: "WEBSITE_UNAVAILABLE",
    RATE_LIMITED: "RATE_LIMITED",
    QUOTA_EXCEEDED: "QUOTA_EXCEEDED",
    GENERATION_FAILED: "GENERATION_FAILED",
    CONTENT_POLICY_BLOCKED: "CONTENT_POLICY_BLOCKED",
    RESPONSE_PARSE_FAILED: "RESPONSE_PARSE_FAILED",
    TIMEOUT: "TIMEOUT",
    PROGRESS_STALLED: "PROGRESS_STALLED",
    DOWNLOAD_FAILED: "DOWNLOAD_FAILED",
    DOWNLOAD_INTERRUPTED: "DOWNLOAD_INTERRUPTED",
    UPLOAD_FAILED: "UPLOAD_FAILED",
    PUBLISH_UNCONFIRMED: "PUBLISH_UNCONFIRMED",
    SEND_UNCONFIRMED: "SEND_UNCONFIRMED",
    DESTINATION_MISMATCH: "DESTINATION_MISMATCH",
    SEND_FAILED: "SEND_FAILED",
    ACCOUNT_RESTRICTED: "ACCOUNT_RESTRICTED",
    NATIVE_SCHEDULE_UNAVAILABLE: "NATIVE_SCHEDULE_UNAVAILABLE",
    BRIDGE_UNREACHABLE: "BRIDGE_UNREACHABLE",
    TAB_CLOSED: "TAB_CLOSED",
    INTERRUPTED: "INTERRUPTED",
    INVALID_INPUT: "INVALID_INPUT",
    INVALID_STATE: "INVALID_STATE",
    NOT_FOUND: "NOT_FOUND",
    PROVIDER_NOT_CONFIGURED: "PROVIDER_NOT_CONFIGURED",
    LICENSE_REQUIRED: "LICENSE_REQUIRED",
    CANCELLED: "CANCELLED",
    INTERNAL: "INTERNAL"
  };
  var META = {
    LOGIN_REQUIRED: { retryable: false, pause: "LOGIN_REQUIRED", userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 \u2014 \u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    CAPTCHA_REQUIRED: { retryable: false, pause: "CAPTCHA", userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E02\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E15\u0E31\u0E27\u0E15\u0E19 (CAPTCHA) \u2014 \u0E17\u0E33\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    PERMISSION_MISSING: { retryable: false, userMessage: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E40\u0E02\u0E49\u0E32\u0E16\u0E36\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E19\u0E35\u0E49 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    SELECTOR_NOT_FOUND: { retryable: true, userMessage: "\u0E2B\u0E32\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E40\u0E08\u0E2D \u2014 \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u0E25\u0E2D\u0E07\u0E01\u0E14 Diagnose \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    INPUT_REJECTED: { retryable: true, userMessage: "\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E23\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34" },
    PAGE_NOT_READY: { retryable: true, userMessage: "\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E22\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21" },
    WEBSITE_UNAVAILABLE: { retryable: true, userMessage: "\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32" },
    RATE_LIMITED: { retryable: false, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E16\u0E35\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B \u2014 \u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E1E\u0E31\u0E01\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry" },
    QUOTA_EXCEEDED: { retryable: false, userMessage: "\u0E43\u0E0A\u0E49\u0E42\u0E04\u0E27\u0E15\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07" },
    GENERATION_FAILED: { retryable: true, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    CONTENT_POLICY_BLOCKED: { retryable: false, userMessage: "\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E1B\u0E0F\u0E34\u0E40\u0E2A\u0E18 prompt \u0E19\u0E35\u0E49 (\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32) \u2014 \u0E41\u0E01\u0E49 prompt \u0E41\u0E25\u0E49\u0E27 Retry" },
    RESPONSE_PARSE_FAILED: { retryable: true, userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E08\u0E32\u0E01 AI \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07)" },
    TIMEOUT: { retryable: true, userMessage: "\u0E23\u0E2D\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14" },
    PROGRESS_STALLED: { retryable: true, userMessage: "\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E27\u0E32\u0E21\u0E04\u0E37\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B" },
    DOWNLOAD_FAILED: { retryable: true, userMessage: "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    DOWNLOAD_INTERRUPTED: { retryable: true, userMessage: "\u0E01\u0E32\u0E23\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30" },
    UPLOAD_FAILED: { retryable: true, userMessage: "\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    PUBLISH_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E02\u0E36\u0E49\u0E19\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E0B\u0E49\u0E33" },
    SEND_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E0A\u0E17\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33" },
    DESTINATION_MISMATCH: { retryable: false, userMessage: "\u0E41\u0E0A\u0E17\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E44\u0E27\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07" },
    SEND_FAILED: { retryable: false, userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    ACCOUNT_RESTRICTED: { retryable: false, pause: "INTERRUPTED", userMessage: "Facebook \u0E08\u0E33\u0E01\u0E31\u0E14\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E2A\u0E48\u0E07\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u0E15\u0E23\u0E27\u0E08\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A Facebook \u0E41\u0E25\u0E30\u0E23\u0E2D\u0E08\u0E19\u0E02\u0E49\u0E2D\u0E08\u0E33\u0E01\u0E31\u0E14\u0E2B\u0E21\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E15\u0E48\u0E2D" },
    NATIVE_SCHEDULE_UNAVAILABLE: { retryable: false, userMessage: "\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A\u0E02\u0E2D\u0E07 Facebook \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E43\u0E0A\u0E49\u0E15\u0E31\u0E27\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E41\u0E17\u0E19" },
    BRIDGE_UNREACHABLE: { retryable: true, userMessage: "\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D\u0E2A\u0E04\u0E23\u0E34\u0E1B\u0E15\u0E4C\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
    TAB_CLOSED: { retryable: true, userMessage: "\u0E41\u0E17\u0E47\u0E1A\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E16\u0E39\u0E01\u0E1B\u0E34\u0E14\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E17\u0E33\u0E07\u0E32\u0E19" },
    INTERRUPTED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E07\u0E32\u0E19\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30 (browser/\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E23\u0E35\u0E2A\u0E15\u0E32\u0E23\u0E4C\u0E17) \u2014 \u0E15\u0E23\u0E27\u0E08\u0E1C\u0E25\u0E1A\u0E19\u0E40\u0E27\u0E47\u0E1A \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry \u0E2B\u0E23\u0E37\u0E2D Cancel" },
    INVALID_INPUT: { retryable: false, userMessage: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E21\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" },
    INVALID_STATE: { retryable: false, userMessage: "\u0E17\u0E33\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E19\u0E35\u0E49\u0E43\u0E19\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
    NOT_FOUND: { retryable: false, userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E23\u0E30\u0E1A\u0E38" },
    PROVIDER_NOT_CONFIGURED: { retryable: false, userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49 \u2014 \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    LICENSE_REQUIRED: { retryable: false, pause: "LICENSE_REQUIRED", userMessage: "License \u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u2014 \u0E07\u0E32\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E23\u0E34\u0E48\u0E21 \u0E15\u0E23\u0E27\u0E08 License \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    CANCELLED: { retryable: false, userMessage: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27" },
    INTERNAL: { retryable: false, userMessage: "\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E20\u0E32\u0E22\u0E43\u0E19 \u2014 \u0E14\u0E39\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E43\u0E19 Log" }
  };
  var AppError = class extends Error {
    code;
    retryable;
    userMessage;
    detail;
    constructor(code, message, opts = {}) {
      super(message, opts.cause === void 0 ? void 0 : { cause: opts.cause });
      this.name = "AppError";
      this.code = code;
      this.retryable = opts.retryable ?? META[code].retryable;
      this.userMessage = opts.userMessage ?? META[code].userMessage;
      this.detail = opts.detail;
    }
    get pauseReason() {
      return META[this.code].pause;
    }
    toJSON() {
      const json = {
        code: this.code,
        message: this.message,
        userMessage: this.userMessage,
        retryable: this.retryable
      };
      if (this.detail !== void 0) json.detail = this.detail;
      return json;
    }
  };
  function isErrorCode(value) {
    return typeof value === "string" && value in META;
  }
  function toAppError(err, fallback = ErrorCode.INTERNAL) {
    if (err instanceof AppError) return err;
    if (isAppErrorJSON(err)) return fromJSON(err);
    if (err instanceof DOMException && err.name === "AbortError") {
      return new AppError(ErrorCode.CANCELLED, "Operation aborted", { cause: err });
    }
    const message = err instanceof Error ? err.message : String(err);
    return new AppError(fallback, message, { cause: err });
  }
  function isAppErrorJSON(value) {
    if (typeof value !== "object" || value === null) return false;
    const v = value;
    return isErrorCode(v["code"]) && typeof v["message"] === "string";
  }
  function fromJSON(json) {
    const code = isErrorCode(json.code) ? json.code : ErrorCode.INTERNAL;
    return new AppError(code, json.message, {
      userMessage: json.userMessage,
      retryable: json.retryable,
      detail: json.detail
    });
  }

  // src/shared/schema.ts
  function fail(path, expected, value) {
    const got = value === null ? "null" : Array.isArray(value) ? "array" : typeof value;
    throw new AppError(ErrorCode.INVALID_INPUT, `${path || "value"}: expected ${expected}, got ${got}`, {
      detail: { path, expected }
    });
  }
  function string(opts = {}) {
    return (value, path = "") => {
      if (typeof value !== "string") fail(path, "string", value);
      if (opts.min !== void 0 && value.length < opts.min) fail(path, `string length >= ${opts.min}`, value);
      if (opts.max !== void 0 && value.length > opts.max) fail(path, `string length <= ${opts.max}`, value);
      if (opts.pattern && !opts.pattern.test(value)) fail(path, `string matching ${opts.pattern}`, value);
      return value;
    };
  }
  function number(opts = {}) {
    return (value, path = "") => {
      if (typeof value !== "number" || !Number.isFinite(value)) fail(path, "finite number", value);
      if (opts.int && !Number.isInteger(value)) fail(path, "integer", value);
      if (opts.min !== void 0 && value < opts.min) fail(path, `number >= ${opts.min}`, value);
      if (opts.max !== void 0 && value > opts.max) fail(path, `number <= ${opts.max}`, value);
      return value;
    };
  }
  var boolean = (value, path = "") => {
    if (typeof value !== "boolean") fail(path, "boolean", value);
    return value;
  };
  function literal(...values) {
    return (value, path = "") => {
      if (!values.includes(value)) fail(path, `one of ${values.join("|")}`, value);
      return value;
    };
  }
  function array(item, opts = {}) {
    return (value, path = "") => {
      if (!Array.isArray(value)) fail(path, "array", value);
      if (opts.max !== void 0 && value.length > opts.max) fail(path, `array length <= ${opts.max}`, value);
      if (opts.min !== void 0 && value.length < opts.min) fail(path, `array length >= ${opts.min}`, value);
      return value.map((v, i) => item(v, `${path}[${i}]`));
    };
  }
  function optional(inner) {
    return (value, path = "") => value === void 0 ? void 0 : inner(value, path);
  }
  function object(shape) {
    return (value, path = "") => {
      if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
      const src = value;
      const out = {};
      for (const [key, validator] of Object.entries(shape)) {
        const v = validator(src[key], path ? `${path}.${key}` : key);
        if (v !== void 0) out[key] = v;
      }
      return out;
    };
  }
  var id = string({ min: 1, max: 64, pattern: /^[A-Za-z0-9_-]+$/ });

  // src/providers/chatgpt/selectors.ts
  var CHATGPT_SELECTORS = {
    composer: [
      { css: "#prompt-textarea" },
      { css: "div.ProseMirror[contenteditable='true']" },
      { css: "textarea[name='prompt-textarea']" },
      { css: "form div[contenteditable='true']" },
      { role: "textbox", name: /message|ask anything|ถามอะไรก็ได้|ส่งข้อความ/i }
    ],
    /** Composer file inputs (checked live 2026-11-13); never the camera one (capture). */
    fileInput: [
      { css: "form input[type='file'][accept='image/*'][multiple]" },
      { css: "form input[type='file'][multiple]:not([capture])" },
      { css: "input[type='file']:not([capture])" }
    ],
    sendButton: [
      { css: "button[data-testid='send-button']" },
      { css: "#composer-submit-button" },
      { role: "button", name: /^send( prompt| message)?$|^ส่ง/i }
    ],
    stopButton: [
      { css: "button[data-testid='stop-button']" },
      { role: "button", name: /stop (streaming|generating)|หยุด/i }
    ],
    // 2026-11 layout (checked live 2026-11-13): no data-message-author-role any more — each message
    // is a "search unit" whose key ends with its role, e.g. "fallback-turn-0:2:assistant".
    assistantMessage: [{ css: "[data-message-author-role='assistant']" }, { css: "[data-content-search-unit-key$=':assistant']" }],
    userMessage: [{ css: "[data-message-author-role='user']" }, { css: "[data-content-search-unit-key$=':user']" }],
    /** The turn's state in the 2026-11 layout ("complete" when the answer is finished). */
    turnState: [{ css: "[data-talvt-turn-state]" }],
    /** Screen-reader heading inside a message ("ChatGPT พูดว่า:") — not part of the answer. */
    roleHeading: [{ css: "[data-conversation-role]" }],
    messageText: [{ css: ".markdown" }, { css: "[class*='markdown']" }],
    codeBlock: [{ css: "pre code" }, { css: "pre" }],
    /**
     * Generated images are matched page-wide and compared with the images present before the prompt
     * (the image turn is not always inside a [data-message-author-role] element).
     */
    generatedImage: [
      { css: "img[alt*='generated image' i]" },
      { css: "img[alt*='\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\u0E17\u0E35\u0E48\u0E2A\u0E23\u0E49\u0E32\u0E07']" },
      { css: "img[src*='/backend-api/estuary/content']" },
      { css: "img[src*='oaiusercontent.com']" },
      { css: "main img" }
    ],
    /**
     * Images that can only come from the image tool (no generic "main img": web-search replies show
     * favicons). Used to notice an image being made when a text answer was asked for.
     */
    toolImage: [
      { css: "img[alt*='generated image' i]" },
      { css: "img[alt*='\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\u0E17\u0E35\u0E48\u0E2A\u0E23\u0E49\u0E32\u0E07']" },
      { css: "img[src*='/backend-api/estuary/content']" },
      { css: "img[src*='oaiusercontent.com']" }
    ],
    loginButton: [
      { css: "button[data-testid='login-button']" },
      { css: "a[href*='auth/login']" },
      { role: "button", name: /^log in$|^เข้าสู่ระบบ$/i }
    ],
    /** Modal dialogs (ChatGPT shows "Too many requests" as a modal with an OK button). */
    dialog: [{ css: "[role='dialog']" }, { css: "[role='alertdialog']" }],
    errorBanner: [
      { css: "[role='alert']" },
      { css: ".text-token-text-error" },
      { css: "[class*='text-red']" }
    ]
  };
  var CHATGPT_TEXT = {
    rateLimit: /you('|’)ve (reached|hit) (the|your) (current )?(usage|message|plan)? ?(cap|limit)|usage cap|too many requests|limit for (image|message)|making requests too quickly|requests too quickly|เกินขีดจำกัด|ถึงขีดจำกัด|คำขอจำนวนมากเกินไป|คำขอเร็วเกินไป|ส่งคำขอถี่เกินไป/i,
    policy: /content polic(y|ies)|violat(e|es|ion)|I can('|’)t (help|create|generate|make)|unable to (create|generate)|ไม่สามารถ(สร้าง|ช่วย)/i,
    /** Status shown while the image tool is working (used to catch it early in text steps). */
    imageInProgress: /creating image|generating image|image created|กำลังสร้าง(รูป)?ภาพ|สร้างรูปภาพแล้ว/i,
    genericError: /something went wrong|network error|an error occurred|เกิดข้อผิดพลาด/i
  };

  // src/providers/chatgpt/protocol.ts
  var CHATGPT_PROVIDER_ID = "chatgpt-web";
  var CHATGPT_PREFIX = "chatgpt";
  var CHATGPT_BRIDGE_VERSION = "4";
  var CHATGPT_CMD = {
    submit: `${CHATGPT_PREFIX}.submit`,
    waitReply: `${CHATGPT_PREFIX}.waitReply`,
    stop: `${CHATGPT_PREFIX}.stop`,
    inspect: `${CHATGPT_PREFIX}.inspect`,
    /** Attach files (already transferred to the page) to the composer; resolves when their previews show. */
    attach: `${CHATGPT_PREFIX}.attach`
  };
  var REPLY_QUIET_MS = 2e3;
  var IMAGE_QUIET_MS = 4e3;
  var REATTACH_GRACE_MS = 12e3;
  var IMAGE_TEXT_ONLY_MS = 45e3;
  var EMPTY_REPLY_MS = 3e4;
  var MAX_KNOWN_IMAGES = 300;
  var MIN_IMAGE_WIDTH = 256;

  // src/shared/async.ts
  function abortError(signal) {
    const reason = signal?.reason;
    if (reason instanceof AppError) return reason;
    return new AppError(ErrorCode.CANCELLED, "Operation cancelled");
  }
  function throwIfAborted(signal) {
    if (signal?.aborted) throw abortError(signal);
  }
  function withTimeout(promise, ms, what, code = ErrorCode.TIMEOUT) {
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new AppError(code, `${what} timed out after ${ms} ms`, { detail: { ms } })), ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
  }

  // src/bridges/bridge-kit/dom.ts
  var POLL_MS = 400;
  var IMPLICIT_ROLE = {
    button: "button,[role='button'],input[type='button'],input[type='submit']",
    textbox: "textarea,input[type='text'],input:not([type]),[contenteditable='true'],[role='textbox']",
    dialog: "[role='dialog'],dialog",
    link: "a[href],[role='link']",
    img: "img,[role='img']",
    checkbox: "input[type='checkbox'],[role='checkbox']",
    menuitem: "[role='menuitem']",
    tab: "[role='tab']",
    alert: "[role='alert'],[role='alertdialog']",
    combobox: "select,[role='combobox']",
    option: "option,[role='option']",
    heading: "h1,h2,h3,h4,h5,h6,[role='heading']"
  };
  function accessibleName(el) {
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.trim();
    const labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      const text = labelledBy.split(/\s+/).map((id2) => el.ownerDocument.getElementById(id2)?.textContent ?? "").join(" ").trim();
      if (text) return text;
    }
    const attr = el.getAttribute("title") ?? el.getAttribute("placeholder") ?? el.getAttribute("alt");
    if (attr) return attr.trim();
    const placeholder = el.getAttribute("data-placeholder");
    if (placeholder) return placeholder.trim();
    return (el.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function queryCandidate(c, root = document) {
    let els;
    if (c.css && c.role) {
      const roleSel = IMPLICIT_ROLE[c.role] ?? `[role='${c.role}']`;
      els = Array.from(root.querySelectorAll(c.css)).filter((e) => e.matches(roleSel));
    } else if (c.css) {
      els = Array.from(root.querySelectorAll(c.css));
    } else if (c.role) {
      els = Array.from(root.querySelectorAll(IMPLICIT_ROLE[c.role] ?? `[role='${c.role}']`));
    } else {
      els = Array.from(root.querySelectorAll("*"));
    }
    const { name, text } = c;
    if (name) els = els.filter((e) => name.test(accessibleName(e)));
    if (text) els = els.filter((e) => text.test((e.textContent ?? "").replace(/\s+/g, " ").trim()));
    return els;
  }
  function isVisible(el) {
    if (!(el instanceof HTMLElement) && !(el instanceof SVGElement)) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    const style = getComputedStyle(el);
    return !(style.visibility === "hidden" || style.display === "none" || Number(style.opacity) === 0);
  }
  function isEnabled(el) {
    if (el.disabled) return false;
    return el.getAttribute("aria-disabled") !== "true";
  }
  function resolveFirst(list, opts = {}) {
    const root = opts.root ?? document;
    for (let i = 0; i < list.length; i++) {
      const candidate = list[i];
      const el = queryCandidate(candidate, root).find(
        (e) => (opts.visible === false || isVisible(e)) && (!opts.enabled || isEnabled(e))
      );
      if (el) return { el, index: i };
    }
    return null;
  }
  function waitForCondition(check, opts) {
    return new Promise((resolve, reject) => {
      throwIfAborted(opts.signal);
      let settled = false;
      const finish = (fn) => {
        if (settled) return;
        settled = true;
        observer.disconnect();
        clearInterval(poll);
        clearTimeout(deadline);
        opts.signal?.removeEventListener("abort", onAbort);
        fn();
      };
      const evaluate = () => {
        try {
          const value = check();
          if (value !== null && value !== void 0 && value !== false) finish(() => resolve(value));
        } catch (err) {
          finish(() => reject(err instanceof Error ? err : new AppError(ErrorCode.INTERNAL, String(err))));
        }
      };
      const observer = new MutationObserver(evaluate);
      observer.observe(opts.observe ?? document, { childList: true, subtree: true, attributes: true, characterData: true });
      const poll = setInterval(evaluate, POLL_MS);
      const deadline = setTimeout(
        () => finish(
          () => reject(opts.onTimeout?.() ?? new AppError(ErrorCode.TIMEOUT, `${opts.what} not reached in ${opts.timeoutMs} ms`))
        ),
        opts.timeoutMs
      );
      const onAbort = () => {
        const reason = opts.signal?.reason;
        finish(() => reject(reason instanceof AppError ? reason : new AppError(ErrorCode.CANCELLED, "Cancelled")));
      };
      opts.signal?.addEventListener("abort", onAbort, { once: true });
      evaluate();
    });
  }
  function waitFor(key, list, opts) {
    return waitForCondition(() => resolveFirst(list, opts), {
      ...opts,
      what: key,
      onTimeout: () => new AppError(ErrorCode.SELECTOR_NOT_FOUND, `Element "${key}" not found within ${opts.timeoutMs} ms`, {
        detail: { selector: key }
      })
    });
  }
  function diagnoseSelectors(map, keys = Object.keys(map)) {
    return keys.map((key) => {
      const list = map[key] ?? [];
      const found = resolveFirst(list, { visible: false });
      return { key, found: found !== null, matchedIndex: found?.index ?? -1, candidates: list.length };
    });
  }

  // src/bridges/bridge-kit/file-input.ts
  function setInputFiles(input, files) {
    if (input.type !== "file") throw new AppError(ErrorCode.UPLOAD_FAILED, "Target is not a file input");
    const data = new DataTransfer();
    for (const f of files) data.items.add(f);
    input.files = data.files;
    if ((input.files?.length ?? 0) !== files.length) {
      throw new AppError(ErrorCode.UPLOAD_FAILED, "File input rejected the files");
    }
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // src/bridges/bridge-kit/input.ts
  function normalise(s) {
    return s.replace(/\s+/g, " ").trim();
  }
  function currentText(el) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) return el.value;
    return el.innerText ?? el.textContent ?? "";
  }
  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (!setter) throw new AppError(ErrorCode.INPUT_REJECTED, "No native value setter");
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function selectAllIn(el) {
    const selection = el.ownerDocument.getSelection();
    if (!selection) return;
    const range = el.ownerDocument.createRange();
    range.selectNodeContents(el);
    selection.removeAllRanges();
    selection.addRange(range);
  }
  function pasteText(el, text) {
    const data = new DataTransfer();
    data.setData("text/plain", text);
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: data, bubbles: true, cancelable: true }));
  }
  function comparable(s) {
    return s.replace(/[^\p{L}\p{M}\p{N}]+/gu, "");
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function settle(check, ms) {
    const until = Date.now() + ms;
    for (; ; ) {
      if (check()) return true;
      if (Date.now() >= until) return false;
      await sleep(50);
    }
  }
  var SETTLE_MS = 2e3;
  async function selectAll(el) {
    el.focus();
    selectAllIn(el);
    await sleep(60);
  }
  async function clearEditor(el) {
    for (let i = 0; i < 3; i++) {
      if (!comparable(currentText(el))) return true;
      await selectAll(el);
      el.ownerDocument.execCommand("delete", false);
      if (await settle(() => !comparable(currentText(el)), 500)) return true;
      await selectAll(el);
      el.dispatchEvent(new InputEvent("beforeinput", { inputType: "deleteContentBackward", bubbles: true, cancelable: true }));
      if (await settle(() => !comparable(currentText(el)), 500)) return true;
    }
    return !comparable(currentText(el));
  }
  async function replaceText(el, text) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      setNativeValue(el, text);
      if (el.value !== text) throw new AppError(ErrorCode.INPUT_REJECTED, "Input value did not stick");
      return;
    }
    const expected = comparable(text);
    const landed = () => comparable(currentText(el)) === expected;
    const attempts = [
      () => pasteText(el, text),
      () => el.ownerDocument.execCommand("insertText", false, text)
    ];
    for (const attempt of attempts) {
      if (!await clearEditor(el)) break;
      await selectAll(el);
      attempt();
      if (await settle(landed, SETTLE_MS)) return;
    }
    const got = normalise(currentText(el)).slice(0, 120);
    await clearEditor(el);
    throw new AppError(ErrorCode.INPUT_REJECTED, "Editor did not accept the text", { detail: { got } });
  }
  function clickElement(el) {
    if (!(el instanceof HTMLElement)) throw new AppError(ErrorCode.INPUT_REJECTED, "Target is not clickable");
    el.scrollIntoView({ block: "center", inline: "center" });
    const rect = el.getBoundingClientRect();
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      clientX: rect.left + rect.width / 2,
      clientY: rect.top + rect.height / 2,
      button: 0
    };
    el.dispatchEvent(new PointerEvent("pointerdown", { ...init, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mousedown", init));
    el.dispatchEvent(new PointerEvent("pointerup", { ...init, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mouseup", init));
    el.dispatchEvent(new MouseEvent("click", init));
  }
  function pressEnter(el) {
    const init = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
    el.dispatchEvent(new KeyboardEvent("keydown", init));
    el.dispatchEvent(new KeyboardEvent("keypress", init));
    el.dispatchEvent(new KeyboardEvent("keyup", init));
  }

  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 1;
  var counter = 0;
  function newRequestId() {
    counter = (counter + 1) % 1e6;
    return `${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }
  function envelope(type, payload, id2 = newRequestId()) {
    return { v: PROTOCOL_VERSION, id: id2, type, payload };
  }
  function isEnvelope(value) {
    if (typeof value !== "object" || value === null) return false;
    const v = value;
    return v["v"] === PROTOCOL_VERSION && typeof v["id"] === "string" && typeof v["type"] === "string";
  }
  function ok(data) {
    return { ok: true, data };
  }
  function failure(err) {
    return { ok: false, error: toAppError(err).toJSON() };
  }
  var BRIDGE_PROGRESS = "bridge.progress";
  var BRIDGE_CANCEL = "bridge.cancel";
  var PORT_TRANSFER_TO_EXTENSION = "acf-transfer-in:";
  var PORT_TRANSFER_TO_PAGE = "acf-transfer-out:";

  // src/shared/hash.ts
  async function sha256Hex(data) {
    const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
  }

  // src/shared/transfer-codec.ts
  var TRANSFER_CHUNK_BYTES = 1024 * 1024;
  var TRANSFER_MAX_BYTES = 1024 * 1024 * 1024;
  function bytesToBase64(bytes) {
    let binary = "";
    const step = 32768;
    for (let i = 0; i < bytes.length; i += step) {
      binary += String.fromCharCode(...bytes.subarray(i, i + step));
    }
    return btoa(binary);
  }
  function base64ToBytes(b64) {
    const binary = atob(b64);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }
  async function sendBlobOverPort(port, blob, name) {
    if (blob.size > TRANSFER_MAX_BYTES) {
      throw new AppError(ErrorCode.UPLOAD_FAILED, `File too large to transfer (${blob.size} bytes)`);
    }
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const chunks = Math.max(1, Math.ceil(bytes.length / TRANSFER_CHUNK_BYTES));
    const ack = new Promise((resolve, reject) => {
      port.onMessage.addListener((msg) => {
        if (msg.k !== "ack") return;
        if (msg.ok) resolve();
        else reject(new AppError(ErrorCode.UPLOAD_FAILED, `Receiver rejected transfer: ${msg.error}`));
      });
      port.onDisconnect.addListener(
        () => reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer port disconnected before ack"))
      );
    });
    port.postMessage({ k: "meta", size: bytes.length, mime: blob.type, name, chunks });
    for (let i = 0; i < chunks; i++) {
      const slice2 = bytes.subarray(i * TRANSFER_CHUNK_BYTES, (i + 1) * TRANSFER_CHUNK_BYTES);
      port.postMessage({ k: "chunk", i, b64: bytesToBase64(slice2) });
    }
    port.postMessage({ k: "end", sha256: await sha256Hex(bytes) });
    await ack;
  }
  function receiveBlobFromPort(port) {
    return new Promise((resolve, reject) => {
      let meta = null;
      const parts = [];
      const fail2 = (error) => {
        try {
          port.postMessage({ k: "ack", ok: false, error });
        } catch {
        }
        reject(new AppError(ErrorCode.UPLOAD_FAILED, error));
      };
      port.onDisconnect.addListener(() => {
        if (!meta || parts.length < meta.chunks) reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer interrupted"));
      });
      port.onMessage.addListener((msg) => {
        if (msg.k === "meta") {
          if (msg.size > TRANSFER_MAX_BYTES) return fail2("file too large");
          meta = msg;
          return;
        }
        if (msg.k === "chunk") {
          if (!meta || msg.i !== parts.length) return fail2(`unexpected chunk ${msg.i}`);
          parts.push(base64ToBytes(msg.b64));
          return;
        }
        if (msg.k === "end") {
          const m = meta;
          if (!m || parts.length !== m.chunks) return fail2("missing chunks");
          const file = new File(parts, m.name, { type: m.mime });
          void file.arrayBuffer().then((buf) => sha256Hex(buf)).then((hash) => {
            if (hash !== msg.sha256) return fail2("checksum mismatch");
            port.postMessage({ k: "ack", ok: true });
            resolve(file);
          }, (err) => fail2(String(err)));
        }
      });
    });
  }

  // src/bridges/bridge-kit/transfer.ts
  async function sendBlobToExtension(transferId, blob, name, timeoutMs) {
    const port = chrome.runtime.connect({ name: `${PORT_TRANSFER_TO_EXTENSION}${transferId}` });
    try {
      await withTimeout(sendBlobOverPort(port, blob, name), timeoutMs, "Transfer to extension", ErrorCode.DOWNLOAD_FAILED);
    } finally {
      port.disconnect();
    }
  }
  function expectFileFromExtension(transferId, timeoutMs) {
    const expected = `${PORT_TRANSFER_TO_PAGE}${transferId}`;
    let listener = null;
    const file = new Promise((resolve, reject) => {
      listener = (port) => {
        if (port.name !== expected) return;
        if (port.sender?.id !== chrome.runtime.id) {
          port.disconnect();
          reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer from unexpected sender"));
          return;
        }
        receiveBlobFromPort(port).then(resolve, reject);
      };
      chrome.runtime.onConnect.addListener(listener);
    });
    return withTimeout(file, timeoutMs, "Transfer from extension", ErrorCode.UPLOAD_FAILED).finally(() => {
      if (listener) chrome.runtime.onConnect.removeListener(listener);
    });
  }
  async function fetchInPage(url, signal) {
    const res = await fetch(url, { credentials: "include", ...signal ? { signal } : {} });
    if (!res.ok) throw new AppError(ErrorCode.DOWNLOAD_FAILED, `HTTP ${res.status} for media`, { detail: { status: res.status } });
    return res.blob();
  }
  var pendingReceives = /* @__PURE__ */ new Map();
  function prepareReceive(transferId, timeoutMs) {
    const file = expectFileFromExtension(transferId, timeoutMs);
    file.catch(() => void 0);
    pendingReceives.set(transferId, file);
  }
  async function takeReceived(transferId) {
    const file = pendingReceives.get(transferId);
    if (!file) throw new AppError(ErrorCode.UPLOAD_FAILED, `No transfer prepared for ${transferId}`);
    try {
      return await file;
    } finally {
      pendingReceives.delete(transferId);
    }
  }

  // src/bridges/bridge-kit/server.ts
  function extensionAlive() {
    try {
      return typeof chrome !== "undefined" && Boolean(chrome.runtime?.id);
    } catch {
      return false;
    }
  }
  function startBridge(providerId, version, handlers) {
    const registry = globalThis.__acfBridges ??= {};
    registry[providerId]?.dispose();
    const inflight = /* @__PURE__ */ new Map();
    const listener = (message, sender, sendResponse) => {
      if (!isEnvelope(message) || sender.id !== chrome.runtime.id || sender.tab || sender.url?.startsWith("http")) return false;
      const env = message;
      if (env.type === BRIDGE_CANCEL) {
        const raw = env.payload?.["requestId"];
        const requestId = typeof raw === "string" ? raw : "";
        inflight.get(requestId)?.abort(new AppError(ErrorCode.CANCELLED, "Cancelled by extension"));
        return false;
      }
      const handler = handlers[env.type];
      if (!handler) return false;
      const controller = new AbortController();
      inflight.set(env.id, controller);
      const ctx = {
        signal: controller.signal,
        requestId: env.id,
        progress: (text, data) => {
          if (!extensionAlive()) return;
          const payload = { requestId: env.id, message: text };
          if (data) payload.data = data;
          chrome.runtime.sendMessage(envelope(BRIDGE_PROGRESS, payload)).catch(() => void 0);
        }
      };
      Promise.resolve().then(() => handler(env.payload ?? {}, ctx)).then(
        (data) => sendResponse(ok(data ?? null)),
        (err) => sendResponse(failure(err))
      ).finally(() => inflight.delete(env.id));
      return true;
    };
    chrome.runtime.onMessage.addListener(listener);
    registry[providerId] = {
      version,
      dispose: () => {
        for (const c of inflight.values()) c.abort(new AppError(ErrorCode.CANCELLED, "Bridge replaced"));
        inflight.clear();
        try {
          chrome.runtime.onMessage.removeListener(listener);
        } catch {
        }
      }
    };
  }

  // src/bridges/bridge-kit/standard.ts
  async function slice(sliceMs, signal, wait, progress) {
    try {
      return { done: true, result: await wait(sliceMs, signal) };
    } catch (err) {
      if (err instanceof AppError && (err.code === ErrorCode.TIMEOUT || err.code === ErrorCode.SELECTOR_NOT_FOUND)) {
        const out = { done: false };
        const p = progress?.();
        if (p) out.progress = p;
        return out;
      }
      throw err;
    }
  }
  var CAPTCHA_TITLE = /just a moment|attention required|security check|ตรวจสอบความปลอดภัย/i;
  var CAPTCHA_SELECTORS = [
    { css: "#challenge-form" },
    { css: "iframe[src*='challenges.cloudflare.com']" },
    { css: "iframe[src*='recaptcha']" },
    { css: "iframe[src*='hcaptcha']" },
    { css: "[id*='captcha' i]" }
  ];
  function captchaVisible() {
    return CAPTCHA_TITLE.test(document.title) || resolveFirst(CAPTCHA_SELECTORS) !== null;
  }
  function describePage(selectors) {
    const parts = Object.keys(selectors).slice(0, 6).map((key) => {
      const list = selectors[key] ?? [];
      if (resolveFirst(list)) return `${key}=visible`;
      if (resolveFirst(list, { visible: false })) return `${key}=hidden`;
      return `${key}=missing`;
    });
    return `page not ready [${document.visibilityState}, captcha=${captchaVisible()}] ${parts.join(" ")}`;
  }
  var sliceMsValidator = number({ int: true, min: 100, max: 6e4 });
  function standardHandlers(opts) {
    const { prefix } = opts;
    return {
      [`${prefix}.ping`]: () => ({
        providerId: opts.providerId,
        version: opts.version,
        url: location.href,
        state: opts.detectState()
      }),
      [`${prefix}.waitReady`]: (payload, ctx) => {
        const { sliceMs } = object({ sliceMs: sliceMsValidator })(payload);
        return slice(
          sliceMs,
          ctx.signal,
          (timeoutMs, signal) => waitForCondition(
            () => {
              const state = opts.detectState();
              return state === "loading" ? null : state;
            },
            { timeoutMs, signal, what: "page ready" }
          ),
          () => describePage(opts.selectors)
        );
      },
      [`${prefix}.diagnose`]: () => diagnoseSelectors(opts.selectors),
      [`${prefix}.prepareReceive`]: (payload) => {
        const { transferId, timeoutMs } = object({
          transferId: id,
          timeoutMs: number({ int: true, min: 1e3, max: 36e5 })
        })(payload);
        prepareReceive(transferId, timeoutMs);
        return { prepared: true };
      },
      [`${prefix}.fetchMedia`]: async (payload, ctx) => {
        const { src, transferId, timeoutMs } = object({
          src: string({ min: 1, max: 8e3, pattern: /^(https:|blob:)/ }),
          transferId: id,
          timeoutMs: number({ int: true, min: 1e3, max: 36e5 })
        })(payload);
        const blob = await fetchInPage(src, ctx.signal);
        await sendBlobToExtension(transferId, blob, "media", timeoutMs);
        return { size: blob.size, mime: blob.type };
      }
    };
  }

  // src/bridges/chatgpt-bridge.ts
  var ELEMENT_WAIT_MS = 1e4;
  var SUBMIT_CONFIRM_MS = 15e3;
  var CONVERSATION_URL_WAIT_MS = 1e4;
  function all(list) {
    for (const c of list) {
      const found = queryCandidate(c);
      if (found.length) return found;
    }
    return [];
  }
  function detectState() {
    if (captchaVisible()) return "captcha";
    if (resolveFirst(CHATGPT_SELECTORS.loginButton)) return "login";
    if (resolveFirst(CHATGPT_SELECTORS.composer)) return "ready";
    return "loading";
  }
  function messageText(msg) {
    const md = resolveFirst(CHATGPT_SELECTORS.messageText, { root: msg, visible: false })?.el;
    const text = (el) => (el.innerText ?? el.textContent ?? "").trim();
    if (md) return text(md);
    const heading = resolveFirst(CHATGPT_SELECTORS.roleHeading, { root: msg, visible: false })?.el;
    if (!heading) return text(msg);
    let top = heading;
    while (top.parentElement && top.parentElement !== msg) top = top.parentElement;
    return [...msg.children].filter((c) => c !== top).map(text).filter(Boolean).join("\n").trim();
  }
  function turnBusy() {
    const turns = all(CHATGPT_SELECTORS.turnState);
    const state = turns[turns.length - 1]?.getAttribute("data-talvt-turn-state");
    return Boolean(state) && state !== "complete";
  }
  function codeBlocks(msg) {
    const blocks = queryCandidate(CHATGPT_SELECTORS.codeBlock[0] ?? { css: "pre code" }, msg);
    const list = blocks.length ? blocks : queryCandidate({ css: "pre" }, msg);
    return list.map((b) => (b.textContent ?? "").trim()).filter(Boolean);
  }
  function imageSrc(img) {
    return img.currentSrc || img.src || "";
  }
  function allImageSources() {
    const out = /* @__PURE__ */ new Set();
    for (const candidate of CHATGPT_SELECTORS.generatedImage) {
      for (const el of queryCandidate(candidate)) {
        const src = imageSrc(el);
        if (src) out.add(src);
      }
    }
    return [...out].slice(-MAX_KNOWN_IMAGES);
  }
  function afterLastPrompt(el) {
    const users = all(CHATGPT_SELECTORS.userMessage);
    const lastUser = users[users.length - 1];
    if (!lastUser) return true;
    return Boolean(lastUser.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING);
  }
  var USER_SIDE = "form, [data-message-author-role='user'], [data-content-search-unit-key$=':user'], [data-chatgpt-search-unit-key$=':user']";
  var attachedNames = /* @__PURE__ */ new Set();
  function isUserImage(el) {
    if (el.closest(USER_SIDE)) return true;
    const alt = (el.getAttribute("alt") ?? "").trim();
    return alt !== "" && attachedNames.has(alt);
  }
  async function attach(payload, signal) {
    const { transferIds } = object({ transferIds: array(id, { min: 1, max: 4 }) })(payload);
    const files = await Promise.all(transferIds.map((id2) => takeReceived(id2)));
    await waitFor("composer", CHATGPT_SELECTORS.composer, { timeoutMs: ELEMENT_WAIT_MS, signal });
    const input = await waitFor("fileInput", CHATGPT_SELECTORS.fileInput, { timeoutMs: ELEMENT_WAIT_MS, signal, visible: false });
    const form = input.el.closest("form") ?? document.body;
    const before = form.querySelectorAll("img").length;
    for (const f of files) attachedNames.add(f.name);
    setInputFiles(input.el, files);
    await waitForCondition(
      () => {
        const imgs = [...form.querySelectorAll("img")];
        return imgs.length >= before + files.length && imgs.every((i) => i.complete) ? true : null;
      },
      {
        timeoutMs: ATTACH_WAIT_MS,
        signal,
        what: "attachment preview",
        onTimeout: () => new AppError(ErrorCode.UPLOAD_FAILED, "ChatGPT did not show the attached picture", { userMessage: "\u0E41\u0E19\u0E1A\u0E23\u0E39\u0E1B\u0E40\u0E02\u0E49\u0E32 ChatGPT \u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 (\u0E44\u0E21\u0E48\u0E40\u0E2B\u0E47\u0E19\u0E23\u0E39\u0E1B\u0E43\u0E19\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C) \u2014 \u0E25\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07" })
      }
    );
    return { attached: files.length };
  }
  var ATTACH_WAIT_MS = 6e4;
  function freshImages(known) {
    const out = /* @__PURE__ */ new Set();
    for (const candidate of CHATGPT_SELECTORS.generatedImage) {
      for (const el of queryCandidate(candidate)) {
        const img = el;
        const src = imageSrc(img);
        if (!known.has(src) && !isUserImage(img) && afterLastPrompt(img) && img.complete && img.naturalWidth >= MIN_IMAGE_WIDTH && /^(https:|blob:)/.test(src)) out.add(src);
      }
    }
    return [...out];
  }
  function newToolImages(known) {
    const out = /* @__PURE__ */ new Set();
    for (const candidate of CHATGPT_SELECTORS.toolImage) {
      for (const el of queryCandidate(candidate)) {
        const src = imageSrc(el);
        if (src && !known.has(src) && !isUserImage(el) && afterLastPrompt(el)) out.add(src);
      }
    }
    return [...out];
  }
  function bannerText() {
    return all(CHATGPT_SELECTORS.errorBanner).map((e) => e.innerText ?? "").join(" ").trim();
  }
  function limitDialog() {
    for (const d of all(CHATGPT_SELECTORS.dialog)) {
      const el = d;
      if (el.offsetParent !== null || el.getClientRects().length) {
        if (CHATGPT_TEXT.rateLimit.test(el.innerText ?? el.textContent ?? "")) return el;
      }
    }
    return null;
  }
  function rateLimitedError(text) {
    return new AppError(ErrorCode.RATE_LIMITED, `ChatGPT limit: ${text.replace(/\s+/g, " ").slice(0, 200)}`, {
      userMessage: "ChatGPT \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E04\u0E33\u0E02\u0E2D\u0E16\u0E35\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B \u2014 \u0E23\u0E30\u0E1A\u0E1A\u0E08\u0E30\u0E1E\u0E31\u0E01\u0E04\u0E34\u0E27\u0E41\u0E25\u0E49\u0E27\u0E17\u0E33\u0E15\u0E48\u0E2D\u0E43\u0E2B\u0E49\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34"
    });
  }
  function assertNoLimitOrError(lastText) {
    const dialog = limitDialog();
    if (dialog) throw rateLimitedError(dialog.innerText ?? "");
    const banner = bannerText();
    if (CHATGPT_TEXT.rateLimit.test(banner) || CHATGPT_TEXT.rateLimit.test(lastText)) {
      throw new AppError(ErrorCode.RATE_LIMITED, `ChatGPT limit: ${(banner || lastText).slice(0, 200)}`, {
        userMessage: "ChatGPT \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E16\u0E36\u0E07\u0E02\u0E35\u0E14\u0E08\u0E33\u0E01\u0E31\u0E14\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E1E\u0E31\u0E01\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry"
      });
    }
    if (CHATGPT_TEXT.genericError.test(banner) && !resolveFirst(CHATGPT_SELECTORS.stopButton)) {
      throw new AppError(ErrorCode.GENERATION_FAILED, `ChatGPT error: ${banner.slice(0, 200)}`, {
        userMessage: "ChatGPT \u0E41\u0E08\u0E49\u0E07\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E15\u0E2D\u0E1A"
      });
    }
  }
  var norm = (s) => s.replace(/\s+/g, " ").trim();
  function samePrompt(shown, sent) {
    const a = norm(shown);
    const b = norm(sent);
    if (a === b) return true;
    return a.length > 40 && a.slice(0, 300) === b.slice(0, 300) && a.slice(-200) === b.slice(-200) && Math.abs(a.length - b.length) <= b.length * 0.05;
  }
  function isBefore(a, b) {
    return Boolean(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
  }
  function userBubbleText(el) {
    return norm(el.textContent ?? "").replace(/\s*(ดูเพิ่มเติม|แสดงเพิ่มเติม|แสดงน้อยลง|show more|show less|see more)$/i, "");
  }
  function bubbleIsPrompt(el, prompt) {
    const shown = userBubbleText(el);
    const sent = norm(prompt);
    if (shown === sent) return true;
    const cut = /(…|\.\.\.)$/.exec(shown);
    if (!cut) return false;
    const head = shown.slice(0, -cut[0].length).trimEnd();
    return head.length >= 200 && sent.startsWith(head);
  }
  function replyByPosition(prompt) {
    const users = all(CHATGPT_SELECTORS.userMessage);
    const lastUser = users[users.length - 1];
    if (!lastUser || !bubbleIsPrompt(lastUser, prompt)) return void 0;
    const after = all(CHATGPT_SELECTORS.assistantMessage).filter((m) => isBefore(lastUser, m));
    return after[after.length - 1];
  }
  function inspect(payload) {
    const { text } = object({ text: string({ min: 1, max: 1e5 }) })(payload);
    const busy = Boolean(resolveFirst(CHATGPT_SELECTORS.stopButton));
    const users = all(CHATGPT_SELECTORS.userMessage);
    const lastUser = users[users.length - 1];
    if (!lastUser || !(samePrompt(lastUser.textContent ?? "", text) || bubbleIsPrompt(lastUser, text))) return { busy };
    const assistants = all(CHATGPT_SELECTORS.assistantMessage);
    const afterCount = assistants.filter((m) => isBefore(m, lastUser)).length;
    const knownImages = [];
    for (const candidate of CHATGPT_SELECTORS.generatedImage) {
      for (const el of queryCandidate(candidate)) {
        const src = imageSrc(el);
        if (src && !afterLastPrompt(el) && !knownImages.includes(src)) knownImages.push(src);
      }
    }
    return { busy, adopt: { afterCount, knownImages: knownImages.slice(-MAX_KNOWN_IMAGES), url: location.href } };
  }
  async function submit(payload, signal) {
    const { text } = object({ text: string({ min: 1, max: 1e5 }) })(payload);
    const stale = limitDialog();
    if (stale) {
      const ok2 = stale.querySelector("button");
      if (ok2) clickElement(ok2);
      else document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      await waitForCondition(() => limitDialog() ? null : true, { timeoutMs: 3e3, signal, what: "limit dialog closed" }).catch(() => void 0);
    }
    const composer = await waitFor("composer", CHATGPT_SELECTORS.composer, { timeoutMs: ELEMENT_WAIT_MS, signal });
    const afterCount = all(CHATGPT_SELECTORS.assistantMessage).length;
    const knownImages = allImageSources();
    const userBefore = all(CHATGPT_SELECTORS.userMessage).length;
    const busyBefore = Boolean(resolveFirst(CHATGPT_SELECTORS.stopButton));
    await replaceText(composer.el, text);
    const submitted = () => all(CHATGPT_SELECTORS.userMessage).length > userBefore || !busyBefore && resolveFirst(CHATGPT_SELECTORS.stopButton) ? true : null;
    const send = await waitFor("sendButton", CHATGPT_SELECTORS.sendButton, { timeoutMs: ELEMENT_WAIT_MS, signal, enabled: true });
    clickElement(send.el);
    try {
      await waitForCondition(submitted, { timeoutMs: SUBMIT_CONFIRM_MS / 2, signal, what: "prompt submitted" });
    } catch {
      pressEnter(composer.el);
      await waitForCondition(submitted, {
        timeoutMs: SUBMIT_CONFIRM_MS / 2,
        signal,
        what: "prompt submitted",
        onTimeout: () => {
          const d = limitDialog();
          return d ? rateLimitedError(d.innerText ?? "") : new AppError(ErrorCode.INPUT_REJECTED, "ChatGPT did not accept the prompt");
        }
      });
    }
    await waitForCondition(() => /\/c\//.test(location.pathname) ? true : null, {
      timeoutMs: CONVERSATION_URL_WAIT_MS,
      signal,
      what: "conversation url"
    }).catch(() => void 0);
    return { afterCount, knownImages, url: location.href };
  }
  var lastChange = { key: "", signature: "", at: 0 };
  var STALL_MIN_CHARS = 80;
  function waitReply(payload, signal) {
    const { afterCount, expect, sliceMs, reattach, knownImages, stallMs, prompt } = object({
      afterCount: number({ int: true, min: 0 }),
      prompt: optional(string({ max: 1e5 })),
      expect: literal("text", "image"),
      knownImages: optional(array(string({ max: 8e3 }), { max: MAX_KNOWN_IMAGES })),
      reattach: optional(boolean),
      sliceMs: sliceMsValidator,
      stallMs: optional(number({ int: true, min: 1e3, max: 36e5 }))
    })(payload);
    const key = `${location.pathname}|${afterCount}|${expect}`;
    if (lastChange.key !== key) Object.assign(lastChange, { key, signature: "", at: Date.now() });
    const startedAt = Date.now();
    const known = new Set(knownImages ?? []);
    let imageCount = 0;
    const quietMs = expect === "image" ? IMAGE_QUIET_MS : REPLY_QUIET_MS;
    let signature = "";
    let changedAt = Date.now();
    let lastLength = 0;
    return slice(
      sliceMs,
      signal,
      (timeoutMs, sig) => waitForCondition(
        () => {
          const msgs = all(CHATGPT_SELECTORS.assistantMessage);
          const last = msgs.length > afterCount ? msgs[msgs.length - 1] : prompt ? replyByPosition(prompt) : void 0;
          const text = last ? messageText(last) : "";
          assertNoLimitOrError(text);
          if (expect === "text") {
            const toolImages = newToolImages(known);
            if (toolImages.length || last && CHATGPT_TEXT.imageInProgress.test(text) && text.length < 200) {
              return { text, codeBlocks: [], images: toolImages, url: location.href, unexpectedImage: true };
            }
          }
          const images = expect === "image" ? freshImages(known) : [];
          imageCount = images.length;
          if (!last && images.length === 0) {
            if (reattach && !resolveFirst(CHATGPT_SELECTORS.stopButton) && Date.now() - startedAt > REATTACH_GRACE_MS) {
              throw new AppError(ErrorCode.GENERATION_FAILED, "Reply of the interrupted prompt not found \u2014 asking again", {
                userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E40\u0E14\u0E34\u0E21\u0E2B\u0E25\u0E31\u0E07\u0E23\u0E35\u0E2A\u0E15\u0E32\u0E23\u0E4C\u0E17 \u2014 \u0E01\u0E33\u0E25\u0E31\u0E07\u0E16\u0E32\u0E21\u0E43\u0E2B\u0E21\u0E48"
              });
            }
            return null;
          }
          lastLength = text.length;
          const sig2 = `${text.length}|${text.slice(-200)}|${images.join(",")}`;
          const now = Date.now();
          if (sig2 !== lastChange.signature) Object.assign(lastChange, { signature: sig2, at: now });
          if (sig2 !== signature) {
            signature = sig2;
            changedAt = now;
            return null;
          }
          const stopBtn = resolveFirst(CHATGPT_SELECTORS.stopButton);
          if (stopBtn && expect === "text" && stallMs && text.length > STALL_MIN_CHARS && now - lastChange.at >= stallMs) {
            clickElement(stopBtn.el);
            return { text, codeBlocks: last ? codeBlocks(last) : [], images: [], url: location.href, stalled: true };
          }
          if (stopBtn || turnBusy() || now - changedAt < quietMs) return null;
          if (expect === "image") {
            if (images.length) return { text, codeBlocks: last ? codeBlocks(last) : [], images, url: location.href };
            if (CHATGPT_TEXT.policy.test(text)) {
              throw new AppError(ErrorCode.CONTENT_POLICY_BLOCKED, `ChatGPT refused: ${text.slice(0, 200)}`, {
                userMessage: "ChatGPT \u0E1B\u0E0F\u0E34\u0E40\u0E2A\u0E18\u0E01\u0E32\u0E23\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E20\u0E32\u0E1E\u0E19\u0E35\u0E49 (\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32) \u2014 \u0E41\u0E01\u0E49 prompt \u0E41\u0E25\u0E49\u0E27 Retry"
              });
            }
            if (now - changedAt < IMAGE_TEXT_ONLY_MS) return null;
            return { text, codeBlocks: last ? codeBlocks(last) : [], images: [], url: location.href };
          }
          if (!last) return null;
          if (!text) {
            if (now - changedAt < EMPTY_REPLY_MS) return null;
            return { text: "", codeBlocks: [], images: [], url: location.href };
          }
          return { text, codeBlocks: codeBlocks(last), images: [], url: location.href };
        },
        { timeoutMs, signal: sig, what: "ChatGPT reply" }
      ),
      () => expect === "image" ? `Waiting for ChatGPT image (${imageCount} new image(s) so far)` : lastLength ? `ChatGPT is replying (${lastLength} chars)` : "Waiting for ChatGPT"
    );
  }
  startBridge(CHATGPT_PROVIDER_ID, CHATGPT_BRIDGE_VERSION, {
    ...standardHandlers({
      providerId: CHATGPT_PROVIDER_ID,
      prefix: CHATGPT_PREFIX,
      version: CHATGPT_BRIDGE_VERSION,
      detectState,
      selectors: CHATGPT_SELECTORS
    }),
    [CHATGPT_CMD.submit]: (payload, ctx) => submit(payload, ctx.signal),
    [CHATGPT_CMD.waitReply]: (payload, ctx) => waitReply(payload, ctx.signal),
    [CHATGPT_CMD.inspect]: (payload) => inspect(payload),
    [CHATGPT_CMD.attach]: (payload, ctx) => attach(payload, ctx.signal),
    [CHATGPT_CMD.stop]: () => {
      const stop = resolveFirst(CHATGPT_SELECTORS.stopButton);
      if (stop) clickElement(stop.el);
      return { stopped: Boolean(stop) };
    }
  });
})();
