"use strict";
(() => {
  // src/shared/errors.ts
  var ErrorCode = {
    LOGIN_REQUIRED: "LOGIN_REQUIRED",
    CAPTCHA_REQUIRED: "CAPTCHA_REQUIRED",
    PERMISSION_MISSING: "PERMISSION_MISSING",
    SELECTOR_NOT_FOUND: "SELECTOR_NOT_FOUND",
    INPUT_REJECTED: "INPUT_REJECTED",
    PAGE_NOT_READY: "PAGE_NOT_READY",
    WEBSITE_UNAVAILABLE: "WEBSITE_UNAVAILABLE",
    RATE_LIMITED: "RATE_LIMITED",
    QUOTA_EXCEEDED: "QUOTA_EXCEEDED",
    GENERATION_FAILED: "GENERATION_FAILED",
    CONTENT_POLICY_BLOCKED: "CONTENT_POLICY_BLOCKED",
    RESPONSE_PARSE_FAILED: "RESPONSE_PARSE_FAILED",
    TIMEOUT: "TIMEOUT",
    PROGRESS_STALLED: "PROGRESS_STALLED",
    DOWNLOAD_FAILED: "DOWNLOAD_FAILED",
    DOWNLOAD_INTERRUPTED: "DOWNLOAD_INTERRUPTED",
    UPLOAD_FAILED: "UPLOAD_FAILED",
    PUBLISH_UNCONFIRMED: "PUBLISH_UNCONFIRMED",
    SEND_UNCONFIRMED: "SEND_UNCONFIRMED",
    DESTINATION_MISMATCH: "DESTINATION_MISMATCH",
    SEND_FAILED: "SEND_FAILED",
    ACCOUNT_RESTRICTED: "ACCOUNT_RESTRICTED",
    NATIVE_SCHEDULE_UNAVAILABLE: "NATIVE_SCHEDULE_UNAVAILABLE",
    BRIDGE_UNREACHABLE: "BRIDGE_UNREACHABLE",
    TAB_CLOSED: "TAB_CLOSED",
    INTERRUPTED: "INTERRUPTED",
    INVALID_INPUT: "INVALID_INPUT",
    INVALID_STATE: "INVALID_STATE",
    NOT_FOUND: "NOT_FOUND",
    PROVIDER_NOT_CONFIGURED: "PROVIDER_NOT_CONFIGURED",
    LICENSE_REQUIRED: "LICENSE_REQUIRED",
    CANCELLED: "CANCELLED",
    INTERNAL: "INTERNAL"
  };
  var META = {
    LOGIN_REQUIRED: { retryable: false, pause: "LOGIN_REQUIRED", userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 \u2014 \u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    CAPTCHA_REQUIRED: { retryable: false, pause: "CAPTCHA", userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E02\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E15\u0E31\u0E27\u0E15\u0E19 (CAPTCHA) \u2014 \u0E17\u0E33\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    PERMISSION_MISSING: { retryable: false, userMessage: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E40\u0E02\u0E49\u0E32\u0E16\u0E36\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E19\u0E35\u0E49 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    SELECTOR_NOT_FOUND: { retryable: true, userMessage: "\u0E2B\u0E32\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E40\u0E08\u0E2D \u2014 \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u0E25\u0E2D\u0E07\u0E01\u0E14 Diagnose \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    INPUT_REJECTED: { retryable: true, userMessage: "\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E23\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34" },
    PAGE_NOT_READY: { retryable: true, userMessage: "\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E22\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21" },
    WEBSITE_UNAVAILABLE: { retryable: true, userMessage: "\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32" },
    RATE_LIMITED: { retryable: false, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E16\u0E35\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B \u2014 \u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E1E\u0E31\u0E01\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry" },
    QUOTA_EXCEEDED: { retryable: false, userMessage: "\u0E43\u0E0A\u0E49\u0E42\u0E04\u0E27\u0E15\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07" },
    GENERATION_FAILED: { retryable: true, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    CONTENT_POLICY_BLOCKED: { retryable: false, userMessage: "\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E1B\u0E0F\u0E34\u0E40\u0E2A\u0E18 prompt \u0E19\u0E35\u0E49 (\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32) \u2014 \u0E41\u0E01\u0E49 prompt \u0E41\u0E25\u0E49\u0E27 Retry" },
    RESPONSE_PARSE_FAILED: { retryable: true, userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E08\u0E32\u0E01 AI \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07)" },
    TIMEOUT: { retryable: true, userMessage: "\u0E23\u0E2D\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14" },
    PROGRESS_STALLED: { retryable: true, userMessage: "\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E27\u0E32\u0E21\u0E04\u0E37\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B" },
    DOWNLOAD_FAILED: { retryable: true, userMessage: "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    DOWNLOAD_INTERRUPTED: { retryable: true, userMessage: "\u0E01\u0E32\u0E23\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30" },
    UPLOAD_FAILED: { retryable: true, userMessage: "\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    PUBLISH_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E02\u0E36\u0E49\u0E19\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E0B\u0E49\u0E33" },
    SEND_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E0A\u0E17\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33" },
    DESTINATION_MISMATCH: { retryable: false, userMessage: "\u0E41\u0E0A\u0E17\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E44\u0E27\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07" },
    SEND_FAILED: { retryable: false, userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
    ACCOUNT_RESTRICTED: { retryable: false, pause: "INTERRUPTED", userMessage: "Facebook \u0E08\u0E33\u0E01\u0E31\u0E14\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E2A\u0E48\u0E07\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u0E15\u0E23\u0E27\u0E08\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A Facebook \u0E41\u0E25\u0E30\u0E23\u0E2D\u0E08\u0E19\u0E02\u0E49\u0E2D\u0E08\u0E33\u0E01\u0E31\u0E14\u0E2B\u0E21\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E15\u0E48\u0E2D" },
    NATIVE_SCHEDULE_UNAVAILABLE: { retryable: false, userMessage: "\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A\u0E02\u0E2D\u0E07 Facebook \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E43\u0E0A\u0E49\u0E15\u0E31\u0E27\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E41\u0E17\u0E19" },
    BRIDGE_UNREACHABLE: { retryable: true, userMessage: "\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D\u0E2A\u0E04\u0E23\u0E34\u0E1B\u0E15\u0E4C\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
    TAB_CLOSED: { retryable: true, userMessage: "\u0E41\u0E17\u0E47\u0E1A\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E16\u0E39\u0E01\u0E1B\u0E34\u0E14\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E17\u0E33\u0E07\u0E32\u0E19" },
    INTERRUPTED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E07\u0E32\u0E19\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30 (browser/\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E23\u0E35\u0E2A\u0E15\u0E32\u0E23\u0E4C\u0E17) \u2014 \u0E15\u0E23\u0E27\u0E08\u0E1C\u0E25\u0E1A\u0E19\u0E40\u0E27\u0E47\u0E1A \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry \u0E2B\u0E23\u0E37\u0E2D Cancel" },
    INVALID_INPUT: { retryable: false, userMessage: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E21\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" },
    INVALID_STATE: { retryable: false, userMessage: "\u0E17\u0E33\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E19\u0E35\u0E49\u0E43\u0E19\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
    NOT_FOUND: { retryable: false, userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E23\u0E30\u0E1A\u0E38" },
    PROVIDER_NOT_CONFIGURED: { retryable: false, userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49 \u2014 \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
    LICENSE_REQUIRED: { retryable: false, pause: "LICENSE_REQUIRED", userMessage: "License \u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u2014 \u0E07\u0E32\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E23\u0E34\u0E48\u0E21 \u0E15\u0E23\u0E27\u0E08 License \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
    CANCELLED: { retryable: false, userMessage: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27" },
    INTERNAL: { retryable: false, userMessage: "\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E20\u0E32\u0E22\u0E43\u0E19 \u2014 \u0E14\u0E39\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E43\u0E19 Log" }
  };
  var AppError = class extends Error {
    code;
    retryable;
    userMessage;
    detail;
    constructor(code, message, opts = {}) {
      super(message, opts.cause === void 0 ? void 0 : { cause: opts.cause });
      this.name = "AppError";
      this.code = code;
      this.retryable = opts.retryable ?? META[code].retryable;
      this.userMessage = opts.userMessage ?? META[code].userMessage;
      this.detail = opts.detail;
    }
    get pauseReason() {
      return META[this.code].pause;
    }
    toJSON() {
      const json = {
        code: this.code,
        message: this.message,
        userMessage: this.userMessage,
        retryable: this.retryable
      };
      if (this.detail !== void 0) json.detail = this.detail;
      return json;
    }
  };
  function isErrorCode(value) {
    return typeof value === "string" && value in META;
  }
  function toAppError(err, fallback = ErrorCode.INTERNAL) {
    if (err instanceof AppError) return err;
    if (isAppErrorJSON(err)) return fromJSON(err);
    if (err instanceof DOMException && err.name === "AbortError") {
      return new AppError(ErrorCode.CANCELLED, "Operation aborted", { cause: err });
    }
    const message = err instanceof Error ? err.message : String(err);
    return new AppError(fallback, message, { cause: err });
  }
  function isAppErrorJSON(value) {
    if (typeof value !== "object" || value === null) return false;
    const v = value;
    return isErrorCode(v["code"]) && typeof v["message"] === "string";
  }
  function fromJSON(json) {
    const code = isErrorCode(json.code) ? json.code : ErrorCode.INTERNAL;
    return new AppError(code, json.message, {
      userMessage: json.userMessage,
      retryable: json.retryable,
      detail: json.detail
    });
  }

  // src/shared/post-attempt.ts
  function beforePostError(err, extra = {}) {
    const e = toAppError(err);
    const detail = typeof e.detail === "object" && e.detail !== null ? e.detail : {};
    return new AppError(e.code, e.message, { cause: err, userMessage: e.userMessage, retryable: e.retryable, detail: { ...detail, ...extra, beforePost: true } });
  }

  // src/shared/schema.ts
  function fail(path, expected, value) {
    const got = value === null ? "null" : Array.isArray(value) ? "array" : typeof value;
    throw new AppError(ErrorCode.INVALID_INPUT, `${path || "value"}: expected ${expected}, got ${got}`, {
      detail: { path, expected }
    });
  }
  function string(opts = {}) {
    return (value, path = "") => {
      if (typeof value !== "string") fail(path, "string", value);
      if (opts.min !== void 0 && value.length < opts.min) fail(path, `string length >= ${opts.min}`, value);
      if (opts.max !== void 0 && value.length > opts.max) fail(path, `string length <= ${opts.max}`, value);
      if (opts.pattern && !opts.pattern.test(value)) fail(path, `string matching ${opts.pattern}`, value);
      return value;
    };
  }
  function number(opts = {}) {
    return (value, path = "") => {
      if (typeof value !== "number" || !Number.isFinite(value)) fail(path, "finite number", value);
      if (opts.int && !Number.isInteger(value)) fail(path, "integer", value);
      if (opts.min !== void 0 && value < opts.min) fail(path, `number >= ${opts.min}`, value);
      if (opts.max !== void 0 && value > opts.max) fail(path, `number <= ${opts.max}`, value);
      return value;
    };
  }
  var boolean = (value, path = "") => {
    if (typeof value !== "boolean") fail(path, "boolean", value);
    return value;
  };
  function array(item, opts = {}) {
    return (value, path = "") => {
      if (!Array.isArray(value)) fail(path, "array", value);
      if (opts.max !== void 0 && value.length > opts.max) fail(path, `array length <= ${opts.max}`, value);
      if (opts.min !== void 0 && value.length < opts.min) fail(path, `array length >= ${opts.min}`, value);
      return value.map((v, i) => item(v, `${path}[${i}]`));
    };
  }
  function optional(inner) {
    return (value, path = "") => value === void 0 ? void 0 : inner(value, path);
  }
  function object(shape) {
    return (value, path = "") => {
      if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
      const src = value;
      const out = {};
      for (const [key, validator] of Object.entries(shape)) {
        const v = validator(src[key], path ? `${path}.${key}` : key);
        if (v !== void 0) out[key] = v;
      }
      return out;
    };
  }
  var id = string({ min: 1, max: 64, pattern: /^[A-Za-z0-9_-]+$/ });

  // src/providers/facebook/selectors.ts
  var FACEBOOK_SELECTORS = {
    composerTrigger: [
      { role: "button", name: /what('|’)s on your mind|คุณกำลังคิดอะไรอยู่|create (a )?post|สร้างโพสต์/i },
      { css: "[aria-label='Create a post']" },
      { css: "[aria-label='\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C']" }
    ],
    /**
     * "Switch to the Page" prompt. Anchored on both ends: the page header also has a voice selector
     * named "เสียงที่ใช้ได้ สลับโปรไฟล์" (you ARE already the Page) — it was mistaken for this (v0.14.1 bug).
     */
    switchProfile: [{ role: "button", name: /^(switch( now| profile)?|สลับ(ตอนนี้|โปรไฟล์)?)$/i }],
    composerDialog: [
      { css: "[role='dialog']", name: /create post|สร้างโพสต์|post|โพสต์/i },
      { css: "[role='dialog']" }
    ],
    dialogTextbox: [
      { css: "div[contenteditable='true'][role='textbox']" },
      { role: "textbox" }
    ],
    photoVideoButton: [{ role: "button", name: /photo\/video|รูปภาพ\/วิดีโอ|^photo|^รูปภาพ/i }],
    fileInput: [
      { css: "input[type='file'][accept*='image']" },
      { css: "input[type='file'][accept*='video']" },
      { css: "input[type='file']" }
    ],
    uploadProgress: [{ css: "[role='progressbar']" }],
    mediaPreview: [{ css: "img[src^='blob:']" }, { css: "video" }, { css: "img[src*='scontent']" }],
    nextButton: [{ role: "button", name: /^next$|^ถัดไป$/i }],
    postButton: [
      { css: "[aria-label='Post'][role='button']" },
      { css: "[aria-label='\u0E42\u0E1E\u0E2A\u0E15\u0E4C'][role='button']" },
      { role: "button", name: /^post$|^โพสต์$|^publish$|^เผยแพร่$|^share now$|^แชร์เลย$/i }
    ],
    /* --- Scheduling (verified live 2026-09-25 on the Thai UI: "ถัดไป" → การตั้งค่าโพสต์ → ตัวเลือกการกำหนดเวลา) --- */
    scheduleOption: [
      { role: "button", text: /^(ตัวเลือกการกำหนดเวลา|scheduling options|schedule options)/i }
    ],
    datePickerButton: [{ css: "[aria-label^='\u0E40\u0E1B\u0E34\u0E14\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48']" }, { css: "[aria-label^='Open date picker' i]" }],
    calendarGrid: [{ css: "[role='grid']" }],
    calendarDay: [{ css: "[role='grid'] [role='gridcell']" }],
    nextMonth: [{ css: "[aria-label='\u0E40\u0E14\u0E37\u0E2D\u0E19\u0E16\u0E31\u0E14\u0E44\u0E1B']" }, { css: "[aria-label='Next month' i]" }],
    timeOption: [{ css: "[role='listbox'] [role='option']" }],
    /** Confirms the date/time panel and returns to the post settings (does not post by itself). */
    scheduleConfirm: [{ role: "button", text: /^(กำหนดเวลาเริ่มเป็นภายหลัง|schedule for later|set date and time)$/i }],
    /** The final button once a time is set. Never "โพสต์"/"Post" — that would publish now. */
    scheduleFinal: [
      { css: "[aria-label='\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E40\u0E27\u0E25\u0E32'][role='button']" },
      { css: "[aria-label='Schedule' i][role='button']" },
      { role: "button", name: /^(กำหนดเวลา|ตั้งเวลา|กำหนดเวลาโพสต์|schedule|schedule post)$/i }
    ],
    closeComposer: [
      { css: "[aria-label='\u0E1B\u0E34\u0E14\u0E01\u0E25\u0E48\u0E2D\u0E07\u0E42\u0E15\u0E49\u0E15\u0E2D\u0E1A\u0E0A\u0E48\u0E2D\u0E07\u0E40\u0E02\u0E35\u0E22\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21']" },
      { css: "[aria-label='Close composer dialog' i]" },
      { role: "button", name: /^(ปิด|close)$/i }
    ],
    backButton: [{ css: "[aria-label='\u0E22\u0E49\u0E2D\u0E19\u0E01\u0E25\u0E31\u0E1A'][role='button']" }, { css: "[aria-label='Back' i][role='button']" }],
    discardButton: [{ role: "button", name: /^(ทิ้ง|discard|ละทิ้ง)$/i }],
    /** "Not now" on Facebook's own suggestion pop-ups (never the accept button). */
    promoDismiss: [{ role: "button", name: /^(ไม่ใช่ตอนนี้|not now)$/i }, { role: "button", text: /^(ไม่ใช่ตอนนี้|not now)$/i }],
    loginForm: [{ css: "input[name='pass']" }, { css: "#login_form" }, { css: "form[action*='login']" }],
    article: [{ css: "[role='article']" }],
    postLink: [
      { css: "a[href*='/posts/']" },
      { css: "a[href*='story_fbid']" },
      { css: "a[href*='/videos/']" },
      { css: "a[href*='/reel/']" },
      { css: "a[href*='/photo']" }
    ]
  };
  var FACEBOOK_TEXT = {
    /** Subtitle of the scheduling row while the post is set to publish immediately. */
    publishNow: /เผยแพร่เลย|publish now|share now/i,
    dateLabel: /^(วันที่|date)/i,
    timeLabel: /^(เวลา|time)/i,
    /**
     * Facebook suggestion pop-ups that appear over the composer and block it (seen live 2026-09-26:
     * "แชทโดยตรงกับลูกค้า — เพิ่มปุ่ม 'ส่งข้อความ'…" with "ไม่ใช่ตอนนี้" / "เพิ่มปุ่ม"). Only these are dismissed.
     */
    promoDialog: /แชทโดยตรงกับลูกค้า|เพิ่มปุ่ม\s*["“]?ส่งข้อความ|chat directly with (your )?customers|add (a )?["“]?send message["”]? button/i,
    postError: /something went wrong|couldn('|’)t (post|upload)|try again|ไม่สามารถ(โพสต์|อัปโหลด)|เกิดข้อผิดพลาด|ลองอีกครั้ง/i
  };

  // src/providers/facebook/protocol.ts
  var FACEBOOK_PROVIDER_ID = "facebook-web";
  var FACEBOOK_PREFIX = "facebook";
  var FACEBOOK_BRIDGE_VERSION = "5";
  var FACEBOOK_CMD = {
    openComposer: `${FACEBOOK_PREFIX}.openComposer`,
    attachMedia: `${FACEBOOK_PREFIX}.attachMedia`,
    waitUpload: `${FACEBOOK_PREFIX}.waitUpload`,
    setCaption: `${FACEBOOK_PREFIX}.setCaption`,
    submitPost: `${FACEBOOK_PREFIX}.submitPost`,
    waitPosted: `${FACEBOOK_PREFIX}.waitPosted`,
    /** Next → scheduling options → date + time → back to settings, verified. Nothing is posted. */
    prepareSchedule: `${FACEBOOK_PREFIX}.prepareSchedule`,
    /** Clicks the final "Schedule" button (irreversible). */
    commitSchedule: `${FACEBOOK_PREFIX}.commitSchedule`,
    waitScheduled: `${FACEBOOK_PREFIX}.waitScheduled`,
    /** Closes the composer without posting (used when native scheduling is not possible). */
    discard: `${FACEBOOK_PREFIX}.discard`
  };

  // src/shared/async.ts
  function abortError(signal) {
    const reason = signal?.reason;
    if (reason instanceof AppError) return reason;
    return new AppError(ErrorCode.CANCELLED, "Operation cancelled");
  }
  function throwIfAborted(signal) {
    if (signal?.aborted) throw abortError(signal);
  }
  function delay(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal?.aborted) {
        reject(abortError(signal));
        return;
      }
      const timer = setTimeout(() => {
        signal?.removeEventListener("abort", onAbort);
        resolve();
      }, ms);
      const onAbort = () => {
        clearTimeout(timer);
        reject(abortError(signal));
      };
      signal?.addEventListener("abort", onAbort, { once: true });
    });
  }
  function withTimeout(promise, ms, what, code = ErrorCode.TIMEOUT) {
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new AppError(code, `${what} timed out after ${ms} ms`, { detail: { ms } })), ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
  }

  // src/bridges/bridge-kit/dom.ts
  var POLL_MS = 400;
  var IMPLICIT_ROLE = {
    button: "button,[role='button'],input[type='button'],input[type='submit']",
    textbox: "textarea,input[type='text'],input:not([type]),[contenteditable='true'],[role='textbox']",
    dialog: "[role='dialog'],dialog",
    link: "a[href],[role='link']",
    img: "img,[role='img']",
    checkbox: "input[type='checkbox'],[role='checkbox']",
    menuitem: "[role='menuitem']",
    tab: "[role='tab']",
    alert: "[role='alert'],[role='alertdialog']",
    combobox: "select,[role='combobox']",
    option: "option,[role='option']",
    heading: "h1,h2,h3,h4,h5,h6,[role='heading']"
  };
  function accessibleName(el) {
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.trim();
    const labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      const text = labelledBy.split(/\s+/).map((id2) => el.ownerDocument.getElementById(id2)?.textContent ?? "").join(" ").trim();
      if (text) return text;
    }
    const attr = el.getAttribute("title") ?? el.getAttribute("placeholder") ?? el.getAttribute("alt");
    if (attr) return attr.trim();
    const placeholder = el.getAttribute("data-placeholder");
    if (placeholder) return placeholder.trim();
    return (el.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function queryCandidate(c, root = document) {
    let els;
    if (c.css && c.role) {
      const roleSel = IMPLICIT_ROLE[c.role] ?? `[role='${c.role}']`;
      els = Array.from(root.querySelectorAll(c.css)).filter((e) => e.matches(roleSel));
    } else if (c.css) {
      els = Array.from(root.querySelectorAll(c.css));
    } else if (c.role) {
      els = Array.from(root.querySelectorAll(IMPLICIT_ROLE[c.role] ?? `[role='${c.role}']`));
    } else {
      els = Array.from(root.querySelectorAll("*"));
    }
    const { name, text } = c;
    if (name) els = els.filter((e) => name.test(accessibleName(e)));
    if (text) els = els.filter((e) => text.test((e.textContent ?? "").replace(/\s+/g, " ").trim()));
    return els;
  }
  function isVisible(el) {
    if (!(el instanceof HTMLElement) && !(el instanceof SVGElement)) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    const style = getComputedStyle(el);
    return !(style.visibility === "hidden" || style.display === "none" || Number(style.opacity) === 0);
  }
  function isEnabled(el) {
    if (el.disabled) return false;
    return el.getAttribute("aria-disabled") !== "true";
  }
  function resolveFirst(list, opts = {}) {
    const root = opts.root ?? document;
    for (let i = 0; i < list.length; i++) {
      const candidate = list[i];
      const el = queryCandidate(candidate, root).find(
        (e) => (opts.visible === false || isVisible(e)) && (!opts.enabled || isEnabled(e))
      );
      if (el) return { el, index: i };
    }
    return null;
  }
  function resolveAll(list, opts = {}) {
    const root = opts.root ?? document;
    const seen = /* @__PURE__ */ new Set();
    for (const candidate of list) {
      for (const el of queryCandidate(candidate, root)) {
        if (opts.visible !== false && !isVisible(el)) continue;
        seen.add(el);
      }
    }
    return [...seen];
  }
  function waitForCondition(check, opts) {
    return new Promise((resolve, reject) => {
      throwIfAborted(opts.signal);
      let settled = false;
      const finish = (fn) => {
        if (settled) return;
        settled = true;
        observer.disconnect();
        clearInterval(poll);
        clearTimeout(deadline);
        opts.signal?.removeEventListener("abort", onAbort);
        fn();
      };
      const evaluate = () => {
        try {
          const value = check();
          if (value !== null && value !== void 0 && value !== false) finish(() => resolve(value));
        } catch (err) {
          finish(() => reject(err instanceof Error ? err : new AppError(ErrorCode.INTERNAL, String(err))));
        }
      };
      const observer = new MutationObserver(evaluate);
      observer.observe(opts.observe ?? document, { childList: true, subtree: true, attributes: true, characterData: true });
      const poll = setInterval(evaluate, POLL_MS);
      const deadline = setTimeout(
        () => finish(
          () => reject(opts.onTimeout?.() ?? new AppError(ErrorCode.TIMEOUT, `${opts.what} not reached in ${opts.timeoutMs} ms`))
        ),
        opts.timeoutMs
      );
      const onAbort = () => {
        const reason = opts.signal?.reason;
        finish(() => reject(reason instanceof AppError ? reason : new AppError(ErrorCode.CANCELLED, "Cancelled")));
      };
      opts.signal?.addEventListener("abort", onAbort, { once: true });
      evaluate();
    });
  }
  function waitFor(key, list, opts) {
    return waitForCondition(() => resolveFirst(list, opts), {
      ...opts,
      what: key,
      onTimeout: () => new AppError(ErrorCode.SELECTOR_NOT_FOUND, `Element "${key}" not found within ${opts.timeoutMs} ms`, {
        detail: { selector: key }
      })
    });
  }
  function diagnoseSelectors(map, keys = Object.keys(map)) {
    return keys.map((key) => {
      const list = map[key] ?? [];
      const found = resolveFirst(list, { visible: false });
      return { key, found: found !== null, matchedIndex: found?.index ?? -1, candidates: list.length };
    });
  }

  // src/providers/facebook-group/protocol.ts
  var GROUP_CMD = {
    inspect: "facebook.group.inspect",
    open: "facebook.group.open",
    attach: "facebook.group.attach",
    upload: "facebook.group.upload",
    caption: "facebook.group.caption",
    submit: "facebook.group.submit",
    confirm: "facebook.group.confirm",
    pendingRoute: "facebook.group.pendingRoute",
    pendingList: "facebook.group.pendingList",
    scanJoined: "facebook.group.scanJoined"
  };

  // src/providers/facebook-group/selectors.ts
  var GROUP_SELECTORS = {
    title: [{ css: "h1,[role='heading'][aria-level='1']" }],
    trigger: [{ role: "button", name: /^เขียนอะไรสักหน่อย\.{3,4}$/ }],
    composer: [{ role: "dialog", name: /^สร้างโพสต์$/ }],
    textbox: [{ css: "[role='textbox'][contenteditable='true']" }],
    post: [{ role: "button", name: /^โพสต์$/ }],
    close: [{ role: "button", name: /^ปิดกล่องโต้ตอบช่องเขียนข้อความ$/ }],
    media: [{ css: "[role='group'][aria-label='\u0E2A\u0E37\u0E48\u0E2D\u0E17\u0E35\u0E48\u0E41\u0E19\u0E1A\u0E21\u0E32'] img, [role='group'][aria-label='\u0E2A\u0E37\u0E48\u0E2D\u0E17\u0E35\u0E48\u0E41\u0E19\u0E1A\u0E21\u0E32'] video" }],
    file: [{ css: "input[type='file'][accept*='image']" }],
    article: [{ css: "[role='article']" }]
  };

  // src/providers/facebook-group/url.ts
  function parseGroupUrl(raw) {
    let u;
    try {
      u = new URL(raw.trim());
    } catch {
      return null;
    }
    if (u.protocol !== "https:" || !/^(www\.|m\.|web\.)?facebook\.com$/.test(u.hostname)) return null;
    if (u.username || u.password || u.port) return null;
    const match = /^\/groups\/([A-Za-z0-9._-]{1,100})\/?$/.exec(u.pathname);
    const key = match?.[1];
    if (!key || /^(feed|discover|create|joins|notifications|yourgroups)$/i.test(key)) return null;
    return `https://www.facebook.com/groups/${key}/`;
  }

  // src/bridges/bridge-kit/input.ts
  function normalise(s) {
    return s.replace(/\s+/g, " ").trim();
  }
  function currentText(el) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) return el.value;
    return el.innerText ?? el.textContent ?? "";
  }
  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (!setter) throw new AppError(ErrorCode.INPUT_REJECTED, "No native value setter");
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function selectAllIn(el) {
    const selection = el.ownerDocument.getSelection();
    if (!selection) return;
    const range = el.ownerDocument.createRange();
    range.selectNodeContents(el);
    selection.removeAllRanges();
    selection.addRange(range);
  }
  function pasteText(el, text) {
    const data = new DataTransfer();
    data.setData("text/plain", text);
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: data, bubbles: true, cancelable: true }));
  }
  function comparable(s) {
    return s.replace(/[^\p{L}\p{M}\p{N}]+/gu, "");
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function settle(check, ms) {
    const until = Date.now() + ms;
    for (; ; ) {
      if (check()) return true;
      if (Date.now() >= until) return false;
      await sleep(50);
    }
  }
  var SETTLE_MS = 2e3;
  async function selectAll(el) {
    el.focus();
    selectAllIn(el);
    await sleep(60);
  }
  async function clearEditor(el) {
    for (let i = 0; i < 3; i++) {
      if (!comparable(currentText(el))) return true;
      await selectAll(el);
      el.ownerDocument.execCommand("delete", false);
      if (await settle(() => !comparable(currentText(el)), 500)) return true;
      await selectAll(el);
      el.dispatchEvent(new InputEvent("beforeinput", { inputType: "deleteContentBackward", bubbles: true, cancelable: true }));
      if (await settle(() => !comparable(currentText(el)), 500)) return true;
    }
    return !comparable(currentText(el));
  }
  async function replaceText(el, text) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      setNativeValue(el, text);
      if (el.value !== text) throw new AppError(ErrorCode.INPUT_REJECTED, "Input value did not stick");
      return;
    }
    const expected = comparable(text);
    const landed = () => comparable(currentText(el)) === expected;
    const attempts = [
      () => pasteText(el, text),
      () => el.ownerDocument.execCommand("insertText", false, text)
    ];
    for (const attempt of attempts) {
      if (!await clearEditor(el)) break;
      await selectAll(el);
      attempt();
      if (await settle(landed, SETTLE_MS)) return;
    }
    const got = normalise(currentText(el)).slice(0, 120);
    await clearEditor(el);
    throw new AppError(ErrorCode.INPUT_REJECTED, "Editor did not accept the text", { detail: { got } });
  }
  function clickElement(el) {
    if (!(el instanceof HTMLElement)) throw new AppError(ErrorCode.INPUT_REJECTED, "Target is not clickable");
    el.scrollIntoView({ block: "center", inline: "center" });
    const rect = el.getBoundingClientRect();
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      clientX: rect.left + rect.width / 2,
      clientY: rect.top + rect.height / 2,
      button: 0
    };
    el.dispatchEvent(new PointerEvent("pointerdown", { ...init, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mousedown", init));
    el.dispatchEvent(new PointerEvent("pointerup", { ...init, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mouseup", init));
    el.dispatchEvent(new MouseEvent("click", init));
  }

  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 1;
  var counter = 0;
  function newRequestId() {
    counter = (counter + 1) % 1e6;
    return `${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }
  function envelope(type, payload, id2 = newRequestId()) {
    return { v: PROTOCOL_VERSION, id: id2, type, payload };
  }
  function isEnvelope(value) {
    if (typeof value !== "object" || value === null) return false;
    const v = value;
    return v["v"] === PROTOCOL_VERSION && typeof v["id"] === "string" && typeof v["type"] === "string";
  }
  function ok(data) {
    return { ok: true, data };
  }
  function failure(err) {
    return { ok: false, error: toAppError(err).toJSON() };
  }
  var BRIDGE_PROGRESS = "bridge.progress";
  var BRIDGE_CANCEL = "bridge.cancel";
  var PORT_TRANSFER_TO_EXTENSION = "acf-transfer-in:";
  var PORT_TRANSFER_TO_PAGE = "acf-transfer-out:";

  // src/shared/hash.ts
  async function sha256Hex(data) {
    const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
  }

  // src/shared/transfer-codec.ts
  var TRANSFER_CHUNK_BYTES = 1024 * 1024;
  var TRANSFER_MAX_BYTES = 1024 * 1024 * 1024;
  function bytesToBase64(bytes) {
    let binary = "";
    const step = 32768;
    for (let i = 0; i < bytes.length; i += step) {
      binary += String.fromCharCode(...bytes.subarray(i, i + step));
    }
    return btoa(binary);
  }
  function base64ToBytes(b64) {
    const binary = atob(b64);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }
  async function sendBlobOverPort(port, blob, name) {
    if (blob.size > TRANSFER_MAX_BYTES) {
      throw new AppError(ErrorCode.UPLOAD_FAILED, `File too large to transfer (${blob.size} bytes)`);
    }
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const chunks = Math.max(1, Math.ceil(bytes.length / TRANSFER_CHUNK_BYTES));
    const ack = new Promise((resolve, reject) => {
      port.onMessage.addListener((msg) => {
        if (msg.k !== "ack") return;
        if (msg.ok) resolve();
        else reject(new AppError(ErrorCode.UPLOAD_FAILED, `Receiver rejected transfer: ${msg.error}`));
      });
      port.onDisconnect.addListener(
        () => reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer port disconnected before ack"))
      );
    });
    port.postMessage({ k: "meta", size: bytes.length, mime: blob.type, name, chunks });
    for (let i = 0; i < chunks; i++) {
      const slice2 = bytes.subarray(i * TRANSFER_CHUNK_BYTES, (i + 1) * TRANSFER_CHUNK_BYTES);
      port.postMessage({ k: "chunk", i, b64: bytesToBase64(slice2) });
    }
    port.postMessage({ k: "end", sha256: await sha256Hex(bytes) });
    await ack;
  }
  function receiveBlobFromPort(port) {
    return new Promise((resolve, reject) => {
      let meta = null;
      const parts = [];
      const fail2 = (error) => {
        try {
          port.postMessage({ k: "ack", ok: false, error });
        } catch {
        }
        reject(new AppError(ErrorCode.UPLOAD_FAILED, error));
      };
      port.onDisconnect.addListener(() => {
        if (!meta || parts.length < meta.chunks) reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer interrupted"));
      });
      port.onMessage.addListener((msg) => {
        if (msg.k === "meta") {
          if (msg.size > TRANSFER_MAX_BYTES) return fail2("file too large");
          meta = msg;
          return;
        }
        if (msg.k === "chunk") {
          if (!meta || msg.i !== parts.length) return fail2(`unexpected chunk ${msg.i}`);
          parts.push(base64ToBytes(msg.b64));
          return;
        }
        if (msg.k === "end") {
          const m = meta;
          if (!m || parts.length !== m.chunks) return fail2("missing chunks");
          const file = new File(parts, m.name, { type: m.mime });
          void file.arrayBuffer().then((buf) => sha256Hex(buf)).then((hash) => {
            if (hash !== msg.sha256) return fail2("checksum mismatch");
            port.postMessage({ k: "ack", ok: true });
            resolve(file);
          }, (err) => fail2(String(err)));
        }
      });
    });
  }

  // src/bridges/bridge-kit/transfer.ts
  async function sendBlobToExtension(transferId, blob, name, timeoutMs) {
    const port = chrome.runtime.connect({ name: `${PORT_TRANSFER_TO_EXTENSION}${transferId}` });
    try {
      await withTimeout(sendBlobOverPort(port, blob, name), timeoutMs, "Transfer to extension", ErrorCode.DOWNLOAD_FAILED);
    } finally {
      port.disconnect();
    }
  }
  function expectFileFromExtension(transferId, timeoutMs) {
    const expected = `${PORT_TRANSFER_TO_PAGE}${transferId}`;
    let listener = null;
    const file = new Promise((resolve, reject) => {
      listener = (port) => {
        if (port.name !== expected) return;
        if (port.sender?.id !== chrome.runtime.id) {
          port.disconnect();
          reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer from unexpected sender"));
          return;
        }
        receiveBlobFromPort(port).then(resolve, reject);
      };
      chrome.runtime.onConnect.addListener(listener);
    });
    return withTimeout(file, timeoutMs, "Transfer from extension", ErrorCode.UPLOAD_FAILED).finally(() => {
      if (listener) chrome.runtime.onConnect.removeListener(listener);
    });
  }
  async function fetchInPage(url, signal) {
    const res = await fetch(url, { credentials: "include", ...signal ? { signal } : {} });
    if (!res.ok) throw new AppError(ErrorCode.DOWNLOAD_FAILED, `HTTP ${res.status} for media`, { detail: { status: res.status } });
    return res.blob();
  }
  var pendingReceives = /* @__PURE__ */ new Map();
  function prepareReceive(transferId, timeoutMs) {
    const file = expectFileFromExtension(transferId, timeoutMs);
    file.catch(() => void 0);
    pendingReceives.set(transferId, file);
  }
  async function takeReceived(transferId) {
    const file = pendingReceives.get(transferId);
    if (!file) throw new AppError(ErrorCode.UPLOAD_FAILED, `No transfer prepared for ${transferId}`);
    try {
      return await file;
    } finally {
      pendingReceives.delete(transferId);
    }
  }

  // src/bridges/bridge-kit/standard.ts
  async function slice(sliceMs, signal, wait, progress) {
    try {
      return { done: true, result: await wait(sliceMs, signal) };
    } catch (err) {
      if (err instanceof AppError && (err.code === ErrorCode.TIMEOUT || err.code === ErrorCode.SELECTOR_NOT_FOUND)) {
        const out = { done: false };
        const p = progress?.();
        if (p) out.progress = p;
        return out;
      }
      throw err;
    }
  }
  var CAPTCHA_TITLE = /just a moment|attention required|security check|ตรวจสอบความปลอดภัย/i;
  var CAPTCHA_SELECTORS = [
    { css: "#challenge-form" },
    { css: "iframe[src*='challenges.cloudflare.com']" },
    { css: "iframe[src*='recaptcha']" },
    { css: "iframe[src*='hcaptcha']" },
    { css: "[id*='captcha' i]" }
  ];
  function captchaVisible() {
    return CAPTCHA_TITLE.test(document.title) || resolveFirst(CAPTCHA_SELECTORS) !== null;
  }
  function describePage(selectors) {
    const parts = Object.keys(selectors).slice(0, 6).map((key) => {
      const list = selectors[key] ?? [];
      if (resolveFirst(list)) return `${key}=visible`;
      if (resolveFirst(list, { visible: false })) return `${key}=hidden`;
      return `${key}=missing`;
    });
    return `page not ready [${document.visibilityState}, captcha=${captchaVisible()}] ${parts.join(" ")}`;
  }
  var sliceMsValidator = number({ int: true, min: 100, max: 6e4 });
  function standardHandlers(opts) {
    const { prefix } = opts;
    return {
      [`${prefix}.ping`]: () => ({
        providerId: opts.providerId,
        version: opts.version,
        url: location.href,
        state: opts.detectState()
      }),
      [`${prefix}.waitReady`]: (payload, ctx) => {
        const { sliceMs } = object({ sliceMs: sliceMsValidator })(payload);
        return slice(
          sliceMs,
          ctx.signal,
          (timeoutMs, signal) => waitForCondition(
            () => {
              const state = opts.detectState();
              return state === "loading" ? null : state;
            },
            { timeoutMs, signal, what: "page ready" }
          ),
          () => describePage(opts.selectors)
        );
      },
      [`${prefix}.diagnose`]: () => diagnoseSelectors(opts.selectors),
      [`${prefix}.prepareReceive`]: (payload) => {
        const { transferId, timeoutMs } = object({
          transferId: id,
          timeoutMs: number({ int: true, min: 1e3, max: 36e5 })
        })(payload);
        prepareReceive(transferId, timeoutMs);
        return { prepared: true };
      },
      [`${prefix}.fetchMedia`]: async (payload, ctx) => {
        const { src, transferId, timeoutMs } = object({
          src: string({ min: 1, max: 8e3, pattern: /^(https:|blob:)/ }),
          transferId: id,
          timeoutMs: number({ int: true, min: 1e3, max: 36e5 })
        })(payload);
        const blob = await fetchInPage(src, ctx.signal);
        await sendBlobToExtension(transferId, blob, "media", timeoutMs);
        return { size: blob.size, mime: blob.type };
      }
    };
  }

  // src/bridges/facebook-promo.ts
  function isPromoDialog(d) {
    if (d.querySelector("[contenteditable='true']")) return false;
    return FACEBOOK_TEXT.promoDialog.test((d.innerText ?? d.textContent ?? "").slice(0, 2e3));
  }
  function dismissPromos() {
    let n = 0;
    for (const d of Array.from(document.querySelectorAll("[role='dialog']"))) {
      if (!isPromoDialog(d)) continue;
      const button = FACEBOOK_SELECTORS.promoDismiss.flatMap((c) => queryCandidate(c, d)).find(isEnabled);
      if (!button) continue;
      clickElement(button);
      n++;
    }
    return n;
  }
  function click(el) {
    dismissPromos();
    clickElement(el);
  }

  // src/bridges/facebook-group.ts
  var MANAGE_HEADING = /^(กลุ่มที่คุณจัดการ|Groups you manage)$/i;
  var JOINED_HEADING = /^(กลุ่มที่คุณเข้าร่วม|กลุ่มทั้งหมดที่คุณเข้าร่วม.*|Groups you've joined|All groups you've joined.*)$/i;
  var OTHER_HEADING = /^(แนะนำสำหรับคุณ|กลุ่มที่แนะนำ|คำแนะนำเพิ่มเติม|ค้นพบ|Suggested for you|More suggestions|Discover)$/i;
  var NOT_A_NAME = /^(ดูกลุ่ม|ดูทั้งหมด|ดูเพิ่มเติม|เข้าร่วมแล้ว|View group|See all|See more|Joined)$/i;
  function joinedGroups() {
    const found = /* @__PURE__ */ new Map();
    let mode = "unknown";
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const el = n;
      if (el instanceof HTMLAnchorElement) {
        if (mode === "other") continue;
        const url = parseGroupUrl(el.href);
        if (!url) continue;
        const g = found.get(url) ?? { url, name: "", admin: false };
        const name = (el.innerText || el.getAttribute("aria-label") || "").split("\n").map((s) => s.replace(/\s+/g, " ").trim()).find(Boolean) ?? "";
        if (!g.name && name.length >= 2 && name.length <= 120 && !NOT_A_NAME.test(name)) g.name = name;
        if (mode === "manage") g.admin = true;
        found.set(url, g);
        continue;
      }
      if (el.childElementCount === 0) {
        const t = (el.textContent ?? "").trim();
        if (t && t.length < 80) {
          if (MANAGE_HEADING.test(t)) mode = "manage";
          else if (JOINED_HEADING.test(t)) mode = "joined";
          else if (OTHER_HEADING.test(t)) mode = "other";
        }
      }
    }
    return [...found.values()].filter((g) => g.name);
  }
  var SCAN_STEP_MS = 700;
  var SCAN_STABLE_ROUNDS = 6;
  function groupPageReady() {
    return location.pathname.startsWith("/groups/") && Boolean(resolveFirst(GROUP_SELECTORS.title));
  }
  function editorText(el) {
    const read = (node) => {
      if (node instanceof HTMLImageElement) return node.alt;
      if (node instanceof HTMLBRElement) return "\n";
      if (node.nodeType === Node.TEXT_NODE) return node.textContent ?? "";
      return Array.from(node.childNodes).map(read).join("");
    };
    const paragraphs = Array.from(el.children);
    if (paragraphs.length && paragraphs.every((p) => p.tagName === "P")) {
      return paragraphs.map((p) => p.childNodes.length === 1 && p.firstChild instanceof HTMLBRElement ? "" : read(p)).join("\n");
    }
    return read(el);
  }
  function groupHandlers(helpers) {
    let target = "";
    let expectedText = "";
    let expectedPhotos = 0;
    let timedPhotos = false;
    let clickedAt = 0;
    let closedAt2 = 0;
    let submittedComposer = null;
    let previousLinks = /* @__PURE__ */ new Set();
    let prepared = false;
    function identity() {
      const current = parseGroupUrl(location.href);
      if (!target || current !== target) throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Group URL changed", {
        userMessage: "Facebook \u0E40\u0E1B\u0E34\u0E14\u0E01\u0E25\u0E38\u0E48\u0E21\u0E2D\u0E37\u0E48\u0E19\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 URL \u2014 \u0E15\u0E23\u0E27\u0E08\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21\u0E01\u0E48\u0E2D\u0E19 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E42\u0E1E\u0E2A\u0E15\u0E4C"
      });
      const titles = resolveAll(GROUP_SELECTORS.title);
      if (titles.length !== 1) throw new AppError(ErrorCode.PAGE_NOT_READY, "Group heading missing or ambiguous", { userMessage: "\u0E40\u0E1B\u0E34\u0E14\u0E01\u0E25\u0E38\u0E48\u0E21\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E25\u0E38\u0E48\u0E21\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" });
      const title = (titles[0].textContent ?? "").trim();
      if (!title) throw new AppError(ErrorCode.PAGE_NOT_READY, "Empty Group heading");
      return { url: current, title, canPost: true };
    }
    function composer() {
      const dialogs = resolveAll(GROUP_SELECTORS.composer).filter((d) => resolveFirst(GROUP_SELECTORS.textbox, { root: d }));
      if (dialogs.length !== 1) throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Group composer missing or ambiguous", { userMessage: "\u0E2B\u0E32 Composer \u0E01\u0E25\u0E38\u0E48\u0E21\u0E44\u0E21\u0E48\u0E1E\u0E1A \u0E2B\u0E23\u0E37\u0E2D\u0E21\u0E35\u0E2B\u0E25\u0E32\u0E22\u0E01\u0E25\u0E48\u0E2D\u0E07 \u2014 Facebook UI \u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19" });
      return dialogs[0];
    }
    function photoReadings(d) {
      const shown = resolveAll(GROUP_SELECTORS.media, { root: d }).length;
      const all = resolveAll(GROUP_SELECTORS.media, { root: d, visible: false }).length;
      const boxes = resolveAll(GROUP_SELECTORS.textbox, { root: d });
      const outsideCaption = (n) => !boxes.some((b) => b.contains(n));
      const plus = /^\s*\+\s?(\d{1,2})\s*$/;
      let more = 0;
      for (const el of d.querySelectorAll("*")) {
        if (!outsideCaption(el)) continue;
        const own = el.children.length === 0 ? el.textContent ?? "" : "";
        const m = plus.exec(own) ?? plus.exec(el.getAttribute("aria-label") ?? "");
        if (m) more = Math.max(more, Number(m[1]));
      }
      return { shown, more, all, busy: Boolean(resolveFirst(FACEBOOK_SELECTORS.uploadProgress, { root: d })) };
    }
    function photosMatch(d, count) {
      const r = photoReadings(d);
      return !r.busy && (r.shown === count || r.shown + r.more === count || r.more > 0 && r.all === count);
    }
    function photoStatus(d, count) {
      const r = photoReadings(d);
      return `\u0E01\u0E33\u0E25\u0E31\u0E07\u0E15\u0E23\u0E27\u0E08\u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E41\u0E19\u0E1A\u0E43\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21 \xB7 \u0E40\u0E2B\u0E47\u0E19 ${r.shown}${r.more ? ` +${r.more}` : ""} \u0E23\u0E39\u0E1B (\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 ${r.all}) / \u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 ${count}${r.busy ? " \xB7 \u0E22\u0E31\u0E07\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E2D\u0E22\u0E39\u0E48" : ""}`;
    }
    function validatePrepared() {
      identity();
      const d = composer();
      const box = resolveFirst(GROUP_SELECTORS.textbox, { root: d }).el;
      if (editorText(box).replace(/\r\n?/g, "\n") !== expectedText.replace(/\r\n?/g, "\n")) {
        throw new AppError(ErrorCode.INPUT_REJECTED, "Group caption differs from snapshot", { userMessage: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E43\u0E19 Composer \u0E44\u0E21\u0E48\u0E04\u0E23\u0E1A\u0E2B\u0E23\u0E37\u0E2D\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u2014 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E42\u0E1E\u0E2A\u0E15\u0E4C" });
      }
      if (!timedPhotos && !photosMatch(d, expectedPhotos)) {
        throw new AppError(ErrorCode.UPLOAD_FAILED, "Group photo evidence missing", { userMessage: "\u0E23\u0E39\u0E1B\u0E43\u0E19 Composer \u0E44\u0E21\u0E48\u0E04\u0E23\u0E1A\u0E2B\u0E23\u0E37\u0E2D\u0E22\u0E31\u0E07\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E2D\u0E22\u0E39\u0E48 \u2014 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E42\u0E1E\u0E2A\u0E15\u0E4C" });
      }
      return d;
    }
    function articleLinks(article) {
      return Array.from(article.querySelectorAll("a[href]")).flatMap((a) => {
        const u = new URL(a.href, location.href);
        const match = /^\/groups\/([^/]+)\/(posts|permalink|pending_posts)\/([^/]+)\/?$/.exec(u.pathname);
        if (!match || parseGroupUrl(`${u.origin}/groups/${match[1]}/`) !== target) return [];
        return [`${u.origin}/groups/${match[1]}/${match[2] === "pending_posts" ? "pending_posts" : "posts"}/${match[3]}/`];
      });
    }
    async function open(payload, signal) {
      const { url } = object({ url: string({ min: 1, max: 400 }) })(payload);
      target = parseGroupUrl(url) ?? "";
      prepared = false;
      clickedAt = 0;
      closedAt2 = 0;
      submittedComposer = null;
      expectedText = "";
      expectedPhotos = 0;
      timedPhotos = false;
      const result = identity();
      if (resolveAll(GROUP_SELECTORS.composer).some((d2) => resolveFirst(GROUP_SELECTORS.textbox, { root: d2 }))) {
        throw new AppError(ErrorCode.INVALID_STATE, "An existing composer is open", { userMessage: "\u0E21\u0E35 Composer \u0E40\u0E1B\u0E34\u0E14\u0E04\u0E49\u0E32\u0E07\u0E2D\u0E22\u0E39\u0E48 \u2014 \u0E40\u0E01\u0E47\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E44\u0E27\u0E49\u0E41\u0E25\u0E30\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E43\u0E2B\u0E21\u0E48", detail: { beforePost: true, draftBlocked: true } });
      }
      await waitFor("groupComposerTrigger", GROUP_SELECTORS.trigger, { timeoutMs: 15e3, signal, enabled: true }).catch(() => {
        throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Group composer trigger unavailable", {
          retryable: false,
          userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E1B\u0E38\u0E48\u0E21\u0E40\u0E02\u0E35\u0E22\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C \u2014 \u0E2D\u0E32\u0E08\u0E44\u0E21\u0E48\u0E21\u0E35\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E42\u0E1E\u0E2A\u0E15\u0E4C \u0E01\u0E25\u0E38\u0E48\u0E21\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49\u0E42\u0E1E\u0E2A\u0E15\u0E4C \u0E2B\u0E23\u0E37\u0E2D Facebook UI \u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19"
        });
      });
      await helpers.open(signal, GROUP_SELECTORS.trigger);
      const d = composer();
      const existingMedia = resolveAll(GROUP_SELECTORS.media, { root: d, visible: false }).length > 0 || resolveAll(FACEBOOK_SELECTORS.mediaPreview, { root: d }).some((media) => media instanceof HTMLVideoElement);
      if (editorText(resolveFirst(GROUP_SELECTORS.textbox, { root: d }).el).trim() || existingMedia) {
        throw new AppError(ErrorCode.INVALID_STATE, "Facebook restored an existing draft", { userMessage: "Facebook \u0E40\u0E1B\u0E34\u0E14\u0E09\u0E1A\u0E31\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E40\u0E14\u0E34\u0E21 \u2014 \u0E40\u0E01\u0E47\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E44\u0E27\u0E49\u0E42\u0E14\u0E22\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E41\u0E01\u0E49\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21", detail: { beforePost: true, draftBlocked: true } });
      }
      if (!resolveFirst(GROUP_SELECTORS.post, { root: d }) || !resolveFirst(GROUP_SELECTORS.file, { root: d, visible: false })) {
        throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Group photo/post controls missing", { userMessage: "Composer \u0E01\u0E25\u0E38\u0E48\u0E21\u0E44\u0E21\u0E48\u0E21\u0E35\u0E1B\u0E38\u0E48\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E2B\u0E23\u0E37\u0E2D\u0E0A\u0E48\u0E2D\u0E07\u0E41\u0E19\u0E1A\u0E23\u0E39\u0E1B \u2014 Facebook UI \u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19" });
      }
      previousLinks = new Set(resolveAll(GROUP_SELECTORS.article).flatMap(articleLinks));
      prepared = true;
      return result;
    }
    let scanStable = 0;
    let scanLastCount = -1;
    return {
      /** One slice of scrolling "Your groups" so Facebook loads more cards; returns everything seen so far. */
      [GROUP_CMD.scanJoined]: async (p, c) => {
        const { sliceMs, reset } = object({ sliceMs: sliceMsValidator, reset: boolean })(p);
        if (resolveFirst(FACEBOOK_SELECTORS.loginForm)) {
          throw new AppError(ErrorCode.LOGIN_REQUIRED, "Facebook login required", { userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 Facebook \u0E43\u0E19\u0E40\u0E1A\u0E23\u0E32\u0E27\u0E4C\u0E40\u0E0B\u0E2D\u0E23\u0E4C\u0E19\u0E35\u0E49 \u2014 \u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E01\u0E48\u0E2D\u0E19\u0E41\u0E25\u0E49\u0E27\u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48" });
        }
        if (!location.pathname.startsWith("/groups/joins")) throw new AppError(ErrorCode.PAGE_NOT_READY, "Not on the joined-groups page");
        if (reset) {
          scanStable = 0;
          scanLastCount = -1;
        }
        const end = Date.now() + Math.max(500, sliceMs - 400);
        let groups = joinedGroups();
        while (Date.now() < end && scanStable < SCAN_STABLE_ROUNDS) {
          window.scrollTo(0, document.documentElement.scrollHeight);
          await delay(SCAN_STEP_MS, c.signal);
          groups = joinedGroups();
          const loading = Boolean(document.querySelector("[role='main'] [role='progressbar'], [role='main'] [aria-busy='true']"));
          if (groups.length === scanLastCount && !loading) scanStable++;
          else {
            scanStable = 0;
            scanLastCount = groups.length;
          }
        }
        return { done: scanStable >= SCAN_STABLE_ROUNDS, groups };
      },
      [GROUP_CMD.pendingRoute]: (p) => {
        const { url } = object({ url: string({ max: 400 }) })(p);
        target = parseGroupUrl(url) ?? "";
        identity();
        const links = Array.from(document.querySelectorAll("a[href]"));
        for (const suffix of ["my_pending_content/", "pending_posts/"]) {
          const route = `${target}${suffix}`;
          if (links.some((a) => a.href.split("?")[0] === route)) return { url: route };
        }
        return { url: null };
      },
      [GROUP_CMD.pendingList]: async (p, c) => {
        const { url } = object({ url: string({ max: 400 }) })(p);
        target = parseGroupUrl(url) ?? "";
        const current = new URL(location.href);
        if (![`${target}my_pending_content/`, `${target}pending_posts/`].includes(`${current.origin}${current.pathname}`)) {
          throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Pending page is not the target Group");
        }
        await waitForCondition(() => {
          if (resolveFirst(FACEBOOK_SELECTORS.loginForm)) throw new AppError(ErrorCode.LOGIN_REQUIRED, "Pending page requires login");
          const main2 = document.querySelector("main,[role='main']");
          const text = main2?.innerText ?? "";
          if (/เนื้อหานี้ไม่พร้อมใช้งาน/.test(text)) throw new AppError(ErrorCode.PAGE_NOT_READY, "Pending page unavailable");
          const match = /(?:รอดำเนินการ|โพสต์ที่รออนุมัติ|โพสต์ที่รอดำเนินการ)\s*·?\s*(\d[\d,]*)/.exec(text);
          if (!match || !text.includes("\u0E43\u0E2B\u0E21\u0E48\u0E17\u0E35\u0E48\u0E2A\u0E38\u0E14\u0E01\u0E48\u0E2D\u0E19")) return null;
          const count2 = Number(match[1].replace(/,/g, ""));
          return count2 === 0 || resolveAll(GROUP_SELECTORS.article, { root: main2 }).some((article) => articleLinks(article).some((href) => href.includes("/pending_posts/"))) ? true : null;
        }, { timeoutMs: 1e4, signal: c.signal, what: "Group pending posts" });
        const main = document.querySelector("main,[role='main']");
        const count = Number(/(?:รอดำเนินการ|โพสต์ที่รออนุมัติ|โพสต์ที่รอดำเนินการ)\s*·?\s*(\d[\d,]*)/.exec(main.innerText)[1].replace(/,/g, ""));
        return { count, posts: resolveAll(GROUP_SELECTORS.article, { root: main }).flatMap((article) => {
          const link = articleLinks(article).find((href) => href.includes("/pending_posts/"));
          if (!link) return [];
          return [{ url: link, text: comparable(article.innerText), photos: article.querySelectorAll("a[href*='/photo/']").length }];
        }) };
      },
      [GROUP_CMD.open]: (p, c) => open(p, c.signal),
      [GROUP_CMD.inspect]: async (p, c) => {
        const result = await open(p, c.signal);
        const close = resolveFirst(GROUP_SELECTORS.close, { root: composer() });
        if (!close) throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Empty test composer cannot be closed");
        click(close.el);
        prepared = false;
        await waitForCondition(
          () => resolveAll(GROUP_SELECTORS.composer).some((d) => resolveFirst(GROUP_SELECTORS.textbox, { root: d })) ? null : true,
          { timeoutMs: 1e4, signal: c.signal, what: "Group test composer closing" }
        );
        return result;
      },
      [GROUP_CMD.attach]: async (p, c) => {
        identity();
        composer();
        if (!prepared) throw new AppError(ErrorCode.INVALID_STATE, "Group not prepared");
        const { transferIds } = object({ transferIds: array(id, { min: 1, max: 10 }) })(p);
        expectedPhotos = transferIds.length;
        return helpers.attach(p, c.signal);
      },
      [GROUP_CMD.upload]: (p, c) => {
        identity();
        composer();
        const { count, sliceMs } = object({ count: number({ int: true, min: 1, max: 10 }), sliceMs: sliceMsValidator })(p);
        return slice(sliceMs, c.signal, (timeoutMs, signal) => waitForCondition(() => {
          identity();
          const d = composer();
          if (FACEBOOK_TEXT.postError.test(d.innerText)) throw new AppError(ErrorCode.UPLOAD_FAILED, "Group image upload failed");
          const previews = resolveAll(GROUP_SELECTORS.media, { root: d });
          const loaded = previews.every((p2) => p2 instanceof HTMLVideoElement ? p2.readyState >= 1 : p2 instanceof HTMLImageElement && p2.complete && p2.naturalWidth > 0);
          return photosMatch(d, count) && loaded ? { previews: count } : null;
        }, { timeoutMs, signal, what: "Group photo upload evidence" }), () => {
          try {
            return photoStatus(composer(), count);
          } catch {
            return "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E15\u0E23\u0E27\u0E08\u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E41\u0E19\u0E1A\u0E43\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21";
          }
        });
      },
      [GROUP_CMD.caption]: async (p) => {
        identity();
        composer();
        const { text, timed } = object({ text: string({ max: 63e3 }), timed: optional(boolean) })(p);
        expectedText = text;
        if (timed) {
          if (FACEBOOK_TEXT.postError.test(composer().innerText)) throw new AppError(ErrorCode.UPLOAD_FAILED, "Group image upload failed", { userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E23\u0E39\u0E1B\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 \u2014 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E42\u0E1E\u0E2A\u0E15\u0E4C" });
          timedPhotos = true;
        }
        if (text) await helpers.caption({ text });
        validatePrepared();
        return { set: true };
      },
      [GROUP_CMD.submit]: async (_p, c) => {
        try {
          if (!prepared || clickedAt) throw new AppError(ErrorCode.INVALID_STATE, "Group submit is not repeatable");
          const d = validatePrepared();
          const post = await waitFor("groupPost", GROUP_SELECTORS.post, { root: d, enabled: true, timeoutMs: 15e3, signal: c.signal });
          validatePrepared();
          submittedComposer = d;
          clickedAt = Date.now();
          click(post.el);
          return { clicked: true };
        } catch (err) {
          if (!clickedAt) throw beforePostError(err);
          throw err;
        }
      },
      [GROUP_CMD.confirm]: (p, c) => {
        const { sliceMs, confirmWindowMs, acceptSubmission } = object({ sliceMs: sliceMsValidator, confirmWindowMs: number({ min: 1e3, max: 6e5 }), acceptSubmission: optional(boolean) })(p);
        return slice(sliceMs, c.signal, (timeoutMs, signal) => waitForCondition(() => {
          if (!clickedAt) throw new AppError(ErrorCode.INVALID_STATE, "Group has not submitted");
          if (acceptSubmission) {
            if (!target || parseGroupUrl(location.href) !== target) throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Group URL changed after Post");
            if (resolveFirst(FACEBOOK_SELECTORS.loginForm)) throw new AppError(ErrorCode.LOGIN_REQUIRED, "Group post requires login");
            if (captchaVisible()) throw new AppError(ErrorCode.CAPTCHA_REQUIRED, "Group post requires security verification");
          } else identity();
          const dialogs = resolveAll(GROUP_SELECTORS.composer).filter((d) => resolveFirst(GROUP_SELECTORS.textbox, { root: d }));
          if (submittedComposer?.isConnected && isVisible(submittedComposer) && !dialogs.includes(submittedComposer)) dialogs.push(submittedComposer);
          const alerts = resolveAll([{ css: "[role='alert']" }]);
          if ([...dialogs, ...alerts].some((d) => FACEBOOK_TEXT.postError.test(d.innerText))) {
            throw new AppError(ErrorCode.UPLOAD_FAILED, "Facebook reported a Group post error");
          }
          if (acceptSubmission) {
            const cleared = dialogs.every((d) => {
              const boxes = resolveAll(GROUP_SELECTORS.textbox, { root: d });
              const media = resolveAll(GROUP_SELECTORS.media, { root: d, visible: false });
              const extraMedia = resolveAll(FACEBOOK_SELECTORS.mediaPreview, { root: d }).filter((el) => el instanceof HTMLVideoElement || el.getAttribute("src")?.startsWith("blob:"));
              return boxes.length > 0 && boxes.every((box) => !editorText(box).trim()) && media.length === 0 && extraMedia.length === 0 && !resolveFirst(FACEBOOK_SELECTORS.uploadProgress, { root: d });
            });
            if (cleared) {
              closedAt2 ||= Date.now();
              if (Date.now() - closedAt2 >= 1e3) return { outcome: "pending_approval", confirmedBy: "dom" };
            } else closedAt2 = 0;
          } else if (!dialogs.length) {
            closedAt2 ||= Date.now();
            const needle = comparable(expectedText);
            for (const article of resolveAll(GROUP_SELECTORS.article).filter(isVisible)) {
              const fresh = articleLinks(article).find((url) => !previousLinks.has(url));
              if (!fresh || !needle || !comparable(article.innerText).includes(needle)) continue;
              const pending = fresh.includes("/pending_posts/");
              return { outcome: pending ? "pending_approval" : "published", confirmedBy: "dom", postUrl: fresh };
            }
          } else {
            closedAt2 = 0;
          }
          if (Date.now() - clickedAt > confirmWindowMs) throw new AppError(ErrorCode.PUBLISH_UNCONFIRMED, "New Group post not found");
          return null;
        }, { timeoutMs, signal, what: "Group publication evidence" }), () => "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21 (\u0E23\u0E27\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34)");
      }
    };
  }

  // src/bridges/bridge-kit/file-input.ts
  function setInputFiles(input, files) {
    if (input.type !== "file") throw new AppError(ErrorCode.UPLOAD_FAILED, "Target is not a file input");
    const data = new DataTransfer();
    for (const f of files) data.items.add(f);
    input.files = data.files;
    if ((input.files?.length ?? 0) !== files.length) {
      throw new AppError(ErrorCode.UPLOAD_FAILED, "File input rejected the files");
    }
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // src/bridges/bridge-kit/server.ts
  function extensionAlive() {
    try {
      return typeof chrome !== "undefined" && Boolean(chrome.runtime?.id);
    } catch {
      return false;
    }
  }
  function startBridge(providerId, version, handlers) {
    const registry = globalThis.__acfBridges ??= {};
    registry[providerId]?.dispose();
    const inflight = /* @__PURE__ */ new Map();
    const listener = (message, sender, sendResponse) => {
      if (!isEnvelope(message) || sender.id !== chrome.runtime.id || sender.tab || sender.url?.startsWith("http")) return false;
      const env = message;
      if (env.type === BRIDGE_CANCEL) {
        const raw = env.payload?.["requestId"];
        const requestId = typeof raw === "string" ? raw : "";
        inflight.get(requestId)?.abort(new AppError(ErrorCode.CANCELLED, "Cancelled by extension"));
        return false;
      }
      const handler = handlers[env.type];
      if (!handler) return false;
      const controller = new AbortController();
      inflight.set(env.id, controller);
      const ctx = {
        signal: controller.signal,
        requestId: env.id,
        progress: (text, data) => {
          if (!extensionAlive()) return;
          const payload = { requestId: env.id, message: text };
          if (data) payload.data = data;
          chrome.runtime.sendMessage(envelope(BRIDGE_PROGRESS, payload)).catch(() => void 0);
        }
      };
      Promise.resolve().then(() => handler(env.payload ?? {}, ctx)).then(
        (data) => sendResponse(ok(data ?? null)),
        (err) => sendResponse(failure(err))
      ).finally(() => inflight.delete(env.id));
      return true;
    };
    chrome.runtime.onMessage.addListener(listener);
    registry[providerId] = {
      version,
      dispose: () => {
        for (const c of inflight.values()) c.abort(new AppError(ErrorCode.CANCELLED, "Bridge replaced"));
        inflight.clear();
        try {
          chrome.runtime.onMessage.removeListener(listener);
        } catch {
        }
      }
    };
  }

  // src/bridges/facebook-schedule.ts
  var STEP_WAIT_MS = 1e4;
  var TH_MONTHS = ["\u0E21\u0E01\u0E23\u0E32\u0E04\u0E21", "\u0E01\u0E38\u0E21\u0E20\u0E32\u0E1E\u0E31\u0E19\u0E18\u0E4C", "\u0E21\u0E35\u0E19\u0E32\u0E04\u0E21", "\u0E40\u0E21\u0E29\u0E32\u0E22\u0E19", "\u0E1E\u0E24\u0E29\u0E20\u0E32\u0E04\u0E21", "\u0E21\u0E34\u0E16\u0E38\u0E19\u0E32\u0E22\u0E19", "\u0E01\u0E23\u0E01\u0E0E\u0E32\u0E04\u0E21", "\u0E2A\u0E34\u0E07\u0E2B\u0E32\u0E04\u0E21", "\u0E01\u0E31\u0E19\u0E22\u0E32\u0E22\u0E19", "\u0E15\u0E38\u0E25\u0E32\u0E04\u0E21", "\u0E1E\u0E24\u0E28\u0E08\u0E34\u0E01\u0E32\u0E22\u0E19", "\u0E18\u0E31\u0E19\u0E27\u0E32\u0E04\u0E21"];
  var TH_SHORT = ["\u0E21.\u0E04.", "\u0E01.\u0E1E.", "\u0E21\u0E35.\u0E04.", "\u0E40\u0E21.\u0E22.", "\u0E1E.\u0E04.", "\u0E21\u0E34.\u0E22.", "\u0E01.\u0E04.", "\u0E2A.\u0E04.", "\u0E01.\u0E22.", "\u0E15.\u0E04.", "\u0E1E.\u0E22.", "\u0E18.\u0E04."];
  var EN_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  function unavailable(message, detail) {
    return new AppError(ErrorCode.NATIVE_SCHEDULE_UNAVAILABLE, message, {
      userMessage: "\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A\u0E02\u0E2D\u0E07 Facebook \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49",
      detail
    });
  }
  function onScreen(el) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    if (r.right <= 0 || r.bottom <= 0 || r.left >= innerWidth || r.top >= innerHeight) return false;
    const style = getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }
  function visibleAll(list) {
    const out = [];
    for (const c of list) for (const el of queryCandidate(c)) if (onScreen(el) && !out.includes(el)) out.push(el);
    return out;
  }
  function visibleFirst(list) {
    return visibleAll(list)[0] ?? null;
  }
  function waitVisible(what, list, signal, enabled = false) {
    return waitForCondition(() => visibleAll(list).find((e) => !enabled || isEnabled(e)) ?? null, {
      timeoutMs: STEP_WAIT_MS,
      signal,
      what,
      onTimeout: () => unavailable(`Scheduling UI: ${what} not found`)
    });
  }
  function labelledCombobox(label) {
    for (const input of document.querySelectorAll("input[role='combobox']")) {
      if (!onScreen(input)) continue;
      const text = (input.closest("label")?.textContent ?? "").trim();
      if (label.test(text)) return input;
    }
    return null;
  }
  function scheduleRowText() {
    const row = visibleFirst(FACEBOOK_SELECTORS.scheduleOption);
    return row ? (row.textContent ?? "").replace(/\s+/g, " ").trim() : null;
  }
  var pad = (n) => String(n).padStart(2, "0");
  function timeText(w) {
    return `${pad(w.hour)}:${pad(w.minute)}`;
  }
  function dayCellMatches(text, w) {
    const flat = text.replace(/\s+/g, " ");
    const th = `\u0E17\u0E35\u0E48 ${w.day} ${TH_MONTHS[w.month - 1]} ${w.year}`;
    const en = `${EN_MONTHS[w.month - 1]} ${w.day}, ${w.year}`;
    return flat.includes(th) || flat.includes(en);
  }
  function dateValueMatches(value, w) {
    const flat = value.replace(/\s+/g, " ").trim();
    const enShort = (EN_MONTHS[w.month - 1] ?? "").slice(0, 3);
    return flat === `${w.day} ${TH_SHORT[w.month - 1]} ${w.year}` || new RegExp(`^${enShort}\\w*\\.? ${w.day}, ${w.year}$`, "i").test(flat) || new RegExp(`^${w.day} ${enShort}\\w*\\.? ${w.year}$`, "i").test(flat);
  }
  async function chooseDate(w, signal) {
    const input = labelledCombobox(FACEBOOK_TEXT.dateLabel);
    if (!input) throw unavailable("Scheduling UI: date field not found");
    if (dateValueMatches(input.value, w)) return;
    const opener = visibleFirst(FACEBOOK_SELECTORS.datePickerButton) ?? input;
    click(opener);
    await waitVisible("calendar", FACEBOOK_SELECTORS.calendarGrid, signal);
    for (let month = 0; month < 14; month++) {
      const cell = visibleAll(FACEBOOK_SELECTORS.calendarDay).find((c) => dayCellMatches(c.textContent ?? "", w));
      if (cell) {
        if (cell.getAttribute("aria-disabled") === "true") throw unavailable("Facebook does not allow that date");
        click(cell);
        break;
      }
      const next = visibleFirst(FACEBOOK_SELECTORS.nextMonth);
      if (!next) throw unavailable("Scheduling UI: next-month button not found");
      click(next);
      await delay(250);
    }
    await waitForCondition(() => dateValueMatches(labelledCombobox(FACEBOOK_TEXT.dateLabel)?.value ?? "", w) ? true : null, {
      timeoutMs: STEP_WAIT_MS,
      signal,
      what: "date set",
      onTimeout: () => unavailable("Date did not stick", { got: labelledCombobox(FACEBOOK_TEXT.dateLabel)?.value })
    });
  }
  async function chooseTime(w, signal) {
    const want = timeText(w);
    const input = labelledCombobox(FACEBOOK_TEXT.timeLabel);
    if (!input) throw unavailable("Scheduling UI: time field not found");
    if (input.value === want) return;
    click(input);
    input.select();
    setNativeValue(input, want);
    const option = await waitForCondition(
      () => visibleAll(FACEBOOK_SELECTORS.timeOption).find((o) => (o.textContent ?? "").trim() === want) ?? null,
      { timeoutMs: STEP_WAIT_MS, signal, what: "time option", onTimeout: () => unavailable(`Time ${want} not offered`) }
    );
    click(option);
    await waitForCondition(() => labelledCombobox(FACEBOOK_TEXT.timeLabel)?.value === want ? true : null, {
      timeoutMs: STEP_WAIT_MS,
      signal,
      what: "time set",
      onTimeout: () => unavailable("Time did not stick", { got: labelledCombobox(FACEBOOK_TEXT.timeLabel)?.value })
    });
  }
  var whenValidator = object({
    year: number({ int: true, min: 2020, max: 2100 }),
    month: number({ int: true, min: 1, max: 12 }),
    day: number({ int: true, min: 1, max: 31 }),
    hour: number({ int: true, min: 0, max: 23 }),
    minute: number({ int: true, min: 0, max: 59 })
  });
  async function prepareSchedule(payload, signal) {
    const w = whenValidator(payload["when"], "when");
    if (!visibleFirst(FACEBOOK_SELECTORS.scheduleOption)) {
      const next = visibleAll(FACEBOOK_SELECTORS.nextButton).find(isEnabled);
      if (!next) throw unavailable("Composer has no Next button (this composer has no scheduling screen)");
      click(next);
      await waitVisible("scheduling option", FACEBOOK_SELECTORS.scheduleOption, signal);
    }
    const row = visibleFirst(FACEBOOK_SELECTORS.scheduleOption);
    if (!row) throw unavailable("Scheduling UI: option row not found");
    click(row);
    await waitForCondition(() => labelledCombobox(FACEBOOK_TEXT.dateLabel) && labelledCombobox(FACEBOOK_TEXT.timeLabel) ? true : null, {
      timeoutMs: STEP_WAIT_MS,
      signal,
      what: "date/time fields",
      onTimeout: () => unavailable("Scheduling UI: date/time fields not found")
    });
    await chooseDate(w, signal);
    await chooseTime(w, signal);
    if (!dateValueMatches(labelledCombobox(FACEBOOK_TEXT.dateLabel)?.value ?? "", w) || labelledCombobox(FACEBOOK_TEXT.timeLabel)?.value !== timeText(w)) {
      throw unavailable("Date/time changed after choosing");
    }
    const confirm = await waitVisible("schedule confirm button", FACEBOOK_SELECTORS.scheduleConfirm, signal, true);
    click(confirm);
    const summary = await waitForCondition(
      () => {
        const text = scheduleRowText();
        if (!text || FACEBOOK_TEXT.publishNow.test(text)) return null;
        return text.includes(timeText(w)) ? text : null;
      },
      {
        timeoutMs: STEP_WAIT_MS,
        signal,
        what: "scheduled time shown",
        onTimeout: () => unavailable("Facebook does not show the chosen time", { row: scheduleRowText() })
      }
    );
    if (!visibleAll(FACEBOOK_SELECTORS.scheduleFinal).some(isEnabled)) {
      throw unavailable("No Schedule button after choosing the time", {
        buttons: visibleAll(FACEBOOK_SELECTORS.postButton).map((b) => b.getAttribute("aria-label") ?? b.textContent)
      });
    }
    return { summary: summary.slice(0, 200) };
  }
  function commitSchedule(payload) {
    const w = whenValidator(payload["when"], "when");
    const row = scheduleRowText();
    if (!row || FACEBOOK_TEXT.publishNow.test(row) || !row.includes(timeText(w))) {
      throw unavailable("Scheduled time is no longer shown \u2014 not clicking", { row });
    }
    const button = visibleAll(FACEBOOK_SELECTORS.scheduleFinal).find(isEnabled);
    if (!button) throw unavailable("Schedule button not found");
    click(button);
    return { clicked: true };
  }
  function waitScheduled(payload, signal) {
    const { timeoutMs } = object({ timeoutMs: number({ int: true, min: 1e3, max: 3e5 }) })(payload);
    const composerOpen = () => [...document.querySelectorAll("[role='dialog']")].find(
      (d) => onScreen(d) && (visibleAll(FACEBOOK_SELECTORS.scheduleFinal).some((b) => d.contains(b)) || visibleAll(FACEBOOK_SELECTORS.scheduleOption).some((r) => d.contains(r)))
    ) ?? null;
    return waitForCondition(
      () => {
        const d = composerOpen();
        if (!d) return { confirmed: true };
        const text = (d.innerText ?? "").slice(0, 3e3);
        if (FACEBOOK_TEXT.postError.test(text)) {
          throw new AppError(ErrorCode.UPLOAD_FAILED, `Facebook schedule error: ${text.slice(0, 200)}`, {
            userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08"
          });
        }
        return null;
      },
      { timeoutMs, signal, what: "Facebook schedule confirmation", onTimeout: () => new AppError(ErrorCode.TIMEOUT, "Composer did not close after Schedule") }
    );
  }
  async function discardComposer(signal) {
    for (let i = 0; i < 4; i++) {
      const close = visibleAll(FACEBOOK_SELECTORS.closeComposer).find((e) => e.closest("[role='dialog']"));
      if (close) {
        click(close);
        await delay(400);
        const discard = visibleFirst(FACEBOOK_SELECTORS.discardButton);
        if (discard) click(discard);
        await delay(400);
        return { discarded: !visibleAll(FACEBOOK_SELECTORS.closeComposer).some((e) => e.closest("[role='dialog']")) };
      }
      const back = visibleFirst(FACEBOOK_SELECTORS.backButton);
      if (!back) break;
      click(back);
      await delay(400);
      if (signal.aborted) break;
    }
    return { discarded: false };
  }

  // src/bridges/facebook-bridge.ts
  var ELEMENT_WAIT_MS = 15e3;
  var closedAt = null;
  var attachedAt = 0;
  function detectState() {
    if (captchaVisible() || /\/checkpoint\//.test(location.pathname)) return "captcha";
    if (resolveFirst(FACEBOOK_SELECTORS.loginForm)) return "login";
    if (groupPageReady()) return "ready";
    if (resolveFirst(FACEBOOK_SELECTORS.composerTrigger) || resolveFirst(FACEBOOK_SELECTORS.switchProfile) || resolveFirst(FACEBOOK_SELECTORS.composerDialog)) return "ready";
    return "loading";
  }
  function dialog() {
    return resolveAll(FACEBOOK_SELECTORS.composerDialog).find((d) => !isPromoDialog(d)) ?? null;
  }
  function requireDialog() {
    const d = dialog();
    if (!d) throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Composer dialog not open", { detail: { selector: "composerDialog" } });
    return d;
  }
  function dialogText(d) {
    return (d.innerText ?? "").slice(0, 5e3);
  }
  async function openComposer(signal, triggers = FACEBOOK_SELECTORS.composerTrigger, fresh = false) {
    if (dialog() && resolveFirst(FACEBOOK_SELECTORS.dialogTextbox, { root: requireDialog() })) {
      if (fresh) throw new AppError(ErrorCode.INVALID_STATE, "An existing feed composer is open", { userMessage: "\u0E21\u0E35\u0E01\u0E25\u0E48\u0E2D\u0E07\u0E40\u0E02\u0E35\u0E22\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E40\u0E14\u0E34\u0E21\u0E04\u0E49\u0E32\u0E07\u0E2D\u0E22\u0E39\u0E48 \u2014 \u0E40\u0E01\u0E47\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E44\u0E27\u0E49\u0E41\u0E25\u0E30\u0E43\u0E0A\u0E49\u0E41\u0E17\u0E47\u0E1A\u0E43\u0E2B\u0E21\u0E48", detail: { beforePost: true, draftBlocked: true } });
      return { opened: true };
    }
    if (!resolveFirst(triggers)) {
      try {
        await waitFor("composerTrigger", triggers, { timeoutMs: ELEMENT_WAIT_MS, signal });
      } catch (err) {
        if (resolveFirst(FACEBOOK_SELECTORS.switchProfile)) {
          throw new AppError(ErrorCode.LOGIN_REQUIRED, "Page profile not active", {
            userMessage: "\u0E15\u0E49\u0E2D\u0E07\u0E2A\u0E25\u0E31\u0E1A\u0E44\u0E1B\u0E43\u0E0A\u0E49\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E40\u0E1E\u0E08\u0E01\u0E48\u0E2D\u0E19 \u2014 \u0E01\u0E14 Switch/\u0E2A\u0E25\u0E31\u0E1A \u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A Facebook \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume"
          });
        }
        throw err;
      }
    }
    const t = resolveFirst(triggers);
    if (!t) throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Composer trigger vanished", { detail: { selector: "composerTrigger" } });
    click(t.el);
    await waitForCondition(
      () => {
        const d = dialog();
        return d && resolveFirst(FACEBOOK_SELECTORS.dialogTextbox, { root: d }) ? true : null;
      },
      {
        timeoutMs: ELEMENT_WAIT_MS,
        signal,
        what: "composer dialog",
        onTimeout: () => new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Composer dialog did not open", { detail: { selector: "composerDialog" } })
      }
    );
    if (fresh) {
      const d = requireDialog();
      const box = resolveFirst(FACEBOOK_SELECTORS.dialogTextbox, { root: d }).el;
      if (box.textContent?.trim() || d.querySelector("img[src^='blob:'],video")) {
        throw new AppError(ErrorCode.INVALID_STATE, "Facebook restored a feed draft", { userMessage: "Facebook \u0E40\u0E1B\u0E34\u0E14\u0E23\u0E48\u0E32\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E40\u0E14\u0E34\u0E21 \u2014 \u0E40\u0E01\u0E47\u0E1A\u0E23\u0E48\u0E32\u0E07\u0E44\u0E27\u0E49\u0E42\u0E14\u0E22\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E41\u0E01\u0E49\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21", detail: { beforePost: true, draftBlocked: true } });
      }
    }
    return { opened: true };
  }
  async function attachMedia(payload, signal) {
    const { transferIds } = object({ transferIds: array(id, { min: 1, max: 10 }) })(payload);
    const files = await Promise.all(transferIds.map((id2) => takeReceived(id2)));
    const d = requireDialog();
    const alreadyAttached = queryCandidate({ css: "img[src^='blob:'],video" }, d).length;
    if (alreadyAttached >= files.length) return { attached: 0 };
    let input = resolveFirst(FACEBOOK_SELECTORS.fileInput, { root: d, visible: false });
    if (!input) {
      const button = resolveFirst(FACEBOOK_SELECTORS.photoVideoButton, { root: d });
      if (button) click(button.el);
      input = await waitFor("fileInput", FACEBOOK_SELECTORS.fileInput, { timeoutMs: ELEMENT_WAIT_MS, signal, visible: false, root: d }).catch(
        () => waitFor("fileInput", FACEBOOK_SELECTORS.fileInput, { timeoutMs: ELEMENT_WAIT_MS, signal, visible: false })
      );
    }
    setInputFiles(input.el, files);
    attachedAt = Date.now();
    return { attached: files.length };
  }
  function waitUpload(payload, signal) {
    const { count, sliceMs, fallbackMs } = object({
      count: number({ int: true, min: 1, max: 10 }),
      sliceMs: sliceMsValidator,
      fallbackMs: optional(number({ int: true, min: 0, max: 6e5 }))
    })(payload);
    let previews = 0;
    return slice(
      sliceMs,
      signal,
      (timeoutMs, sig) => waitForCondition(
        () => {
          const d = requireDialog();
          if (FACEBOOK_TEXT.postError.test(dialogText(d))) {
            throw new AppError(ErrorCode.UPLOAD_FAILED, `Facebook upload error: ${dialogText(d).slice(0, 200)}`, {
              userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08"
            });
          }
          previews = resolveAll(FACEBOOK_SELECTORS.mediaPreview, { root: d }).length;
          const busy = resolveFirst(FACEBOOK_SELECTORS.uploadProgress, { root: d }) !== null;
          const videosReady = resolveAll([{ css: "video" }], { root: d }).every((el) => el instanceof HTMLVideoElement && el.readyState >= 1);
          if (previews >= count && !busy && videosReady) return { previews };
          if (fallbackMs && attachedAt && Date.now() - attachedAt >= fallbackMs && (previews >= count || !busy)) return { previews, byTime: true };
          return null;
        },
        { timeoutMs, signal: sig, what: "Facebook upload" }
      ),
      () => `Uploading to Facebook (${previews}/${count} ready)`
    );
  }
  async function setCaption(payload) {
    const { text } = object({ text: string({ min: 1, max: 63e3 }) })(payload);
    const d = requireDialog();
    const box = resolveFirst(FACEBOOK_SELECTORS.dialogTextbox, { root: d });
    if (!box) throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Caption box not found", { detail: { selector: "dialogTextbox" } });
    await replaceText(box.el, text);
    return { set: true };
  }
  async function submitPost(signal) {
    let clicked = false;
    try {
      closedAt = null;
      const d = requireDialog();
      const next = resolveFirst(FACEBOOK_SELECTORS.nextButton, { root: d, enabled: true });
      if (next) {
        click(next.el);
        await waitFor("postButton", FACEBOOK_SELECTORS.postButton, { timeoutMs: ELEMENT_WAIT_MS, signal, enabled: true });
      }
      const post = await waitFor("postButton", FACEBOOK_SELECTORS.postButton, { timeoutMs: ELEMENT_WAIT_MS, signal, enabled: true, root: dialog() ?? document });
      clicked = true;
      click(post.el);
      return { clicked: true };
    } catch (err) {
      if (!clicked) throw beforePostError(err);
      throw err;
    }
  }
  function findPost(probe) {
    const needle = comparable(probe);
    if (!needle) return null;
    for (const article of queryCandidate(FACEBOOK_SELECTORS.article[0] ?? { css: "[role='article']" })) {
      const text = comparable(article.innerText ?? "");
      if (!text.includes(needle)) continue;
      const link = resolveFirst(FACEBOOK_SELECTORS.postLink, { root: article, visible: false })?.el;
      const out = { confirmed: true };
      if (link?.href) out.postUrl = link.href.split("?")[0] ?? link.href;
      return out;
    }
    return null;
  }
  function waitPosted(payload, signal) {
    const { captionProbe, confirmWindowMs, sliceMs, acceptSubmission } = object({
      captionProbe: string({ max: 200 }),
      confirmWindowMs: number({ int: true, min: 1e3, max: 6e5 }),
      sliceMs: sliceMsValidator,
      acceptSubmission: optional(boolean)
    })(payload);
    return slice(
      sliceMs,
      signal,
      (timeoutMs, sig) => waitForCondition(
        () => {
          const d = dialog();
          if (d && resolveFirst(FACEBOOK_SELECTORS.dialogTextbox, { root: d })) {
            if (FACEBOOK_TEXT.postError.test(dialogText(d))) {
              throw new AppError(ErrorCode.UPLOAD_FAILED, `Facebook post error: ${dialogText(d).slice(0, 200)}`, {
                userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08"
              });
            }
            closedAt = null;
            return null;
          }
          closedAt ??= Date.now();
          const found = findPost(captionProbe);
          if (found) return found;
          if (acceptSubmission && Date.now() - closedAt >= 1e3) return { confirmed: true };
          return Date.now() - closedAt > confirmWindowMs ? { confirmed: false } : null;
        },
        { timeoutMs, signal: sig, what: "Facebook post confirmation" }
      ),
      () => closedAt ? "Composer closed \u2014 looking for the new post" : "Waiting for Facebook to publish"
    );
  }
  function guarded(handler) {
    return async (payload, ctx) => {
      dismissPromos();
      const timer = setInterval(() => dismissPromos(), 300);
      try {
        return await handler(payload, ctx);
      } finally {
        clearInterval(timer);
      }
    };
  }
  startBridge(FACEBOOK_PROVIDER_ID, FACEBOOK_BRIDGE_VERSION, {
    ...groupHandlers({ open: openComposer, attach: attachMedia, caption: setCaption }),
    ...standardHandlers({
      providerId: FACEBOOK_PROVIDER_ID,
      prefix: FACEBOOK_PREFIX,
      version: FACEBOOK_BRIDGE_VERSION,
      detectState,
      selectors: FACEBOOK_SELECTORS
    }),
    [FACEBOOK_CMD.openComposer]: guarded((payload, ctx) => {
      const { fresh } = object({ fresh: optional(boolean) })(payload);
      return openComposer(ctx.signal, FACEBOOK_SELECTORS.composerTrigger, fresh);
    }),
    [FACEBOOK_CMD.attachMedia]: guarded((payload, ctx) => attachMedia(payload, ctx.signal)),
    [FACEBOOK_CMD.waitUpload]: guarded((payload, ctx) => waitUpload(payload, ctx.signal)),
    [FACEBOOK_CMD.setCaption]: guarded((payload) => setCaption(payload)),
    [FACEBOOK_CMD.submitPost]: guarded((_payload, ctx) => submitPost(ctx.signal)),
    [FACEBOOK_CMD.waitPosted]: guarded((payload, ctx) => waitPosted(payload, ctx.signal)),
    [FACEBOOK_CMD.prepareSchedule]: guarded((payload, ctx) => prepareSchedule(payload, ctx.signal)),
    [FACEBOOK_CMD.commitSchedule]: guarded((payload) => commitSchedule(payload)),
    [FACEBOOK_CMD.waitScheduled]: guarded((payload, ctx) => waitScheduled(payload, ctx.signal)),
    [FACEBOOK_CMD.discard]: guarded((_payload, ctx) => discardComposer(ctx.signal))
  });
})();
