// src/platform/license-config.ts
var LICENSE_API_BASE = "https://drfx-license.drfx-bot.workers.dev";
var LICENSE_PUBLIC_KEYS = {
  "k1": {
    "kty": "EC",
    "x": "7sYFfx0juV9sTwmLM34Je0V9hjP6Gmop3FfY8KTEkCg",
    "y": "9EFa0kQZTWBZLVfmu3FJ0hqCXD13DQNJZo_kYhiobTs",
    "crv": "P-256"
  }
};

// src/platform/entitlements.ts
function hasAll(e, keys) {
  return keys.every((k) => e.granted.includes(k));
}

// src/platform/tools.ts
var TOOLS = [
  {
    id: "PRODUCT_UPDATE_BOT",
    name: "PRODUCT UPDATE BOT",
    description: "\u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E40\u0E02\u0E49\u0E32\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 \u0E41\u0E25\u0E30\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E1A\u0E19\u0E40\u0E1E\u0E08/\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E19\u0E04\u0E25\u0E34\u0E01\u0E40\u0E14\u0E35\u0E22\u0E27",
    icon: "box",
    capabilities: ["Products", "Group Chat", "Page Post", "Date Card", "History"],
    status: "AVAILABLE",
    route: "product-update",
    enabled: true,
    order: 10,
    requiredEntitlements: ["tool.product_update_bot"],
    sections: ["\u0E2A\u0E48\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49", "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32", "\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17", "\u0E2A\u0E16\u0E32\u0E19\u0E30", "\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34"]
  }
];
function toolCards(entitlements, tools = TOOLS) {
  return [...tools].filter((t) => t.status !== "DISABLED").sort((a, b) => a.order - b.order).map((t) => {
    if (t.status === "COMING_SOON" || !t.enabled) return { ...t, usable: false, reason: "\u0E40\u0E23\u0E47\u0E27 \u0E46 \u0E19\u0E35\u0E49" };
    if (!hasAll(entitlements, t.requiredEntitlements)) return { ...t, usable: false, reason: entitlements.denyReason ?? (entitlements.granted.length ? "License \u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E23\u0E27\u0E21\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E21\u0E37\u0E2D\u0E19\u0E35\u0E49" : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19") };
    return { ...t, usable: true };
  });
}
var JOB_TYPE_TOOL = { product_send: "product-update", date_card: "product-update", date_style: "product-update", content_plan: "product-update", content_image: "product-update" };
var SOURCE_TOOL = [
  [/^product-update\b/, "product-update"],
  [/^(campaign|library|scheduler)\b/, "content-factory"]
];
function toolOfJobType(type) {
  return JOB_TYPE_TOOL[type] ?? "content-factory";
}
function toolOfLog(entry) {
  if (entry.jobType) return toolOfJobType(entry.jobType);
  if (entry.jobId && /^engine\/(pace|send_message)\b/.test(entry.source)) return "product-update";
  for (const [re, tool] of SOURCE_TOOL) if (re.test(entry.source)) return tool;
  return entry.jobId ? "content-factory" : "system";
}
function logBelongsTo(entry, tool) {
  const owner = toolOfLog(entry);
  return owner === tool || tool === "content-factory" && owner === "system";
}

// src/shared/errors.ts
var ErrorCode = {
  LOGIN_REQUIRED: "LOGIN_REQUIRED",
  CAPTCHA_REQUIRED: "CAPTCHA_REQUIRED",
  PERMISSION_MISSING: "PERMISSION_MISSING",
  SELECTOR_NOT_FOUND: "SELECTOR_NOT_FOUND",
  INPUT_REJECTED: "INPUT_REJECTED",
  PAGE_NOT_READY: "PAGE_NOT_READY",
  WEBSITE_UNAVAILABLE: "WEBSITE_UNAVAILABLE",
  RATE_LIMITED: "RATE_LIMITED",
  QUOTA_EXCEEDED: "QUOTA_EXCEEDED",
  GENERATION_FAILED: "GENERATION_FAILED",
  CONTENT_POLICY_BLOCKED: "CONTENT_POLICY_BLOCKED",
  RESPONSE_PARSE_FAILED: "RESPONSE_PARSE_FAILED",
  TIMEOUT: "TIMEOUT",
  PROGRESS_STALLED: "PROGRESS_STALLED",
  DOWNLOAD_FAILED: "DOWNLOAD_FAILED",
  DOWNLOAD_INTERRUPTED: "DOWNLOAD_INTERRUPTED",
  UPLOAD_FAILED: "UPLOAD_FAILED",
  PUBLISH_UNCONFIRMED: "PUBLISH_UNCONFIRMED",
  SEND_UNCONFIRMED: "SEND_UNCONFIRMED",
  DESTINATION_MISMATCH: "DESTINATION_MISMATCH",
  SEND_FAILED: "SEND_FAILED",
  ACCOUNT_RESTRICTED: "ACCOUNT_RESTRICTED",
  NATIVE_SCHEDULE_UNAVAILABLE: "NATIVE_SCHEDULE_UNAVAILABLE",
  BRIDGE_UNREACHABLE: "BRIDGE_UNREACHABLE",
  TAB_CLOSED: "TAB_CLOSED",
  INTERRUPTED: "INTERRUPTED",
  INVALID_INPUT: "INVALID_INPUT",
  INVALID_STATE: "INVALID_STATE",
  NOT_FOUND: "NOT_FOUND",
  PROVIDER_NOT_CONFIGURED: "PROVIDER_NOT_CONFIGURED",
  LICENSE_REQUIRED: "LICENSE_REQUIRED",
  CANCELLED: "CANCELLED",
  INTERNAL: "INTERNAL"
};
var META = {
  LOGIN_REQUIRED: { retryable: false, pause: "LOGIN_REQUIRED", userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 \u2014 \u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
  CAPTCHA_REQUIRED: { retryable: false, pause: "CAPTCHA", userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E02\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E15\u0E31\u0E27\u0E15\u0E19 (CAPTCHA) \u2014 \u0E17\u0E33\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
  PERMISSION_MISSING: { retryable: false, userMessage: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E40\u0E02\u0E49\u0E32\u0E16\u0E36\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E19\u0E35\u0E49 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
  SELECTOR_NOT_FOUND: { retryable: true, userMessage: "\u0E2B\u0E32\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E40\u0E08\u0E2D \u2014 \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u0E25\u0E2D\u0E07\u0E01\u0E14 Diagnose \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
  INPUT_REJECTED: { retryable: true, userMessage: "\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E23\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34" },
  PAGE_NOT_READY: { retryable: true, userMessage: "\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E22\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21" },
  WEBSITE_UNAVAILABLE: { retryable: true, userMessage: "\u0E40\u0E1B\u0E34\u0E14\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E47\u0E1A\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32" },
  RATE_LIMITED: { retryable: false, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E16\u0E35\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B \u2014 \u0E23\u0E2D\u0E2A\u0E31\u0E01\u0E1E\u0E31\u0E01\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry" },
  QUOTA_EXCEEDED: { retryable: false, userMessage: "\u0E43\u0E0A\u0E49\u0E42\u0E04\u0E27\u0E15\u0E49\u0E32\u0E02\u0E2D\u0E07\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07" },
  GENERATION_FAILED: { retryable: true, userMessage: "\u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  CONTENT_POLICY_BLOCKED: { retryable: false, userMessage: "\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E1B\u0E0F\u0E34\u0E40\u0E2A\u0E18 prompt \u0E19\u0E35\u0E49 (\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E40\u0E19\u0E37\u0E49\u0E2D\u0E2B\u0E32) \u2014 \u0E41\u0E01\u0E49 prompt \u0E41\u0E25\u0E49\u0E27 Retry" },
  RESPONSE_PARSE_FAILED: { retryable: true, userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E08\u0E32\u0E01 AI \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07)" },
  TIMEOUT: { retryable: true, userMessage: "\u0E23\u0E2D\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14" },
  PROGRESS_STALLED: { retryable: true, userMessage: "\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E27\u0E32\u0E21\u0E04\u0E37\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B" },
  DOWNLOAD_FAILED: { retryable: true, userMessage: "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  DOWNLOAD_INTERRUPTED: { retryable: true, userMessage: "\u0E01\u0E32\u0E23\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30" },
  UPLOAD_FAILED: { retryable: true, userMessage: "\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  PUBLISH_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E02\u0E36\u0E49\u0E19\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E0B\u0E49\u0E33" },
  SEND_UNCONFIRMED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E01\u0E14\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E08\u0E23\u0E34\u0E07 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E0A\u0E17\u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33" },
  DESTINATION_MISMATCH: { retryable: false, userMessage: "\u0E41\u0E0A\u0E17\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E44\u0E27\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07" },
  SEND_FAILED: { retryable: false, userMessage: "Facebook \u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" },
  ACCOUNT_RESTRICTED: { retryable: false, pause: "INTERRUPTED", userMessage: "Facebook \u0E08\u0E33\u0E01\u0E31\u0E14\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E2A\u0E48\u0E07\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\u0E41\u0E25\u0E49\u0E27 \u0E15\u0E23\u0E27\u0E08\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A Facebook \u0E41\u0E25\u0E30\u0E23\u0E2D\u0E08\u0E19\u0E02\u0E49\u0E2D\u0E08\u0E33\u0E01\u0E31\u0E14\u0E2B\u0E21\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E15\u0E48\u0E2D" },
  NATIVE_SCHEDULE_UNAVAILABLE: { retryable: false, userMessage: "\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A\u0E02\u0E2D\u0E07 Facebook \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E43\u0E0A\u0E49\u0E15\u0E31\u0E27\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E43\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E41\u0E17\u0E19" },
  BRIDGE_UNREACHABLE: { retryable: true, userMessage: "\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D\u0E2A\u0E04\u0E23\u0E34\u0E1B\u0E15\u0E4C\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
  TAB_CLOSED: { retryable: true, userMessage: "\u0E41\u0E17\u0E47\u0E1A\u0E02\u0E2D\u0E07\u0E40\u0E27\u0E47\u0E1A\u0E16\u0E39\u0E01\u0E1B\u0E34\u0E14\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E17\u0E33\u0E07\u0E32\u0E19" },
  INTERRUPTED: { retryable: false, pause: "INTERRUPTED", userMessage: "\u0E07\u0E32\u0E19\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30 (browser/\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E23\u0E35\u0E2A\u0E15\u0E32\u0E23\u0E4C\u0E17) \u2014 \u0E15\u0E23\u0E27\u0E08\u0E1C\u0E25\u0E1A\u0E19\u0E40\u0E27\u0E47\u0E1A \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry \u0E2B\u0E23\u0E37\u0E2D Cancel" },
  INVALID_INPUT: { retryable: false, userMessage: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E2A\u0E48\u0E07\u0E21\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" },
  INVALID_STATE: { retryable: false, userMessage: "\u0E17\u0E33\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E19\u0E35\u0E49\u0E43\u0E19\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49" },
  NOT_FOUND: { retryable: false, userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E23\u0E30\u0E1A\u0E38" },
  PROVIDER_NOT_CONFIGURED: { retryable: false, userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49 \u2014 \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options" },
  LICENSE_REQUIRED: { retryable: false, pause: "LICENSE_REQUIRED", userMessage: "License \u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u2014 \u0E07\u0E32\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E23\u0E34\u0E48\u0E21 \u0E15\u0E23\u0E27\u0E08 License \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume" },
  CANCELLED: { retryable: false, userMessage: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27" },
  INTERNAL: { retryable: false, userMessage: "\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14\u0E20\u0E32\u0E22\u0E43\u0E19 \u2014 \u0E14\u0E39\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E43\u0E19 Log" }
};
var AppError = class extends Error {
  code;
  retryable;
  userMessage;
  detail;
  constructor(code, message, opts = {}) {
    super(message, opts.cause === void 0 ? void 0 : { cause: opts.cause });
    this.name = "AppError";
    this.code = code;
    this.retryable = opts.retryable ?? META[code].retryable;
    this.userMessage = opts.userMessage ?? META[code].userMessage;
    this.detail = opts.detail;
  }
  get pauseReason() {
    return META[this.code].pause;
  }
  toJSON() {
    const json = {
      code: this.code,
      message: this.message,
      userMessage: this.userMessage,
      retryable: this.retryable
    };
    if (this.detail !== void 0) json.detail = this.detail;
    return json;
  }
};
function isErrorCode(value) {
  return typeof value === "string" && value in META;
}
function toAppError(err, fallback = ErrorCode.INTERNAL) {
  if (err instanceof AppError) return err;
  if (isAppErrorJSON(err)) return fromJSON(err);
  if (err instanceof DOMException && err.name === "AbortError") {
    return new AppError(ErrorCode.CANCELLED, "Operation aborted", { cause: err });
  }
  const message = err instanceof Error ? err.message : String(err);
  return new AppError(fallback, message, { cause: err });
}
function isAppErrorJSON(value) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  return isErrorCode(v["code"]) && typeof v["message"] === "string";
}
function fromJSON(json) {
  const code = isErrorCode(json.code) ? json.code : ErrorCode.INTERNAL;
  return new AppError(code, json.message, {
    userMessage: json.userMessage,
    retryable: json.retryable,
    detail: json.detail
  });
}

// src/shared/async.ts
function abortError(signal) {
  const reason = signal?.reason;
  if (reason instanceof AppError) return reason;
  return new AppError(ErrorCode.CANCELLED, "Operation cancelled");
}
function delay(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortError(signal));
      return;
    }
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortError(signal));
    };
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}
function withTimeout(promise, ms, what, code = ErrorCode.TIMEOUT) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new AppError(code, `${what} timed out after ${ms} ms`, { detail: { ms } })), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}
var Mutex = class {
  tail = Promise.resolve();
  run(fn) {
    const result = this.tail.then(fn, fn);
    this.tail = result.then(
      () => void 0,
      () => void 0
    );
    return result;
  }
};
var KeyedMutex = class {
  locks = /* @__PURE__ */ new Map();
  run(key, fn) {
    let m = this.locks.get(key);
    if (!m) {
      m = new Mutex();
      this.locks.set(key, m);
    }
    return m.run(fn);
  }
};

// src/shared/post-attempt.ts
function beforePostError(err, extra = {}) {
  const e = toAppError(err);
  const detail = typeof e.detail === "object" && e.detail !== null ? e.detail : {};
  return new AppError(e.code, e.message, { cause: err, userMessage: e.userMessage, retryable: e.retryable, detail: { ...detail, ...extra, beforePost: true } });
}
function isBeforePost(err) {
  return err.detail?.beforePost === true;
}

// src/shared/ids.ts
function newId(prefix = "") {
  const time = Date.now().toString(36).padStart(10, "0");
  const bytes = new Uint8Array(6);
  crypto.getRandomValues(bytes);
  const rand = Array.from(bytes, (b) => b.toString(36).padStart(2, "0")).join("").slice(0, 8);
  return `${prefix}${time}${rand}`;
}

// src/providers/common/web-adapter.ts
var WAIT_SLICE_MS = 2e4;
var WebAdapter = class {
  constructor(deps) {
    this.deps = deps;
  }
  /** Runs `fn` with exclusive use of a ready provider tab. */
  withSession(ctx, url, fn) {
    const opts = { timeouts: ctx.timeouts, signal: ctx.signal, ...url ? { url } : {} };
    return this.deps.tabs.withLock(
      this.spec,
      async (session) => {
        await session.activate();
        await this.ensureReady(session, ctx);
        return fn(session);
      },
      opts
    );
  }
  /** One recovery before Post is allowed; an uncertain click is never repeated. */
  async withPostSession(ctx, url, fn) {
    for (let attempt2 = 0; ; attempt2++) {
      let entered = false;
      try {
        return await this.withSession(ctx, url, async (session) => {
          entered = true;
          try {
            return await fn(session);
          } catch (err) {
            await session.hold(ctx.jobId).catch((holdError) => ctx.log.warn("Cannot isolate failed post tab", { message: String(holdError) }));
            throw err;
          }
        });
      } catch (err) {
        const e = entered ? toAppError(err) : beforePostError(err);
        const draftBlocked = e.detail?.draftBlocked;
        const retry = attempt2 === 0 && isBeforePost(e) && (e.retryable || draftBlocked) && !ctx.signal.aborted && e.code !== ErrorCode.CANCELLED;
        if (retry) {
          ctx.log.warn("Recovering before Post in a new background tab", { code: e.code, message: e.message });
          ctx.progress("\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E40\u0E1A\u0E37\u0E49\u0E2D\u0E07\u0E2B\u0E25\u0E31\u0E07 \u2014 \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E01\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C");
          await delay(1e3, ctx.signal);
          continue;
        }
        throw new AppError(e.code, e.message, { cause: err, userMessage: e.userMessage, retryable: false, detail: e.detail });
      }
    }
  }
  /** Shown when the page never becomes usable (e.g. composer missing). */
  readyHint() {
    return `\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A ${this.siteName} \u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 (\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C) \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E41\u0E17\u0E47\u0E1A\u0E14\u0E39\u0E27\u0E48\u0E32\u0E21\u0E35\u0E2D\u0E30\u0E44\u0E23\u0E1A\u0E31\u0E07\u0E2D\u0E22\u0E39\u0E48\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48`;
  }
  async ensureReady(session, ctx) {
    let state;
    let lastReport = "";
    try {
      state = await session.sendUntilDone(
        `${this.spec.commandPrefix}.waitReady`,
        {},
        {
          totalTimeoutMs: ctx.timeouts.tabLoadMs,
          sliceMs: WAIT_SLICE_MS,
          signal: ctx.signal,
          clock: this.deps.clock,
          onProgress: (m) => {
            lastReport = m;
          }
        }
      );
    } catch (err) {
      const e = toAppError(err);
      if (e.code !== ErrorCode.TIMEOUT) throw e;
      throw new AppError(ErrorCode.PAGE_NOT_READY, `${this.siteName}: ${lastReport || "page not ready"}`, {
        userMessage: this.readyHint(),
        cause: err,
        detail: { report: lastReport }
      });
    }
    if (state === "login") {
      throw new AppError(ErrorCode.LOGIN_REQUIRED, `${this.siteName}: not logged in`, {
        userMessage: `\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 ${this.siteName} \u2014 \u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume`
      });
    }
    if (state === "captcha") {
      throw new AppError(ErrorCode.CAPTCHA_REQUIRED, `${this.siteName}: verification required`, {
        userMessage: `${this.siteName} \u0E02\u0E2D\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E15\u0E31\u0E27\u0E15\u0E19 \u2014 \u0E17\u0E33\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E2B\u0E49 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Resume`
      });
    }
  }
  async checkReady(ctx) {
    try {
      await this.withSession(ctx, void 0, () => Promise.resolve());
      return { ok: true };
    } catch (err) {
      const e = toAppError(err);
      const needs = {
        [ErrorCode.LOGIN_REQUIRED]: "LOGIN",
        [ErrorCode.CAPTCHA_REQUIRED]: "CAPTCHA",
        [ErrorCode.PERMISSION_MISSING]: "PERMISSION"
      };
      return { ok: false, needs: needs[e.code] ?? "UNAVAILABLE", message: e.userMessage };
    }
  }
  async diagnose(ctx) {
    const opts = { timeouts: ctx.timeouts, signal: ctx.signal };
    return this.deps.tabs.withLock(
      this.spec,
      async (session) => {
        await session.activate();
        return session.send(`${this.spec.commandPrefix}.diagnose`, {}, {
          timeoutMs: ctx.timeouts.bridgeCommandMs,
          signal: ctx.signal
        });
      },
      opts
    );
  }
  /**
   * Brings a media file shown on the page into the asset store.
   * Order: fetch inside the page (has the site's cookies) → fetch from the SW (host permission, no CORS).
   */
  async ingestMedia(session, src, meta, ctx) {
    let pageError = null;
    try {
      const incoming = this.deps.transfers.expectFromPage(ctx.timeouts.downloadMs);
      const sent = session.send(
        `${this.spec.commandPrefix}.fetchMedia`,
        { src, transferId: incoming.transferId, timeoutMs: ctx.timeouts.downloadMs },
        { timeoutMs: ctx.timeouts.downloadMs, signal: ctx.signal }
      );
      const [file] = await Promise.all([incoming.file, sent]);
      return await ctx.assets.ingest(file, meta);
    } catch (err) {
      pageError = toAppError(err);
      ctx.log.warn("In-page media fetch failed \u2014 trying from the extension", { code: pageError.code, message: pageError.message });
    }
    if (!/^https:/i.test(src)) throw pageError;
    try {
      const res = await fetch(src, { credentials: "include", signal: ctx.signal });
      if (!res.ok) throw new AppError(ErrorCode.DOWNLOAD_FAILED, `HTTP ${res.status} fetching media`);
      return await ctx.assets.ingest(await res.blob(), meta);
    } catch (err) {
      const e = toAppError(err, ErrorCode.DOWNLOAD_FAILED);
      throw new AppError(ErrorCode.DOWNLOAD_FAILED, `Could not fetch media: page=${pageError.message}; extension=${e.message}`, {
        userMessage: `\u0E14\u0E36\u0E07\u0E44\u0E1F\u0E25\u0E4C\u0E08\u0E32\u0E01 ${this.siteName} \u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08`,
        cause: err
      });
    }
  }
  /**
   * Copies assets from the extension's store into the page; returns the transfer ids the bridge
   * can consume (takeReceived) when attaching them to an uploader.
   */
  async pushAssets(session, assetIds, ctx) {
    const ids = [];
    for (const assetId of assetIds) {
      const [asset, blob] = await Promise.all([ctx.assets.get(assetId), ctx.assets.getBlob(assetId)]);
      const transferId = newId("tout_");
      await session.send(
        `${this.spec.commandPrefix}.prepareReceive`,
        { transferId, timeoutMs: ctx.timeouts.uploadMs },
        { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal }
      );
      const ext = asset.mime === "video/quicktime" ? "mov" : asset.mime.split("/")[1]?.split(";")[0] ?? "bin";
      await this.deps.transfers.sendToPage(session.tabId, transferId, blob, `${asset.kind}-${asset.id}.${ext}`, ctx.timeouts.uploadMs);
      ids.push(transferId);
      ctx.progress(`Prepared file ${ids.length}/${assetIds.length}`);
    }
    return ids;
  }
};

// src/providers/messenger/protocol.ts
var MESSENGER_PROVIDER_ID = "facebook-messenger-web";
var MESSENGER_PREFIX = "messenger";
var MESSENGER_HOME = "https://www.facebook.com/messages/";
var MESSENGER_BRIDGE_VERSION = "2";
var MESSENGER_CMD = {
  /** Reads the open chat's identity (thread id from the URL, title from the header). */
  inspect: `${MESSENGER_PREFIX}.inspect`,
  /** Throws DESTINATION_MISMATCH unless the open chat is the target (thread id; header = composer, ADR-70). */
  verifyTarget: `${MESSENGER_PREFIX}.verifyTarget`,
  /** Refuses to continue when the composer already holds text or files (never mix messages). */
  checkClean: `${MESSENGER_PREFIX}.checkClean`,
  attach: `${MESSENGER_PREFIX}.attach`,
  waitAttached: `${MESSENGER_PREFIX}.waitAttached`,
  setText: `${MESSENGER_PREFIX}.setText`,
  /** Presses send (irreversible). Returns the counts needed to confirm. */
  send: `${MESSENGER_PREFIX}.send`,
  waitSent: `${MESSENGER_PREFIX}.waitSent`
};
var TEXT_PROBE_CHARS = 40;

// src/providers/messenger/adapter.ts
var CONFIRM_MS = 9e4;
function textProbe(text2) {
  return text2.replace(/\s+/g, " ").trim().slice(0, TEXT_PROBE_CHARS);
}
function assertChatUrl(url) {
  if (!/^https:\/\/www\.facebook\.com\/messages\/(?:e2ee\/)?t\/[A-Za-z0-9._-]+\/?$/.test(url)) {
    throw new AppError(ErrorCode.INVALID_INPUT, `Not a chat URL: ${url}`, { userMessage: "\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E41\u0E0A\u0E17\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" });
  }
}
var MessengerWebAdapter = class extends WebAdapter {
  info = {
    id: MESSENGER_PROVIDER_ID,
    displayName: "Facebook \u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 (facebook.com/messages)",
    capabilities: ["message"],
    origins: ["https://www.facebook.com/*"],
    homeUrl: MESSENGER_HOME
  };
  siteName = "Facebook Messenger";
  spec = {
    providerId: MESSENGER_PROVIDER_ID,
    background: true,
    expectedVersion: MESSENGER_BRIDGE_VERSION,
    matches: ["https://www.facebook.com/messages/*"],
    homeUrl: MESSENGER_HOME,
    bridgeFile: "bridges/messenger-bridge.js",
    commandPrefix: MESSENGER_PREFIX
  };
  capabilities = {
    message: {
      inspectChat: (target, ctx) => this.inspectChat(target, ctx),
      sendChatMessage: (req2, ctx) => this.sendChatMessage(req2, ctx)
    }
  };
  readyHint() {
    return "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E43\u0E19\u0E41\u0E0A\u0E17 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E41\u0E17\u0E47\u0E1A Facebook \u0E14\u0E39\u0E27\u0E48\u0E32\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19 \u0E43\u0E2A\u0E48 PIN \u0E41\u0E0A\u0E17 \u0E2B\u0E23\u0E37\u0E2D\u0E21\u0E35\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07\u0E1A\u0E31\u0E07\u0E2D\u0E22\u0E39\u0E48\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48";
  }
  /**
   * Reloads the chat so every check reads the current page (a tab left open for hours can show
   * a stale title, a half-typed draft or old error banners).
   */
  async fresh(session, ctx) {
    await session.reload(ctx.timeouts, ctx.signal);
    await this.ensureReady(session, ctx);
  }
  async inspectChat(target, ctx) {
    assertChatUrl(target.url);
    return this.withSession(ctx, target.url, async (session) => {
      await this.fresh(session, ctx);
      return session.send(MESSENGER_CMD.inspect, {}, { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal });
    }).then((id2) => {
      if (!id2.title) {
        throw new AppError(ErrorCode.SELECTOR_NOT_FOUND, "Chat title not found", { userMessage: "\u0E2D\u0E48\u0E32\u0E19\u0E0A\u0E37\u0E48\u0E2D\u0E41\u0E0A\u0E17\u0E08\u0E32\u0E01\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E27\u0E47\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E22\u0E31\u0E07\u0E43\u0E0A\u0E49\u0E40\u0E1B\u0E47\u0E19\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (\u0E25\u0E2D\u0E07 Diagnose \u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Options)" });
      }
      return id2;
    });
  }
  /**
   * Images first, text second (user request 2026-09-25: the text must not arrive before the photos
   * finish uploading). Each part is its own send with its own irreversible click; the images part is
   * confirmed in the conversation (uploaded, not previews) + a per-image settle wait before the text.
   */
  async sendChatMessage(req2, ctx) {
    assertChatUrl(req2.target.url);
    const images = req2.skipImages ? [] : req2.imageAssetIds;
    const text2 = req2.text.trim() ? req2.text : "";
    if (!text2 && images.length === 0) {
      if (req2.skipImages) return { confirmedBy: "dom" };
      throw new AppError(ErrorCode.INVALID_INPUT, "Empty message", { userMessage: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E27\u0E48\u0E32\u0E07\u0E41\u0E25\u0E30\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B" });
    }
    const target = { threadId: req2.target.threadId, expectedTitle: req2.target.expectedTitle };
    return this.withSession(ctx, req2.target.url, async (session) => {
      const cmd = { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal };
      await this.fresh(session, ctx);
      let chatTitle = "";
      if (images.length) {
        chatTitle = (await session.send(MESSENGER_CMD.verifyTarget, target, cmd)).title;
        await session.send(MESSENGER_CMD.checkClean, {}, cmd);
        const transferIds = await this.pushAssets(session, images, ctx);
        await session.send(MESSENGER_CMD.attach, { transferIds }, cmd);
        await session.sendUntilDone(MESSENGER_CMD.waitAttached, { count: transferIds.length }, this.waitOpts(ctx, ctx.timeouts.uploadMs));
        await delay(1500, ctx.signal);
        const hasVideo = (await Promise.all(images.map((id2) => ctx.assets.get(id2)))).some((asset) => asset.kind === "video");
        const perPhoto = Math.max(0, req2.imageSettleMs ?? 0);
        const how = await this.clickAndConfirm(session, ctx, target, "", images.length, "images_clicked", "\u0E23\u0E39\u0E1B", hasVideo ? 0 : perPhoto * images.length, hasVideo);
        if (how) ctx.log.info(`\u0E23\u0E39\u0E1B\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27 (\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E08\u0E32\u0E01: ${how})`);
        const settle = how === "time per photo" ? 0 : perPhoto * images.length;
        if (settle > 0) {
          ctx.progress(`\u0E23\u0E39\u0E1B\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E04\u0E23\u0E1A ${images.length} \u0E23\u0E39\u0E1B \u2014 \u0E23\u0E2D\u0E2D\u0E35\u0E01 ${Math.round(settle / 1e3)} \u0E27\u0E34\u0E19\u0E32\u0E17\u0E35\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21`);
          await delay(settle, ctx.signal);
        }
        await ctx.checkpoint("images_sent", { threadId: req2.target.threadId, images: images.length });
        ctx.log.info(`\u0E2A\u0E48\u0E07\u0E23\u0E39\u0E1B ${images.length} \u0E23\u0E39\u0E1B\u0E41\u0E25\u0E49\u0E27 (\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17)${text2 ? " \u2014 \u0E15\u0E48\u0E2D\u0E14\u0E49\u0E27\u0E22\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21" : ""}`);
      }
      if (text2) {
        chatTitle = (await session.send(MESSENGER_CMD.verifyTarget, target, cmd)).title;
        await session.send(MESSENGER_CMD.checkClean, {}, cmd);
        await session.send(MESSENGER_CMD.setText, { text: text2 }, cmd);
        await this.clickAndConfirm(session, ctx, target, textProbe(text2), 0, "send_clicked", "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21");
      }
      return { confirmedBy: "dom", ...chatTitle ? { chatTitle } : {} };
    });
  }
  waitOpts(ctx, totalTimeoutMs) {
    return { totalTimeoutMs, sliceMs: WAIT_SLICE_MS, signal: ctx.signal, clock: this.deps.clock, onProgress: (m) => ctx.progress(m) };
  }
  /** The irreversible click + confirmation in the conversation. Any doubt after it = SEND_UNCONFIRMED. */
  async clickAndConfirm(session, ctx, target, probe, images, phase, what, fallbackMs = 0, strictMedia = false) {
    const cmd = { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal };
    await ctx.checkpoint(phase, { threadId: target.threadId });
    let clicked;
    try {
      clicked = await session.send(MESSENGER_CMD.send, { ...target, probe }, cmd);
    } catch (err) {
      const e = toAppError(err);
      if (e.code === ErrorCode.DESTINATION_MISMATCH || e.code === ErrorCode.ACCOUNT_RESTRICTED || e.code === ErrorCode.SELECTOR_NOT_FOUND) throw e;
      throw unconfirmed(e, what);
    }
    ctx.log.info(`\u0E01\u0E14\u0E2A\u0E48\u0E07${what}\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E23\u0E2D${what}\u0E02\u0E36\u0E49\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17`);
    try {
      const done = await session.sendUntilDone(
        MESSENGER_CMD.waitSent,
        { probe, probeBefore: clicked.probeBefore, imagesBefore: clicked.imagesBefore, images, strictMedia, ...fallbackMs > 0 ? { fallbackMs } : {} },
        this.waitOpts(ctx, images ? Math.max(CONFIRM_MS, ctx.timeouts.uploadMs, fallbackMs + 3e4) : CONFIRM_MS)
      );
      return done.how;
    } catch (err) {
      const e = toAppError(err);
      if (e.code === ErrorCode.SEND_FAILED || e.code === ErrorCode.ACCOUNT_RESTRICTED || e.code === ErrorCode.CANCELLED) throw e;
      throw unconfirmed(e, what);
    }
  }
};
function unconfirmed(cause, what) {
  return new AppError(ErrorCode.SEND_UNCONFIRMED, `Outcome unknown after sending the ${what === "\u0E23\u0E39\u0E1B" ? "images" : "text"}: ${cause.message}`, {
    cause,
    detail: { mayHaveSent: true, part: what === "\u0E23\u0E39\u0E1B" ? "images" : "text" },
    userMessage: `\u0E01\u0E14\u0E2A\u0E48\u0E07${what}\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E41\u0E0A\u0E17\u0E15\u0E23\u0E27\u0E08\u0E01\u0E48\u0E2D\u0E19 (\u0E23\u0E30\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33\u0E40\u0E2D\u0E07)`
  });
}

// src/storage/db.ts
var DB_NAME = "ai-content-factory";
var DB_VERSION = 3;
var STORE = {
  jobs: "jobs",
  content: "content",
  assets: "assets",
  assetBlobs: "assetBlobs",
  logs: "logs",
  schedules: "schedules",
  campaigns: "campaigns",
  campaignItems: "campaignItems",
  products: "products",
  msgTemplates: "msgTemplates",
  destinations: "destinations",
  batches: "batches",
  productSends: "productSends"
};
var MIGRATIONS = {
  1: (db) => {
    const jobs = db.createObjectStore(STORE.jobs, { keyPath: "jobId" });
    jobs.createIndex("updatedAt", "updatedAt");
    const content = db.createObjectStore(STORE.content, { keyPath: "id" });
    content.createIndex("status", "status");
    content.createIndex("createdAt", "createdAt");
    const assets = db.createObjectStore(STORE.assets, { keyPath: "id" });
    assets.createIndex("contentId", "contentId");
    db.createObjectStore(STORE.assetBlobs);
    const logs = db.createObjectStore(STORE.logs, { keyPath: "id" });
    logs.createIndex("jobId", "jobId");
    logs.createIndex("ts", "ts");
    const schedules = db.createObjectStore(STORE.schedules, { keyPath: "id" });
    schedules.createIndex("status", "status");
  },
  // v2 (0.10.0): Content Campaigns. Additive only — existing stores untouched.
  2: (db) => {
    const campaigns = db.createObjectStore(STORE.campaigns, { keyPath: "id" });
    campaigns.createIndex("createdAt", "createdAt");
    const items = db.createObjectStore(STORE.campaignItems, { keyPath: "id" });
    items.createIndex("campaignId", "campaignId");
    items.createIndex("jobId", "jobId");
  },
  // v3 (0.14.0): Product Update Bot — its own stores, every record scoped by workspaceId.
  3: (db) => {
    for (const name of [STORE.products, STORE.msgTemplates, STORE.destinations]) {
      db.createObjectStore(name, { keyPath: "id" }).createIndex("workspaceId", "workspaceId");
    }
    const batches = db.createObjectStore(STORE.batches, { keyPath: "id" });
    batches.createIndex("workspaceId", "workspaceId");
    batches.createIndex("createdAt", "createdAt");
    const sends = db.createObjectStore(STORE.productSends, { keyPath: "id" });
    sends.createIndex("batchId", "batchId");
    sends.createIndex("jobId", "jobId");
    sends.createIndex("workspaceId", "workspaceId");
    sends.createIndex("productId", "productId");
  }
};
var dbPromise = null;
function req(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(storageError("request", request.error));
  });
}
function storageError(op, cause) {
  return new AppError(ErrorCode.INTERNAL, `IndexedDB ${op} failed: ${String(cause)}`, {
    cause,
    userMessage: "\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01/\u0E2D\u0E48\u0E32\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 (IndexedDB)"
  });
}
function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const open = indexedDB.open(DB_NAME, DB_VERSION);
    open.onupgradeneeded = (event) => {
      const db = open.result;
      const tx = open.transaction;
      if (!tx) return;
      for (let v = event.oldVersion + 1; v <= DB_VERSION; v++) {
        const migrate = MIGRATIONS[v];
        if (!migrate) throw new Error(`Missing IndexedDB migration for version ${v}`);
        migrate(db, tx);
      }
    };
    open.onsuccess = () => {
      const db = open.result;
      db.onversionchange = () => {
        db.close();
        dbPromise = null;
      };
      resolve(db);
    };
    open.onerror = () => {
      dbPromise = null;
      reject(storageError("open", open.error));
    };
    open.onblocked = () => {
      dbPromise = null;
      reject(storageError("open (blocked)", "another context holds an older version open"));
    };
  });
  return dbPromise;
}
async function withStore(names, mode, fn) {
  const db = await openDb();
  const tx = db.transaction(names, mode);
  const done = new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(storageError("transaction", tx.error));
    tx.onabort = () => reject(storageError("transaction aborted", tx.error));
  });
  const result = await fn(tx);
  await done;
  return result;
}
function get(store, key) {
  return withStore(store, "readonly", (tx) => req(tx.objectStore(store).get(key)));
}
function put(store, value, key) {
  return withStore(store, "readwrite", async (tx) => {
    await req(tx.objectStore(store).put(value, key));
  });
}
function del(store, key) {
  return withStore(store, "readwrite", async (tx) => {
    await req(tx.objectStore(store).delete(key));
  });
}
function getAll(store) {
  return withStore(store, "readonly", (tx) => req(tx.objectStore(store).getAll()));
}
function getAllByIndex(store, index, key) {
  return withStore(store, "readonly", (tx) => req(tx.objectStore(store).index(index).getAll(key)));
}
function count(store) {
  return withStore(store, "readonly", (tx) => req(tx.objectStore(store).count()));
}
function queryIndexDesc(store, index, limit, filter = () => true) {
  return withStore(store, "readonly", (tx) => {
    return new Promise((resolve, reject) => {
      const out = [];
      const cursorReq = tx.objectStore(store).index(index).openCursor(null, "prev");
      cursorReq.onerror = () => reject(storageError("cursor", cursorReq.error));
      cursorReq.onsuccess = () => {
        const cursor = cursorReq.result;
        if (!cursor || out.length >= limit) {
          resolve(out);
          return;
        }
        const value = cursor.value;
        if (filter(value)) out.push(value);
        cursor.continue();
      };
    });
  });
}
function deleteBelow(store, index, upper) {
  return withStore(store, "readwrite", (tx) => {
    return new Promise((resolve, reject) => {
      let deleted = 0;
      const cursorReq = tx.objectStore(store).index(index).openCursor(IDBKeyRange.upperBound(upper, true));
      cursorReq.onerror = () => reject(storageError("cursor", cursorReq.error));
      cursorReq.onsuccess = () => {
        const cursor = cursorReq.result;
        if (!cursor) {
          resolve(deleted);
          return;
        }
        cursor.delete();
        deleted++;
        cursor.continue();
      };
    });
  });
}
function clearStore(store) {
  return withStore(store, "readwrite", async (tx) => {
    await req(tx.objectStore(store).clear());
  });
}

// src/storage/product-update-repo.ts
var ScopedStore = class {
  constructor(store, label) {
    this.store = store;
    this.label = label;
  }
  async list(workspaceId) {
    return getAllByIndex(this.store, "workspaceId", workspaceId);
  }
  async find(workspaceId, id2) {
    const r = await get(this.store, id2);
    return r && r.workspaceId === workspaceId ? r : void 0;
  }
  async get(workspaceId, id2) {
    const r = await this.find(workspaceId, id2);
    if (!r) throw new AppError(ErrorCode.NOT_FOUND, `${this.label} ${id2} not found`, { userMessage: `\u0E44\u0E21\u0E48\u0E1E\u0E1A${this.label}` });
    return r;
  }
  async put(record3) {
    await put(this.store, record3);
    return record3;
  }
  async delete(workspaceId, id2) {
    await this.get(workspaceId, id2);
    await del(this.store, id2);
  }
};
var ProductUpdateRepo = class {
  products = new ScopedStore(STORE.products, "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
  templates = new ScopedStore(STORE.msgTemplates, "Template");
  destinations = new ScopedStore(STORE.destinations, "\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07");
  batches = new ScopedStore(STORE.batches, "Batch");
  sends = new ScopedStore(STORE.productSends, "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07");
  sendsOfBatch(batchId) {
    return getAllByIndex(STORE.productSends, "batchId", batchId).then((s) => s.sort((a, b) => a.sequence - b.sequence));
  }
  async sendById(id2) {
    const s = await get(STORE.productSends, id2);
    if (!s) throw new AppError(ErrorCode.NOT_FOUND, `Send ${id2} not found`, { userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07" });
    return s;
  }
  async sendByJob(jobId) {
    return (await getAllByIndex(STORE.productSends, "jobId", jobId))[0];
  }
  /** Read-modify-write of one send (the workflow and the UI both update sends). */
  updateSend(id2, mutate, now) {
    return withStore(STORE.productSends, "readwrite", (tx) => {
      const store = tx.objectStore(STORE.productSends);
      return new Promise((resolve, reject) => {
        const r = store.get(id2);
        r.onerror = () => reject(new AppError(ErrorCode.INTERNAL, "send read failed"));
        r.onsuccess = () => {
          const s = r.result;
          if (!s) {
            reject(new AppError(ErrorCode.NOT_FOUND, `Send ${id2} not found`, { userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07" }));
            return;
          }
          mutate(s);
          s.updatedAt = now;
          store.put(s);
          resolve(s);
        };
      });
    });
  }
  /** Batch + all its sends in one transaction (never a batch without its sends). */
  createBatch(batch, sends) {
    return withStore([STORE.batches, STORE.productSends], "readwrite", (tx) => {
      tx.objectStore(STORE.batches).add(batch);
      const store = tx.objectStore(STORE.productSends);
      for (const s of sends) store.add(s);
    });
  }
};

// src/shared/product-media.ts
function productMediaKind(mime) {
  if (/^image\/(png|jpeg|webp|gif)$/.test(mime)) return "image";
  if (/^video\/(mp4|webm|quicktime)$/.test(mime)) return "video";
  return void 0;
}

// src/shared/hash.ts
async function sha256Hex(data) {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}

// src/shared/transfer-codec.ts
var TRANSFER_CHUNK_BYTES = 1024 * 1024;
var TRANSFER_MAX_BYTES = 1024 * 1024 * 1024;
function bytesToBase64(bytes) {
  let binary = "";
  const step = 32768;
  for (let i = 0; i < bytes.length; i += step) {
    binary += String.fromCharCode(...bytes.subarray(i, i + step));
  }
  return btoa(binary);
}
function base64ToBytes(b64) {
  const binary = atob(b64);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}
async function sendBlobOverPort(port5, blob, name) {
  if (blob.size > TRANSFER_MAX_BYTES) {
    throw new AppError(ErrorCode.UPLOAD_FAILED, `File too large to transfer (${blob.size} bytes)`);
  }
  const bytes = new Uint8Array(await blob.arrayBuffer());
  const chunks = Math.max(1, Math.ceil(bytes.length / TRANSFER_CHUNK_BYTES));
  const ack = new Promise((resolve, reject) => {
    port5.onMessage.addListener((msg) => {
      if (msg.k !== "ack") return;
      if (msg.ok) resolve();
      else reject(new AppError(ErrorCode.UPLOAD_FAILED, `Receiver rejected transfer: ${msg.error}`));
    });
    port5.onDisconnect.addListener(
      () => reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer port disconnected before ack"))
    );
  });
  port5.postMessage({ k: "meta", size: bytes.length, mime: blob.type, name, chunks });
  for (let i = 0; i < chunks; i++) {
    const slice = bytes.subarray(i * TRANSFER_CHUNK_BYTES, (i + 1) * TRANSFER_CHUNK_BYTES);
    port5.postMessage({ k: "chunk", i, b64: bytesToBase64(slice) });
  }
  port5.postMessage({ k: "end", sha256: await sha256Hex(bytes) });
  await ack;
}
function receiveBlobFromPort(port5) {
  return new Promise((resolve, reject) => {
    let meta = null;
    const parts = [];
    const fail2 = (error) => {
      try {
        port5.postMessage({ k: "ack", ok: false, error });
      } catch {
      }
      reject(new AppError(ErrorCode.UPLOAD_FAILED, error));
    };
    port5.onDisconnect.addListener(() => {
      if (!meta || parts.length < meta.chunks) reject(new AppError(ErrorCode.UPLOAD_FAILED, "Transfer interrupted"));
    });
    port5.onMessage.addListener((msg) => {
      if (msg.k === "meta") {
        if (msg.size > TRANSFER_MAX_BYTES) return fail2("file too large");
        meta = msg;
        return;
      }
      if (msg.k === "chunk") {
        if (!meta || msg.i !== parts.length) return fail2(`unexpected chunk ${msg.i}`);
        parts.push(base64ToBytes(msg.b64));
        return;
      }
      if (msg.k === "end") {
        const m = meta;
        if (!m || parts.length !== m.chunks) return fail2("missing chunks");
        const file = new File(parts, m.name, { type: m.mime });
        void file.arrayBuffer().then((buf) => sha256Hex(buf)).then((hash) => {
          if (hash !== msg.sha256) return fail2("checksum mismatch");
          port5.postMessage({ k: "ack", ok: true });
          resolve(file);
        }, (err) => fail2(String(err)));
      }
    });
  });
}

// src/shared/schema.ts
function fail(path, expected, value) {
  const got = value === null ? "null" : Array.isArray(value) ? "array" : typeof value;
  throw new AppError(ErrorCode.INVALID_INPUT, `${path || "value"}: expected ${expected}, got ${got}`, {
    detail: { path, expected }
  });
}
function string(opts = {}) {
  return (value, path = "") => {
    if (typeof value !== "string") fail(path, "string", value);
    if (opts.min !== void 0 && value.length < opts.min) fail(path, `string length >= ${opts.min}`, value);
    if (opts.max !== void 0 && value.length > opts.max) fail(path, `string length <= ${opts.max}`, value);
    if (opts.pattern && !opts.pattern.test(value)) fail(path, `string matching ${opts.pattern}`, value);
    return value;
  };
}
function number(opts = {}) {
  return (value, path = "") => {
    if (typeof value !== "number" || !Number.isFinite(value)) fail(path, "finite number", value);
    if (opts.int && !Number.isInteger(value)) fail(path, "integer", value);
    if (opts.min !== void 0 && value < opts.min) fail(path, `number >= ${opts.min}`, value);
    if (opts.max !== void 0 && value > opts.max) fail(path, `number <= ${opts.max}`, value);
    return value;
  };
}
var boolean = (value, path = "") => {
  if (typeof value !== "boolean") fail(path, "boolean", value);
  return value;
};
var unknownValue = (value) => value;
function literal(...values) {
  return (value, path = "") => {
    if (!values.includes(value)) fail(path, `one of ${values.join("|")}`, value);
    return value;
  };
}
function array(item, opts = {}) {
  return (value, path = "") => {
    if (!Array.isArray(value)) fail(path, "array", value);
    if (opts.max !== void 0 && value.length > opts.max) fail(path, `array length <= ${opts.max}`, value);
    if (opts.min !== void 0 && value.length < opts.min) fail(path, `array length >= ${opts.min}`, value);
    return value.map((v, i) => item(v, `${path}[${i}]`));
  };
}
function optional(inner) {
  return (value, path = "") => value === void 0 ? void 0 : inner(value, path);
}
function object(shape) {
  return (value, path = "") => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
    const src = value;
    const out = {};
    for (const [key, validator] of Object.entries(shape)) {
      const v = validator(src[key], path ? `${path}.${key}` : key);
      if (v !== void 0) out[key] = v;
    }
    return out;
  };
}
function record(inner, opts = {}) {
  return (value, path = "") => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) fail(path, "object", value);
    const entries = Object.entries(value);
    if (opts.maxKeys !== void 0 && entries.length > opts.maxKeys) fail(path, `<= ${opts.maxKeys} keys`, value);
    const out = {};
    for (const [k, v] of entries) out[k] = inner(v, `${path}.${k}`);
    return out;
  };
}
var empty = (value, path = "") => {
  if (value !== void 0 && (typeof value !== "object" || value === null)) fail(path, "empty object", value);
  return {};
};
var isoDate = (value, path = "") => {
  const s = string({ max: 40 })(value, path);
  if (Number.isNaN(Date.parse(s))) fail(path, "ISO date", value);
  return s;
};
var id = string({ min: 1, max: 64, pattern: /^[A-Za-z0-9_-]+$/ });

// src/shared/pricing.ts
var NUM = String.raw`\d{1,6}(?:\.\d{1,2})?`;
var CURRENCY = new RegExp(String.raw`(?<p>${NUM})\s*(?:฿|บาท)`);
var EQUALS = new RegExp(String.raw`=\s*(?<p>${NUM})(?!\d)`);
var SIZE = new RegExp(String.raw`\d{1,3}/\d{1,3}(?:\s+|\s*-\s*)(?<p>${NUM})(?=\s|$)`);
var UNIT = new RegExp(String.raw`\d+\s*(?:กรัม|ขีด|ฝา|ไม้|ตัว|แพ็ค|แพค|กก\.?|โล)\s+(?<p>${NUM})\s*$`);
var ONLY = new RegExp(String.raw`^\s*(?<p>${NUM})\s*$`);
var TRAIL = new RegExp(String.raw`[^\d/.\-](?<p>${NUM})\s*(?:\([^)]*\))?\s*$`);
var ORDERED = [CURRENCY, EQUALS, SIZE, UNIT, ONLY, TRAIL];
var MIN_ORDER = /ขั้นต่ำ|หิ้ว|คละ/;
var DATE = /\d{1,2}\/\d{1,2}\/\d{2,4}|\d{1,2}-\d{1,2}-\d{2,4}|วันที่\s*\d/;
var REMARK = /^(?:📌|‼️|❗|✨|✅|✖️|⚠️|\*|\(|•\s*\()/u;
var SEPARATOR = /^[\s\-_—=~.·*]+$/;
function sectionName(line) {
  return line.replace(/[\uFE0E\uFE0F\u200D]/g, "").replace(/[^\p{L}\p{M}\p{N}\s()/\-.]/gu, " ").replace(/\s+/g, " ").trim().slice(0, 60);
}
function lineKey(section, label) {
  return `${section}|${label}`;
}
function formatPrice(n) {
  return Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100);
}
function findPrice(line) {
  const t = line.trim();
  if (!t || SEPARATOR.test(t)) return null;
  if (DATE.test(t)) return null;
  const currency = CURRENCY.exec(line);
  if (MIN_ORDER.test(t) && !currency) return null;
  for (const rx of ORDERED) {
    const m = rx === CURRENCY ? currency : rx.exec(line);
    const p = m?.groups?.["p"];
    if (!m || p === void 0) continue;
    const start = m.index + m[0].indexOf(p, rx === TRAIL ? 1 : 0);
    return { start, end: start + p.length, price: Number(p) };
  }
  return null;
}
function classify(line) {
  const t = line.trim();
  if (!t || SEPARATOR.test(t)) return "blank";
  if (DATE.test(t) || MIN_ORDER.test(t) || REMARK.test(t)) return "note";
  return "heading";
}
function labelOf(line, f) {
  const rest = `${line.slice(0, f.start)} ${line.slice(f.end)}`.replace(/(?:฿|บาท)/g, " ").replace(/\([^)]*\)/g, " ");
  const name = sectionName(rest).replace(/[=\-\s]+$/g, "").replace(/^[=\-\s]+/g, "");
  return name || "\u2014";
}
var EMPTY_PRICING = { plus: 0, minus: 0, sections: {}, lines: {} };
function applyPricing(source, settings = EMPTY_PRICING) {
  const lines = source.split("\n");
  const out = [];
  const rows = [];
  const sections = [];
  let current = "";
  let blankBefore = true;
  const sectionOf = (name) => {
    let s = sections.find((x) => x.name === name);
    if (!s) {
      const own = settings.sections[name];
      s = { name, plus: own ? own.plus : settings.plus, minus: own ? own.minus : settings.minus, own: Boolean(own), rows: [] };
      sections.push(s);
    }
    return s;
  };
  for (const [i, line] of lines.entries()) {
    const f = findPrice(line);
    if (!f) {
      const kind = classify(line);
      if (kind === "heading") current = sectionName(line) || current;
      blankBefore = kind === "blank";
      out.push(line);
      continue;
    }
    let label = labelOf(line, f);
    const named = new RegExp("\\p{L}{2,}", "u").test(label) && !/\d/.test(label.replace(/\d+\s*(?:กรัม|ขีด|ฝา|ไม้|ตัว|แพ็ค|แพค|โล)/g, ""));
    let name = current;
    if (!current || blankBefore && named) {
      name = label;
      label = "\u2014";
    }
    blankBefore = false;
    const sec = sectionOf(name || "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23");
    const key = lineKey(sec.name, label);
    const extra = Number.isFinite(settings.lines[key]) ? settings.lines[key] : 0;
    const sale = Math.max(0, f.price + sec.plus + extra);
    const cost = Math.max(0, f.price - sec.minus);
    const row = { line: i, section: sec.name, label, key, price: f.price, sale, cost, extra };
    rows.push(row);
    sec.rows.push(row);
    out.push(sale === f.price ? line : line.slice(0, f.start) + formatPrice(sale) + line.slice(f.end));
  }
  return { output: out.join("\n"), rows, sections: sections.filter((s) => s.rows.length) };
}
var baht = number({ min: -1e5, max: 1e5 });
var validatePricing = object({
  source: string({ max: 4e3 }),
  plus: baht,
  minus: baht,
  sections: record(object({ plus: baht, minus: baht }), { maxKeys: 200 }),
  lines: record(baht, { maxKeys: 1e3 }),
  pricedAt: optional(isoDate)
});

// src/shared/product-update.ts
var PRODUCT_LIMITS = {
  nameMax: 120,
  descriptionMax: 2e3,
  imagesMax: 10,
  imageBytesMax: 8 * 1024 * 1024,
  videoBytesMax: 25 * 1024 * 1024,
  templateBodyMax: 3e3,
  batchProductsMax: 100,
  batchDestinationsMax: 10
};
function isLine(d) {
  return d.type === "LINE_OPENCHAT";
}
function isGroup(d) {
  return d.type === "FACEBOOK_GROUP";
}
function isPost(d) {
  return isFeed(d) || isGroup(d);
}
function isFeed(d) {
  return d.type === "FACEBOOK_FEED";
}
var DEFAULT_DATE_CARD = {
  enabled: false,
  shopName: "",
  headline: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 {date}",
  details: "",
  style: "",
  aspect: "16:9",
  repeat: 1,
  autoStyle: false,
  business: ""
};
var CHAT_URL = /^https:\/\/(?:www\.)?facebook\.com\/messages\/(?:e2ee\/)?t\/([A-Za-z0-9._-]{3,64})\/?(?:[?#].*)?$/;
var NOT_A_FEED = /^(messages|groups|watch|marketplace|events|gaming|reel|reels|stories|photo|photos|video|videos|login|settings|help|notifications|bookmarks|friends|search|share|hashtag|business|ads)(\/|$)/i;
function parseFeedUrl(raw) {
  let u;
  try {
    u = new URL(raw.trim());
  } catch {
    return null;
  }
  if (u.protocol !== "https:" || !/^(www\.|m\.|web\.)?facebook\.com$/.test(u.hostname)) return null;
  const path = u.pathname.replace(/^\/+|\/+$/g, "");
  if (path === "profile.php") {
    const id2 = u.searchParams.get("id");
    return id2 && /^\d{5,20}$/.test(id2) ? `https://www.facebook.com/profile.php?id=${id2}` : null;
  }
  if (!path || NOT_A_FEED.test(path)) return null;
  const parts = path.split("/");
  if (parts[0] === "people" && parts.length >= 3 && /^\d+$/.test(parts[2] ?? "")) return `https://www.facebook.com/profile.php?id=${parts[2]}`;
  if (parts.length !== 1 || !/^[A-Za-z0-9.\-]{3,80}$/.test(parts[0])) return null;
  return `https://www.facebook.com/${parts[0]}`;
}
function parseChatUrl(raw) {
  const m = CHAT_URL.exec(raw.trim());
  if (!m?.[1]) return null;
  const e2ee = /\/messages\/e2ee\//.test(raw);
  return { threadId: m[1], url: `https://www.facebook.com/messages/${e2ee ? "e2ee/" : ""}t/${m[1]}/` };
}
var text = (max) => string({ max });
var validateProductInput = object({
  name: string({ min: 1, max: PRODUCT_LIMITS.nameMax }),
  description: text(PRODUCT_LIMITS.descriptionMax),
  price: (value, path = "") => value === null || value === void 0 || value === "" ? null : number({ min: 0, max: 1e8 })(value, path),
  currency: string({ min: 1, max: 8 }),
  unit: optional(string({ max: 20 })),
  images: array(id, { max: PRODUCT_LIMITS.imagesMax }),
  templateId: id,
  active: boolean,
  imagesOnly: optional(boolean),
  pricing: optional(validatePricing)
});
var validateTemplateInput = object({
  name: string({ min: 1, max: 80 }),
  body: string({ min: 1, max: PRODUCT_LIMITS.templateBodyMax }),
  active: boolean
});
var validateDateCardSettings = object({
  enabled: boolean,
  shopName: string({ max: 80 }),
  headline: string({ min: 1, max: 120 }),
  details: text(400),
  style: text(600),
  aspect: literal("1:1", "4:5", "16:9"),
  repeat: number({ int: true, min: 1, max: 10 }),
  autoStyle: boolean,
  business: text(300)
});
var validateDestinationInput = object({
  type: optional(literal("FACEBOOK_GROUP_CHAT", "FACEBOOK_FEED", "FACEBOOK_GROUP", "LINE_OPENCHAT")),
  name: string({ min: 1, max: 100 }),
  /** Facebook: a link (parsers reject anything short) · LINE: the room name as LINE PC shows it. */
  url: string({ min: 1, max: 300 }),
  /** LINE OpenChat only: the room's invite link (optional; lets LINE PC jump straight to the room). */
  roomUrl: optional(string({ max: 300 })),
  enabled: boolean,
  notes: text(500)
});
function parseLineRoomUrl(raw) {
  const t = raw.trim();
  if (!t) return null;
  const m = /^(?:https?:\/\/line\.me\/ti\/g2\/|line:\/\/ti\/g2\/)([A-Za-z0-9_-]{6,120})(?:[?#].*)?$/.exec(t);
  return m?.[1] ? `line://ti/g2/${m[1]}` : null;
}

// src/providers/messenger/chat-name.ts
var EMOJI = /[\p{Extended_Pictographic}\p{Emoji_Modifier}\p{Regional_Indicator}\u{200D}\u{FE0E}\u{FE0F}\u{20E3}]/gu;
var spaces = (s) => s.replace(/\s+/g, " ").trim().toLowerCase();
function chatNameKey(name) {
  const plain = spaces(name.replace(EMOJI, ""));
  return plain || spaces(name);
}
function sameChatName(a, b) {
  return chatNameKey(a) === chatNameKey(b);
}

// src/providers/facebook-group/url.ts
function parseGroupUrl(raw) {
  let u;
  try {
    u = new URL(raw.trim());
  } catch {
    return null;
  }
  if (u.protocol !== "https:" || !/^(www\.|m\.|web\.)?facebook\.com$/.test(u.hostname)) return null;
  if (u.username || u.password || u.port) return null;
  const match = /^\/groups\/([A-Za-z0-9._-]{1,100})\/?$/.exec(u.pathname);
  const key = match?.[1];
  if (!key || /^(feed|discover|create|joins|notifications|yourgroups)$/i.test(key)) return null;
  return `https://www.facebook.com/groups/${key}/`;
}

// src/tools/product-update/date-card.ts
var TH_MONTHS = ["\u0E21\u0E01\u0E23\u0E32\u0E04\u0E21", "\u0E01\u0E38\u0E21\u0E20\u0E32\u0E1E\u0E31\u0E19\u0E18\u0E4C", "\u0E21\u0E35\u0E19\u0E32\u0E04\u0E21", "\u0E40\u0E21\u0E29\u0E32\u0E22\u0E19", "\u0E1E\u0E24\u0E29\u0E20\u0E32\u0E04\u0E21", "\u0E21\u0E34\u0E16\u0E38\u0E19\u0E32\u0E22\u0E19", "\u0E01\u0E23\u0E01\u0E0E\u0E32\u0E04\u0E21", "\u0E2A\u0E34\u0E07\u0E2B\u0E32\u0E04\u0E21", "\u0E01\u0E31\u0E19\u0E22\u0E32\u0E22\u0E19", "\u0E15\u0E38\u0E25\u0E32\u0E04\u0E21", "\u0E1E\u0E24\u0E28\u0E08\u0E34\u0E01\u0E32\u0E22\u0E19", "\u0E18\u0E31\u0E19\u0E27\u0E32\u0E04\u0E21"];
function thaiLongDate(ymd) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd);
  if (!m) return ymd;
  const month = TH_MONTHS[Number(m[2]) - 1];
  return month ? `${Number(m[3])} ${month} ${Number(m[1]) + 543}` : ymd;
}
function dateCardLines(s, ymd) {
  return [s.shopName, s.headline.replace(/\{date\}/g, thaiLongDate(ymd)), ...s.details.split(/\r?\n/)].map((l) => l.trim()).filter(Boolean);
}
var DEFAULT_STYLE = "\u0E1B\u0E49\u0E32\u0E22\u0E1B\u0E23\u0E30\u0E01\u0E32\u0E28\u0E23\u0E49\u0E32\u0E19\u0E2D\u0E32\u0E2B\u0E32\u0E23\u0E17\u0E30\u0E40\u0E25\u0E2A\u0E14 \u0E14\u0E39\u0E2A\u0E14\u0E43\u0E2A \u0E2A\u0E30\u0E2D\u0E32\u0E14\u0E15\u0E32 \u0E42\u0E17\u0E19\u0E1F\u0E49\u0E32-\u0E19\u0E49\u0E33\u0E40\u0E07\u0E34\u0E19-\u0E02\u0E32\u0E27 \u0E21\u0E35\u0E20\u0E32\u0E1E\u0E2D\u0E32\u0E2B\u0E32\u0E23\u0E17\u0E30\u0E40\u0E25 (\u0E01\u0E38\u0E49\u0E07 \u0E1B\u0E39 \u0E2B\u0E2D\u0E22 \u0E1B\u0E25\u0E32\u0E2B\u0E21\u0E36\u0E01) \u0E40\u0E1B\u0E47\u0E19\u0E2D\u0E07\u0E04\u0E4C\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A \u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23\u0E43\u0E2B\u0E0D\u0E48 \u0E2D\u0E48\u0E32\u0E19\u0E07\u0E48\u0E32\u0E22\u0E1A\u0E19\u0E21\u0E37\u0E2D\u0E16\u0E37\u0E2D";
var ASPECT_WORD = { "1:1": "\u0E2A\u0E35\u0E48\u0E40\u0E2B\u0E25\u0E35\u0E48\u0E22\u0E21\u0E08\u0E31\u0E15\u0E38\u0E23\u0E31\u0E2A 1:1", "4:5": "\u0E41\u0E19\u0E27\u0E15\u0E31\u0E49\u0E07 4:5", "16:9": "\u0E41\u0E19\u0E27\u0E19\u0E2D\u0E19 16:9" };
function dateCardPrompt(s, ymd) {
  const lines = dateCardLines(s, ymd);
  return [
    `\u0E2D\u0E2D\u0E01\u0E41\u0E1A\u0E1A\u0E20\u0E32\u0E1E\u0E1B\u0E49\u0E32\u0E22\u0E1B\u0E23\u0E30\u0E01\u0E32\u0E28 ${ASPECT_WORD[s.aspect]} \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E2A\u0E48\u0E07\u0E43\u0E19\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17\u0E25\u0E39\u0E01\u0E04\u0E49\u0E32`,
    `\u0E2A\u0E44\u0E15\u0E25\u0E4C: ${s.style.trim() || DEFAULT_STYLE}`,
    "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E1A\u0E19\u0E20\u0E32\u0E1E \u0E15\u0E49\u0E2D\u0E07\u0E2A\u0E30\u0E01\u0E14\u0E43\u0E2B\u0E49\u0E15\u0E23\u0E07\u0E15\u0E32\u0E21\u0E19\u0E35\u0E49\u0E17\u0E38\u0E01\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23 (\u0E20\u0E32\u0E29\u0E32\u0E44\u0E17\u0E22\u0E15\u0E49\u0E2D\u0E07\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 \u0E27\u0E23\u0E23\u0E13\u0E22\u0E38\u0E01\u0E15\u0E4C\u0E04\u0E23\u0E1A) \u0E41\u0E25\u0E30\u0E27\u0E32\u0E07\u0E15\u0E32\u0E21\u0E25\u0E33\u0E14\u0E31\u0E1A\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14:",
    ...lines.map((l, i) => `${i + 1}. ${l}`),
    `\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E17\u0E35\u0E48 2 (\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48) \u0E40\u0E14\u0E48\u0E19\u0E17\u0E35\u0E48\u0E2A\u0E38\u0E14 \xB7 \u0E2B\u0E49\u0E32\u0E21\u0E40\u0E02\u0E35\u0E22\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E2D\u0E37\u0E48\u0E19\u0E19\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E19\u0E35\u0E49 \xB7 \u0E2B\u0E49\u0E32\u0E21\u0E21\u0E35 QR code \xB7 \u0E2B\u0E49\u0E32\u0E21\u0E21\u0E35\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E2B\u0E23\u0E37\u0E2D\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E30\u0E1A\u0E38\u0E44\u0E27\u0E49`
  ].join("\n");
}

// src/tools/product-update/daily-style.ts
var STYLE_DNA_KEYS = ["environment", "timeOfDay", "weather", "cameraAngle", "truckPosition", "signPosition", "lighting", "atmosphere"];
var SIMILAR_FIELDS = 5;
var STYLE_HISTORY_DAYS = 30;
var STYLE_MAX_TRIES = 3;
var DEFAULT_BUSINESS = "\u0E23\u0E49\u0E32\u0E19\u0E02\u0E32\u0E22\u0E2A\u0E48\u0E07\u0E2D\u0E32\u0E2B\u0E32\u0E23\u0E17\u0E30\u0E40\u0E25\u0E43\u0E19\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28\u0E44\u0E17\u0E22: \u0E02\u0E32\u0E22\u0E2A\u0E48\u0E07 \u0E08\u0E31\u0E14\u0E2A\u0E48\u0E07 \u0E01\u0E23\u0E30\u0E08\u0E32\u0E22\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E2D\u0E32\u0E2B\u0E32\u0E23\u0E17\u0E30\u0E40\u0E25 \u0E04\u0E25\u0E31\u0E07\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E15\u0E25\u0E32\u0E14\u0E2D\u0E32\u0E2B\u0E32\u0E23\u0E17\u0E30\u0E40\u0E25 \u0E23\u0E16\u0E02\u0E19\u0E2A\u0E48\u0E07";
function styleDirectorPrompt(brief, avoid) {
  const brand = brief.shopName.trim() || "the shop";
  const recent = brief.recent.slice(0, STYLE_HISTORY_DAYS);
  return [
    `You are the Daily Visual Style Director for ${brand}.`,
    "Generate ONE fresh visual style for today's product announcement image.",
    "The visual style must be noticeably different from recently used styles \u2014 a different place, light and camera, not just different words.",
    "",
    "Brand context:",
    `- ${brand}`,
    `- ${brief.business.trim() || DEFAULT_BUSINESS}`,
    "- realistic commercial photography",
    "",
    "The announcement sign must remain the main focal point.",
    "Vary: environment, location type, weather, time of day, camera angle, camera distance, truck position, sign position, lighting, atmosphere, background activity, props, composition, perspective.",
    recent.length ? `Avoid repeating these recent combinations (newest first):
${recent.map((d, i) => `${i + 1}. ${STYLE_DNA_KEYS.map((k) => `${k}=${d[k]}`).join("; ")}`).join("\n")}` : "",
    avoid ? `Your previous answer was too close to a recent day (${avoid}). Change those aspects completely.` : "",
    "",
    "Do NOT write the announcement text (the sign's words are added later by the system).",
    "Do NOT add: QR code, random text, extra phone number, URL, unrelated brand.",
    "",
    "Return JSON only, exactly this shape (all values short English phrases; visualPrompt = 2-4 sentences describing the photo, with an empty announcement sign as the focal point):",
    '{"scene":"","mood":"","composition":"","camera":"","lighting":"","styleDNA":{"environment":"","timeOfDay":"","weather":"","cameraAngle":"","truckPosition":"","signPosition":"","lighting":"","atmosphere":""},"visualPrompt":""}'
  ].filter((l) => l !== "").join("\n");
}
var str = (v, max) => typeof v === "string" ? v.trim().slice(0, max) : "";
function parseStyleReply(reply) {
  const candidates = [...reply.codeBlocks, reply.text, /\{[\s\S]*\}/.exec(reply.text)?.[0] ?? ""];
  for (const raw of candidates) {
    let o;
    try {
      o = JSON.parse(raw.trim());
    } catch {
      continue;
    }
    if (!o || typeof o !== "object") continue;
    const r = o;
    const dnaRaw = r.styleDNA && typeof r.styleDNA === "object" ? r.styleDNA : {};
    const styleDNA = Object.fromEntries(STYLE_DNA_KEYS.map((k) => [k, str(dnaRaw[k], 120)]));
    const visualPrompt = str(r.visualPrompt, 1500);
    if (!visualPrompt || STYLE_DNA_KEYS.some((k) => !styleDNA[k])) continue;
    return { scene: str(r.scene, 300), mood: str(r.mood, 200), composition: str(r.composition, 300), camera: str(r.camera, 200), lighting: str(r.lighting, 200), styleDNA, visualPrompt };
  }
  return null;
}
var norm = (s) => s.toLowerCase().replace(/[^a-z0-9ก-๙]+/g, " ").trim();
function sameFields(a, b) {
  return STYLE_DNA_KEYS.filter((k) => norm(a[k]) !== "" && norm(a[k]) === norm(b[k]));
}
function tooSimilar(dna, recent) {
  let worst = null;
  recent.slice(0, STYLE_HISTORY_DAYS).forEach((r, index) => {
    const fields = sameFields(dna, r);
    if (fields.length >= SIMILAR_FIELDS && (!worst || fields.length > worst.fields.length)) worst = { index, fields };
  });
  return worst;
}
function recentDNA(history, date) {
  const from = shiftYmd(date, -STYLE_HISTORY_DAYS);
  return history.filter((h) => h.date !== date && h.date >= from && h.date < date && h.styleDNA).sort((a, b) => b.date.localeCompare(a.date)).map((h) => h.styleDNA);
}
function shiftYmd(ymd, days) {
  const d = /* @__PURE__ */ new Date(`${ymd}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

// src/storage/style-history-repo.ts
var STYLE_KEEP_DAYS = 60;
var LocalStyleHistoryRepo = class {
  lock = new Mutex();
  key(ws) {
    return `pu:dateStyle:${ws}`;
  }
  async load(workspaceId) {
    const raw = (await chrome.storage.local.get(this.key(workspaceId)))[this.key(workspaceId)];
    return raw && Array.isArray(raw.entries) ? raw : { entries: [] };
  }
  update(workspaceId, change) {
    return this.lock.run(async () => {
      const s = await this.load(workspaceId);
      change(s);
      s.entries.sort((a, b) => b.date.localeCompare(a.date));
      const newest = s.entries[0]?.date;
      if (newest) {
        const cut = /* @__PURE__ */ new Date(`${newest}T00:00:00Z`);
        cut.setUTCDate(cut.getUTCDate() - STYLE_KEEP_DAYS);
        const from = cut.toISOString().slice(0, 10);
        s.entries = s.entries.filter((e) => e.date >= from);
      }
      await chrome.storage.local.set({ [this.key(workspaceId)]: s });
      return s;
    });
  }
};

// src/tools/product-update/template.ts
var TEMPLATE_FIELDS = [
  { key: "productName", label: "\u0E0A\u0E37\u0E48\u0E2D\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32" },
  { key: "price", label: "\u0E23\u0E32\u0E04\u0E32 (\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E2B\u0E19\u0E48\u0E27\u0E22)" },
  { key: "description", label: "\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14" },
  { key: "date", label: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E02\u0E2D\u0E07\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15" },
  { key: "destinationName", label: "\u0E0A\u0E37\u0E48\u0E2D\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17" }
];
var PLACEHOLDER = /\{\{|\}\}|\{([A-Za-z]+)\}/g;
var KNOWN = new Set(TEMPLATE_FIELDS.map((f) => f.key));
var DEFAULT_TEMPLATE_BODY = "{description}";
var LEGACY_DEFAULT_TEMPLATE_BODY = "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49\n\n{productName}\n\n\u{1F4B0} \u0E23\u0E32\u0E04\u0E32 {price}\n\n{description}\n\n\u0E2A\u0E19\u0E43\u0E08\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 \u0E17\u0E31\u0E01\u0E44\u0E14\u0E49\u0E40\u0E25\u0E22\u0E04\u0E23\u0E31\u0E1A";
function unknownPlaceholders(body) {
  const out = /* @__PURE__ */ new Set();
  for (const m of body.matchAll(PLACEHOLDER)) if (m[1] && !KNOWN.has(m[1])) out.add(m[1]);
  return [...out];
}
function renderTemplate(body, data) {
  const lines = body.replace(/\r\n?/g, "\n").split("\n").flatMap((line) => {
    let placeholders = 0;
    let filled = 0;
    const rendered = line.replace(PLACEHOLDER, (all, key) => {
      if (all === "{{") return "{";
      if (all === "}}") return "}";
      if (!key || !KNOWN.has(key)) return all;
      placeholders++;
      const value = data[key].trim();
      if (value) filled++;
      return value;
    });
    return placeholders > 0 && filled === 0 ? [] : [rendered.replace(/[ \t]+$/, "")];
  });
  return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}
var CURRENCY_LABEL = { THB: "\u0E1A\u0E32\u0E17", USD: "USD" };
function formatPrice2(price, currency, unit) {
  if (price === null || !Number.isFinite(price)) return "";
  const amount = price.toLocaleString("en-US", { maximumFractionDigits: 2 });
  const cur = CURRENCY_LABEL[currency] ?? currency;
  return `${amount} ${cur}${unit ? `/${unit}` : ""}`;
}
function formatDate(ymd) {
  const d = /* @__PURE__ */ new Date(`${ymd}T00:00:00Z`);
  return Number.isNaN(d.getTime()) ? ymd : d.toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
}

// src/tools/product-update/batch.ts
function renderProductMessage(product, template, date, destinationName) {
  if (product.imagesOnly) return "";
  return renderTemplate(template.body, {
    productName: product.name,
    price: formatPrice2(product.price, product.currency, product.unit),
    description: product.description,
    date: formatDate(date),
    destinationName
  });
}
function planBatch(input) {
  const issues = [];
  if (!input.products.length) issues.push({ message: "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22 1 \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23" });
  if (!input.destinations.length) issues.push({ message: "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22 1 \u0E01\u0E25\u0E38\u0E48\u0E21" });
  for (const d of input.destinations) {
    if (!d.enabled) issues.push({ destinationId: d.id, message: `\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07 "${d.name}" \u0E16\u0E39\u0E01\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19` });
  }
  const templates = new Map(input.templates.map((t) => [t.id, t]));
  const sends = [];
  let sequence = 0;
  for (const d of input.destinations) {
    const feed = isFeed(d);
    const group = isGroup(d);
    const channel = group ? { channel: "group" } : feed ? { channel: "feed" } : isLine(d) ? { channel: "line" } : {};
    const chat = { destinationName: d.name, chatUrl: d.chatReference.url, threadId: d.chatReference.threadId, expectedTitle: d.verifiedTitle ?? "", ...channel };
    const repeat = isPost(d) ? 0 : input.dateCard?.repeat ?? 0;
    for (let i = 1; i <= repeat; i++) {
      sends.push({
        sequence: ++sequence,
        kind: "date_card",
        productId: "",
        destinationId: d.id,
        snapshot: {
          productName: repeat > 1 ? `\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 (${i}/${repeat})` : "\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48",
          price: null,
          currency: "THB",
          message: "",
          imageAssetIds: input.dateCard?.assetId ? [input.dateCard.assetId] : [],
          templateName: "",
          ...chat
        }
      });
    }
    for (const p of input.products) {
      const t = templates.get(p.templateId);
      if (!t) {
        if (d === input.destinations[0]) issues.push({ productId: p.id, message: `\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 "${p.name}" \u0E44\u0E21\u0E48\u0E21\u0E35 Template \u2014 \u0E40\u0E25\u0E37\u0E2D\u0E01 Template \u0E43\u0E2B\u0E49\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E19\u0E35\u0E49\u0E01\u0E48\u0E2D\u0E19` });
        continue;
      }
      if (!p.active && d === input.destinations[0]) issues.push({ productId: p.id, message: `\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 "${p.name}" \u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E2D\u0E22\u0E39\u0E48` });
      const message = group ? p.imagesOnly ? "" : p.description : renderProductMessage(p, t, input.date, d.name);
      if (!message && !p.images.length && d === input.destinations[0]) {
        issues.push({ productId: p.id, message: p.imagesOnly ? `\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 "${p.name}" \u0E15\u0E31\u0E49\u0E07\u0E43\u0E2B\u0E49\u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E39\u0E1B \u0E41\u0E15\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B` : `\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 "${p.name}" \u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E41\u0E25\u0E30\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B` });
      }
      sends.push({
        sequence: ++sequence,
        productId: p.id,
        destinationId: d.id,
        snapshot: {
          productName: p.name,
          price: p.price,
          currency: p.currency,
          ...p.unit ? { unit: p.unit } : {},
          message,
          imageAssetIds: [...p.images],
          templateName: t.name,
          destinationName: d.name,
          chatUrl: d.chatReference.url,
          threadId: d.chatReference.threadId,
          expectedTitle: d.verifiedTitle ?? "",
          ...channel
        }
      });
    }
  }
  return { sends, issues };
}
function planContentSends(input) {
  const issues = [];
  if (!input.destinations.length) issues.push({ message: "\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E40\u0E1E\u0E08 / \u0E01\u0E25\u0E38\u0E48\u0E21\u0E17\u0E35\u0E48\u0E08\u0E30\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22 1 \u0E17\u0E35\u0E48" });
  if (!input.message.trim() && !input.assetIds.length) issues.push({ message: "\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E19\u0E35\u0E49\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E25\u0E30\u0E23\u0E39\u0E1B" });
  for (const d of input.destinations) if (!d.enabled) issues.push({ destinationId: d.id, message: `\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07 "${d.name}" \u0E16\u0E39\u0E01\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19` });
  const sends = input.destinations.map((d, i) => {
    const channel = isGroup(d) ? { channel: "group" } : isFeed(d) ? { channel: "feed" } : isLine(d) ? { channel: "line" } : {};
    return {
      sequence: i + 1,
      kind: "content",
      productId: "",
      destinationId: d.id,
      snapshot: {
        productName: input.title,
        price: null,
        currency: "THB",
        message: input.message,
        imageAssetIds: [...input.assetIds],
        templateName: "",
        destinationName: d.name,
        chatUrl: d.chatReference.url,
        threadId: d.chatReference.threadId,
        expectedTitle: d.verifiedTitle ?? "",
        ...channel
      }
    };
  });
  return { sends, issues };
}

// src/background/product-update.ts
var PRODUCT_IMAGE_SOURCE = "product-upload";
var OPEN_JOB = ["PENDING", "RUNNING", "PAUSED"];
var LAST_ATTEMPT_KEY = "productUpdate:lastAttemptAt";
var today = (clock) => new Date(clock.now() + 7 * 36e5).toISOString().slice(0, 10);
function invalid(message) {
  return new AppError(ErrorCode.INVALID_INPUT, message, { userMessage: message });
}
var ProductUpdateService = class {
  constructor(deps) {
    this.deps = deps;
    this.styles = deps.styles ?? new LocalStyleHistoryRepo();
  }
  styles;
  now() {
    return this.deps.clock.iso();
  }
  /* ------------------------------ templates ------------------------------ */
  /** Every workspace starts with one ready-to-use template. */
  async ensureTemplates(ws) {
    const list = await this.deps.repo.templates.list(ws);
    if (list.length) {
      for (const t2 of list) {
        if (t2.body !== LEGACY_DEFAULT_TEMPLATE_BODY) continue;
        t2.body = DEFAULT_TEMPLATE_BODY;
        t2.updatedAt = this.now();
        await this.deps.repo.templates.put(t2);
      }
      return list;
    }
    const now = this.now();
    const t = { schemaVersion: 1, id: newId("tpl_"), workspaceId: ws, name: "\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E1B\u0E23\u0E30\u0E08\u0E33\u0E27\u0E31\u0E19", body: DEFAULT_TEMPLATE_BODY, active: true, createdAt: now, updatedAt: now };
    await this.deps.repo.templates.put(t);
    return [t];
  }
  async listTemplates() {
    const ws = await this.deps.workspaceId();
    const [templates, products] = await Promise.all([this.ensureTemplates(ws), this.deps.repo.products.list(ws)]);
    return templates.map((t) => ({ ...t, usedBy: products.filter((p) => p.templateId === t.id).length })).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  }
  async saveTemplate(id2, input) {
    const ws = await this.deps.workspaceId();
    const unknown = unknownPlaceholders(input.body);
    if (unknown.length) throw invalid(`\u0E0A\u0E48\u0E2D\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${unknown.map((u) => `{${u}}`).join(", ")}`);
    const now = this.now();
    const base = id2 ? await this.deps.repo.templates.get(ws, id2) : void 0;
    const t = base ? { ...base, name: input.name.trim(), body: input.body, active: input.active, updatedAt: now } : { schemaVersion: 1, id: newId("tpl_"), workspaceId: ws, name: input.name.trim(), body: input.body, active: input.active, createdAt: now, updatedAt: now };
    await this.deps.repo.templates.put(t);
    this.deps.onChanged();
    return t;
  }
  async duplicateTemplate(id2) {
    const t = await this.deps.repo.templates.get(await this.deps.workspaceId(), id2);
    return this.saveTemplate(null, { name: `${t.name} (\u0E2A\u0E33\u0E40\u0E19\u0E32)`.slice(0, 80), body: t.body, active: t.active });
  }
  /** A template used by products can only be deleted by moving those products to another one. */
  async deleteTemplate(id2, reassignTo) {
    const ws = await this.deps.workspaceId();
    await this.deps.repo.templates.get(ws, id2);
    const users = (await this.deps.repo.products.list(ws)).filter((p) => p.templateId === id2);
    if (users.length) {
      if (!reassignTo || reassignTo === id2) throw invalid(`Template \u0E19\u0E35\u0E49\u0E43\u0E0A\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E01\u0E31\u0E1A\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 ${users.length} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23 \u2014 \u0E40\u0E25\u0E37\u0E2D\u0E01 Template \u0E2D\u0E37\u0E48\u0E19\u0E43\u0E2B\u0E49\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E40\u0E2B\u0E25\u0E48\u0E32\u0E19\u0E31\u0E49\u0E19\u0E01\u0E48\u0E2D\u0E19\u0E25\u0E1A`);
      await this.deps.repo.templates.get(ws, reassignTo);
      for (const p of users) await this.deps.repo.products.put({ ...p, templateId: reassignTo, updatedAt: this.now() });
    }
    await this.deps.repo.templates.delete(ws, id2);
    await this.deps.onDeleted?.("template", id2);
    this.deps.onChanged();
    return { moved: users.length };
  }
  /* ------------------------------- products ------------------------------- */
  async listProducts() {
    const ws = await this.deps.workspaceId();
    return (await this.deps.repo.products.list(ws)).sort((a, b) => a.sortOrder - b.sortOrder || a.createdAt.localeCompare(b.createdAt));
  }
  async saveProduct(id2, input) {
    const ws = await this.deps.workspaceId();
    await this.deps.repo.templates.get(ws, input.templateId);
    for (const a of input.images) {
      const asset = await this.deps.assets.get(a).catch(() => null);
      if (!asset || !["image", "video"].includes(asset.kind) || !productMediaKind(asset.mime)) throw invalid("\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 \u2014 \u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E43\u0E2B\u0E21\u0E48");
    }
    const now = this.now();
    const pricing = input.pricing ? { ...input.pricing, source: input.pricing.source.replace(/\r\n?/g, "\n") } : void 0;
    const description = pricing ? applyPricing(pricing.source, pricing).output : input.description;
    if (description.trim().length > PRODUCT_LIMITS.descriptionMax) throw invalid(`\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E22\u0E32\u0E27\u0E40\u0E01\u0E34\u0E19 ${PRODUCT_LIMITS.descriptionMax} \u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23`);
    const fields = {
      name: input.name.trim(),
      description: description.trim(),
      price: input.price,
      currency: input.currency,
      images: [...new Set(input.images)],
      templateId: input.templateId,
      active: input.active,
      imagesOnly: input.imagesOnly === true
    };
    let p;
    if (id2) {
      const base = await this.deps.repo.products.get(ws, id2);
      p = { ...base, ...fields, updatedAt: now };
      const pricedAt = pricing?.pricedAt ?? base.pricing?.pricedAt;
      if (pricing) p.pricing = pricedAt ? { ...pricing, pricedAt } : pricing;
      else delete p.pricing;
      if (input.unit?.trim()) p.unit = input.unit.trim();
      else delete p.unit;
    } else {
      const all = await this.deps.repo.products.list(ws);
      p = { schemaVersion: 1, id: newId("prd_"), workspaceId: ws, ...fields, sortOrder: all.reduce((m, x) => Math.max(m, x.sortOrder), 0) + 1, createdAt: now, updatedAt: now };
      if (pricing) p.pricing = pricing;
      if (input.unit?.trim()) p.unit = input.unit.trim();
    }
    await this.deps.repo.products.put(p);
    this.deps.onChanged();
    return p;
  }
  async duplicateProduct(id2) {
    const p = await this.deps.repo.products.get(await this.deps.workspaceId(), id2);
    const input = { name: `${p.name} (\u0E2A\u0E33\u0E40\u0E19\u0E32)`.slice(0, PRODUCT_LIMITS.nameMax), description: p.description, price: p.price, currency: p.currency, images: p.images, templateId: p.templateId, active: p.active, imagesOnly: p.imagesOnly === true };
    if (p.unit) input.unit = p.unit;
    if (p.pricing) input.pricing = p.pricing;
    return this.saveProduct(null, input);
  }
  async setProductActive(id2, active) {
    const ws = await this.deps.workspaceId();
    const p = { ...await this.deps.repo.products.get(ws, id2), active, updatedAt: this.now() };
    await this.deps.repo.products.put(p);
    this.deps.onChanged();
    return p;
  }
  /** Saves the manual order (ids first-to-last); products not listed keep their relative order after. */
  async reorderProducts(ids) {
    const all = await this.listProducts();
    const rank = new Map(ids.map((id2, i) => [id2, i]));
    const ordered = [...all].sort((a, b) => (rank.get(a.id) ?? ids.length + a.sortOrder) - (rank.get(b.id) ?? ids.length + b.sortOrder));
    const now = this.now();
    for (const [i, p] of ordered.entries()) if (p.sortOrder !== i + 1) await this.deps.repo.products.put({ ...p, sortOrder: i + 1, updatedAt: now });
    this.deps.onChanged();
    return this.listProducts();
  }
  /** Deleting a product never touches history (sends keep their snapshot). */
  async deleteProduct(id2) {
    const ws = await this.deps.workspaceId();
    await this.deps.repo.products.delete(ws, id2);
    await this.deps.onDeleted?.("product", id2);
    this.deps.onChanged();
  }
  /** Stores an uploaded image once (same bytes → same asset). */
  async addImage(base64, mime) {
    if (productMediaKind(mime) !== "image") throw invalid("\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E39\u0E1B PNG / JPG / WEBP / GIF");
    return this.addMedia(base64, mime);
  }
  async addMedia(base64, mime) {
    const kind = productMediaKind(mime);
    if (!kind) throw invalid("\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E23\u0E39\u0E1B PNG / JPG / WEBP / GIF \u0E41\u0E25\u0E30\u0E04\u0E25\u0E34\u0E1B MP4 / WEBM / MOV");
    const bytes = new Uint8Array(base64ToBytes(base64));
    const limit = kind === "video" ? PRODUCT_LIMITS.videoBytesMax : PRODUCT_LIMITS.imageBytesMax;
    if (bytes.byteLength > limit) throw invalid(`${kind === "video" ? "\u0E04\u0E25\u0E34\u0E1B" : "\u0E23\u0E39\u0E1B"}\u0E43\u0E2B\u0E0D\u0E48\u0E40\u0E01\u0E34\u0E19 ${limit / 1024 / 1024} MB`);
    const blob = new Blob([bytes], { type: mime });
    const existing = await this.deps.assets.findBySha256(await sha256Hex(bytes.buffer), PRODUCT_IMAGE_SOURCE);
    if (existing) return { assetId: existing.id };
    const asset = await this.deps.assets.ingest(blob, { kind, providerId: PRODUCT_IMAGE_SOURCE });
    return { assetId: asset.id };
  }
  /* ----------------------------- destinations ----------------------------- */
  async listDestinations() {
    const ws = await this.deps.workspaceId();
    return (await this.deps.repo.destinations.list(ws)).sort((a, b) => (b.lastUsedAt ?? "").localeCompare(a.lastUsedAt ?? "") || a.name.localeCompare(b.name));
  }
  async saveDestination(id2, input) {
    const ws = await this.deps.workspaceId();
    const base = id2 ? await this.deps.repo.destinations.get(ws, id2) : void 0;
    const type = base?.type ?? input.type ?? "FACEBOOK_GROUP_CHAT";
    const others = (await this.deps.repo.destinations.list(ws)).filter((d2) => d2.id !== id2);
    let ref;
    if (type === "FACEBOOK_FEED") {
      const url = parseFeedUrl(input.url);
      if (!url) throw invalid("\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E40\u0E1E\u0E08/\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08\u0E2B\u0E23\u0E37\u0E2D\u0E2B\u0E19\u0E49\u0E32\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13 \u0E41\u0E25\u0E49\u0E27\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E25\u0E34\u0E07\u0E01\u0E4C (\u0E40\u0E0A\u0E48\u0E19 https://www.facebook.com/jatuponseafood)");
      if (others.some((d2) => isFeed(d2) && d2.chatReference.url === url)) throw invalid("\u0E21\u0E35\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E40\u0E1E\u0E08/\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E19\u0E35\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27");
      ref = { url, threadId: "" };
    } else if (type === "FACEBOOK_GROUP") {
      const url = parseGroupUrl(input.url);
      if (!url) throw invalid("\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21 Facebook \u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 \u2014 \u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01 URL \u0E2B\u0E19\u0E49\u0E32\u0E01\u0E25\u0E38\u0E48\u0E21 (https://www.facebook.com/groups/\u2026)");
      if (others.some((d2) => d2.type === "FACEBOOK_GROUP" && d2.chatReference.url === url)) throw invalid("\u0E21\u0E35\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E01\u0E25\u0E38\u0E48\u0E21\u0E19\u0E35\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27");
      ref = { url, threadId: "" };
    } else if (type === "LINE_OPENCHAT") {
      const room = input.url.replace(/\s+/g, " ").trim();
      if (room.length < 1 || room.length > 100) throw invalid("\u0E43\u0E2A\u0E48\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07 OpenChat \u0E43\u0E2B\u0E49\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E17\u0E35\u0E48\u0E41\u0E2A\u0E14\u0E07\u0E43\u0E19 LINE PC (1\u2013100 \u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23)");
      let roomUrl = "";
      if (input.roomUrl?.trim()) {
        const parsed = parseLineRoomUrl(input.roomUrl);
        if (!parsed) throw invalid("\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E2B\u0E49\u0E2D\u0E07 OpenChat \u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 \u2014 \u0E43\u0E0A\u0E49\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E40\u0E0A\u0E34\u0E0D\u0E02\u0E2D\u0E07\u0E2B\u0E49\u0E2D\u0E07 (https://line.me/ti/g2/\u2026) \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E27\u0E49\u0E19\u0E27\u0E48\u0E32\u0E07");
        roomUrl = parsed;
      }
      if (others.some((d2) => isLine(d2) && d2.chatReference.url.toLowerCase() === room.toLowerCase())) throw invalid("\u0E21\u0E35\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E2B\u0E49\u0E2D\u0E07 OpenChat \u0E19\u0E35\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27");
      ref = { url: room, threadId: roomUrl };
    } else {
      const chat = parseChatUrl(input.url);
      if (!chat) throw invalid("\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E41\u0E0A\u0E17\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17\u0E43\u0E19 facebook.com/messages \u0E41\u0E25\u0E49\u0E27\u0E04\u0E31\u0E14\u0E25\u0E2D\u0E01\u0E25\u0E34\u0E07\u0E01\u0E4C (\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A https://www.facebook.com/messages/t/\u2026)");
      if (others.some((d2) => d2.type === "FACEBOOK_GROUP_CHAT" && d2.chatReference.threadId === chat.threadId)) throw invalid("\u0E21\u0E35\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E17\u0E35\u0E48\u0E43\u0E0A\u0E49\u0E41\u0E0A\u0E17\u0E19\u0E35\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27");
      ref = chat;
    }
    const now = this.now();
    const d = base ? { ...base, name: input.name.trim(), enabled: input.enabled, notes: input.notes.trim(), chatReference: ref, updatedAt: now } : { schemaVersion: 1, id: newId("dst_"), workspaceId: ws, name: input.name.trim(), type, chatReference: ref, enabled: input.enabled, notes: input.notes.trim(), createdAt: now, updatedAt: now };
    if (base && (base.chatReference.threadId !== ref.threadId || (type === "FACEBOOK_GROUP" || type === "LINE_OPENCHAT") && base.chatReference.url !== ref.url)) {
      delete d.verifiedTitle;
      delete d.verifiedAt;
    }
    await this.deps.repo.destinations.put(d);
    this.deps.onChanged();
    return d;
  }
  async deleteDestination(id2) {
    const ws = await this.deps.workspaceId();
    const open = await this.openSends(ws);
    if (open.some((s) => s.destinationId === id2)) throw invalid("\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E19\u0E35\u0E49\u0E21\u0E35\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E23\u0E2D\u0E2A\u0E48\u0E07\u0E2D\u0E22\u0E39\u0E48 \u2014 \u0E22\u0E01\u0E40\u0E25\u0E34\u0E01 Batch \u0E01\u0E48\u0E2D\u0E19");
    await this.deps.repo.destinations.delete(ws, id2);
    await this.deps.onDeleted?.("destination", id2);
    this.deps.onChanged();
  }
  /**
   * Opens the chat (no sending) and records the title Facebook shows. Sends are only allowed to a
   * verified destination; at the send the thread id must match and the page must name one chat
   * (header = composer). A renamed group is followed, not blocked (ADR-70).
   */
  async verifyDestination(id2) {
    const ws = await this.deps.workspaceId();
    const d = await this.deps.repo.destinations.get(ws, id2);
    if (isFeed(d)) throw invalid("\u0E40\u0E1E\u0E08/\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E0A\u0E17");
    if (isLine(d)) return this.verifyLineDestination(d);
    if (d.type === "FACEBOOK_GROUP") {
      if (!this.deps.inspectGroup) throw invalid("\u0E15\u0E31\u0E27\u0E15\u0E23\u0E27\u0E08\u0E01\u0E25\u0E38\u0E48\u0E21 Facebook \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19");
      const group = await this.deps.inspectGroup(d.chatReference.url, await this.deps.probeContext("product-update/group-test"));
      if (group.url !== d.chatReference.url || !group.canPost) throw invalid("\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E25\u0E38\u0E48\u0E21\u0E2B\u0E23\u0E37\u0E2D\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49");
      const updated2 = { ...d, verifiedTitle: group.title, verifiedAt: this.now(), updatedAt: this.now() };
      await this.deps.repo.destinations.put(updated2);
      this.deps.onChanged();
      return { destination: updated2, inspection: { threadId: "", title: group.title, canSend: true } };
    }
    const inspection = await this.deps.inspectChat(d.chatReference, await this.deps.probeContext("product-update"));
    if (inspection.threadId !== d.chatReference.threadId) {
      throw new AppError(ErrorCode.DESTINATION_MISMATCH, `Opened thread ${inspection.threadId}, expected ${d.chatReference.threadId}`, {
        userMessage: "Facebook \u0E40\u0E1B\u0E34\u0E14\u0E41\u0E0A\u0E17\u0E2D\u0E37\u0E48\u0E19\u0E41\u0E17\u0E19\u0E41\u0E0A\u0E17\u0E43\u0E19\u0E25\u0E34\u0E07\u0E01\u0E4C \u2014 \u0E15\u0E23\u0E27\u0E08\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07"
      });
    }
    const updated = { ...d, verifiedTitle: inspection.title, verifiedAt: this.now(), updatedAt: this.now() };
    await this.deps.repo.destinations.put(updated);
    this.deps.log.info(`\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E41\u0E25\u0E49\u0E27: ${d.name} \u2192 \u0E41\u0E0A\u0E17 "${inspection.title}"`);
    this.deps.onChanged();
    return { destination: updated, inspection };
  }
  /**
   * LINE OpenChat (ADR-78): the host opens the room in LINE PC. When LINE exposes the room title
   * (UI Automation) and it matches, the room is verified at once. Otherwise the screenshot goes
   * back to the user, who confirms it is the right room (confirmLineDestination) — the bot never
   * decides that by itself.
   */
  async verifyLineDestination(d) {
    if (!this.deps.inspectLine) throw invalid("\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE PC \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19");
    const room = { name: d.chatReference.url, ...d.chatReference.threadId ? { url: d.chatReference.threadId } : {} };
    const r = await this.deps.inspectLine(room, await this.deps.probeContext("product-update/line-test"));
    const inspection = { threadId: "", title: r.title || d.chatReference.url, canSend: true };
    if (r.verifiedBy === "uia" && r.title) {
      if (r.title !== room.name && !r.title.startsWith(room.name)) {
        throw new AppError(ErrorCode.DESTINATION_MISMATCH, `LINE opened "${r.title}", expected "${room.name}"`, { userMessage: `LINE \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07 "${r.title}" \u0E41\u0E17\u0E19 "${room.name}" \u2014 \u0E15\u0E23\u0E27\u0E08\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E2B\u0E49\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E43\u0E19 LINE PC` });
      }
      const updated = { ...d, verifiedTitle: r.title, verifiedAt: this.now(), updatedAt: this.now() };
      await this.deps.repo.destinations.put(updated);
      this.deps.log.info(`\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07 LINE \u0E41\u0E25\u0E49\u0E27: ${d.name} \u2192 "${r.title}" (\u0E2D\u0E48\u0E32\u0E19\u0E0A\u0E37\u0E48\u0E2D\u0E08\u0E32\u0E01 LINE \u0E44\u0E14\u0E49)`);
      this.deps.onChanged();
      return { destination: updated, inspection };
    }
    this.deps.log.info(`\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07 LINE "${room.name}" \u0E41\u0E25\u0E49\u0E27 \u2014 LINE \u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07\u0E01\u0E25\u0E31\u0E1A \u0E23\u0E2D\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E08\u0E32\u0E01\u0E20\u0E32\u0E1E\u0E2B\u0E19\u0E49\u0E32\u0E08\u0E2D`);
    return { destination: d, inspection, pending: { screenshot: r.screenshot } };
  }
  /** The user looked at the screenshot and confirmed the room: verified under the name they typed. */
  async confirmLineDestination(id2) {
    const ws = await this.deps.workspaceId();
    const d = await this.deps.repo.destinations.get(ws, id2);
    if (!isLine(d)) throw invalid("\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E2B\u0E49\u0E2D\u0E07 LINE OpenChat");
    const updated = { ...d, verifiedTitle: d.chatReference.url, verifiedAt: this.now(), updatedAt: this.now() };
    await this.deps.repo.destinations.put(updated);
    this.deps.log.info(`\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E2B\u0E49\u0E2D\u0E07 LINE: ${d.name} \u2192 "${d.chatReference.url}"`);
    this.deps.onChanged();
    return updated;
  }
  /* ------------------------------ daily update ------------------------------ */
  async dailyContext() {
    const ws = await this.deps.workspaceId();
    const [products, destinations, templates, batches] = await Promise.all([this.listProducts(), this.listDestinations(), this.ensureTemplates(ws), this.deps.repo.batches.list(ws)]);
    const lastBatch = batches.sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
    const ctx = { products: products.filter((p) => p.active), destinations: destinations.filter((d) => d.enabled), templates };
    if (lastBatch) ctx.last = { productIds: lastBatch.productIds, destinationIds: lastBatch.destinationIds, date: lastBatch.date };
    return ctx;
  }
  async selection(ws, productIds, destinationIds) {
    if (productIds.length > PRODUCT_LIMITS.batchProductsMax) throw invalid(`\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E14\u0E49\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14 ${PRODUCT_LIMITS.batchProductsMax} \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E15\u0E48\u0E2D Batch`);
    if (destinationIds.length > PRODUCT_LIMITS.batchDestinationsMax) throw invalid(`\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E14\u0E49\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14 ${PRODUCT_LIMITS.batchDestinationsMax} \u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E15\u0E48\u0E2D Batch`);
    const products = await Promise.all([...new Set(productIds)].map((id2) => this.deps.repo.products.get(ws, id2)));
    const destinations = await Promise.all([...new Set(destinationIds)].map((id2) => this.deps.repo.destinations.get(ws, id2)));
    products.sort((a, b) => a.sortOrder - b.sortOrder);
    return { products, destinations, templates: await this.ensureTemplates(ws) };
  }
  async previewBatch(productIds, destinationIds, date, withCard = false) {
    const ws = await this.deps.workspaceId();
    const plan = planBatch({ ...await this.selection(ws, productIds, destinationIds), date, ...await this.cardPlan(ws, date, withCard) });
    return {
      issues: plan.issues,
      sends: plan.sends.map((s) => ({ sequence: s.sequence, ...s.kind ? { kind: s.kind } : {}, productId: s.productId, destinationId: s.destinationId, productName: s.snapshot.productName, destinationName: s.snapshot.destinationName, message: s.snapshot.message, imageAssetIds: s.snapshot.imageAssetIds }))
    };
  }
  async createBatch(input) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(input.date)) throw invalid("\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
    const ws = await this.deps.workspaceId();
    const sel = await this.selection(ws, input.productIds, input.destinationIds);
    const card = await this.cardPlan(ws, input.date, input.dateCard === true);
    const plan = planBatch({ ...sel, date: input.date, ...card });
    if (plan.issues.length) throw invalid(plan.issues.map((i) => i.message).join(" \xB7 "));
    const now = this.now();
    const batch = {
      schemaVersion: 1,
      id: newId("bat_"),
      workspaceId: ws,
      name: input.name?.trim() || `\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15 ${input.date}`,
      date: input.date,
      destinationIds: sel.destinations.map((d) => d.id),
      productIds: sel.products.map((p) => p.id),
      sendCount: plan.sends.length,
      createdAt: now,
      updatedAt: now
    };
    if (card.dateCard) {
      batch.dateCard = { repeat: card.dateCard.repeat, status: card.dateCard.assetId ? "READY" : "WAITING", ...card.dateCard.assetId ? { assetId: card.dateCard.assetId } : {} };
    }
    const sends = plan.sends.map((s) => ({ schemaVersion: 1, id: newId("snd_"), batchId: batch.id, workspaceId: ws, ...s, status: "READY", attempts: 0, createdAt: now, updatedAt: now }));
    await this.deps.repo.createBatch(batch, sends);
    this.deps.log.info(`\u0E2A\u0E23\u0E49\u0E32\u0E07 Batch "${batch.name}" \u2014 ${sends.length} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23`);
    this.deps.onChanged();
    return batch;
  }
  /** An approved content-planner post → a batch of one send per destination (READY; started like any batch). */
  async createContentBatch(input) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(input.date)) throw invalid("\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
    const ws = await this.deps.workspaceId();
    const all = await this.deps.repo.destinations.list(ws);
    const destinations = input.destinationIds.map((id2) => all.find((d) => d.id === id2)).filter((d) => Boolean(d));
    for (const id2 of input.assetIds) if (!await this.deps.assets.get(id2).catch(() => null)) throw invalid("\u0E23\u0E39\u0E1B\u0E02\u0E2D\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E2B\u0E32\u0E22\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E40\u0E25\u0E37\u0E2D\u0E01\u0E23\u0E39\u0E1B\u0E43\u0E2B\u0E21\u0E48");
    const plan = planContentSends({ title: input.title, message: input.message, assetIds: input.assetIds, destinations });
    if (plan.issues.length) throw invalid(plan.issues.map((i) => i.message).join(" \xB7 "));
    const now = this.now();
    const batch = {
      schemaVersion: 1,
      id: newId("bat_"),
      workspaceId: ws,
      name: `\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C ${input.date} \xB7 ${input.title}`.slice(0, 120),
      date: input.date,
      destinationIds: destinations.map((d) => d.id),
      productIds: [],
      sendCount: plan.sends.length,
      createdAt: now,
      updatedAt: now
    };
    const sends = plan.sends.map((s) => ({ schemaVersion: 1, id: newId("snd_"), batchId: batch.id, workspaceId: ws, ...s, status: "READY", attempts: 0, createdAt: now, updatedAt: now }));
    await this.deps.repo.createBatch(batch, sends);
    this.deps.log.info(`\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C "${input.title}" \u0E40\u0E02\u0E49\u0E32\u0E04\u0E34\u0E27\u0E41\u0E25\u0E49\u0E27 \u2014 ${sends.length} \u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07`);
    this.deps.onChanged();
    return batch;
  }
  /* ------------------------------ date card ------------------------------- */
  cardKey(kind, ws) {
    return `pu:dateCard:${kind}:${ws}`;
  }
  async dateCardSettings(ws) {
    const id2 = ws ?? await this.deps.workspaceId();
    const key = this.cardKey("settings", id2);
    const stored = (await chrome.storage.local.get(key))[key];
    try {
      return validateDateCardSettings({ ...DEFAULT_DATE_CARD, ...stored ?? {} });
    } catch {
      return { ...DEFAULT_DATE_CARD };
    }
  }
  async saveDateCardSettings(input, opts = {}) {
    const s = validateDateCardSettings(input);
    if (s.enabled && !s.shopName.trim()) throw invalid("\u0E43\u0E2A\u0E48\u0E0A\u0E37\u0E48\u0E2D\u0E23\u0E49\u0E32\u0E19\u0E17\u0E35\u0E48\u0E08\u0E30\u0E41\u0E2A\u0E14\u0E07\u0E1A\u0E19\u0E1B\u0E49\u0E32\u0E22");
    const ws = opts.ws ?? await this.deps.workspaceId();
    await chrome.storage.local.set({ [this.cardKey("settings", ws)]: s, [`pu:dateCard:updatedAt:${ws}`]: opts.updatedAt ?? this.now() });
    this.deps.onChanged();
    return s;
  }
  /** When the date card settings last changed (epoch = never saved here). */
  async dateCardUpdatedAt(ws) {
    const key = `pu:dateCard:updatedAt:${ws ?? await this.deps.workspaceId()}`;
    return (await chrome.storage.local.get(key))[key] ?? "1970-01-01T00:00:00.000Z";
  }
  /** The latest card made (any date) — backups (ADR-65). */
  async latestCardImage(ws) {
    const key = this.cardKey("image", ws ?? await this.deps.workspaceId());
    return (await chrome.storage.local.get(key))[key];
  }
  /** Restores a backed-up card as the latest one, unless a newer card exists already. */
  async restoreCardImage(card, ws) {
    const id2 = ws ?? await this.deps.workspaceId();
    const current = await this.latestCardImage(id2);
    if (current && current.date >= card.date) return false;
    await chrome.storage.local.set({ [this.cardKey("image", id2)]: card });
    return true;
  }
  /** The card already made for `date` (latest one per workspace). */
  async cardFor(ws, date) {
    const key = this.cardKey("image", ws);
    const card = (await chrome.storage.local.get(key))[key];
    if (!card || card.date !== date) return void 0;
    return await this.deps.assets.get(card.assetId).catch(() => null) ? card : void 0;
  }
  async openCardJob(ws, date) {
    return (await this.deps.jobs.listOpen()).find((j) => {
      const input = j.input;
      return j.type === "date_card" && input.date === date && (input.workspaceId ?? ws) === ws;
    });
  }
  async cardPlan(ws, date, wanted) {
    if (!wanted) return {};
    const settings = await this.dateCardSettings(ws);
    if (!settings.enabled) throw invalid("\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49 \u2014 \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32 Daily Update");
    const card = await this.cardFor(ws, date);
    return { dateCard: { repeat: settings.repeat, ...card ? { assetId: card.assetId } : {} } };
  }
  async dateCardState(date) {
    const ws = await this.deps.workspaceId();
    const state = { settings: await this.dateCardSettings(ws) };
    const card = await this.cardFor(ws, date);
    if (card) state.card = card;
    const job = await this.openCardJob(ws, date);
    if (job) {
      const progress = job.steps.find((s) => s.status === "RUNNING")?.progress?.message;
      state.generating = { jobId: job.jobId, ...progress ? { progress } : {} };
    }
    const errKey = this.cardKey("error", ws);
    const err = (await chrome.storage.local.get(errKey))[errKey];
    if (err?.date === date && !card && !job) state.lastError = err.message;
    return state;
  }
  /** Queues ChatGPT to make (or remake) the card of `date`. One job per date at a time. */
  async generateDateCard(date, batchId) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw invalid("\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
    const ws = await this.deps.workspaceId();
    const settings = await this.dateCardSettings(ws);
    if (!settings.shopName.trim()) throw invalid("\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E0A\u0E37\u0E48\u0E2D\u0E23\u0E49\u0E32\u0E19\u0E02\u0E2D\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E01\u0E48\u0E2D\u0E19");
    const open = await this.openCardJob(ws, date);
    if (open) return { jobId: open.jobId };
    await chrome.storage.local.remove(this.cardKey("error", ws));
    const job = await this.deps.engine.create("date_card", { kind: "date_card", title: `\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 ${date}`, date, ...batchId ? { batchId } : {}, workspaceId: ws });
    this.deps.log.info(`\u0E2A\u0E31\u0E48\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 ${date}`);
    this.deps.onChanged();
    return { jobId: job.jobId };
  }
  /** Port: the prompt for the job's workspace. */
  async dateCardPrompt(date, ws) {
    const id2 = ws ?? await this.deps.workspaceId();
    const settings = await this.dateCardSettings(id2);
    const style = this.effectiveStyle(settings, (await this.styles.load(id2)).entries, date);
    return { prompt: dateCardPrompt({ ...settings, style: style.from === "default" ? "" : style.text }, date), aspect: settings.aspect };
  }
  /* --------------------------- daily style (ADR-64) --------------------------- */
  /**
   * The style the card of `date` uses: auto on → that date's style, else the latest earlier one
   * (AI failed / not made yet), else the typed style; auto off → the typed style, as before.
   */
  effectiveStyle(settings, history, date) {
    if (settings.autoStyle) {
      const todays = history.find((h) => h.date === date);
      if (todays?.stylePrompt.trim()) return { text: todays.stylePrompt, from: "today" };
      const latest = history.filter((h) => h.date < date && h.stylePrompt.trim()).sort((a, b) => b.date.localeCompare(a.date))[0];
      if (latest) return { text: latest.stylePrompt, from: "latest" };
    }
    return settings.style.trim() ? { text: settings.style, from: "manual" } : { text: "", from: "default" };
  }
  async openStyleJob(ws, date) {
    return (await this.deps.jobs.listOpen()).find((j) => {
      const input = j.input;
      return j.type === "date_style" && input.date === date && (input.workspaceId ?? ws) === ws;
    });
  }
  async dailyStyleState(date) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw invalid("\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
    const ws = await this.deps.workspaceId();
    const settings = await this.dateCardSettings(ws);
    const history = await this.styles.load(ws);
    const style = history.entries.find((h) => h.date === date);
    const state = { date, autoStyle: settings.autoStyle, effective: this.effectiveStyle(settings, history.entries, date), ...style ? { style } : {} };
    const job = await this.openStyleJob(ws, date);
    if (job) {
      const progress = job.steps.find((x) => x.status === "RUNNING")?.progress?.message;
      state.generating = { jobId: job.jobId, ...progress ? { progress } : {} };
    }
    if (history.error?.date === date && !job) state.lastError = history.error.message;
    return state;
  }
  async startStyleJob(ws, date) {
    await this.styles.update(ws, (h) => {
      if (h.error?.date === date) delete h.error;
    });
    const job = await this.deps.engine.create("date_style", { kind: "date_style", title: `\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E ${date}`, date, workspaceId: ws });
    this.deps.log.info(`\u0E2A\u0E31\u0E48\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E\u0E02\u0E2D\u0E07\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 ${date}`);
    this.deps.onChanged();
    return job.jobId;
  }
  /**
   * Opening the Daily Update: with auto style on and no style yet for `date`, ask the AI once —
   * once per day even if it fails (a refresh never asks again; the button can).
   */
  async ensureDailyStyle(date) {
    const ws = await this.deps.workspaceId();
    const settings = await this.dateCardSettings(ws);
    const history = await this.styles.load(ws);
    const due = settings.enabled && settings.autoStyle && !history.entries.some((h) => h.date === date) && history.autoAttempted !== date && !await this.openStyleJob(ws, date);
    if (due) {
      await this.styles.update(ws, (h) => h.autoAttempted = date);
      await this.startStyleJob(ws, date);
    }
    return this.dailyStyleState(date);
  }
  /** "สร้างสไตล์ใหม่": a new style for `date` (no image is made, nothing is sent). */
  async generateDailyStyle(date) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw invalid("\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
    const ws = await this.deps.workspaceId();
    if ((await this.styles.load(ws)).entries.find((h) => h.date === date)?.locked) throw invalid("\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E02\u0E2D\u0E07\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49\u0E16\u0E39\u0E01\u0E25\u0E47\u0E2D\u0E01\u0E44\u0E27\u0E49 \u2014 \u0E1B\u0E25\u0E14\u0E25\u0E47\u0E2D\u0E01\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E43\u0E2B\u0E21\u0E48");
    const open = await this.openStyleJob(ws, date);
    if (open) return { jobId: open.jobId };
    return { jobId: await this.startStyleJob(ws, date) };
  }
  /** The user edits the day's style text (auto mode). */
  async saveDailyStyleText(date, text2) {
    const ws = await this.deps.workspaceId();
    const now = this.now();
    await this.styles.update(ws, (h) => {
      const e = h.entries.find((x) => x.date === date);
      if (e) Object.assign(e, { stylePrompt: text2.trim(), source: "edited", updatedAt: now });
      else h.entries.push({ date, stylePrompt: text2.trim(), source: "edited", locked: false, retries: 0, createdAt: now, updatedAt: now });
    });
    this.deps.onChanged();
    return this.dailyStyleState(date);
  }
  /** Lock = the day's style never changes automatically (the button too, until unlocked). */
  async setDailyStyleLock(date, locked) {
    const ws = await this.deps.workspaceId();
    const settings = await this.dateCardSettings(ws);
    const history = await this.styles.load(ws);
    const effective = this.effectiveStyle(settings, history.entries, date);
    const now = this.now();
    await this.styles.update(ws, (h) => {
      const e = h.entries.find((x) => x.date === date);
      if (e) Object.assign(e, { locked, updatedAt: now });
      else if (locked) h.entries.push({ date, stylePrompt: effective.text, source: "edited", locked: true, retries: 0, createdAt: now, updatedAt: now });
    });
    this.deps.onChanged();
    return this.dailyStyleState(date);
  }
  /** Port: what the style director knows — the shop and recent looks (never the card's text). */
  async dateStyleBrief(date, ws) {
    const id2 = ws ?? await this.deps.workspaceId();
    const settings = await this.dateCardSettings(id2);
    return { shopName: settings.shopName, business: settings.business.trim() || DEFAULT_BUSINESS, recent: recentDNA((await this.styles.load(id2)).entries, date) };
  }
  /** Port: the AI's style is accepted unless the user locked or edited that date's style meanwhile. */
  async dateStyleGenerated(input) {
    const ws = input.workspaceId ?? await this.deps.workspaceId();
    const now = this.now();
    const { proposal } = input;
    let kept = false;
    await this.styles.update(ws, (h) => {
      const existing = h.entries.find((x) => x.date === input.date);
      if (existing?.locked) {
        kept = true;
        return;
      }
      h.entries = h.entries.filter((x) => x.date !== input.date);
      h.entries.push({
        date: input.date,
        stylePrompt: proposal.visualPrompt,
        styleDNA: proposal.styleDNA,
        scene: proposal.scene,
        mood: proposal.mood,
        composition: proposal.composition,
        camera: proposal.camera,
        lighting: proposal.lighting,
        source: "ai",
        locked: false,
        retries: input.retries,
        createdAt: existing?.createdAt ?? now,
        updatedAt: now
      });
      if (h.error?.date === input.date) delete h.error;
    });
    if (kept) this.deps.log.info(`\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 ${input.date} \u0E16\u0E39\u0E01\u0E25\u0E47\u0E2D\u0E01\u0E44\u0E27\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19`);
    this.deps.onChanged();
  }
  /** Port: the style failed — the card keeps using the fallback style (Daily Update keeps working). */
  async dateStyleFailed(input) {
    const ws = input.workspaceId ?? await this.deps.workspaceId();
    await this.styles.update(ws, (h) => h.error = { date: input.date, message: input.message });
    this.deps.log.warn(`\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 (${input.date}): ${input.message} \u2014 \u0E43\u0E0A\u0E49\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E40\u0E14\u0E34\u0E21\u0E41\u0E17\u0E19`);
    this.deps.onChanged();
  }
  /** Port: card made → remember it; a batch waiting for it starts now. */
  async dateCardGenerated(input) {
    const ws = input.workspaceId ?? await this.deps.workspaceId();
    const card = { date: input.date, assetId: input.assetId, createdAt: this.now() };
    await chrome.storage.local.set({ [this.cardKey("image", ws)]: card });
    this.deps.onChanged();
    const waiting = input.batchId ? await this.deps.repo.batches.find(ws, input.batchId) : void 0;
    if (waiting?.dateCard && waiting.dateCard.status !== "SKIPPED") {
      await this.updateBatch(ws, waiting.id, (b) => b.dateCard = { repeat: waiting.dateCard.repeat, status: "READY", assetId: input.assetId });
      await this.startBatch(waiting.id);
    }
  }
  /** Port: generation failed — the waiting batch stays unsent; the user retries or sends without it. */
  async dateCardFailed(input) {
    const ws = input.workspaceId ?? await this.deps.workspaceId();
    const batch = input.batchId ? await this.deps.repo.batches.find(ws, input.batchId) : void 0;
    if (batch?.dateCard) {
      await this.updateBatch(ws, batch.id, (b) => b.dateCard = { repeat: batch.dateCard.repeat, status: "FAILED", error: input.message });
    }
    const date = batch?.date;
    if (date) await chrome.storage.local.set({ [this.cardKey("error", ws)]: { date, message: input.message } });
    this.deps.log.warn(`\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08: ${input.message}${batch ? ` \u2014 Batch "${batch.name}" \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07` : ""}`);
    this.deps.onChanged();
  }
  /** Sends the batch without its date card (card sends cancelled). */
  async skipDateCard(batchId) {
    const ws = await this.deps.workspaceId();
    const batch = await this.deps.repo.batches.get(ws, batchId);
    if (!batch.dateCard) throw invalid("Batch \u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E21\u0E35\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48");
    if (batch.dateCard.jobId) await this.deps.engine.cancel(batch.dateCard.jobId).catch(() => void 0);
    await this.updateBatch(ws, batchId, (b) => b.dateCard = { repeat: batch.dateCard.repeat, status: "SKIPPED" });
    for (const s of await this.deps.repo.sendsOfBatch(batchId)) {
      if (s.kind === "date_card" && s.status === "READY" && !s.jobId) await this.deps.repo.updateSend(s.id, (x) => x.status = "CANCELLED", this.now());
    }
    return this.startBatch(batchId);
  }
  async updateBatch(ws, batchId, mutate) {
    const b = await this.deps.repo.batches.get(ws, batchId);
    mutate(b);
    b.updatedAt = this.now();
    await this.deps.repo.batches.put(b);
    return b;
  }
  /* -------------------------------- queue --------------------------------- */
  async jobOf(s) {
    return s.jobId ? this.deps.jobs.get(s.jobId).catch(() => null) : null;
  }
  /** Recorded outcome wins; otherwise the live job decides. */
  async view(s) {
    if (s.status !== "READY") return { ...s, view: s.status };
    const job = await this.jobOf(s);
    if (!job) return { ...s, view: "READY" };
    const running = job.steps.find((x) => x.status === "RUNNING");
    const progress = running?.progress?.message;
    const map = { PENDING: "QUEUED", RUNNING: "SENDING", PAUSED: "PAUSED", SUCCESS: "SENT", FAILED: "FAILED", CANCELLED: "CANCELLED" };
    const v = { ...s, view: map[job.status] };
    const beforePost = job.error?.detail?.beforePost === true;
    const preparing = job.steps.find((x) => x.id === "send_message")?.checkpoint?.phase === "post_preparing";
    if (job.status === "PAUSED" && job.pauseReason !== "USER" && job.pauseReason !== "LICENSE_REQUIRED" && !beforePost && !preparing) v.needsCheck = true;
    if (job.status === "PAUSED" && job.error) v.error = errorOf(job.error);
    if (job.error && job.status === "FAILED") v.error = errorOf(job.error);
    if (progress && job.status === "RUNNING") v.progress = progress;
    return v;
  }
  async listBatches(limit = 30) {
    const ws = await this.deps.workspaceId();
    const batches = (await this.deps.repo.batches.list(ws)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit);
    return Promise.all(batches.map((b) => this.batchView(b.id)));
  }
  async batchView(batchId) {
    const ws = await this.deps.workspaceId();
    const batch = await this.deps.repo.batches.get(ws, batchId);
    const sends = await Promise.all((await this.deps.repo.sendsOfBatch(batchId)).map((s) => this.view(s)));
    const counts = { READY: 0, QUEUED: 0, SENDING: 0, PAUSED: 0, SENT: 0, PENDING_APPROVAL: 0, FAILED: 0, CANCELLED: 0 };
    for (const s of sends) counts[s.view]++;
    const open = counts.QUEUED + counts.SENDING + (batch.dateCard?.status === "GENERATING" ? 1 : 0);
    const state = counts.READY === sends.length && open === 0 ? "READY" : open > 0 ? "RUNNING" : counts.PAUSED > 0 ? "PAUSED" : counts.CANCELLED === sends.length ? "CANCELLED" : counts.FAILED > 0 || counts.CANCELLED > 0 ? "DONE_WITH_ERRORS" : counts.READY > 0 ? "READY" : "DONE";
    const view = { batch, sends, counts, state };
    const current = sends.find((s) => s.view === "SENDING") ?? sends.find((s) => s.view === "QUEUED");
    if (current) view.current = current;
    return view;
  }
  /** Queues every READY send of the batch, in order. Destinations must be verified first. */
  async startBatch(batchId) {
    const ws = await this.deps.workspaceId();
    let batch = await this.deps.repo.batches.get(ws, batchId);
    const destinations = await Promise.all(batch.destinationIds.map((id2) => this.deps.repo.destinations.find(ws, id2)));
    const missing = destinations.findIndex((d) => !d);
    if (missing >= 0) throw invalid("\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E02\u0E2D\u0E07 Batch \u0E19\u0E35\u0E49\u0E16\u0E39\u0E01\u0E25\u0E1A\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27");
    const unverified = destinations.filter((d) => d && !isFeed(d) && !d.verifiedTitle).map((d) => d.name);
    if (unverified.length) throw invalid(`\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E14 "\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E0A\u0E17" / "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E01\u0E25\u0E38\u0E48\u0E21" / "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07" \u0E02\u0E2D\u0E07\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07: ${unverified.join(", ")}`);
    const byId = new Map(destinations.map((d) => [d.id, d]));
    const card = batch.dateCard;
    if (card && (card.status === "WAITING" || card.status === "FAILED" || card.status === "GENERATING")) {
      const ready = await this.cardFor(ws, batch.date);
      if (!ready) {
        if (card.status !== "GENERATING") {
          const { jobId } = await this.generateDateCard(batch.date, batchId);
          batch = await this.updateBatch(ws, batchId, (b) => b.dateCard = { repeat: card.repeat, status: "GENERATING", jobId });
          this.deps.log.info(`Batch "${batch.name}" \u0E23\u0E2D\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 \u2014 \u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E14\u0E49\u0E27\u0E22 ChatGPT \u0E41\u0E25\u0E49\u0E27\u0E08\u0E30\u0E40\u0E23\u0E34\u0E48\u0E21\u0E2A\u0E48\u0E07\u0E40\u0E2D\u0E07`);
          this.deps.onChanged();
        }
        return { queued: 0, generating: true };
      }
      batch = await this.updateBatch(ws, batchId, (b) => b.dateCard = { repeat: card.repeat, status: "READY", assetId: ready.assetId });
    }
    if (batch.dateCard?.assetId) {
      const assetId = batch.dateCard.assetId;
      for (const s of await this.deps.repo.sendsOfBatch(batchId)) {
        if (s.kind === "date_card" && s.status === "READY" && !s.jobId && s.snapshot.imageAssetIds[0] !== assetId) {
          await this.deps.repo.updateSend(s.id, (x) => x.snapshot.imageAssetIds = [assetId], this.now());
        }
      }
    }
    let queued = 0;
    for (const s of await this.deps.repo.sendsOfBatch(batchId)) {
      if (s.status !== "READY" || s.jobId) continue;
      await this.enqueue(s, byId.get(s.destinationId));
      queued++;
    }
    const now = this.now();
    await this.deps.repo.batches.put({ ...await this.deps.repo.batches.get(ws, batchId), startedAt: batch.startedAt ?? now, updatedAt: now });
    for (const d of byId.values()) await this.deps.repo.destinations.put({ ...d, lastUsedAt: now });
    this.deps.log.info(`\u0E40\u0E23\u0E34\u0E48\u0E21\u0E2A\u0E48\u0E07 Batch "${batch.name}" \u2014 ${queued} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E02\u0E49\u0E32\u0E04\u0E34\u0E27`);
    this.deps.onChanged();
    return { queued };
  }
  async enqueue(s, d) {
    await this.deps.repo.updateSend(s.id, (x) => {
      x.snapshot.expectedTitle = d.verifiedTitle ?? "";
      x.snapshot.chatUrl = d.chatReference.url;
      x.snapshot.threadId = d.chatReference.threadId;
    }, this.now());
    const job = await this.deps.engine.create("product_send", {
      kind: "product_send",
      title: `${d.type === "FACEBOOK_GROUP_CHAT" || d.type === "LINE_OPENCHAT" ? "\u0E2A\u0E48\u0E07" : "\u0E42\u0E1E\u0E2A\u0E15\u0E4C"}: ${s.snapshot.productName} \u2192 ${d.name}`,
      sendId: s.id,
      channel: s.snapshot.channel ?? "chat",
      batchId: s.batchId,
      workspaceId: s.workspaceId
    });
    await this.deps.repo.updateSend(s.id, (x) => {
      x.jobId = job.jobId;
      x.attempts += 1;
      delete x.error;
    }, this.now());
  }
  async pauseBatch(batchId) {
    let paused = 0;
    for (const s of (await this.batchView(batchId)).sends) {
      if ((s.view === "QUEUED" || s.view === "SENDING") && s.jobId) await this.deps.engine.pause(s.jobId).then(() => paused++).catch(() => void 0);
    }
    this.deps.onChanged();
    return { paused };
  }
  async resumeBatch(batchId) {
    let resumed = 0;
    for (const s of (await this.batchView(batchId)).sends) {
      if (s.view !== "PAUSED" || !s.jobId) continue;
      const job = await this.jobOf(s);
      if (job?.status === "PAUSED" && (job.pauseReason === "USER" || job.pauseReason === "LICENSE_REQUIRED")) await this.deps.engine.resume(job.jobId).then(() => resumed++).catch(() => void 0);
    }
    this.deps.onChanged();
    return { resumed };
  }
  /** Stops the batch: queued/paused sends are cancelled. Sent messages stay sent. */
  async cancelBatch(batchId) {
    let cancelled = 0;
    const ws = await this.deps.workspaceId();
    const batch = await this.deps.repo.batches.get(ws, batchId);
    if (batch.dateCard?.status === "GENERATING") {
      if (batch.dateCard.jobId) await this.deps.engine.cancel(batch.dateCard.jobId).catch(() => void 0);
      await this.updateBatch(ws, batchId, (b) => b.dateCard = { repeat: batch.dateCard.repeat, status: "SKIPPED" });
    }
    for (const s of (await this.batchView(batchId)).sends) {
      if (s.view === "READY") {
        await this.deps.repo.updateSend(s.id, (x) => x.status = "CANCELLED", this.now());
        cancelled++;
      } else if (["QUEUED", "SENDING", "PAUSED"].includes(s.view) && s.jobId) {
        await this.deps.engine.cancel(s.jobId).then(() => cancelled++).catch(() => void 0);
      }
    }
    this.deps.onChanged();
    return { cancelled };
  }
  /** Retries ONE failed/cancelled send (never the successful ones — no duplicate messages). */
  async retrySend(sendId) {
    const ws = await this.deps.workspaceId();
    const s = await this.deps.repo.sends.get(ws, sendId);
    const v = await this.view(s);
    if (v.view !== "FAILED" && v.view !== "CANCELLED") throw invalid("\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33\u0E44\u0E14\u0E49\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E17\u0E35\u0E48\u0E25\u0E49\u0E21\u0E40\u0E2B\u0E25\u0E27\u0E2B\u0E23\u0E37\u0E2D\u0E16\u0E39\u0E01\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01");
    const d = await this.deps.repo.destinations.get(ws, s.destinationId).catch(() => {
      throw invalid("\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07\u0E02\u0E2D\u0E07\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E16\u0E39\u0E01\u0E25\u0E1A\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27");
    });
    if (!isFeed(d) && !d.verifiedTitle) throw invalid(`\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E14 "\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E0A\u0E17" / "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E01\u0E25\u0E38\u0E48\u0E21" / "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07" \u0E02\u0E2D\u0E07 ${d.name} \u0E01\u0E48\u0E2D\u0E19`);
    await this.deps.repo.updateSend(s.id, (x) => {
      x.status = "READY";
      delete x.jobId;
    }, this.now());
    await this.enqueue({ ...s, status: "READY" }, d);
    this.deps.onChanged();
    return this.view(await this.deps.repo.sends.get(ws, sendId));
  }
  /**
   * A send that may have gone out (interrupted / unconfirmed) after the user checked the chat:
   * "sent" records it as sent; "not_sent" sends it again (only the text when the images are already
   * recorded as delivered); "images_only" = the photos are in the chat but the text is not → send the text.
   */
  async resolveUnconfirmed(sendId, outcome) {
    const ws = await this.deps.workspaceId();
    const s = await this.deps.repo.sends.get(ws, sendId);
    const v = await this.view(s);
    const unsure = v.needsCheck || v.view === "FAILED" && v.error?.mayHaveSent;
    if (!unsure) throw invalid("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E23\u0E2D\u0E15\u0E23\u0E27\u0E08");
    if (outcome === "pending_approval" && s.snapshot.channel !== "group") throw invalid("\u0E2A\u0E16\u0E32\u0E19\u0E30\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E43\u0E0A\u0E49\u0E44\u0E14\u0E49\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21");
    const job = await this.jobOf(s);
    if (outcome === "images_only") {
      if (s.snapshot.channel === "group") throw invalid("\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E19\u0E1A\u0E23\u0E39\u0E1B\u0E01\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E01\u0E31\u0E19 \u2014 \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E27\u0E08\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E30\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E01\u0E48\u0E2D\u0E19");
      if (!s.snapshot.imageAssetIds.length) throw invalid("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B");
      await this.deps.repo.updateSend(s.id, (x) => {
        x.imagesSentAt = x.imagesSentAt ?? this.now();
      }, this.now());
      this.deps.log.info(`\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E27\u0E48\u0E32\u0E23\u0E39\u0E1B\u0E02\u0E36\u0E49\u0E19\u0E41\u0E25\u0E49\u0E27 \u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21: ${s.snapshot.productName} \u2192 ${s.snapshot.destinationName}`);
    }
    if (outcome === "sent" || outcome === "pending_approval") {
      if (job && OPEN_JOB.includes(job.status)) await this.deps.engine.cancel(job.jobId).catch(() => void 0);
      await this.deps.repo.updateSend(s.id, (x) => {
        x.status = outcome === "pending_approval" ? "PENDING_APPROVAL" : "SENT";
        x.sentAt = x.sentAt ?? this.now();
        delete x.error;
        delete x.confirmedBy;
      }, this.now());
      this.deps.log.info(`\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19${outcome === "pending_approval" ? "\u0E27\u0E48\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34" : "\u0E27\u0E48\u0E32\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27"}: ${s.snapshot.productName} \u2192 ${s.snapshot.destinationName}`);
    } else if (job?.status === "PAUSED") {
      await this.deps.engine.resume(job.jobId);
    } else {
      await this.deps.repo.updateSend(s.id, (x) => {
        x.status = "FAILED";
        if (x.error) delete x.error.mayHaveSent;
      }, this.now());
      await this.retrySend(sendId);
    }
    this.deps.onChanged();
    return this.view(await this.deps.repo.sends.get(ws, sendId));
  }
  async deleteBatch(batchId) {
    const v = await this.batchView(batchId);
    if (v.sends.some((s) => ["QUEUED", "SENDING", "PAUSED"].includes(s.view))) throw invalid("Batch \u0E22\u0E31\u0E07\u0E2A\u0E48\u0E07\u0E2D\u0E22\u0E39\u0E48 \u2014 \u0E2B\u0E22\u0E38\u0E14/\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E01\u0E48\u0E2D\u0E19");
    if (v.sends.some((s) => s.view === "SENT" || s.view === "PENDING_APPROVAL")) throw invalid("Batch \u0E19\u0E35\u0E49\u0E2A\u0E48\u0E07\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27\u0E1A\u0E32\u0E07\u0E2A\u0E48\u0E27\u0E19 \u2014 \u0E40\u0E01\u0E47\u0E1A\u0E44\u0E27\u0E49\u0E40\u0E1B\u0E47\u0E19\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34 (\u0E25\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49)");
    const ws = await this.deps.workspaceId();
    for (const s of v.sends) await this.deps.repo.sends.delete(ws, s.id);
    await this.deps.repo.batches.delete(ws, batchId);
    this.deps.onChanged();
  }
  /* ------------------------------- history -------------------------------- */
  /** Finished sends, newest first (immutable snapshot + result). */
  async history(limit = 200) {
    const ws = await this.deps.workspaceId();
    const batches = new Map((await this.deps.repo.batches.list(ws)).map((b) => [b.id, b]));
    const sends = await Promise.all((await this.deps.repo.sends.list(ws)).map((s) => this.view(s)));
    return sends.filter((s) => s.view === "SENT" || s.view === "PENDING_APPROVAL" || s.view === "FAILED" || s.view === "CANCELLED").map((s) => ({ ...s, batchName: batches.get(s.batchId)?.name ?? "", batchDate: batches.get(s.batchId)?.date ?? "" })).sort((a, b) => (b.sentAt ?? b.updatedAt).localeCompare(a.sentAt ?? a.updatedAt)).slice(0, limit);
  }
  async openSends(ws) {
    const sends = await Promise.all((await this.deps.repo.sends.list(ws)).filter((s) => s.status === "READY" && s.jobId).map((s) => this.view(s)));
    return sends.filter((s) => ["QUEUED", "SENDING", "PAUSED"].includes(s.view));
  }
  /* --------------------------- workflow runtime --------------------------- */
  getSend(sendId) {
    return this.deps.repo.sendById(sendId);
  }
  async markSent(sendId, confirmedBy, chatTitle) {
    await this.deps.repo.updateSend(sendId, (x) => {
      x.status = "SENT";
      x.sentAt = this.now();
      x.confirmedBy = confirmedBy;
      delete x.error;
    }, this.now());
    if (chatTitle) await this.rememberChatTitle(sendId, chatTitle).catch(() => void 0);
    this.deps.onChanged();
  }
  async markPendingApproval(sendId) {
    await this.deps.repo.updateSend(sendId, (x) => {
      if (x.snapshot.channel !== "group") throw invalid("\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21");
      if (x.status === "SENT") return;
      x.status = "PENDING_APPROVAL";
      x.sentAt = this.now();
      x.confirmedBy = "dom";
      delete x.error;
    }, this.now());
    this.deps.onChanged();
  }
  /** The group was renamed (same thread id): remember the new name, no re-verify needed (ADR-70). */
  async rememberChatTitle(sendId, title) {
    const send = await this.deps.repo.sendById(sendId);
    const d = await this.deps.repo.destinations.get(send.workspaceId, send.destinationId);
    if (d.type !== "FACEBOOK_GROUP_CHAT" || !d.verifiedTitle || d.verifiedTitle === title) return;
    await this.deps.repo.destinations.put({ ...d, verifiedTitle: title, verifiedAt: this.now(), updatedAt: this.now() });
    if (!sameChatName(d.verifiedTitle, title)) this.deps.log.info(`\u0E01\u0E25\u0E38\u0E48\u0E21 ${d.name} \u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E0A\u0E37\u0E48\u0E2D\u0E1A\u0E19 Facebook \u0E40\u0E1B\u0E47\u0E19 "${title}" \u2014 \u0E08\u0E33\u0E0A\u0E37\u0E48\u0E2D\u0E43\u0E2B\u0E21\u0E48\u0E41\u0E25\u0E49\u0E27`);
  }
  async markImagesSent(sendId) {
    await this.deps.repo.updateSend(sendId, (x) => {
      x.imagesSentAt = this.now();
    }, this.now());
    this.deps.onChanged();
  }
  async markEnded(sendId, status, error) {
    await this.deps.repo.updateSend(sendId, (x) => {
      if (x.status === "SENT" || x.status === "PENDING_APPROVAL") return;
      x.status = status;
      if (error) x.error = errorOf(error);
    }, this.now());
    this.deps.onChanged();
  }
  /** Pauses every queued send of the workspace (Facebook restricted sending). */
  async haltQueue(reason) {
    const ws = await this.deps.workspaceId();
    let held = 0;
    for (const s of await this.openSends(ws)) {
      if ((s.snapshot.channel ?? "chat") === "chat" && s.view === "QUEUED" && s.jobId) await this.deps.engine.pause(s.jobId).then(() => held++).catch(() => void 0);
    }
    this.deps.log.warn(`\u0E2B\u0E22\u0E38\u0E14\u0E04\u0E34\u0E27\u0E2A\u0E48\u0E07\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 (${held} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23): ${reason}`);
    this.deps.onChanged();
  }
  async lastAttemptAt(channel = "chat") {
    const key = `${LAST_ATTEMPT_KEY}:${channel}`;
    const v = (await chrome.storage.local.get(key))[key];
    return typeof v === "number" ? v : 0;
  }
  async setLastAttemptAt(ms, channel = "chat") {
    await chrome.storage.local.set({ [`${LAST_ATTEMPT_KEY}:${channel}`]: ms });
  }
  static today(clock) {
    return today(clock);
  }
  static openJobStatuses = OPEN_JOB;
};
function errorOf(e) {
  const detail = e.detail;
  return { code: e.code, message: e.message, userMessage: e.userMessage, ...detail?.mayHaveSent ? { mayHaveSent: true } : {} };
}

// src/shared/protocol.ts
var PROTOCOL_VERSION = 1;
var counter = 0;
function newRequestId() {
  counter = (counter + 1) % 1e6;
  return `${Date.now().toString(36)}-${counter.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function envelope(type, payload, id2 = newRequestId()) {
  return { v: PROTOCOL_VERSION, id: id2, type, payload };
}
function isEnvelope(value) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  return v["v"] === PROTOCOL_VERSION && typeof v["id"] === "string" && typeof v["type"] === "string";
}
function ok(data) {
  return { ok: true, data };
}
function failure(err) {
  return { ok: false, error: toAppError(err).toJSON() };
}
function isResult(value) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  if (v["ok"] === true) return "data" in v;
  return v["ok"] === false && isAppErrorJSON(v["error"]);
}
function unwrap(result, context) {
  if (!isResult(result)) {
    throw new AppError(ErrorCode.INTERNAL, `${context}: malformed response`, { detail: { result } });
  }
  if (result.ok) return result.data;
  throw fromJSON(result.error);
}
var BRIDGE_PROGRESS = "bridge.progress";
var BRIDGE_CANCEL = "bridge.cancel";
var PORT_TRANSFER_TO_EXTENSION = "acf-transfer-in:";
var PORT_TRANSFER_TO_PAGE = "acf-transfer-out:";
var PORT_UI_EVENTS = "acf-ui-events";
var STORAGE_KEYS = {
  openJobs: "jobs:open",
  settings: "settings",
  workspaces: "workspaces"
};

// src/shared/workspace.ts
var LOCAL_TENANT_ID = "local";
var DEFAULT_WORKSPACE_ID = "ws_default";
function defaultWorkspace(now, legacy) {
  return {
    schemaVersion: 1,
    id: DEFAULT_WORKSPACE_ID,
    tenantId: LOCAL_TENANT_ID,
    name: "\u0E23\u0E49\u0E32\u0E19\u0E02\u0E2D\u0E07\u0E09\u0E31\u0E19",
    dna: {
      brandName: "",
      domain: "general",
      audience: "",
      tone: "",
      voice: legacy?.voice?.trim() ?? "",
      pillars: [],
      preferredTerms: [],
      forbiddenTerms: [],
      ctaPreference: "",
      visualStyle: "",
      rules: legacy?.rules?.trim() ?? ""
    },
    createdAt: now,
    updatedAt: now
  };
}
var terms = array(string({ min: 1, max: 80 }), { max: 40 });
var validateContentDNA = (value, path = "dna") => object({
  brandName: string({ max: 80 }),
  domain: string({ min: 1, max: 40, pattern: /^[a-z_]+$/ }),
  audience: string({ max: 500 }),
  tone: string({ max: 120 }),
  voice: string({ max: 2e3 }),
  pillars: array(string({ min: 1, max: 60 }), { max: 12 }),
  preferredTerms: terms,
  forbiddenTerms: terms,
  ctaPreference: string({ max: 300 }),
  visualStyle: string({ max: 1e3 }),
  rules: string({ max: 4e3 })
})(value, path);
var validateWorkspace = (value, path = "workspace") => object({
  schemaVersion: literal(1),
  id: string({ min: 1, max: 64 }),
  tenantId: string({ min: 1, max: 64 }),
  name: string({ min: 1, max: 80 }),
  dna: validateContentDNA,
  createdAt: string({ max: 40 }),
  updatedAt: string({ max: 40 })
})(value, path);

// src/storage/workspace-repo.ts
var KEY = STORAGE_KEYS.workspaces;
var WorkspaceRepo = class {
  constructor(now, legacy) {
    this.now = now;
    this.legacy = legacy;
  }
  async load() {
    const raw = (await chrome.storage.local.get(KEY))[KEY];
    const items = [];
    for (const w of Array.isArray(raw?.items) ? raw.items : []) {
      try {
        items.push(validateWorkspace(w));
      } catch {
      }
    }
    if (!items.length) {
      const seeded = defaultWorkspace(this.now(), await this.legacy());
      const stored = { items: [seeded], activeId: seeded.id };
      await chrome.storage.local.set({ [KEY]: stored });
      return stored;
    }
    const activeId = items.some((w) => w.id === raw?.activeId) ? raw?.activeId : items[0].id;
    return { items, activeId };
  }
  async list() {
    return (await this.load()).items;
  }
  async active() {
    const s = await this.load();
    return s.items.find((w) => w.id === s.activeId) ?? s.items[0];
  }
  /** The workspace by id; unknown/absent id = the default workspace (records made before v0.13). */
  async get(id2) {
    const s = await this.load();
    return id2 && s.items.find((w) => w.id === id2) || s.items.find((w) => w.id === DEFAULT_WORKSPACE_ID) || s.items[0];
  }
  /**
   * The workspace of an account (Cloud Sync, ADR-66), made active. The first account to sync on this
   * browser claims the existing (unclaimed) workspace — its local data migrates to that account; any
   * other account gets its own new, empty workspace, so one account's data never goes to another.
   */
  async forTenant(tenantId) {
    const s = await this.load();
    let w = s.items.find((x) => x.tenantId === tenantId);
    if (!w) {
      const unclaimed = s.items.find((x) => x.tenantId === LOCAL_TENANT_ID);
      if (unclaimed) {
        unclaimed.tenantId = tenantId;
        unclaimed.updatedAt = this.now();
        w = unclaimed;
      } else {
        const base = defaultWorkspace(this.now());
        w = { ...base, id: `ws_${tenantId.replace(/[^\w-]/g, "").slice(-24)}`, tenantId };
        s.items.push(w);
      }
    }
    s.activeId = w.id;
    await chrome.storage.local.set({ [KEY]: s });
    return w;
  }
  async update(id2, patch) {
    const s = await this.load();
    const w = s.items.find((x) => x.id === id2);
    if (!w) throw new AppError(ErrorCode.NOT_FOUND, `Workspace ${id2} not found`, { userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A Workspace" });
    if (patch.name !== void 0) w.name = patch.name.trim() || w.name;
    if (patch.dna) w.dna = validateContentDNA(patch.dna);
    w.updatedAt = this.now();
    validateWorkspace(w);
    await chrome.storage.local.set({ [KEY]: s });
    return w;
  }
};

// src/core/constants.ts
var WATCHDOG_PERIOD_MIN = 0.5;
var WATCHDOG_ALARM = "acf-watchdog";
var IN_MEMORY_RETRY_WAIT_MAX_MS = 25e3;
var RATE_LIMIT_COOLDOWN_MS = 5 * 6e4;
var RATE_LIMIT_MAX_WAITS = 3;
var PROGRESS_PERSIST_INTERVAL_MS = 2e3;
var LOG_RETENTION = { maxEntries: 5e3 };
var JOB_HISTORY_LIMIT = 500;
var CLEANUP_INTERVAL_MS = 6 * 60 * 6e4;
var DAY_MS = 24 * 60 * 6e4;

// src/shared/types.ts
var TERMINAL_JOB_STATUSES = ["SUCCESS", "FAILED", "CANCELLED"];
function isToolInput(input) {
  return "kind" in input;
}
function jobTitle(input) {
  return isToolInput(input) ? input.title : input.topic;
}
var LOG_LEVEL_ORDER = { DEBUG: 10, INFO: 20, WARN: 30, ERROR: 40 };

// src/core/pause.ts
var PauseSignal = class extends Error {
  constructor(reason, message, pendingInput) {
    super(message);
    this.reason = reason;
    this.pendingInput = pendingInput;
    this.name = "PauseSignal";
  }
};

// src/core/retry.ts
var DEFAULT_BACKOFF = { baseMs: 2e3, factor: 2, maxMs: 6e4, jitter: 0.2 };
function backoffDelay(attempt2, policy = DEFAULT_BACKOFF, random = Math.random) {
  const raw = Math.min(policy.maxMs, policy.baseMs * policy.factor ** Math.max(0, attempt2 - 1));
  const spread = raw * policy.jitter;
  return Math.round(raw - spread + random() * spread * 2);
}

// src/core/job-engine.ts
function notStarted(job) {
  return job.steps.every((s) => s.status === "PENDING" || s.status === "SKIPPED");
}
var SHUTDOWN = /browser is shutting down|extension context invalidated/i;
var JobEngine = class {
  constructor(deps) {
    this.deps = deps;
    this.log = deps.logger.scope("engine");
  }
  workflows = /* @__PURE__ */ new Map();
  /** The executing job of each lane. */
  active = /* @__PURE__ */ new Map();
  pumping = false;
  /** A pump was asked for while one was running: run again when it ends (jobs created meanwhile). */
  pumpAgain = false;
  log;
  /** Registers the workflow of one job type (its steps receive that type's input). */
  register(workflow) {
    this.workflows.set(workflow.type, workflow);
  }
  isActive(jobId) {
    return this.runOf(jobId) !== void 0;
  }
  runOf(jobId) {
    for (const run of this.active.values()) if (run.jobId === jobId) return run;
    return void 0;
  }
  lane(job) {
    return this.deps.laneOf?.(job) ?? "main";
  }
  async create(type, input, contentId) {
    const wf = this.workflow(type);
    const now = this.deps.clock.iso();
    const job = {
      schemaVersion: 1,
      jobId: newId("job_"),
      type,
      status: "PENDING",
      currentStep: null,
      input,
      context: {},
      steps: wf.steps.map(
        (s) => ({
          id: s.id,
          label: s.label,
          status: "PENDING",
          attempts: 0,
          maxAttempts: s.maxAttempts,
          resumePolicy: s.resumePolicy
        })
      ),
      createdAt: now,
      updatedAt: now
    };
    if (contentId) job.contentId = contentId;
    await this.deps.repo.add(job);
    this.deps.logger.scope("engine", job.jobId, job.type).info(`JOB CREATED (${wf.label})`, { topic: jobTitle(input) });
    void this.pump();
    return job;
  }
  /* ----------------------------- user commands ----------------------------- */
  async pause(jobId) {
    const job = await this.deps.repo.get(jobId);
    if (job.status === "PENDING") {
      return this.update(jobId, (j) => {
        j.status = "PAUSED";
        j.pauseReason = "USER";
      });
    }
    if (job.status !== "RUNNING") throw invalidState("pause", job);
    return this.update(jobId, (j) => {
      j.pauseRequested = true;
    });
  }
  async resume(jobId) {
    const job = await this.deps.repo.get(jobId);
    if (job.status !== "PAUSED") throw invalidState("resume", job);
    const updated = await this.update(jobId, (j) => {
      j.status = j.pauseReason === "LICENSE_REQUIRED" ? "PENDING" : "RUNNING";
      delete j.pauseReason;
      delete j.pauseRequested;
      delete j.error;
    });
    void this.pump();
    return updated;
  }
  async approve(jobId) {
    const job = await this.deps.repo.get(jobId);
    if (job.status !== "PAUSED" || job.pauseReason !== "AWAITING_APPROVAL") throw invalidState("approve", job);
    await this.update(jobId, (j) => {
      j.approved = true;
    });
    return this.resume(jobId);
  }
  async provideInput(jobId, stepId, text2) {
    const job = await this.deps.repo.get(jobId);
    const pending = job.pendingInput;
    if (job.status !== "PAUSED" || pending?.stepId !== stepId) throw invalidState("provideInput", job);
    await this.update(jobId, (j) => {
      j.providedInputs = { ...j.providedInputs ?? {}, [pending.key]: text2 };
      delete j.pendingInput;
    });
    return this.resume(jobId);
  }
  async cancel(jobId) {
    const job = await this.deps.repo.get(jobId);
    if (job.status === "SUCCESS" || job.status === "FAILED" || job.status === "CANCELLED") {
      throw invalidState("cancel", job);
    }
    const run = this.runOf(jobId);
    if (run) {
      const updated = await this.update(jobId, (j) => {
        j.cancelRequested = true;
      });
      const reason = new AppError(ErrorCode.CANCELLED, "Cancelled by user");
      run.stepController?.abort(reason);
      run.controller.abort(reason);
      return updated;
    }
    const ended = await this.finish(jobId, "CANCELLED", new AppError(ErrorCode.CANCELLED, "Cancelled by user"));
    void this.pump();
    return ended;
  }
  /** Retry a FAILED job, or a PAUSED(INTERRUPTED) one, from the step that stopped it. */
  async retry(jobId) {
    const job = await this.deps.repo.get(jobId);
    const reset = (j) => {
      const step = j.steps.find((s) => s.status === "FAILED" || s.status === "PENDING" || s.status === "RETRY");
      if (step) {
        step.status = "PENDING";
        step.attempts = 0;
        delete step.error;
        delete step.nextRetryAt;
        delete step.checkpoint;
      }
      for (const s of j.steps) if (s.status === "CANCELLED") s.status = "PENDING";
      j.status = "PENDING";
      delete j.error;
      delete j.pauseReason;
      delete j.pauseRequested;
    };
    let updated;
    if (job.status === "FAILED") {
      updated = await this.deps.repo.reopen(jobId, reset, this.deps.clock.iso());
    } else if (job.status === "PAUSED") {
      updated = await this.update(jobId, reset);
    } else {
      throw invalidState("retry", job);
    }
    this.deps.logger.scope("engine", jobId, updated.type).info("JOB RETRY requested by user");
    void this.pump();
    return updated;
  }
  /* ------------------------------ scheduling ------------------------------- */
  /**
   * Called on SW start and by the watchdog: repairs jobs whose executor died with the previous
   * service worker instance (ARCHITECTURE §4.4), detects stalls, then pumps the queue.
   */
  async watchdog() {
    const settings = await this.deps.getSettings();
    const now = this.deps.clock.now();
    for (const run of this.active.values()) {
      if (now - run.lastProgressAt <= settings.timeouts.progressStallMs) continue;
      this.log.warn("Step stalled \u2014 aborting", { jobId: run.jobId });
      run.stepController?.abort(new AppError(ErrorCode.PROGRESS_STALLED, `No progress for ${settings.timeouts.progressStallMs} ms`, run.lastProgressMessage ? { userMessage: `\u0E07\u0E32\u0E19\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E27\u0E32\u0E21\u0E04\u0E37\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E32\u0E19\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B \u2014 \u0E04\u0E49\u0E32\u0E07\u0E17\u0E35\u0E48: ${run.lastProgressMessage}` } : {}));
    }
    for (const job of await this.deps.repo.listOpen()) {
      if (job.status !== "RUNNING" || this.isActive(job.jobId)) continue;
      const step = job.steps.find((s) => s.status === "RUNNING");
      if (!step) continue;
      await this.recoverOrphanStep(job, step);
    }
    await this.pump();
  }
  async recoverOrphanStep(job, step) {
    const log = this.deps.logger.scope("engine", job.jobId, job.type);
    if (step.resumePolicy === "manual" || step.attempts >= step.maxAttempts) {
      const err = new AppError(ErrorCode.INTERRUPTED, `Step ${step.id} interrupted by restart`);
      log.warn(`Step "${step.label}" interrupted \u2014 waiting for user`, { policy: step.resumePolicy });
      await this.update(job.jobId, (j) => {
        const s = findStep(j, step.id);
        s.status = "PENDING";
        s.error = err.toJSON();
        j.status = "PAUSED";
        j.pauseReason = "INTERRUPTED";
        j.error = err.toJSON();
      });
      return;
    }
    log.info(`Recovering step "${step.label}" after restart (${step.resumePolicy})`);
    await this.update(job.jobId, (j) => {
      findStep(j, step.id).status = "PENDING";
    });
  }
  /** License gate (deps.canStart) for a job about to start; a refused job is paused with the reason. */
  async mayStart(job) {
    if (!this.deps.canStart || job.status === "RUNNING" && !notStarted(job)) return true;
    const reason = await this.deps.canStart(job).catch((err) => `License check failed: ${String(err)}`);
    if (reason === null) return true;
    await this.update(job.jobId, (j) => {
      j.status = "PAUSED";
      j.pauseReason = "LICENSE_REQUIRED";
      j.error = new AppError(ErrorCode.LICENSE_REQUIRED, reason, { userMessage: `${reason} \u2014 \u0E07\u0E32\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E23\u0E34\u0E48\u0E21 \u0E01\u0E14 Resume \u0E40\u0E21\u0E37\u0E48\u0E2D License \u0E1E\u0E23\u0E49\u0E2D\u0E21` }).toJSON();
    });
    this.deps.logger.scope("engine", job.jobId, job.type).warn(`JOB NOT STARTED (license): ${reason}`);
    return false;
  }
  /** Starts the next runnable job of every lane that is not executing one. */
  async pump() {
    if (this.pumping) {
      this.pumpAgain = true;
      return;
    }
    this.pumping = true;
    this.pumpAgain = false;
    const started = [];
    try {
      const jobs = await this.deps.repo.listOpen();
      const now = this.deps.clock.now();
      const runnable = (j) => {
        const step = j.steps.find((s) => s.status !== "SUCCESS" && s.status !== "SKIPPED");
        if (step?.status === "RUNNING") return false;
        return !(step?.status === "RETRY" && step.nextRetryAt && Date.parse(step.nextRetryAt) - now > IN_MEMORY_RETRY_WAIT_MAX_MS);
      };
      const lanes = [...new Set(jobs.map((j) => this.lane(j)))];
      for (const lane of lanes) {
        if (this.active.has(lane)) continue;
        const inLane = jobs.filter((j) => this.lane(j) === lane);
        const resting = inLane.some(
          (j) => j.steps.some((s) => s.status === "RETRY" && s.error?.code === ErrorCode.RATE_LIMITED && s.nextRetryAt && Date.parse(s.nextRetryAt) > now + IN_MEMORY_RETRY_WAIT_MAX_MS)
        );
        if (resting) continue;
        const candidates = [...inLane.filter((j) => j.status === "RUNNING" && runnable(j)), ...inLane.filter((j) => j.status === "PENDING" && runnable(j))];
        let next;
        for (const j of candidates) {
          if (this.isActive(j.jobId)) break;
          if (await this.mayStart(j)) {
            next = j;
            break;
          }
        }
        if (!next) continue;
        const run = { jobId: next.jobId, lane, controller: new AbortController(), stepController: null, lastProgressAt: now, lastPersistAt: 0 };
        this.active.set(lane, run);
        started.push(run);
      }
    } finally {
      this.pumping = false;
    }
    for (const run of started) {
      void this.execute(run).finally(() => {
        if (this.active.get(run.lane) === run) this.active.delete(run.lane);
        void this.pump();
      });
    }
    if (this.pumpAgain) void this.pump();
  }
  /* ------------------------------- execution ------------------------------- */
  async execute(run) {
    const { jobId } = run;
    const type = await this.deps.repo.get(jobId).then((j) => j.type).catch(() => void 0);
    const log = this.deps.logger.scope("engine", jobId, type);
    try {
      let job = await this.update(jobId, (j) => {
        if (j.status === "PENDING") log.info("JOB START");
        j.status = "RUNNING";
      });
      const wf = this.workflow(job.type);
      for (let i = 0; i < wf.steps.length; i++) {
        const def = wf.steps[i];
        job = await this.deps.repo.get(jobId);
        const step = findStep(job, def.id);
        if (step.status === "SUCCESS" || step.status === "SKIPPED") continue;
        if (job.cancelRequested) {
          await this.finish(jobId, "CANCELLED", new AppError(ErrorCode.CANCELLED, "Cancelled by user"));
          return;
        }
        if (job.pauseRequested) {
          await this.update(jobId, (j) => {
            j.status = "PAUSED";
            j.pauseReason = "USER";
            delete j.pauseRequested;
          });
          log.info("JOB PAUSED by user");
          return;
        }
        if (def.enabled && !def.enabled(job)) {
          await this.update(jobId, (j) => {
            findStep(j, def.id).status = "SKIPPED";
          });
          log.info(`Step skipped: ${def.label}`);
          continue;
        }
        if (step.status === "RETRY" && step.nextRetryAt) {
          const wait = Date.parse(step.nextRetryAt) - this.deps.clock.now();
          if (wait > IN_MEMORY_RETRY_WAIT_MAX_MS) return;
          if (wait > 0) await delay(wait, run.controller.signal);
        }
        const outcome = await this.runStep(run, def, log);
        if (outcome === "retry") {
          i--;
          continue;
        }
        if (outcome === "stop") return;
      }
      await this.finish(jobId, "SUCCESS");
    } catch (err) {
      const e = toAppError(err);
      if (SHUTDOWN.test(e.message)) {
        log.warn(`Execution interrupted by shutdown: ${e.message}`);
        return;
      }
      const job = await this.deps.repo.get(jobId).catch(() => null);
      if (job && (job.status === "RUNNING" || job.status === "PENDING")) {
        const status = e.code === ErrorCode.CANCELLED && job.cancelRequested ? "CANCELLED" : "FAILED";
        await this.finish(jobId, status, e);
      }
      if (e.code !== ErrorCode.CANCELLED) log.error(`JOB ERROR: ${e.message}`, e.toJSON());
    }
  }
  /** Runs one attempt; returns what the loop should do next. */
  async runStep(run, def, jobLog) {
    const { jobId } = run;
    const settings = await this.deps.getSettings();
    const stepController = new AbortController();
    const onJobAbort = () => stepController.abort(run.controller.signal.reason);
    run.controller.signal.addEventListener("abort", onJobAbort, { once: true });
    run.stepController = stepController;
    run.lastProgressAt = this.deps.clock.now();
    delete run.lastProgressMessage;
    const started = await this.update(jobId, (j) => {
      const s = findStep(j, def.id);
      s.status = "RUNNING";
      s.attempts += 1;
      s.startedAt = this.deps.clock.iso();
      delete s.endedAt;
      delete s.nextRetryAt;
      j.currentStep = def.id;
    });
    const stepState = findStep(started, def.id);
    const log = jobLog.child(def.id);
    log.info(`${def.label} \u2014 started (attempt ${stepState.attempts}/${stepState.maxAttempts})`);
    const ctx = this.buildContext(run, started, def, stepState, settings, stepController.signal, log);
    const timeoutMs2 = def.timeoutMs(settings.timeouts);
    try {
      const output = await withTimeout(
        def.run(ctx),
        timeoutMs2,
        def.label
      ).catch((err) => {
        const e = toAppError(err);
        if (e.code === ErrorCode.TIMEOUT) stepController.abort(e);
        throw err;
      });
      await this.update(jobId, (j) => {
        const s = findStep(j, def.id);
        s.status = "SUCCESS";
        s.endedAt = this.deps.clock.iso();
        s.output = output;
        delete s.error;
        delete s.checkpoint;
        delete s.progress;
        j.context[def.id] = output;
      });
      log.info(`${def.label} \u2014 done`);
      return "next";
    } catch (err) {
      return this.handleStepError(run, def, err, log);
    } finally {
      run.controller.signal.removeEventListener("abort", onJobAbort);
      run.stepController = null;
    }
  }
  async handleStepError(run, def, err, log) {
    const { jobId } = run;
    if (err instanceof PauseSignal) {
      await this.update(jobId, (j) => {
        const s = findStep(j, def.id);
        s.status = "PENDING";
        s.attempts = Math.max(0, s.attempts - 1);
        j.status = "PAUSED";
        j.pauseReason = err.reason;
        if (err.pendingInput) j.pendingInput = err.pendingInput;
      });
      log.info(`JOB PAUSED \u2014 ${err.message}`);
      return "stop";
    }
    const e = toAppError(err);
    const job = await this.deps.repo.get(jobId);
    if (e.code === ErrorCode.CANCELLED && job.cancelRequested) {
      await this.update(jobId, (j) => {
        findStep(j, def.id).status = "CANCELLED";
      });
      await this.finish(jobId, "CANCELLED", e);
      log.info("JOB CANCELLED");
      return "stop";
    }
    const pauseReason = e.pauseReason;
    if (pauseReason) {
      await this.update(jobId, (j) => {
        const s = findStep(j, def.id);
        s.status = "PENDING";
        s.attempts = Math.max(0, s.attempts - 1);
        s.error = e.toJSON();
        j.status = "PAUSED";
        j.pauseReason = pauseReason;
        j.error = e.toJSON();
      });
      log.warn(`JOB PAUSED (${pauseReason}) \u2014 ${e.userMessage}`, { code: e.code, message: e.message });
      return "stop";
    }
    const step = findStep(job, def.id);
    const waits = (step.rateLimitWaits ?? 0) + 1;
    if (e.code === ErrorCode.RATE_LIMITED && waits <= RATE_LIMIT_MAX_WAITS) {
      const waitMs = RATE_LIMIT_COOLDOWN_MS * waits;
      const nextRetryAt = new Date(this.deps.clock.now() + waitMs).toISOString();
      await this.update(jobId, (j) => {
        const s = findStep(j, def.id);
        s.status = "RETRY";
        s.nextRetryAt = nextRetryAt;
        s.attempts = Math.max(0, s.attempts - 1);
        s.rateLimitWaits = waits;
        s.error = e.toJSON();
        delete s.checkpoint;
      });
      log.warn(
        `${def.label} \u2014 \u0E40\u0E27\u0E47\u0E1A\u0E41\u0E08\u0E49\u0E07\u0E27\u0E48\u0E32\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E16\u0E35\u0E48\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B: \u0E1E\u0E31\u0E01\u0E04\u0E34\u0E27\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 ${Math.round(waitMs / 6e4)} \u0E19\u0E32\u0E17\u0E35 \u0E41\u0E25\u0E49\u0E27\u0E17\u0E33\u0E15\u0E48\u0E2D\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34 (\u0E04\u0E23\u0E31\u0E49\u0E07\u0E17\u0E35\u0E48 ${waits}/${RATE_LIMIT_MAX_WAITS})`,
        { message: e.message }
      );
      return "retry";
    }
    if (e.retryable && step.attempts < step.maxAttempts) {
      const waitMs = (this.deps.backoff ?? backoffDelay)(step.attempts);
      const nextRetryAt = new Date(this.deps.clock.now() + waitMs).toISOString();
      await this.update(jobId, (j) => {
        const s = findStep(j, def.id);
        s.status = "RETRY";
        s.nextRetryAt = nextRetryAt;
        s.error = e.toJSON();
        delete s.checkpoint;
      });
      log.warn(`${def.label} \u2014 ${e.code}, retry in ${Math.round(waitMs / 1e3)}s`, { message: e.message });
      return "retry";
    }
    await this.update(jobId, (j) => {
      const s = findStep(j, def.id);
      s.status = "FAILED";
      s.endedAt = this.deps.clock.iso();
      s.error = e.toJSON();
      delete s.checkpoint;
    });
    log.error(`${def.label} \u2014 FAILED: ${e.userMessage}`, { code: e.code, message: e.message });
    await this.finish(jobId, "FAILED", e);
    return "stop";
  }
  buildContext(run, job, def, step, settings, signal, log) {
    const { jobId } = run;
    return {
      jobId,
      stepId: def.id,
      job,
      input: job.input,
      settings,
      services: this.deps.services,
      log,
      signal,
      timeouts: settings.timeouts,
      assets: this.deps.assets,
      previousCheckpoint: step.checkpoint,
      inputFor: (prompt) => job.providedInputs?.[inputKey(def.id, prompt)],
      output: (stepId) => job.context[stepId],
      checkpoint: async (phase, data) => {
        await this.update(jobId, (j) => {
          const cp = { phase, at: this.deps.clock.iso() };
          if (data) cp.data = data;
          findStep(j, def.id).checkpoint = cp;
        });
      },
      progress: (message) => {
        const now = this.deps.clock.now();
        run.lastProgressAt = now;
        run.lastProgressMessage = message;
        if (now - run.lastPersistAt < PROGRESS_PERSIST_INTERVAL_MS) return;
        run.lastPersistAt = now;
        void this.update(jobId, (j) => {
          findStep(j, def.id).progress = { message, at: this.deps.clock.iso() };
        }).catch((err) => log.debug("progress persist failed", toAppError(err).message));
      }
    };
  }
  async finish(jobId, status, err) {
    const job = await this.update(jobId, (j) => {
      j.status = status;
      j.currentStep = null;
      delete j.pauseReason;
      delete j.pauseRequested;
      delete j.cancelRequested;
      if (err && status !== "SUCCESS") j.error = err.toJSON();
      if (status === "CANCELLED") {
        for (const s of j.steps) if (s.status === "PENDING" || s.status === "RETRY" || s.status === "RUNNING") s.status = "CANCELLED";
      }
    });
    const log = this.deps.logger.scope("engine", jobId, job.type);
    if (status === "SUCCESS") log.info("JOB SUCCESS");
    else log[status === "FAILED" ? "error" : "info"](`JOB ${status}${err ? `: ${err.userMessage}` : ""}`);
    const wf = this.workflows.get(job.type);
    if (status !== "SUCCESS") {
      await wf?.onJobEnded?.(job, this.deps.services).catch(
        (e) => log.error("onJobEnded hook failed", toAppError(e).toJSON())
      );
    } else {
      await wf?.onJobSucceeded?.(job, this.deps.services).catch(
        (e) => log.error("onJobSucceeded hook failed", toAppError(e).toJSON())
      );
    }
    return job;
  }
  update(jobId, mutate) {
    return this.deps.repo.update(jobId, mutate, this.deps.clock.iso());
  }
  workflow(type) {
    const wf = this.workflows.get(type);
    if (!wf) throw new AppError(ErrorCode.INTERNAL, `No workflow registered for ${type}`);
    return wf;
  }
};
function inputKey(stepId, prompt) {
  let h = 5381;
  for (let i = 0; i < prompt.length; i++) h = (h << 5) + h + prompt.charCodeAt(i) >>> 0;
  return `${stepId}:${h.toString(36)}`;
}
function findStep(job, stepId) {
  const step = job.steps.find((s) => s.id === stepId);
  if (!step) throw new AppError(ErrorCode.INTERNAL, `Step ${stepId} missing in job ${job.jobId}`);
  return step;
}
function invalidState(action, job) {
  return new AppError(ErrorCode.INVALID_STATE, `Cannot ${action} job in status ${job.status}`, {
    userMessage: `\u0E17\u0E33\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E43\u0E19\u0E2A\u0E16\u0E32\u0E19\u0E30 ${job.status}`
  });
}

// src/core/logger.ts
var MAX_STRING = 2e3;
var MAX_DEPTH = 4;
var MAX_KEYS = 40;
var SENSITIVE_KEY = /pass(word)?|token|secret|cookie|authorization|session|api[-_]?key|credential/i;
var SENSITIVE_QUERY = /([?&](?:access_token|token|key|sig|signature|oh|oe|_nc_sid|auth|session|code)=)[^&#\s]+/gi;
function redact(value, depth = 0) {
  if (typeof value === "string") {
    const clean = value.replace(SENSITIVE_QUERY, "$1[redacted]");
    return clean.length > MAX_STRING ? `${clean.slice(0, MAX_STRING)}\u2026 (${clean.length} chars)` : clean;
  }
  if (value === null || typeof value !== "object") return value;
  if (depth >= MAX_DEPTH) return "[depth limit]";
  if (Array.isArray(value)) return value.slice(0, MAX_KEYS).map((v) => redact(v, depth + 1));
  if (value instanceof Error) return { name: value.name, message: redact(value.message, depth + 1) };
  const out = {};
  for (const [k, v] of Object.entries(value).slice(0, MAX_KEYS)) {
    out[k] = SENSITIVE_KEY.test(k) ? "[redacted]" : redact(v, depth + 1);
  }
  return out;
}
var Logger = class _Logger {
  constructor(sink, clock) {
    this.sink = sink;
    this.clock = clock;
  }
  minLevel = "INFO";
  appendsSincePrune = 0;
  listeners = /* @__PURE__ */ new Set();
  static PRUNE_EVERY = 200;
  setLevel(level) {
    this.minLevel = level;
  }
  onEntry(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  scope(source, jobId, jobType) {
    const write = (level) => (message, data) => this.write(level, source, message, jobId, data, jobType);
    return {
      debug: write("DEBUG"),
      info: write("INFO"),
      warn: write("WARN"),
      error: write("ERROR"),
      child: (child) => this.scope(`${source}/${child}`, jobId, jobType)
    };
  }
  write(level, source, message, jobId, data, jobType) {
    if (LOG_LEVEL_ORDER[level] < LOG_LEVEL_ORDER[this.minLevel]) return;
    const entry = {
      id: newId("log_"),
      ts: this.clock.iso(),
      level,
      source,
      message: redact(message)
    };
    if (jobId) entry.jobId = jobId;
    if (jobType) entry.jobType = jobType;
    if (data !== void 0) entry.data = redact(data);
    console.debug(`[ACF ${level}] ${source}: ${entry.message}`, entry.data ?? "");
    for (const l of this.listeners) l(entry);
    void this.persist(entry);
  }
  async persist(entry) {
    try {
      await this.sink.append(entry);
      if (++this.appendsSincePrune >= _Logger.PRUNE_EVERY) {
        this.appendsSincePrune = 0;
        await this.sink.prune(LOG_RETENTION.maxEntries);
      }
    } catch (err) {
      console.debug("[ACF] failed to persist log entry", err);
    }
  }
};

// src/core/tab-session.ts
var AUTOMATION_WINDOW_KEY = "automationWindowId";
var AUTOMATION_WINDOW_SIZE = { width: 1280, height: 900 };
var OWN_TABS_KEY = "automationTabIds";
var MAX_OWN_TABS = 20;
var GROUP_KEY = "postHubGroupId";
var RUN_KEY = "postHubRunActive";
var GROUP_TITLE = "PostHub";
var NO_RECEIVER = /Receiving end does not exist|Could not establish connection/i;
var NO_TAB = /No tab with id|Tab .* not found|tab was closed/i;
var CHANNEL_CLOSED = /message channel closed before a response|message port closed/i;
function matchesPattern(url, pattern) {
  const m = /^(\*|https?):\/\/([^/]+)(\/.*)$/.exec(pattern);
  if (!m) return false;
  const [, scheme, host, path] = m;
  let u;
  try {
    u = new URL(url);
  } catch {
    return false;
  }
  const schemeOk = scheme === "*" ? u.protocol === "https:" || u.protocol === "http:" : u.protocol === `${scheme}:`;
  const hostOk = host.startsWith("*.") ? u.hostname === host.slice(2) || u.hostname.endsWith(host.slice(1)) : u.hostname === host.split(":")[0];
  const pathRe = new RegExp(`^${path.split("*").map(escapeRe).join(".*")}$`);
  return schemeOk && hostOk && pathRe.test(u.pathname + u.search);
}
function escapeRe(s) {
  return s.replace(/[.+?^${}()|[\]\\]/g, "\\$&");
}
var TabSessionManager = class {
  constructor(deps) {
    this.deps = deps;
  }
  locks = new KeyedMutex();
  ownership = new Mutex();
  opening = new Mutex();
  grouping = new Mutex();
  groupTitle = GROUP_TITLE;
  groupColor = "green";
  progressListeners = /* @__PURE__ */ new Map();
  /** Serialises all use of one provider's tab (ARCHITECTURE §5.4). */
  withLock(spec, fn, opts) {
    return this.locks.run(spec.providerId, async () => fn(await this.acquire(spec, opts)));
  }
  async acquire(spec, opts) {
    const settings = await this.deps.getSettings();
    let tab = await this.opening.run(async () => {
      const existing = await this.findTab(spec, settings);
      if (existing) return existing;
      const opened = await this.openTab(opts.url ?? spec.homeUrl, settings, spec.providerId, !spec.background);
      this.deps.log.info(`Opened ${spec.providerId} tab`, { tabId: opened.id });
      return opened;
    });
    if (opts.url && !sameUrl(tab.url, opts.url)) {
      tab = await chrome.tabs.update(requireTabId(tab), { url: opts.url }) ?? tab;
    }
    const tabId = requireTabId(tab);
    await this.waitLoaded(tabId, opts.timeouts.tabLoadMs);
    const session = new TabSession(this, spec, tabId, this.deps.log);
    await session.ensureBridge(opts.timeouts, opts.signal);
    return session;
  }
  /** Called by the router for `bridge.progress` messages from content scripts. */
  handleProgress(progress) {
    this.progressListeners.get(progress.requestId)?.(progress);
  }
  onProgress(requestId, listener) {
    this.progressListeners.set(requestId, listener);
    return () => this.progressListeners.delete(requestId);
  }
  /**
   * Waits for the tab's load to finish, but a page that never reports "complete" (long-polling
   * sites, a stuck sub-resource) is not an error by itself: the bridge's readiness check decides.
   */
  async waitLoaded(tabId, timeoutMs2) {
    try {
      await this.waitComplete(tabId, timeoutMs2);
    } catch (err) {
      const e = toAppError(err);
      if (e.code !== ErrorCode.PAGE_NOT_READY) throw e;
      this.deps.log.warn("Page still loading \u2014 continuing; the page's readiness check decides", { tabId });
    }
  }
  async waitComplete(tabId, timeoutMs2) {
    if (this.deps.waitTabComplete) return this.deps.waitTabComplete(tabId, timeoutMs2);
    const done = new Promise((resolve, reject) => {
      const onUpdated = (id2, info) => {
        if (id2 === tabId && info.status === "complete") cleanup(resolve);
      };
      const onRemoved = (id2) => {
        if (id2 === tabId) cleanup(() => reject(new AppError(ErrorCode.TAB_CLOSED, `Tab ${tabId} closed while loading`)));
      };
      const cleanup = (fn) => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        chrome.tabs.onRemoved.removeListener(onRemoved);
        fn();
      };
      chrome.tabs.onUpdated.addListener(onUpdated);
      chrome.tabs.onRemoved.addListener(onRemoved);
      chrome.tabs.get(tabId).then(
        (t) => {
          if (t.status === "complete") cleanup(resolve);
        },
        () => cleanup(() => reject(new AppError(ErrorCode.TAB_CLOSED, `Tab ${tabId} not found`)))
      );
    });
    await withTimeout(done, timeoutMs2, "Page load", ErrorCode.PAGE_NOT_READY);
  }
  /**
   * The tab this provider works in. Tabs are owned per provider (ADR-56): tools run side by side, so
   * the Page publisher (facebook.com/*) must never take the group-chat sender's facebook.com/messages
   * tab, and vice versa.
   */
  async findTab(spec, settings) {
    const tabs = await chrome.tabs.query({ url: spec.matches });
    if (tabs.length === 0) return void 0;
    const owned = await this.ownedTabs();
    const ownerOf = (t) => {
      const owner = owned.find((o) => o.id === t.id)?.provider;
      if ((owner === "facebook-web" || owner === "") && t.url?.startsWith("https://www.facebook.com/groups/")) return "facebook-group-web";
      return owner;
    };
    const mine = (t) => ownerOf(t) === spec.providerId;
    const free = tabs.filter((t) => t.id !== void 0 && (ownerOf(t) === void 0 || ownerOf(t) === spec.providerId || ownerOf(t) === ""));
    if (settings.automationWindow === "separate") {
      const windowId = await this.automationWindowId();
      const inWindow = free.filter((t) => t.windowId === windowId);
      const tab2 = inWindow.find(mine) ?? (spec.background ? void 0 : inWindow.find((t) => ownerOf(t) === void 0 || ownerOf(t) === ""));
      if (tab2?.id !== void 0) await this.claim(tab2.id, spec.providerId);
      return tab2;
    }
    const tab = free.find(mine) ?? free.find((t) => ownerOf(t) === "");
    if (tab?.id !== void 0) {
      await this.claim(tab.id, spec.providerId);
      await this.addToGroup(tab);
    }
    return tab;
  }
  /** Tabs opened by the extension and the provider using each ("" = recorded before v0.15). */
  async ownedTabs() {
    const stored = await chrome.storage.session.get(OWN_TABS_KEY);
    const raw = stored[OWN_TABS_KEY];
    if (!Array.isArray(raw)) return [];
    const out = [];
    for (const x of raw) {
      if (typeof x === "number") out.push({ id: x, provider: "" });
      else if (x && typeof x === "object" && typeof x.id === "number") {
        const o = x;
        const entry = { id: o.id, provider: typeof o.provider === "string" ? o.provider : "" };
        if (typeof o.jobId === "string") entry.jobId = o.jobId;
        out.push(entry);
      }
    }
    return out;
  }
  /** Preserve a failed composer for review, but never lend it to the next product. */
  async hold(tabId, provider, jobId) {
    await this.claim(tabId, `${provider}:held`, jobId);
  }
  async claim(tabId, provider, jobId) {
    await this.ownership.run(async () => {
      const rest = (await this.ownedTabs()).filter((o) => o.id !== tabId).slice(-MAX_OWN_TABS + 1);
      const entry = jobId ? { id: tabId, provider, jobId } : { id: tabId, provider };
      await chrome.storage.session.set({ [OWN_TABS_KEY]: [...rest, entry] });
    });
  }
  /* -------------------------------------------------------------- PostHub tab group */
  tabGroupsAvailable() {
    return typeof chrome.tabs.group === "function" && typeof chrome.tabGroups?.update === "function";
  }
  /** Puts a tab the extension opened into the PostHub group. Cosmetic: a failure is logged, never thrown. */
  async addToGroup(tab) {
    const tabId = tab.id;
    if (tabId === void 0 || !this.tabGroupsAvailable()) return;
    await this.grouping.run(async () => {
      try {
        const stored = (await chrome.storage.session.get(GROUP_KEY))[GROUP_KEY];
        let groupId;
        if (typeof stored === "number") {
          try {
            if ((await chrome.tabGroups.get(stored)).windowId === tab.windowId) groupId = stored;
          } catch {
          }
        }
        if (groupId !== void 0) {
          if (tab.groupId !== groupId) await chrome.tabs.group({ groupId, tabIds: tabId });
          return;
        }
        const created = await chrome.tabs.group({ tabIds: tabId, createProperties: { windowId: tab.windowId } });
        await chrome.tabGroups.update(created, { title: this.groupTitle, color: this.groupColor, collapsed: false });
        await chrome.storage.session.set({ [GROUP_KEY]: created });
      } catch (err) {
        this.deps.log.warn("Cannot put the automation tab in the PostHub group", { tabId, message: String(err) });
      }
    });
  }
  async setGroupLook(title, color) {
    this.groupTitle = title;
    this.groupColor = color;
    if (!this.tabGroupsAvailable()) return;
    await this.grouping.run(async () => {
      const stored = (await chrome.storage.session.get(GROUP_KEY))[GROUP_KEY];
      if (typeof stored !== "number") return;
      try {
        await chrome.tabGroups.update(stored, { title, color });
      } catch {
        await chrome.storage.session.remove(GROUP_KEY);
      }
    });
  }
  /**
   * Follows the product-send queue. While sends run the group reads "PostHub n/N"; when the run ends
   * (finished or paused), the tabs of `providers` that finished cleanly are closed, each under its
   * provider lock so a tab still in use is never closed, and tabs held for review stay open.
   */
  async noteQueue(state, providers) {
    if (state.running) {
      await chrome.storage.session.set({ [RUN_KEY]: true });
      await this.setGroupLook(state.total ? `${GROUP_TITLE} ${state.current ?? 0}/${state.total}` : GROUP_TITLE, "green");
      return;
    }
    if ((await chrome.storage.session.get(RUN_KEY))[RUN_KEY] !== true) return;
    await chrome.storage.session.remove(RUN_KEY);
    const settings = await this.deps.getSettings();
    if (settings.automationWindow === "separate" || !settings.closeSendTabsAfterRun) {
      await this.refreshHeldLook();
      return;
    }
    for (const provider of providers) {
      await this.locks.run(provider, async () => {
        for (const o of (await this.ownedTabs()).filter((x) => x.provider === provider)) await this.closeOwned(o.id);
      });
    }
    await this.refreshHeldLook();
  }
  /**
   * Closes the bot's own tabs of one provider once its work is done (e.g. the ChatGPT tab after
   * the content planner got its answer). Same opt-outs as the end of a send run.
   */
  async closeProviderTabs(provider) {
    const settings = await this.deps.getSettings();
    if (settings.automationWindow === "separate" || !settings.closeSendTabsAfterRun) return;
    await this.locks.run(provider, async () => {
      for (const o of (await this.ownedTabs()).filter((x) => x.provider === provider)) await this.closeOwned(o.id);
    });
    await this.refreshHeldLook();
  }
  async closeOwned(tabId) {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
    }
    await this.ownership.run(async () => {
      await chrome.storage.session.set({ [OWN_TABS_KEY]: (await this.ownedTabs()).filter((o) => o.id !== tabId) });
    });
  }
  /** Held tabs (kept for review after an unconfirmed post) that are still open. */
  async liveHeld() {
    const out = [];
    for (const o of (await this.ownedTabs()).filter((x) => x.provider.endsWith(":held"))) {
      try {
        await chrome.tabs.get(o.id);
        out.push(o);
      } catch {
      }
    }
    return out;
  }
  async refreshHeldLook() {
    const held = (await this.liveHeld()).length;
    if (held > 0) await this.setGroupLook(`${GROUP_TITLE} \xB7 \u0E40\u0E0A\u0E47\u0E01 ${held}`, "orange");
    else await this.setGroupLook(GROUP_TITLE, "green");
  }
  /** The tab kept open for review after an unconfirmed post of this job, if it is still open. */
  async heldTabFor(jobId) {
    return (await this.liveHeld()).find((o) => o.jobId === jobId)?.id;
  }
  /** Brings a tab to the front (the user asked to look at it). */
  async showTab(tabId) {
    const tab = await chrome.tabs.update(tabId, { active: true });
    if (tab?.windowId !== void 0) await chrome.windows.update(tab.windowId, { focused: true });
  }
  /** Closes the review tab of a send the user has settled (any outcome). */
  async releaseHeld(jobId) {
    const id2 = await this.heldTabFor(jobId);
    if (id2 === void 0) return;
    await this.closeOwned(id2);
    await this.refreshHeldLook();
  }
  async openTab(url, settings, provider, active) {
    if (settings.automationWindow === "separate") {
      const windowId = await this.automationWindowId();
      if (windowId !== void 0) {
        const tab3 = await chrome.tabs.create({ windowId, url, active });
        if (tab3.id !== void 0) await this.claim(tab3.id, provider);
        return tab3;
      }
      const win = await chrome.windows.create({ url, focused: false, type: "normal", ...AUTOMATION_WINDOW_SIZE });
      if (win?.id === void 0) throw new AppError(ErrorCode.INTERNAL, "Failed to open automation window");
      await chrome.storage.session.set({ [AUTOMATION_WINDOW_KEY]: win.id });
      const tab2 = win.tabs?.[0];
      if (!tab2) throw new AppError(ErrorCode.INTERNAL, "Automation window has no tab");
      if (tab2.id !== void 0) await this.claim(tab2.id, provider);
      return tab2;
    }
    const tab = await chrome.tabs.create({ url, active });
    if (tab.id !== void 0) await this.claim(tab.id, provider);
    await this.addToGroup(tab);
    return tab;
  }
  async automationWindowId() {
    const stored = await chrome.storage.session.get(AUTOMATION_WINDOW_KEY);
    const id2 = stored[AUTOMATION_WINDOW_KEY];
    if (typeof id2 !== "number") return void 0;
    try {
      await chrome.windows.get(id2);
      return id2;
    } catch {
      await chrome.storage.session.remove(AUTOMATION_WINDOW_KEY);
      return void 0;
    }
  }
};
function sameUrl(a, b) {
  const norm2 = (u) => u.split("#")[0]?.replace(/\/+$/, "") ?? u;
  return a !== void 0 && norm2(a) === norm2(b);
}
function requireTabId(tab) {
  if (tab.id === void 0) throw new AppError(ErrorCode.TAB_CLOSED, "Tab has no id");
  return tab.id;
}
var TabSession = class {
  constructor(manager, spec, tabId, log) {
    this.manager = manager;
    this.spec = spec;
    this.tabId = tabId;
    this.log = log;
  }
  async hold(jobId) {
    await this.manager.hold(this.tabId, this.spec.providerId, jobId);
  }
  async url() {
    try {
      return (await chrome.tabs.get(this.tabId)).url ?? "";
    } catch (err) {
      throw new AppError(ErrorCode.TAB_CLOSED, "Provider tab was closed", { cause: err });
    }
  }
  /**
   * Shows this tab even for a background provider, for pages that only load while visible (infinite
   * scroll runs on the rendering loop, which Chrome pauses in hidden tabs). Returns the tab to go back to.
   */
  async bringToFront() {
    try {
      const tab = await chrome.tabs.get(this.tabId);
      const [previous] = await chrome.tabs.query({ active: true, windowId: tab.windowId });
      await chrome.tabs.update(this.tabId, { active: true });
      return previous?.id !== void 0 && previous.id !== this.tabId ? previous.id : void 0;
    } catch (err) {
      throw new AppError(ErrorCode.TAB_CLOSED, "Provider tab was closed", { cause: err });
    }
  }
  /** Goes back to the tab that was active before bringToFront (best effort). */
  async returnTo(tabId) {
    if (tabId === void 0) return;
    await chrome.tabs.update(tabId, { active: true }).catch(() => void 0);
  }
  /** Makes the tab the active one in its window so the page renders at full speed (R-08). */
  async activate() {
    if (this.spec.background) return;
    try {
      await chrome.tabs.update(this.tabId, { active: true });
    } catch (err) {
      throw new AppError(ErrorCode.TAB_CLOSED, "Provider tab was closed", { cause: err });
    }
  }
  async navigate(url, timeouts, signal) {
    try {
      await chrome.tabs.update(this.tabId, { url });
    } catch (err) {
      throw new AppError(ErrorCode.TAB_CLOSED, "Provider tab was closed", { cause: err });
    }
    await this.manager.waitLoaded(this.tabId, timeouts.tabLoadMs);
    await this.ensureBridge(timeouts, signal);
  }
  async reload(timeouts, signal) {
    await chrome.tabs.reload(this.tabId);
    await this.manager.waitLoaded(this.tabId, timeouts.tabLoadMs);
    await this.ensureBridge(timeouts, signal);
  }
  /** Pings the bridge; injects it when absent or stale (R-14). */
  async ensureBridge(timeouts, signal) {
    const ping = () => this.send(`${this.spec.commandPrefix}.ping`, {}, { timeoutMs: timeouts.bridgePingMs, ...signal ? { signal } : {} });
    try {
      const response = await ping();
      if (this.spec.expectedVersion && response.version !== this.spec.expectedVersion) throw new AppError(ErrorCode.BRIDGE_UNREACHABLE, "Outdated bridge");
      return response;
    } catch (err) {
      const e = toAppError(err);
      if (e.code !== ErrorCode.BRIDGE_UNREACHABLE && e.code !== ErrorCode.TIMEOUT) throw e;
    }
    this.log.debug(`Injecting ${this.spec.bridgeFile}`, { tabId: this.tabId });
    try {
      await chrome.scripting.executeScript({ target: { tabId: this.tabId }, files: [this.spec.bridgeFile] });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (/Cannot access|permission/i.test(message)) {
        throw new AppError(ErrorCode.PERMISSION_MISSING, message, { cause: err });
      }
      if (NO_TAB.test(message)) throw new AppError(ErrorCode.TAB_CLOSED, message, { cause: err });
      throw new AppError(ErrorCode.BRIDGE_UNREACHABLE, `Bridge injection failed: ${message}`, { cause: err });
    }
    return ping();
  }
  /** Sends one command to the bridge in the top frame. */
  async send(type, payload, opts) {
    const requestId = newRequestId();
    const unsubscribe = opts.onProgress ? this.manager.onProgress(requestId, opts.onProgress) : () => false;
    const onAbort = () => {
      chrome.tabs.sendMessage(this.tabId, envelope(BRIDGE_CANCEL, { requestId }), { frameId: 0 }).catch(() => void 0);
    };
    opts.signal?.addEventListener("abort", onAbort, { once: true });
    try {
      if (opts.signal?.aborted) throw toAppError(opts.signal.reason);
      const response = await withTimeout(
        chrome.tabs.sendMessage(this.tabId, envelope(type, payload, requestId), { frameId: 0 }),
        opts.timeoutMs,
        type
      );
      if (response === void 0) {
        throw new AppError(ErrorCode.BRIDGE_UNREACHABLE, `${type}: bridge returned nothing`);
      }
      return unwrap(response, type);
    } catch (err) {
      if (err instanceof AppError) {
        if (err.code === ErrorCode.TIMEOUT) onAbort();
        throw err;
      }
      const message = err instanceof Error ? err.message : String(err);
      if (NO_RECEIVER.test(message)) throw new AppError(ErrorCode.BRIDGE_UNREACHABLE, `${type}: ${message}`, { cause: err });
      if (NO_TAB.test(message)) throw new AppError(ErrorCode.TAB_CLOSED, `${type}: ${message}`, { cause: err });
      if (CHANNEL_CLOSED.test(message)) {
        const alive = await chrome.tabs.get(this.tabId).then(() => true, () => false);
        throw new AppError(alive ? ErrorCode.BRIDGE_UNREACHABLE : ErrorCode.TAB_CLOSED, `${type}: ${message}`, { cause: err });
      }
      throw toAppError(err);
    } finally {
      unsubscribe();
      opts.signal?.removeEventListener("abort", onAbort);
    }
  }
  /**
   * Long waits are split into slices shorter than the SW's single-call limits (R-10).
   * The bridge command must be idempotent and return `{ done, result?, progress? }`.
   */
  async sendUntilDone(type, payload, opts) {
    const deadline = opts.clock.now() + opts.totalTimeoutMs;
    for (; ; ) {
      const remaining = deadline - opts.clock.now();
      if (remaining <= 0) throw new AppError(ErrorCode.TIMEOUT, `${type} did not finish in ${opts.totalTimeoutMs} ms`);
      const sliceMs = Math.min(opts.sliceMs, remaining);
      const res = await this.send(
        type,
        { ...payload, sliceMs },
        {
          timeoutMs: sliceMs + SLICE_GRACE_MS,
          ...opts.signal ? { signal: opts.signal } : {},
          onProgress: (p) => opts.onProgress?.(p.message)
        }
      );
      if (res.progress) opts.onProgress?.(res.progress);
      if (res.done) return res.result;
      if (opts.signal?.aborted) throw toAppError(opts.signal.reason);
      await delay(0, opts.signal);
    }
  }
};
var SLICE_GRACE_MS = 5e3;

// src/core/transfer.ts
var TransferHub = class {
  waiting = /* @__PURE__ */ new Map();
  /** Must be registered with chrome.runtime.onConnect by the service worker. */
  handleConnect(port5) {
    if (!port5.name.startsWith(PORT_TRANSFER_TO_EXTENSION)) return false;
    const transferId = port5.name.slice(PORT_TRANSFER_TO_EXTENSION.length);
    const waiter = this.waiting.get(transferId);
    if (!waiter || port5.sender?.id !== chrome.runtime.id || !port5.sender.tab) {
      port5.disconnect();
      return true;
    }
    this.waiting.delete(transferId);
    waiter(port5);
    return true;
  }
  /**
   * Registers an expected incoming transfer and returns its id plus a promise for the file.
   * The caller then asks the bridge (by command) to send the file under that id.
   */
  expectFromPage(timeoutMs2) {
    const transferId = newId("tin_");
    const file = new Promise((resolve, reject) => {
      this.waiting.set(transferId, (port5) => {
        receiveBlobFromPort(port5).then(resolve, reject);
      });
    });
    return {
      transferId,
      file: withTimeout(file, timeoutMs2, "File transfer from page", ErrorCode.DOWNLOAD_FAILED).finally(
        () => this.waiting.delete(transferId)
      )
    };
  }
  /** Pushes a blob into a content script that is waiting on PORT_TRANSFER_TO_PAGE + transferId. */
  async sendToPage(tabId, transferId, blob, name, timeoutMs2) {
    const port5 = chrome.tabs.connect(tabId, { name: `${PORT_TRANSFER_TO_PAGE}${transferId}`, frameId: 0 });
    try {
      await withTimeout(sendBlobOverPort(port5, blob, name), timeoutMs2, "File transfer to page", ErrorCode.UPLOAD_FAILED);
    } finally {
      port5.disconnect();
    }
  }
};

// src/providers/chatgpt/protocol.ts
var CHATGPT_PROVIDER_ID = "chatgpt-web";
var CHATGPT_PREFIX = "chatgpt";
var CHATGPT_HOME = "https://chatgpt.com/";
var CHATGPT_CMD = {
  submit: `${CHATGPT_PREFIX}.submit`,
  waitReply: `${CHATGPT_PREFIX}.waitReply`,
  stop: `${CHATGPT_PREFIX}.stop`,
  inspect: `${CHATGPT_PREFIX}.inspect`,
  /** Attach files (already transferred to the page) to the composer; resolves when their previews show. */
  attach: `${CHATGPT_PREFIX}.attach`
};

// src/providers/chatgpt/adapter.ts
function imageGenerationPrompt(imagePrompt, aspect, inThread = false) {
  return `Create an image. ${inThread ? NEW_IMAGE_IN_THREAD : ""}Aspect ratio ${aspect}. ${imagePrompt}`;
}
var TEXT_ONLY_GUARD = "\u0E2A\u0E33\u0E04\u0E31\u0E0D: \u0E15\u0E2D\u0E1A\u0E40\u0E1B\u0E47\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E40\u0E17\u0E48\u0E32\u0E19\u0E31\u0E49\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E (Reply in text only. Do not create an image.)\n\n";
var BUSY_POLL_MS = 3e3;
var CONVERSATION_URL = /^https:\/\/chatgpt\.com\/(?:g\/[^/]+\/)?c\/[\w-]+/;
var PROJECT_URL = /^https:\/\/chatgpt\.com\/g\/g-p-[A-Za-z0-9-]+(?:\/project)?\/?$/;
var NEW_IMAGE_IN_THREAD = "This is a NEW, separate image for a different post \u2014 do not edit or reuse any previous image in this chat. ";
function newChatStart(newChatUrl) {
  return newChatUrl && PROJECT_URL.test(newChatUrl) ? newChatUrl : CHATGPT_HOME;
}
function isConversationUrl(url) {
  return typeof url === "string" && CONVERSATION_URL.test(url);
}
var ChatGPTWebAdapter = class extends WebAdapter {
  info = {
    id: CHATGPT_PROVIDER_ID,
    displayName: "ChatGPT (\u0E40\u0E27\u0E47\u0E1A chatgpt.com)",
    capabilities: ["text", "image"],
    origins: ["https://chatgpt.com/*"],
    homeUrl: CHATGPT_HOME
  };
  siteName = "ChatGPT";
  spec = {
    providerId: CHATGPT_PROVIDER_ID,
    matches: ["https://chatgpt.com/*"],
    homeUrl: CHATGPT_HOME,
    bridgeFile: "bridges/chatgpt-bridge.js",
    commandPrefix: CHATGPT_PREFIX
  };
  async inspect(session, prompt, ctx) {
    return session.send(CHATGPT_CMD.inspect, { text: prompt }, { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal });
  }
  async adoptable(session, prompt, ctx) {
    return (await this.inspect(session, prompt, ctx)).adopt;
  }
  /**
   * ChatGPT ignores a new prompt while it is still answering (e.g. an image from an attempt that
   * was reported as failed): wait for it to finish first, then give up with a clear message.
   */
  async waitUntilIdle(session, ctx, maxWaitMs) {
    const until = this.deps.clock.now() + maxWaitMs;
    while ((await this.inspect(session, "-", ctx)).busy) {
      if (this.deps.clock.now() > until) {
        throw new AppError(ErrorCode.GENERATION_FAILED, "ChatGPT is still answering a previous prompt", {
          userMessage: "ChatGPT \u0E22\u0E31\u0E07\u0E15\u0E2D\u0E1A\u0E04\u0E33\u0E02\u0E2D\u0E01\u0E48\u0E2D\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E44\u0E21\u0E48\u0E40\u0E2A\u0E23\u0E47\u0E08 \u2014 \u0E23\u0E2D\u0E43\u0E2B\u0E49\u0E40\u0E2A\u0E23\u0E47\u0E08 (\u0E2B\u0E23\u0E37\u0E2D\u0E01\u0E14\u0E2B\u0E22\u0E38\u0E14\u0E43\u0E19 ChatGPT) \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry"
        });
      }
      ctx.progress("ChatGPT \u0E22\u0E31\u0E07\u0E15\u0E2D\u0E1A\u0E04\u0E33\u0E02\u0E2D\u0E01\u0E48\u0E2D\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E2D\u0E22\u0E39\u0E48 \u2014 \u0E23\u0E2D\u0E43\u0E2B\u0E49\u0E40\u0E2A\u0E23\u0E47\u0E08\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E43\u0E2B\u0E21\u0E48");
      await delay(BUSY_POLL_MS, ctx.signal);
    }
  }
  /** When the last prompt was sent (this service-worker lifetime). */
  lastSubmitAt = 0;
  /**
   * Keeps prompts at least timeouts.promptGapMs apart: a campaign sends many prompts back to back
   * and ChatGPT answers "too many requests / too quickly" (seen live 2026-09-26).
   */
  async pace(ctx) {
    const wait = this.lastSubmitAt + ctx.timeouts.promptGapMs - this.deps.clock.now();
    if (!(wait > 0)) return;
    ctx.progress(`\u0E40\u0E27\u0E49\u0E19\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E04\u0E33\u0E2A\u0E31\u0E48\u0E07\u0E16\u0E31\u0E14\u0E44\u0E1B ${Math.ceil(wait / 1e3)} \u0E27\u0E34\u0E19\u0E32\u0E17\u0E35`);
    await delay(wait, ctx.signal);
  }
  capabilities = {
    text: { generateText: (req2, ctx) => this.generateText(req2, ctx) },
    image: { generateImage: (req2, ctx) => this.generateImage(req2, ctx) }
  };
  /** Where to run: the conversation of an interrupted attempt, the requested one, or a new chat. */
  targetUrl(conversationRef, ctx, newChatUrl) {
    const cp = ctx.previousCheckpoint;
    const cpUrl = cp?.phase === "submitted" ? cp.data?.["url"] : void 0;
    if (typeof cpUrl === "string" && CONVERSATION_URL.test(cpUrl)) return cpUrl;
    return isConversationUrl(conversationRef) ? conversationRef : newChatStart(newChatUrl);
  }
  async generateText(req2, ctx) {
    const url = this.targetUrl(req2.conversationRef, ctx, req2.newChatUrl);
    return this.withSession(ctx, url, async (session) => {
      const replyMs2 = Math.max(ctx.timeouts.textGenerationMs, req2.timeoutMs ?? 0);
      let reply = await this.ask(session, req2.prompt, "text", replyMs2, ctx);
      if (reply.stalled) {
        ctx.log.warn(`ChatGPT \u0E2B\u0E22\u0E38\u0E14\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E01\u0E25\u0E32\u0E07\u0E04\u0E31\u0E19 (\u0E44\u0E21\u0E48\u0E02\u0E22\u0E31\u0E1A ${Math.round(replyStallMs(ctx) / 1e3)} \u0E27\u0E34\u0E19\u0E32\u0E17\u0E35) \u2014 \u0E01\u0E14\u0E2B\u0E22\u0E38\u0E14\u0E41\u0E25\u0E49\u0E27 \u0E08\u0E30\u0E02\u0E2D\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E43\u0E2B\u0E21\u0E48\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E40\u0E14\u0E34\u0E21`);
      }
      const first = textProblem(reply);
      if (first) {
        ctx.log.warn(
          first === "image" ? "ChatGPT \u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B\u0E41\u0E17\u0E19\u0E01\u0E32\u0E23\u0E15\u0E2D\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E41\u0E25\u0E49\u0E27\u0E16\u0E32\u0E21\u0E43\u0E2B\u0E21\u0E48\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E43\u0E2B\u0E21\u0E48" : "ChatGPT \u0E15\u0E2D\u0E1A\u0E01\u0E25\u0E31\u0E1A\u0E27\u0E48\u0E32\u0E07\u0E40\u0E1B\u0E25\u0E48\u0E32 \u2014 \u0E16\u0E32\u0E21\u0E43\u0E2B\u0E21\u0E48\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E43\u0E2B\u0E21\u0E48"
        );
        await session.send(CHATGPT_CMD.stop, {}, { timeoutMs: ctx.timeouts.bridgePingMs }).catch(() => void 0);
        await session.navigate(newChatStart(req2.newChatUrl), ctx.timeouts, ctx.signal);
        await this.ensureReady(session, ctx);
        reply = await this.ask(session, TEXT_ONLY_GUARD + req2.prompt, "text", replyMs2, ctx, { fresh: true });
        const second = textProblem(reply);
        if (second === "image") {
          await session.send(CHATGPT_CMD.stop, {}, { timeoutMs: ctx.timeouts.bridgePingMs }).catch(() => void 0);
          throw new AppError(ErrorCode.GENERATION_FAILED, "ChatGPT answered a text prompt with an image twice", {
            retryable: false,
            userMessage: 'ChatGPT \u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B\u0E41\u0E17\u0E19\u0E01\u0E32\u0E23\u0E15\u0E2D\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 2 \u0E04\u0E23\u0E31\u0E49\u0E07\u0E15\u0E34\u0E14 \u2014 \u0E14\u0E39\u0E17\u0E35\u0E48\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E02\u0E2D\u0E07 ChatGPT \u0E27\u0E48\u0E32\u0E21\u0E35\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E21\u0E37\u0E2D "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E" \u0E16\u0E39\u0E01\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E04\u0E49\u0E32\u0E07\u0E44\u0E27\u0E49\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48 (\u0E16\u0E49\u0E32\u0E21\u0E35\u0E43\u0E2B\u0E49\u0E01\u0E14 \xD7 \u0E2D\u0E2D\u0E01) \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry'
          });
        }
        if (second === "empty") {
          throw new AppError(ErrorCode.GENERATION_FAILED, "ChatGPT returned an empty reply", {
            userMessage: "ChatGPT \u0E15\u0E2D\u0E1A\u0E01\u0E25\u0E31\u0E1A\u0E27\u0E48\u0E32\u0E07\u0E40\u0E1B\u0E25\u0E48\u0E32"
          });
        }
      }
      const result = { text: reply.text, codeBlocks: reply.codeBlocks };
      if (CONVERSATION_URL.test(reply.url)) result.conversationRef = reply.url;
      return result;
    });
  }
  async generateImage(req2, ctx) {
    const url = this.targetUrl(req2.conversationRef, ctx, req2.newChatUrl);
    const inThread = isConversationUrl(url);
    return this.withSession(ctx, url, async (session) => {
      const prompt = imageGenerationPrompt(req2.prompt, req2.aspect, inThread);
      const reply = await this.ask(session, prompt, "image", ctx.timeouts.imageGenerationMs, ctx, {
        onSubmitted: async (url2) => {
          if (isConversationUrl(url2)) await req2.onConversation?.(url2).catch(() => void 0);
        },
        ...req2.referenceAssetIds?.length ? { attachAssetIds: req2.referenceAssetIds } : {}
      });
      const src = reply.images[reply.images.length - 1];
      if (!src) {
        throw new AppError(ErrorCode.GENERATION_FAILED, "ChatGPT replied without an image", {
          userMessage: "ChatGPT \u0E15\u0E2D\u0E1A\u0E01\u0E25\u0E31\u0E1A\u0E41\u0E15\u0E48\u0E44\u0E21\u0E48\u0E21\u0E35\u0E20\u0E32\u0E1E",
          detail: { text: reply.text.slice(0, 300) }
        });
      }
      ctx.progress("Image ready \u2014 fetching file");
      const asset = await this.ingestMedia(session, src, { kind: "image", providerId: CHATGPT_PROVIDER_ID, sourceUrl: src }, ctx);
      const result = { assets: [asset] };
      if (CONVERSATION_URL.test(reply.url)) result.conversationRef = reply.url;
      return result;
    });
  }
  /**
   * Submits a prompt (unless a checkpoint shows it was already submitted in this conversation)
   * and waits for the complete reply in slices.
   */
  async ask(session, prompt, expect, totalTimeoutMs, ctx, opts = {}) {
    const cp = opts.fresh ? void 0 : ctx.previousCheckpoint;
    const currentUrl = await session.url();
    let afterCount;
    let knownImages = [];
    let reattach = false;
    let adopted;
    if (cp?.phase === "submitted" && typeof cp.data?.["afterCount"] === "number" && cp.data["url"] === currentUrl) {
      afterCount = cp.data["afterCount"];
      const saved = cp.data["knownImages"];
      knownImages = Array.isArray(saved) ? saved.filter((x) => typeof x === "string") : [];
      reattach = true;
      ctx.log.info("Reattaching to a prompt submitted before the restart");
    } else if (expect === "image" && (adopted = await this.adoptable(session, prompt, ctx))) {
      afterCount = adopted.afterCount;
      knownImages = adopted.knownImages;
      reattach = true;
      await ctx.checkpoint("submitted", { afterCount, knownImages, url: adopted.url });
      ctx.log.info("\u0E1E\u0E1A\u0E04\u0E33\u0E02\u0E2D\u0E23\u0E39\u0E1B\u0E19\u0E35\u0E49\u0E43\u0E19\u0E41\u0E0A\u0E17\u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E43\u0E0A\u0E49\u0E23\u0E39\u0E1B\u0E08\u0E32\u0E01\u0E04\u0E33\u0E02\u0E2D\u0E40\u0E14\u0E34\u0E21 \u0E44\u0E21\u0E48\u0E2A\u0E31\u0E48\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E43\u0E2B\u0E21\u0E48");
    } else {
      await this.waitUntilIdle(session, ctx, expect === "image" ? 4 * 6e4 : 2 * 6e4);
      await this.pace(ctx);
      if (opts.attachAssetIds?.length) {
        ctx.progress("\u0E01\u0E33\u0E25\u0E31\u0E07\u0E41\u0E19\u0E1A\u0E23\u0E39\u0E1B\u0E40\u0E02\u0E49\u0E32 ChatGPT");
        const transferIds = await this.pushAssets(session, opts.attachAssetIds, ctx);
        await session.send(CHATGPT_CMD.attach, { transferIds }, { timeoutMs: 9e4, signal: ctx.signal });
      }
      const submitted = await session.send(CHATGPT_CMD.submit, { text: prompt }, {
        timeoutMs: ctx.timeouts.bridgeCommandMs,
        signal: ctx.signal
      });
      this.lastSubmitAt = this.deps.clock.now();
      afterCount = submitted.afterCount;
      knownImages = submitted.knownImages;
      await ctx.checkpoint("submitted", { afterCount, knownImages, url: submitted.url });
      await opts.onSubmitted?.(submitted.url);
      ctx.log.info(`Prompt sent to ChatGPT (${expect})`);
    }
    try {
      return await session.sendUntilDone(
        CHATGPT_CMD.waitReply,
        { afterCount, expect, reattach, knownImages, stallMs: replyStallMs(ctx), prompt },
        {
          totalTimeoutMs,
          sliceMs: WAIT_SLICE_MS,
          signal: ctx.signal,
          clock: this.deps.clock,
          onProgress: (m) => ctx.progress(m)
        }
      );
    } catch (err) {
      const reason = ctx.signal.reason;
      const slowImage = expect === "image" && (reason?.code === ErrorCode.TIMEOUT || reason?.code === ErrorCode.PROGRESS_STALLED);
      if (ctx.signal.aborted && !slowImage) {
        await session.send(CHATGPT_CMD.stop, {}, { timeoutMs: ctx.timeouts.bridgePingMs }).catch(() => void 0);
      }
      throw err;
    }
  }
};
function replyStallMs(ctx) {
  return Math.max(1e4, Math.round(ctx.timeouts.progressStallMs / 2));
}
function textProblem(reply) {
  if (reply.unexpectedImage) return "image";
  return reply.text.trim() === "" && reply.codeBlocks.length === 0 ? "empty" : null;
}

// src/providers/facebook/protocol.ts
var FACEBOOK_PROVIDER_ID = "facebook-web";
var FACEBOOK_PREFIX = "facebook";
var FACEBOOK_HOME = "https://www.facebook.com/";
var FACEBOOK_BRIDGE_VERSION = "5";
var FACEBOOK_CMD = {
  openComposer: `${FACEBOOK_PREFIX}.openComposer`,
  attachMedia: `${FACEBOOK_PREFIX}.attachMedia`,
  waitUpload: `${FACEBOOK_PREFIX}.waitUpload`,
  setCaption: `${FACEBOOK_PREFIX}.setCaption`,
  submitPost: `${FACEBOOK_PREFIX}.submitPost`,
  waitPosted: `${FACEBOOK_PREFIX}.waitPosted`,
  /** Next → scheduling options → date + time → back to settings, verified. Nothing is posted. */
  prepareSchedule: `${FACEBOOK_PREFIX}.prepareSchedule`,
  /** Clicks the final "Schedule" button (irreversible). */
  commitSchedule: `${FACEBOOK_PREFIX}.commitSchedule`,
  waitScheduled: `${FACEBOOK_PREFIX}.waitScheduled`,
  /** Closes the composer without posting (used when native scheduling is not possible). */
  discard: `${FACEBOOK_PREFIX}.discard`
};
var CAPTION_PROBE_CHARS = 40;
var CONFIRM_WINDOW_MS = 45e3;

// src/providers/facebook/adapter.ts
function localParts(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) throw new AppError(ErrorCode.INVALID_INPUT, `Invalid time ${iso}`);
  return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate(), hour: d.getHours(), minute: d.getMinutes() };
}
function captionProbe(caption) {
  return caption.replace(/\s+/g, " ").trim().slice(0, CAPTION_PROBE_CHARS);
}
var FacebookWebAdapter = class extends WebAdapter {
  info = {
    id: FACEBOOK_PROVIDER_ID,
    displayName: "Facebook Page (\u0E40\u0E27\u0E47\u0E1A facebook.com)",
    capabilities: ["publish"],
    origins: ["https://www.facebook.com/*"],
    homeUrl: FACEBOOK_HOME
  };
  siteName = "Facebook";
  spec = {
    providerId: FACEBOOK_PROVIDER_ID,
    background: true,
    expectedVersion: FACEBOOK_BRIDGE_VERSION,
    matches: ["https://www.facebook.com/*"],
    homeUrl: FACEBOOK_HOME,
    bridgeFile: "bridges/facebook-bridge.js",
    commandPrefix: FACEBOOK_PREFIX
  };
  capabilities = {
    publish: {
      publishNow: (req2, ctx) => this.publishNow(req2, ctx),
      schedulePost: (req2, ctx) => this.schedulePost(req2, ctx)
    }
  };
  readyHint() {
    return "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E1B\u0E38\u0E48\u0E21\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E1A\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1E\u0E08 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E27\u0E48\u0E32 URL \u0E40\u0E1E\u0E08\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 \u0E04\u0E38\u0E13\u0E40\u0E1B\u0E47\u0E19\u0E41\u0E2D\u0E14\u0E21\u0E34\u0E19 \u0E41\u0E25\u0E30\u0E2A\u0E25\u0E31\u0E1A\u0E42\u0E1B\u0E23\u0E44\u0E1F\u0E25\u0E4C\u0E40\u0E1B\u0E47\u0E19\u0E40\u0E1E\u0E08\u0E41\u0E25\u0E49\u0E27";
  }
  checkPageUrl(pageUrl) {
    if (!/^https:\/\/www\.facebook\.com\//.test(pageUrl)) {
      throw new AppError(ErrorCode.INVALID_INPUT, "Page URL must be https://www.facebook.com/\u2026", {
        userMessage: "URL \u0E40\u0E1E\u0E08\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 https://www.facebook.com/"
      });
    }
  }
  /** Opens the composer, attaches the media and sets the caption. Nothing is posted. */
  async fillComposer(session, req2, ctx) {
    const cmd = { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal };
    await session.send(FACEBOOK_CMD.openComposer, { fresh: Boolean(req2.acceptSubmission) }, cmd);
    ctx.log.info("Facebook composer opened");
    if (req2.assetIds.length) {
      const transferIds = await this.pushAssets(session, req2.assetIds, ctx);
      const { attached } = await session.send(FACEBOOK_CMD.attachMedia, { transferIds }, cmd);
      if (attached === 0) ctx.log.info("Media already attached in the open composer \u2014 not attaching again");
      ctx.log.info("Facebook upload started", { files: transferIds.length });
      const hasVideo = (await Promise.all(req2.assetIds.map((id2) => ctx.assets.get(id2)))).some((asset) => asset.kind === "video");
      const fallbackMs = !hasVideo && req2.uploadWaitPerFileMs ? req2.uploadWaitPerFileMs * transferIds.length : 0;
      await session.sendUntilDone(FACEBOOK_CMD.waitUpload, { count: transferIds.length, ...fallbackMs ? { fallbackMs } : {} }, {
        totalTimeoutMs: ctx.timeouts.uploadMs,
        sliceMs: WAIT_SLICE_MS,
        signal: ctx.signal,
        clock: this.deps.clock,
        onProgress: (m) => ctx.progress(m)
      });
      ctx.log.info("Facebook upload finished");
    }
    if (req2.caption.trim()) await session.send(FACEBOOK_CMD.setCaption, { text: req2.caption }, cmd);
  }
  /**
   * Facebook's own scheduler (D8 = C). Everything up to the final "Schedule" click is reversible:
   * any problem there closes the composer and throws NATIVE_SCHEDULE_UNAVAILABLE (caller falls back
   * to the local scheduler). After the click the outcome is irreversible → PUBLISH_UNCONFIRMED.
   */
  async schedulePost(req2, ctx) {
    this.checkPageUrl(req2.pageUrl);
    const when = localParts(req2.at);
    return this.withSession(ctx, req2.pageUrl, async (session) => {
      const cmd = { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal };
      let summary;
      try {
        await this.fillComposer(session, req2, ctx);
        ({ summary } = await session.send(FACEBOOK_CMD.prepareSchedule, { when }, cmd));
      } catch (err) {
        const e = toAppError(err);
        if (e.code === ErrorCode.CANCELLED || e.pauseReason) throw e;
        await session.send(FACEBOOK_CMD.discard, {}, cmd).catch(() => void 0);
        if (e.code === ErrorCode.NATIVE_SCHEDULE_UNAVAILABLE) throw e;
        throw new AppError(ErrorCode.NATIVE_SCHEDULE_UNAVAILABLE, `Could not prepare the Facebook schedule: ${e.message}`, { cause: err });
      }
      ctx.log.info(`Facebook shows: ${summary}`);
      await ctx.checkpoint("schedule_clicked", { pageUrl: req2.pageUrl, at: req2.at });
      try {
        await session.send(FACEBOOK_CMD.commitSchedule, { when }, cmd);
      } catch (err) {
        const e = toAppError(err);
        if (e.code === ErrorCode.NATIVE_SCHEDULE_UNAVAILABLE) {
          await session.send(FACEBOOK_CMD.discard, {}, cmd).catch(() => void 0);
          throw e;
        }
        throw new AppError(ErrorCode.PUBLISH_UNCONFIRMED, `Outcome unknown after Schedule click: ${e.message}`, { cause: err });
      }
      ctx.log.info("Facebook Schedule clicked \u2014 confirming");
      try {
        await session.send(FACEBOOK_CMD.waitScheduled, { timeoutMs: CONFIRM_WINDOW_MS }, {
          timeoutMs: CONFIRM_WINDOW_MS + ctx.timeouts.bridgeCommandMs,
          signal: ctx.signal
        });
      } catch (err) {
        const e = toAppError(err);
        if (isBeforePost(e) || e.code === ErrorCode.UPLOAD_FAILED || e.code === ErrorCode.CANCELLED) throw e;
        throw new AppError(ErrorCode.PUBLISH_UNCONFIRMED, `Outcome unknown after Schedule click: ${e.message}`, {
          cause: err,
          userMessage: "\u0E01\u0E14\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E25\u0E49\u0E27\u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E27\u0E48\u0E32\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E17\u0E35\u0E48\u0E15\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32\u0E44\u0E27\u0E49\u0E43\u0E19 Meta Business Suite \u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E15\u0E31\u0E49\u0E07\u0E0B\u0E49\u0E33"
        });
      }
      return { summary };
    });
  }
  async publishNow(req2, ctx) {
    this.checkPageUrl(req2.pageUrl);
    return this.withPostSession(ctx, req2.pageUrl, async (session) => {
      const cmd = { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal };
      await ctx.checkpoint("post_preparing", { pageUrl: req2.pageUrl });
      try {
        await this.fillComposer(session, req2, ctx);
      } catch (err) {
        throw beforePostError(err);
      }
      await ctx.checkpoint("post_submit_started", { pageUrl: req2.pageUrl });
      let posted;
      try {
        await session.send(FACEBOOK_CMD.submitPost, {}, cmd);
        await ctx.checkpoint("post_clicked", { pageUrl: req2.pageUrl });
        ctx.log.info("Facebook Post clicked \u2014 confirming");
        posted = await session.sendUntilDone(
          FACEBOOK_CMD.waitPosted,
          // Photos only: nothing to find in the feed, so a short wait after the composer closed.
          { captionProbe: captionProbe(req2.caption), confirmWindowMs: captionProbe(req2.caption) ? CONFIRM_WINDOW_MS : 5e3, acceptSubmission: Boolean(req2.acceptSubmission) },
          {
            totalTimeoutMs: ctx.timeouts.uploadMs + CONFIRM_WINDOW_MS,
            sliceMs: WAIT_SLICE_MS,
            signal: ctx.signal,
            clock: this.deps.clock,
            onProgress: (m) => ctx.progress(m)
          }
        );
      } catch (err) {
        const e = toAppError(err);
        if (isBeforePost(e) || e.code === ErrorCode.UPLOAD_FAILED || e.code === ErrorCode.CANCELLED) throw e;
        throw new AppError(ErrorCode.PUBLISH_UNCONFIRMED, `Outcome unknown after Post click: ${e.message}`, { cause: err, userMessage: `\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E1C\u0E25\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 ${e.userMessage} \u0E15\u0E23\u0E27\u0E08\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1F\u0E2A/\u0E40\u0E1E\u0E08\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33`, detail: { mayHaveSent: true, causeCode: e.code } });
      }
      if (!posted.confirmed) {
        if (!captionProbe(req2.caption)) {
          ctx.log.info("\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E23\u0E39\u0E1B\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E40\u0E14\u0E35\u0E22\u0E27 \u2014 \u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E08\u0E32\u0E01\u0E01\u0E25\u0E48\u0E2D\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E1B\u0E34\u0E14\u0E42\u0E14\u0E22\u0E44\u0E21\u0E48\u0E21\u0E35\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14");
          return { confirmedBy: "dom" };
        }
        throw new AppError(ErrorCode.PUBLISH_UNCONFIRMED, "Composer closed but the new post was not found on the page");
      }
      const result = { confirmedBy: "dom" };
      if (posted.postUrl) result.postUrl = posted.postUrl;
      return result;
    });
  }
};

// src/providers/facebook-group/protocol.ts
var GROUP_CMD = {
  inspect: "facebook.group.inspect",
  open: "facebook.group.open",
  attach: "facebook.group.attach",
  upload: "facebook.group.upload",
  caption: "facebook.group.caption",
  submit: "facebook.group.submit",
  confirm: "facebook.group.confirm",
  pendingRoute: "facebook.group.pendingRoute",
  pendingList: "facebook.group.pendingList",
  scanJoined: "facebook.group.scanJoined"
};
var GROUPS_JOINS_URL = "https://www.facebook.com/groups/joins/?nav_source=tab";

// src/providers/facebook-group/adapter.ts
var FacebookGroupWebAdapter = class extends WebAdapter {
  info = { id: "facebook-group-web", displayName: "Facebook Group", capabilities: [], origins: ["https://www.facebook.com/*"], homeUrl: FACEBOOK_HOME };
  capabilities = {};
  siteName = "Facebook Group";
  spec = {
    providerId: "facebook-group-web",
    background: true,
    expectedVersion: FACEBOOK_BRIDGE_VERSION,
    matches: ["https://www.facebook.com/groups/*"],
    homeUrl: FACEBOOK_HOME,
    bridgeFile: "bridges/facebook-bridge.js",
    commandPrefix: FACEBOOK_PREFIX
  };
  readyHint() {
    return "\u0E40\u0E1B\u0E34\u0E14\u0E01\u0E25\u0E38\u0E48\u0E21\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u0E2B\u0E23\u0E37\u0E2D Facebook UI \u0E2D\u0E32\u0E08\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E17\u0E47\u0E1A Facebook";
  }
  async inspectGroup(url, ctx) {
    const target = this.target(url);
    return this.withSession(ctx, target, (session) => this.shown(session, () => session.send(GROUP_CMD.inspect, { url: target }, { timeoutMs: ctx.timeouts.bridgeCommandMs * 2, signal: ctx.signal })));
  }
  /**
   * Reads every group the logged-in account has joined from "Your groups", a slice at a time
   * (Facebook loads more cards as the page scrolls). Read-only: nothing is clicked in any group.
   * `onSlice` gets the list after each slice; `shouldStop` ends the scan early with what was found.
   */
  async scanJoinedGroups(ctx, onSlice, shouldStop) {
    const sliceMs = 3e3;
    return this.deps.tabs.withLock(this.spec, async (session) => {
      const back = await session.bringToFront();
      try {
        for (let first = true; ; first = false) {
          const res = await session.send(GROUP_CMD.scanJoined, { sliceMs, reset: first }, { timeoutMs: sliceMs + 1e4, signal: ctx.signal });
          onSlice(res.groups);
          if (res.done) return { groups: res.groups, complete: true };
          if (shouldStop()) return { groups: res.groups, complete: false };
        }
      } finally {
        await session.returnTo(back);
      }
    }, { timeouts: ctx.timeouts, signal: ctx.signal, url: GROUPS_JOINS_URL });
  }
  target(url) {
    const target = parseGroupUrl(url);
    if (!target) throw new AppError(ErrorCode.INVALID_INPUT, "Invalid Facebook Group URL", { userMessage: "\u0E25\u0E34\u0E07\u0E01\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21 Facebook \u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" });
    return target;
  }
  async publishGroup(req2, ctx) {
    const url = this.target(req2.pageUrl);
    return this.withPostSession(ctx, url, (session) => this.shown(session, () => this.postInGroup(session, req2, url, ctx)));
  }
  async shown(session, fn) {
    const back = await session.bringToFront();
    try {
      return await fn();
    } finally {
      await session.returnTo(back);
    }
  }
  async postInGroup(session, req2, url, ctx) {
    {
      const cmd = { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal };
      const route = req2.acceptSubmission ? { url: null } : await session.send(GROUP_CMD.pendingRoute, { url }, cmd);
      let baseline;
      if (route.url) {
        try {
          await session.navigate(route.url, ctx.timeouts, ctx.signal);
          baseline = await session.send(GROUP_CMD.pendingList, { url }, cmd);
        } catch {
          ctx.log.info("\u0E2D\u0E48\u0E32\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E01\u0E48\u0E2D\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E08\u0E30\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E2B\u0E25\u0E31\u0E01\u0E10\u0E32\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48");
        }
        await session.navigate(url, ctx.timeouts, ctx.signal);
        await this.ensureReady(session, ctx);
      }
      await ctx.checkpoint("post_preparing", { pageUrl: url });
      try {
        ctx.progress("\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07\u0E40\u0E02\u0E35\u0E22\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E19\u0E01\u0E25\u0E38\u0E48\u0E21");
        await session.send(GROUP_CMD.open, { url }, cmd);
        if (req2.assetIds.length) {
          ctx.progress(`\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E48\u0E07\u0E23\u0E39\u0E1B ${req2.assetIds.length} \u0E23\u0E39\u0E1B\u0E40\u0E02\u0E49\u0E32\u0E42\u0E1E\u0E2A\u0E15\u0E4C`);
          const transferIds = await this.pushAssets(session, req2.assetIds, ctx);
          await session.send(GROUP_CMD.attach, { transferIds }, cmd);
          const perPhoto = Math.max(0, req2.uploadWaitPerFileMs ?? 0);
          if (perPhoto > 0) {
            const n = transferIds.length;
            for (let left = perPhoto * n; left > 0; left -= 1e3) {
              ctx.progress(`\u0E23\u0E2D\u0E23\u0E39\u0E1B\u0E02\u0E36\u0E49\u0E19 ${n} \u0E23\u0E39\u0E1B (${Math.round(perPhoto / 1e3)} \u0E27\u0E34/\u0E23\u0E39\u0E1B) \xB7 \u0E2D\u0E35\u0E01 ${Math.ceil(left / 1e3)} \u0E27\u0E34`);
              await delay(Math.min(1e3, left), ctx.signal);
            }
          } else {
            await session.sendUntilDone(GROUP_CMD.upload, { count: transferIds.length }, {
              totalTimeoutMs: ctx.timeouts.uploadMs,
              sliceMs: WAIT_SLICE_MS,
              signal: ctx.signal,
              clock: this.deps.clock,
              onProgress: (m) => ctx.progress(m)
            });
          }
        }
        ctx.progress("\u0E01\u0E33\u0E25\u0E31\u0E07\u0E43\u0E2A\u0E48\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E42\u0E1E\u0E2A\u0E15\u0E4C");
        await session.send(GROUP_CMD.caption, { text: req2.caption, ...req2.assetIds.length && (req2.uploadWaitPerFileMs ?? 0) > 0 ? { timed: true } : {} }, cmd);
      } catch (err) {
        throw beforePostError(err);
      }
      await ctx.checkpoint("post_submit_started", { pageUrl: url });
      try {
        ctx.progress("\u0E01\u0E33\u0E25\u0E31\u0E07\u0E01\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C");
        await session.send(GROUP_CMD.submit, {}, cmd);
        await ctx.checkpoint("post_clicked", { pageUrl: url });
        return await session.sendUntilDone(GROUP_CMD.confirm, { confirmWindowMs: CONFIRM_WINDOW_MS, acceptSubmission: Boolean(req2.acceptSubmission) }, {
          totalTimeoutMs: ctx.timeouts.uploadMs + CONFIRM_WINDOW_MS,
          sliceMs: WAIT_SLICE_MS,
          signal: ctx.signal,
          clock: this.deps.clock,
          onProgress: (m) => ctx.progress(m)
        });
      } catch (err) {
        const e = toAppError(err);
        if (isBeforePost(e) || e.code === ErrorCode.UPLOAD_FAILED || e.code === ErrorCode.CANCELLED) throw e;
        if (e.code === ErrorCode.PUBLISH_UNCONFIRMED && route.url && baseline) {
          try {
            await session.navigate(route.url, ctx.timeouts, ctx.signal);
            const after = await session.send(GROUP_CMD.pendingList, { url }, cmd);
            const newest = after.posts[0];
            const needle = req2.caption.replace(/[^\p{L}\p{M}\p{N}]+/gu, "");
            const retainedBaseline = baseline.count === 0 || after.posts.some((post) => post.url === baseline.posts[0]?.url);
            if (newest && needle && after.count > baseline.count && retainedBaseline && newest.text.includes(needle) && !baseline.posts.some((post) => post.url === newest.url)) {
              return { outcome: "pending_approval", confirmedBy: "dom", postUrl: newest.url };
            }
          } catch {
            ctx.log.info("\u0E15\u0E23\u0E27\u0E08\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E2B\u0E25\u0E31\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E15\u0E49\u0E2D\u0E07\u0E43\u0E2B\u0E49\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49\u0E15\u0E23\u0E27\u0E08\u0E1C\u0E25");
          }
        }
        throw new AppError(ErrorCode.PUBLISH_UNCONFIRMED, `Group post outcome unconfirmed: ${e.code}`, {
          cause: err,
          userMessage: `\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E1C\u0E25\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E01\u0E25\u0E38\u0E48\u0E21\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 ${e.userMessage} \u0E15\u0E23\u0E27\u0E08\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E30\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33`,
          detail: { mayHaveSent: true, causeCode: e.code }
        });
      }
    }
  }
};

// src/providers/facebook-story/protocol.ts
var STORY_PROVIDER = "facebook-story-web";
var STORY_PREFIX = "facebookStory";
var STORY_URL = "https://www.facebook.com/stories/create/";
var STORY_CMD = {
  attach: `${STORY_PREFIX}.attach`,
  preview: `${STORY_PREFIX}.preview`,
  owner: `${STORY_PREFIX}.owner`,
  publish: `${STORY_PREFIX}.publish`,
  observe: `${STORY_PREFIX}.observe`,
  nextCard: `${STORY_PREFIX}.nextCard`
};

// src/providers/facebook-story/photo-proof.ts
async function photoPixels(blob, aspect) {
  const image = await createImageBitmap(blob);
  try {
    const canvas = new OffscreenCanvas(96, 96);
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Cannot compare Story photo");
    let w = image.width;
    let h = image.height;
    if (aspect) {
      if (w / h > aspect) w = h * aspect;
      else h = w / aspect;
    }
    ctx.drawImage(image, (image.width - w) / 2, (image.height - h) / 2, w, h, 0, 0, 96, 96);
    const rgba = ctx.getImageData(0, 0, 96, 96).data;
    return Array.from(rgba).filter((_, i) => i % 4 !== 3);
  } finally {
    image.close();
  }
}
function samePhoto(a, b) {
  if (!a.length || a.length !== b.length) return false;
  const spread = Math.max(...a) - Math.min(...a);
  if (spread < 40) return false;
  const differences = a.map((n, i) => Math.abs(n - b[i]));
  return differences.reduce((sum, n) => sum + n, 0) / a.length < 4 && Math.sqrt(differences.reduce((sum, n) => sum + n * n, 0) / a.length) < 8 && differences.filter((n) => n > 40).length / a.length < 2e-3;
}

// src/providers/facebook-story/adapter.ts
var FacebookStoryAdapter = class extends WebAdapter {
  info = { id: STORY_PROVIDER, displayName: "Facebook Story Preview", capabilities: [], origins: ["https://www.facebook.com/*"], homeUrl: STORY_URL };
  capabilities = {};
  siteName = "Facebook";
  spec = {
    providerId: STORY_PROVIDER,
    matches: ["https://www.facebook.com/*"],
    homeUrl: STORY_URL,
    bridgeFile: "bridges/facebook-story-bridge.js",
    commandPrefix: STORY_PREFIX
  };
  async prepare(assetId, ctx) {
    return this.storySession(ctx, async (session) => {
      const transferIds = await this.pushAssets(session, [assetId], ctx);
      await session.send(STORY_CMD.attach, { transferId: transferIds[0] }, { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal });
      await session.sendUntilDone(STORY_CMD.preview, {}, {
        totalTimeoutMs: ctx.timeouts.uploadMs,
        sliceMs: WAIT_SLICE_MS,
        signal: ctx.signal,
        clock: this.deps.clock,
        onProgress: (message) => ctx.progress(message)
      });
      const tab = await chrome.tabs.get(session.tabId);
      if (tab.windowId !== void 0) await chrome.windows.update(tab.windowId, { focused: true });
      return { tabId: session.tabId, ready: true, published: false, messageButton: "unavailable" };
    });
  }
  storySession(ctx, fn) {
    return this.deps.tabs.withLock(this.spec, async (session) => {
      await session.activate();
      const url = new URL(await session.url());
      if (!/^\/stories\/create\/?$/.test(url.pathname)) {
        if (!/^\/stories(?:\/?$|\/\d+(?:\/|$))/.test(url.pathname)) {
          throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Story tab is not a known viewer route", { userMessage: "\u0E41\u0E17\u0E47\u0E1A Story \u0E2D\u0E22\u0E39\u0E48\u0E2B\u0E19\u0E49\u0E32\u0E2D\u0E37\u0E48\u0E19\u0E17\u0E35\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A \u2014 \u0E44\u0E21\u0E48\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E41\u0E25\u0E30\u0E44\u0E21\u0E48\u0E41\u0E17\u0E19\u0E23\u0E48\u0E32\u0E07\u0E40\u0E14\u0E34\u0E21 \u0E15\u0E23\u0E27\u0E08\u0E41\u0E17\u0E47\u0E1A Facebook \u0E01\u0E48\u0E2D\u0E19" });
        }
        await session.navigate(STORY_URL, ctx.timeouts, ctx.signal);
      }
      await this.ensureReady(session, ctx);
      return fn(session);
    }, { timeouts: ctx.timeouts, signal: ctx.signal });
  }
  async inspectOwner(ctx) {
    return this.storySession(ctx, async (session) => (await session.send(STORY_CMD.owner, {}, {
      timeoutMs: ctx.timeouts.bridgeCommandMs,
      signal: ctx.signal
    })).owner);
  }
  async publishPhoto(assetId, owner, ctx, beforeClick) {
    await this.storySession(ctx, async (session) => {
      const options = { timeoutMs: ctx.timeouts.bridgeCommandMs, signal: ctx.signal };
      const actualOwner = await session.send(STORY_CMD.owner, {}, options);
      if (actualOwner.owner !== owner) throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Story account changed", { userMessage: "\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Facebook \u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E08\u0E32\u0E01\u0E0A\u0E38\u0E14\u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E0A\u0E38\u0E14\u0E41\u0E25\u0E49\u0E27" });
      const blob = await ctx.assets.getBlob(assetId);
      const source = await createImageBitmap(blob);
      const aspect = source.width / source.height;
      source.close();
      const pixels = await photoPixels(blob);
      if (!samePhoto(pixels, pixels)) throw new AppError(ErrorCode.INVALID_INPUT, "Flat photo cannot be verified", { userMessage: "\u0E23\u0E39\u0E1B\u0E19\u0E35\u0E49\u0E21\u0E35\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E19\u0E49\u0E2D\u0E22\u0E40\u0E01\u0E34\u0E19\u0E44\u0E1B\u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E1C\u0E25\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34 \u2014 \u0E43\u0E0A\u0E49 Preview \u0E41\u0E25\u0E30\u0E41\u0E0A\u0E23\u0E4C\u0E40\u0E2D\u0E07" });
      const transferIds = await this.pushAssets(session, [assetId], ctx);
      await session.send(STORY_CMD.attach, { transferId: transferIds[0] }, options);
      await session.sendUntilDone(STORY_CMD.preview, {}, {
        totalTimeoutMs: ctx.timeouts.uploadMs,
        sliceMs: WAIT_SLICE_MS,
        signal: ctx.signal,
        clock: this.deps.clock
      });
      await beforeClick();
      await session.send(STORY_CMD.publish, { owner }, options);
      const deadline = this.deps.clock.now() + ctx.timeouts.uploadMs;
      const seen = /* @__PURE__ */ new Set();
      while (this.deps.clock.now() < deadline) {
        await session.ensureBridge(ctx.timeouts, ctx.signal);
        const evidence = await session.send(STORY_CMD.observe, { owner }, options);
        if (evidence?.src && !seen.has(evidence.src)) {
          seen.add(evidence.src);
          const url = new URL(evidence.src);
          if (evidence.fresh && url.protocol === "https:" && url.hostname.endsWith(".fbcdn.net")) {
            const response = await fetch(url, { credentials: "omit", redirect: "error", signal: ctx.signal });
            if (response.ok && response.headers.get("content-type")?.startsWith("image/")) {
              const published = await response.blob();
              if (published.size <= 20 * 1024 * 1024 && samePhoto(pixels, await photoPixels(published, aspect))) return;
            }
          }
          if (evidence.next) {
            await session.send(STORY_CMD.nextCard, { owner }, options);
          }
        } else if (evidence && !evidence.src && evidence.next) {
          await session.send(STORY_CMD.nextCard, { owner }, options);
        }
        await delay(1e3, ctx.signal);
      }
      throw new AppError(ErrorCode.PUBLISH_UNCONFIRMED, "Story photo not confirmed in own fresh card", { userMessage: "\u0E01\u0E14\u0E41\u0E0A\u0E23\u0E4C Story \u0E41\u0E25\u0E49\u0E27 \u0E41\u0E15\u0E48\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E23\u0E39\u0E1B\u0E43\u0E2B\u0E21\u0E48\u0E43\u0E19\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E2B\u0E22\u0E38\u0E14\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14 \u0E15\u0E23\u0E27\u0E08 Facebook \u0E01\u0E48\u0E2D\u0E19 \u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E23\u0E39\u0E1B\u0E19\u0E35\u0E49\u0E0B\u0E49\u0E33" });
    });
  }
};

// src/shared/line-openchat.ts
var LINE_HOST_NAME = "com.drfx.line_openchat";
var LINE_HOST_MIN_VERSION = "1.0.0";
var LINE_HOST_ERRORS = {
  LINE_NOT_RUNNING: "LINE PC \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1B\u0E34\u0E14 \u2014 \u0E40\u0E1B\u0E34\u0E14 LINE \u0E41\u0E25\u0E30\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19\u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry",
  LINE_WINDOW_NOT_FOUND: "\u0E40\u0E1B\u0E34\u0E14 LINE \u0E2D\u0E22\u0E39\u0E48\u0E41\u0E15\u0E48\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07\u0E2B\u0E25\u0E31\u0E01 (\u0E01\u0E33\u0E25\u0E31\u0E07\u0E25\u0E47\u0E2D\u0E01\u0E2D\u0E34\u0E19?) \u2014 \u0E23\u0E2D\u0E43\u0E2B\u0E49 LINE \u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry",
  FOCUS_FAILED: "\u0E14\u0E36\u0E07\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07 LINE \u0E21\u0E32\u0E14\u0E49\u0E32\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E1B\u0E34\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07\u0E17\u0E35\u0E48\u0E1A\u0E31\u0E07\u0E2D\u0E22\u0E39\u0E48 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry",
  FOCUS_LOST: "\u0E2B\u0E22\u0E38\u0E14\u0E2A\u0E48\u0E07\u0E40\u0E1E\u0E23\u0E32\u0E30\u0E21\u0E35\u0E01\u0E32\u0E23\u0E41\u0E15\u0E30\u0E40\u0E21\u0E32\u0E2A\u0E4C/\u0E04\u0E35\u0E22\u0E4C\u0E1A\u0E2D\u0E23\u0E4C\u0E14 (\u0E2B\u0E23\u0E37\u0E2D\u0E01\u0E14 Ctrl+Alt+Del \u0E1B\u0E25\u0E14\u0E25\u0E47\u0E2D\u0E01) \u2014 \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E19 LINE PC \u0E40\u0E0A\u0E47\u0E01\u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E2A\u0E16\u0E32\u0E19\u0E30 (\u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33\u0E16\u0E49\u0E32\u0E02\u0E36\u0E49\u0E19\u0E41\u0E25\u0E49\u0E27)",
  CLIPBOARD_BUSY: "\u0E43\u0E0A\u0E49 clipboard \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27 (\u0E42\u0E1B\u0E23\u0E41\u0E01\u0E23\u0E21\u0E2D\u0E37\u0E48\u0E19\u0E16\u0E37\u0E2D\u0E44\u0E27\u0E49) \u2014 \u0E01\u0E14 Retry",
  FILE_MISSING: "\u0E44\u0E1F\u0E25\u0E4C\u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E44\u0E27\u0E49\u0E2B\u0E32\u0E22 \u2014 \u0E01\u0E14 Retry \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E43\u0E2B\u0E21\u0E48",
  DESTINATION_MISMATCH: 'LINE \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E2B\u0E31\u0E27\u0E41\u0E0A\u0E17\u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E2B\u0E49\u0E2D\u0E07\u0E17\u0E35\u0E48\u0E1A\u0E2D\u0E17\u0E08\u0E33\u0E44\u0E27\u0E49 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07\u0E2D\u0E30\u0E44\u0E23\u0E40\u0E25\u0E22 \u0E15\u0E23\u0E27\u0E08\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E19 LINE PC \xB7 \u0E16\u0E49\u0E32\u0E2B\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E23\u0E37\u0E2D\u0E23\u0E39\u0E1B\u0E08\u0E23\u0E34\u0E07 \u0E43\u0E2B\u0E49\u0E01\u0E14 "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07" \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E43\u0E2B\u0E49\u0E1A\u0E2D\u0E17\u0E08\u0E33\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48',
  LINE_WINDOW_CHANGED: "\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07 LINE \u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E01\u0E25\u0E32\u0E07\u0E04\u0E31\u0E19 (\u0E40\u0E0A\u0E48\u0E19 \u0E21\u0E35\u0E41\u0E08\u0E49\u0E07\u0E40\u0E15\u0E37\u0E2D\u0E19\u0E08\u0E32\u0E01\u0E2B\u0E49\u0E2D\u0E07\u0E2D\u0E37\u0E48\u0E19\u0E40\u0E14\u0E49\u0E07) \u2014 \u0E1A\u0E2D\u0E17\u0E2B\u0E22\u0E38\u0E14\u0E44\u0E27\u0E49 \u0E44\u0E21\u0E48\u0E04\u0E25\u0E34\u0E01\u0E15\u0E48\u0E2D \xB7 \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07\u0E43\u0E19 LINE PC \u0E40\u0E0A\u0E47\u0E01\u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D\u0E43\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E2A\u0E16\u0E32\u0E19\u0E30 (\u0E2B\u0E49\u0E32\u0E21\u0E2A\u0E48\u0E07\u0E0B\u0E49\u0E33\u0E16\u0E49\u0E32\u0E02\u0E36\u0E49\u0E19\u0E41\u0E25\u0E49\u0E27)",
  ROOM_NOT_READY: "\u0E2B\u0E49\u0E2D\u0E07\u0E41\u0E0A\u0E17\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E34\u0E14/\u0E22\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E21\u0E48\u0E40\u0E2A\u0E23\u0E47\u0E08 (\u0E25\u0E2D\u0E07\u0E04\u0E49\u0E19\u0E2B\u0E32\u0E43\u0E2B\u0E21\u0E48\u0E41\u0E25\u0E49\u0E27) \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07\u0E2D\u0E30\u0E44\u0E23\u0E40\u0E25\u0E22 \xB7 \u0E16\u0E49\u0E32\u0E2B\u0E49\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E40\u0E1B\u0E34\u0E14\u0E04\u0E49\u0E32\u0E07\u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E49\u0E27\u0E41\u0E25\u0E30\u0E1A\u0E2D\u0E17\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E04\u0E22\u0E08\u0E33\u0E2B\u0E49\u0E2D\u0E07\u0E19\u0E35\u0E49 \u0E43\u0E2B\u0E49\u0E04\u0E25\u0E34\u0E01\u0E44\u0E1B\u0E2B\u0E49\u0E2D\u0E07\u0E2D\u0E37\u0E48\u0E19\u0E43\u0E19 LINE \u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 Retry",
  HOST_NOT_INSTALLED: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE PC \u2014 \u0E14\u0E39\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A LINE OpenChat",
  HOST_ERROR: "\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE PC \u0E17\u0E33\u0E07\u0E32\u0E19\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14 \u2014 \u0E14\u0E39 host.log \u0E43\u0E19 %LOCALAPPDATA%\\DRFX\\line-host"
};

// src/providers/line-openchat/protocol.ts
function isHostEvent(m) {
  return "event" in m;
}
function versionAtLeast(actual, min) {
  const a = actual.split(".").map((n) => Number(n) || 0);
  const b = min.split(".").map((n) => Number(n) || 0);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] ?? 0, y = b[i] ?? 0;
    if (x !== y) return x > y;
  }
  return true;
}

// src/providers/line-openchat/adapter.ts
var COMMAND_MS = 12e4;
var CONNECT_MS = 15e3;
var HostLink = class _HostLink {
  constructor(port5) {
    this.port = port5;
    port5.onMessage.addListener((raw) => this.onMessage(raw));
    port5.onDisconnect.addListener(() => {
      const why = chrome.runtime.lastError?.message ?? "native host disconnected";
      this.closed = why;
      for (const p of this.pending.values()) p.reject(hostUnreachable(why));
      this.pending.clear();
    });
  }
  next = 1;
  pending = /* @__PURE__ */ new Map();
  closed = null;
  static async open(signal) {
    if (typeof chrome.runtime.connectNative !== "function") throw hostUnreachable("nativeMessaging not available");
    const link = new _HostLink(chrome.runtime.connectNative(LINE_HOST_NAME));
    const ping = await link.call({ cmd: "ping" }, { timeoutMs: CONNECT_MS, ...signal ? { signal } : {} });
    const version = str2(ping, "version") || "0.0.0";
    if (!versionAtLeast(version, LINE_HOST_MIN_VERSION)) {
      link.close();
      throw new AppError(ErrorCode.PROVIDER_NOT_CONFIGURED, `LINE host ${version} < ${LINE_HOST_MIN_VERSION}`, { userMessage: `\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE PC \u0E40\u0E1B\u0E47\u0E19\u0E23\u0E38\u0E48\u0E19\u0E40\u0E01\u0E48\u0E32 (${version}) \u2014 \u0E23\u0E31\u0E19 install.cmd \u0E08\u0E32\u0E01\u0E42\u0E1F\u0E25\u0E40\u0E14\u0E2D\u0E23\u0E4C native-host \u0E02\u0E2D\u0E07\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E23\u0E38\u0E48\u0E19\u0E19\u0E35\u0E49\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07` });
    }
    return link;
  }
  onMessage(m) {
    const p = this.pending.get(m.id);
    if (!p) return;
    if (isHostEvent(m)) {
      const data = { ...m };
      delete data["id"];
      delete data["event"];
      delete data["phase"];
      p.onEvent?.(m.phase, data);
      return;
    }
    this.pending.delete(m.id);
    p.resolve(m);
  }
  call(command, opts = {}) {
    if (this.closed) return Promise.reject(hostUnreachable(this.closed));
    const id2 = this.next++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id2);
        reject(new AppError(ErrorCode.TIMEOUT, `LINE host '${command.cmd}' timed out`, { userMessage: "LINE PC \u0E44\u0E21\u0E48\u0E15\u0E2D\u0E1A\u0E2A\u0E19\u0E2D\u0E07\u0E43\u0E19\u0E40\u0E27\u0E25\u0E32\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E27\u0E48\u0E32 LINE \u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E22\u0E39\u0E48\u0E41\u0E25\u0E30\u0E44\u0E21\u0E48\u0E21\u0E35\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07\u0E04\u0E49\u0E32\u0E07" }));
      }, opts.timeoutMs ?? COMMAND_MS);
      const abort = () => {
        clearTimeout(timer);
        this.pending.delete(id2);
        reject(new AppError(ErrorCode.CANCELLED, "cancelled"));
      };
      opts.signal?.addEventListener("abort", abort, { once: true });
      const entry = {
        resolve: (m) => {
          clearTimeout(timer);
          opts.signal?.removeEventListener("abort", abort);
          if (isHostEvent(m)) return;
          if (m.ok) resolve(m);
          else reject(hostFailure(m));
        },
        reject: (e) => {
          clearTimeout(timer);
          opts.signal?.removeEventListener("abort", abort);
          reject(e);
        }
      };
      if (opts.onEvent) entry.onEvent = opts.onEvent;
      this.pending.set(id2, entry);
      try {
        this.port.postMessage({ id: id2, ...command });
      } catch (err) {
        this.pending.delete(id2);
        clearTimeout(timer);
        reject(hostUnreachable(err instanceof Error ? err.message : String(err)));
      }
    });
  }
  close() {
    try {
      this.port.disconnect();
    } catch {
    }
  }
};
function str2(r, key) {
  const v = r[key];
  return typeof v === "string" ? v : typeof v === "number" ? String(v) : "";
}
function hostUnreachable(why) {
  const notInstalled = /not found|forbidden|Access to the specified native messaging host is forbidden|Native host has exited/i.test(why);
  return new AppError(ErrorCode.PROVIDER_NOT_CONFIGURED, `LINE host unreachable: ${why}`, {
    userMessage: notInstalled ? LINE_HOST_ERRORS["HOST_NOT_INSTALLED"] : `\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE PC \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (${why}) \u2014 \u0E14\u0E39\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E43\u0E19\u0E41\u0E17\u0E47\u0E1A LINE OpenChat`,
    detail: { hostError: why }
  });
}
function hostFailure(m) {
  const userMessage = LINE_HOST_ERRORS[m.code] ?? `\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 LINE PC \u0E41\u0E08\u0E49\u0E07: ${m.message}`;
  const detail = { hostCode: m.code };
  if (m.mayHaveSent) detail["mayHaveSent"] = true;
  if (m.code === "DESTINATION_MISMATCH") return new AppError(ErrorCode.DESTINATION_MISMATCH, m.message, { userMessage, detail });
  if (m.code === "FOCUS_LOST" || m.code === "LINE_WINDOW_CHANGED") return new AppError(ErrorCode.SEND_UNCONFIRMED, m.message, { userMessage, detail });
  if (m.code === "LINE_NOT_RUNNING" || m.code === "LINE_WINDOW_NOT_FOUND" || m.code === "FOCUS_FAILED" || m.code === "CLIPBOARD_BUSY" || m.code === "FILE_MISSING" || m.code === "ROOM_NOT_READY") {
    return new AppError(ErrorCode.PAGE_NOT_READY, m.message, { userMessage, detail, retryable: false });
  }
  return new AppError(ErrorCode.SEND_FAILED, m.message, { userMessage, detail });
}
var LineOpenChatAdapter = class {
  id = "line-openchat";
  /** Host reachable? LINE running? (never touches LINE's window) */
  async status() {
    const extensionId = chrome.runtime.id;
    let link = null;
    try {
      link = await HostLink.open();
      const ping = await link.call({ cmd: "ping" }, { timeoutMs: CONNECT_MS });
      return { connected: true, extensionId, hostVersion: str2(ping, "version"), lineRunning: Boolean(ping["lineRunning"]), uia: Boolean(ping["uia"]), hostDir: str2(ping, "hostDir") };
    } catch (err) {
      const e = err instanceof AppError ? err : new AppError(ErrorCode.INTERNAL, String(err));
      const detail = e.detail;
      return { connected: false, extensionId, error: detail?.hostError ?? e.userMessage };
    } finally {
      link?.close();
    }
  }
  /** Focuses LINE and dumps what Windows UI Automation sees + a screenshot (for tuning config.json). */
  async diagnose(ctx) {
    const link = await HostLink.open(ctx.signal);
    try {
      const r = await link.call({ cmd: "diagnose" }, { signal: ctx.signal });
      return r;
    } finally {
      link.close();
    }
  }
  /** Opens the room (no sending) and returns LINE's title when readable, plus a screenshot. */
  async inspectRoom(room, ctx, lockInput) {
    const link = await HostLink.open(ctx.signal);
    try {
      ctx.log.info(`LINE: \u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07 "${room.name}" \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E15\u0E23\u0E27\u0E08 (\u0E44\u0E21\u0E48\u0E2A\u0E48\u0E07)`);
      const r = await link.call({ cmd: "inspect", roomName: room.name, ...room.url ? { roomUrl: room.url } : {}, ...lockInput !== void 0 ? { ui: { blockInput: lockInput } } : {} }, { signal: ctx.signal });
      return { title: str2(r, "title"), verifiedBy: r["verifiedBy"] === "uia" ? "uia" : "screenshot", screenshot: str2(r, "screenshot") };
    } finally {
      link.close();
    }
  }
  /** Photos (one message) then the text (second message); checkpoints "images_sent" for retries. */
  async send(req2, ctx) {
    const images = req2.skipImages ? [] : req2.imageAssetIds;
    const text2 = req2.text.trim() ? req2.text : "";
    if (!text2 && images.length === 0) {
      if (req2.skipImages) return { confirmedBy: "host" };
      throw new AppError(ErrorCode.INVALID_INPUT, "Empty message", { userMessage: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E27\u0E48\u0E32\u0E07\u0E41\u0E25\u0E30\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B" });
    }
    if (!req2.expectedTitle) throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Room not verified", { userMessage: `\u0E2B\u0E49\u0E2D\u0E07 "${req2.roomName}" \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E17\u0E14\u0E2A\u0E2D\u0E1A \u2014 \u0E01\u0E14 "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07" \u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01` });
    const link = await HostLink.open(ctx.signal);
    const sessionId = newId("ls_");
    try {
      const files = [];
      for (let i = 0; i < images.length; i++) {
        const assetId = images[i];
        const [asset, blob] = await Promise.all([ctx.assets.get(assetId), ctx.assets.getBlob(assetId)]);
        ctx.progress(`\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E23\u0E39\u0E1B ${i + 1}/${images.length}`);
        const ext = asset.mime === "image/png" ? "png" : asset.mime === "image/webp" ? "webp" : asset.mime === "video/mp4" ? "mp4" : "jpg";
        const dataBase64 = bytesToBase64(new Uint8Array(await blob.arrayBuffer()));
        const staged = await link.call({ cmd: "stageFile", sessionId, index: i + 1, name: `${asset.id}.${ext}`, dataBase64 }, { signal: ctx.signal });
        files.push(str2(staged, "path"));
      }
      ctx.progress(images.length ? `\u0E2A\u0E48\u0E07\u0E23\u0E39\u0E1B ${images.length} \u0E23\u0E39\u0E1B\u0E40\u0E02\u0E49\u0E32 LINE PC\u2026` : "\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E40\u0E02\u0E49\u0E32 LINE PC\u2026");
      const r = await link.call(
        { cmd: "send", roomName: req2.roomName, ...req2.roomUrl ? { roomUrl: req2.roomUrl } : {}, expectedTitle: req2.expectedTitle, text: text2, files, ...req2.lockInput !== void 0 ? { ui: { blockInput: req2.lockInput } } : {} },
        {
          signal: ctx.signal,
          timeoutMs: COMMAND_MS + images.length * 1e4,
          onEvent: (phase) => {
            if (phase === "line_focused") ctx.progress("\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07 LINE PC \u0E41\u0E25\u0E49\u0E27");
            else if (phase === "room_opened") ctx.progress(`\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E49\u0E2D\u0E07 "${req2.roomName}" \u0E41\u0E25\u0E49\u0E27`);
            else if (phase === "images_pasted") ctx.progress("\u0E27\u0E32\u0E07\u0E23\u0E39\u0E1B\u0E43\u0E19\u0E0A\u0E48\u0E2D\u0E07\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E48\u0E07");
            else if (phase === "images_sent") {
              ctx.progress("\u0E2A\u0E48\u0E07\u0E23\u0E39\u0E1B\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E15\u0E48\u0E2D\u0E14\u0E49\u0E27\u0E22\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21");
              void ctx.checkpoint("images_sent", { room: req2.roomName, images: images.length });
            } else if (phase === "text_sent") ctx.progress("\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E25\u0E49\u0E27");
          }
        }
      );
      const title = str2(r, "title");
      ctx.log.info(`LINE: \u0E2A\u0E48\u0E07\u0E40\u0E02\u0E49\u0E32 "${req2.roomName}" \u0E41\u0E25\u0E49\u0E27 (${images.length} \u0E23\u0E39\u0E1B${text2 ? " + \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21" : ""}) \u2014 \u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E08\u0E32\u0E01\u0E15\u0E31\u0E27\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2D\u0E48\u0E32\u0E19\u0E2B\u0E49\u0E2D\u0E07\u0E01\u0E25\u0E31\u0E1A`);
      return title ? { confirmedBy: "host", title } : { confirmedBy: "host" };
    } finally {
      try {
        await link.call({ cmd: "cleanup", sessionId }, { timeoutMs: 1e4 });
      } catch {
      }
      link.close();
    }
  }
};

// src/providers/registry.ts
var ProviderRegistry = class {
  adapters = /* @__PURE__ */ new Map();
  register(adapter) {
    if (this.adapters.has(adapter.info.id)) {
      throw new AppError(ErrorCode.INTERNAL, `Provider ${adapter.info.id} registered twice`);
    }
    for (const cap of adapter.info.capabilities) {
      if (!adapter.capabilities[cap]) {
        throw new AppError(ErrorCode.INTERNAL, `Provider ${adapter.info.id} declares ${cap} without implementing it`);
      }
    }
    this.adapters.set(adapter.info.id, adapter);
  }
  get(providerId) {
    const adapter = this.adapters.get(providerId);
    if (!adapter) throw new AppError(ErrorCode.NOT_FOUND, `Unknown provider ${providerId}`);
    return adapter;
  }
  list() {
    return [...this.adapters.values()].map((a) => a.info);
  }
  resolve(capability, settings) {
    const providerId = settings.providerFor[capability];
    if (!providerId) {
      throw new AppError(ErrorCode.PROVIDER_NOT_CONFIGURED, `No provider configured for ${capability}`);
    }
    const adapter = this.adapters.get(providerId);
    const impl = adapter?.capabilities[capability];
    if (!adapter || !impl) {
      throw new AppError(ErrorCode.PROVIDER_NOT_CONFIGURED, `Provider ${providerId} does not support ${capability}`);
    }
    return { adapter, impl };
  }
};

// src/shared/clock.ts
var systemClock = {
  now: () => Date.now(),
  iso: () => (/* @__PURE__ */ new Date()).toISOString()
};

// src/storage/asset-repo.ts
var MIME_BY_KIND = {
  image: /^image\//,
  video: /^video\//,
  audio: /^audio\//,
  document: /^(application|text)\//
};
var AssetRepo = class {
  constructor(clock) {
    this.clock = clock;
  }
  async ingest(blob, meta) {
    if (blob.size === 0) {
      throw new AppError(ErrorCode.DOWNLOAD_FAILED, "Empty file received", { userMessage: "\u0E44\u0E14\u0E49\u0E44\u0E1F\u0E25\u0E4C\u0E27\u0E48\u0E32\u0E07\u0E40\u0E1B\u0E25\u0E48\u0E32\u0E08\u0E32\u0E01\u0E1C\u0E39\u0E49\u0E43\u0E2B\u0E49\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23" });
    }
    const mime = blob.type || "application/octet-stream";
    if (!MIME_BY_KIND[meta.kind].test(mime)) {
      throw new AppError(ErrorCode.DOWNLOAD_FAILED, `Expected ${meta.kind} but got ${mime}`, {
        userMessage: `\u0E44\u0E1F\u0E25\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E14\u0E49\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48 ${meta.kind} (${mime})`
      });
    }
    const sha256 = await sha256Hex(await blob.arrayBuffer());
    const asset = {
      schemaVersion: 1,
      id: newId("ast_"),
      kind: meta.kind,
      mime,
      size: blob.size,
      sha256,
      source: meta.sourceUrl ? { providerId: meta.providerId, url: meta.sourceUrl } : { providerId: meta.providerId },
      createdAt: this.clock.iso()
    };
    await withStore([STORE.assets, STORE.assetBlobs], "readwrite", (tx) => {
      tx.objectStore(STORE.assetBlobs).put(blob, asset.id);
      tx.objectStore(STORE.assets).put(asset);
    });
    return asset;
  }
  /** An already stored asset with these bytes from this source (dedupes user uploads). */
  async findBySha256(sha256, providerId) {
    return (await getAll(STORE.assets)).find((a) => a.sha256 === sha256 && a.source.providerId === providerId);
  }
  async get(assetId) {
    const asset = await get(STORE.assets, assetId);
    if (!asset) throw new AppError(ErrorCode.NOT_FOUND, `Asset ${assetId} not found`);
    return asset;
  }
  async getBlob(assetId) {
    const blob = await get(STORE.assetBlobs, assetId);
    if (!blob) {
      throw new AppError(ErrorCode.NOT_FOUND, `Blob for asset ${assetId} not found`, {
        userMessage: "\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E19\u0E04\u0E25\u0E31\u0E07\u0E02\u0E2D\u0E07\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22 (\u0E2D\u0E32\u0E08\u0E16\u0E39\u0E01\u0E25\u0E49\u0E32\u0E07\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27) \u2014 \u0E43\u0E0A\u0E49\u0E44\u0E1F\u0E25\u0E4C\u0E43\u0E19\u0E42\u0E1F\u0E25\u0E40\u0E14\u0E2D\u0E23\u0E4C Downloads \u0E41\u0E17\u0E19"
      });
    }
    return blob;
  }
  async hasBlob(assetId) {
    return await get(STORE.assetBlobs, assetId) !== void 0;
  }
  listByContent(contentId) {
    return getAllByIndex(STORE.assets, "contentId", contentId);
  }
  listAll() {
    return getAll(STORE.assets);
  }
  async update(assetId, mutate) {
    return withStore(STORE.assets, "readwrite", async (tx) => {
      const store = tx.objectStore(STORE.assets);
      const asset = await new Promise((resolve, reject) => {
        const r = store.get(assetId);
        r.onsuccess = () => resolve(r.result);
        r.onerror = () => reject(new AppError(ErrorCode.INTERNAL, `IndexedDB get failed: ${String(r.error)}`));
      });
      if (!asset) throw new AppError(ErrorCode.NOT_FOUND, `Asset ${assetId} not found`);
      mutate(asset);
      store.put(asset);
      return asset;
    });
  }
  async deleteBlob(assetId) {
    await withStore(STORE.assetBlobs, "readwrite", (tx) => {
      tx.objectStore(STORE.assetBlobs).delete(assetId);
    });
  }
  async delete(assetId) {
    await withStore([STORE.assets, STORE.assetBlobs], "readwrite", (tx) => {
      tx.objectStore(STORE.assets).delete(assetId);
      tx.objectStore(STORE.assetBlobs).delete(assetId);
    });
  }
  put(asset) {
    return put(STORE.assets, asset);
  }
};

// src/storage/job-repo.ts
var OPEN_JOBS_KEY = STORAGE_KEYS.openJobs;
var JobRepo = class {
  mutex = new Mutex();
  async listOpen() {
    const stored = await chrome.storage.local.get(OPEN_JOBS_KEY);
    const jobs = stored[OPEN_JOBS_KEY];
    return Array.isArray(jobs) ? jobs : [];
  }
  async get(jobId) {
    const open = (await this.listOpen()).find((j) => j.jobId === jobId);
    if (open) return open;
    const done = await get(STORE.jobs, jobId);
    if (!done) throw new AppError(ErrorCode.NOT_FOUND, `Job ${jobId} not found`);
    return done;
  }
  async history(limit) {
    return queryIndexDesc(STORE.jobs, "updatedAt", limit);
  }
  /** Inserts a new open job at the end of the queue. */
  add(job) {
    return this.mutex.run(async () => {
      const jobs = await this.listOpen();
      jobs.push(job);
      await chrome.storage.local.set({ [OPEN_JOBS_KEY]: jobs });
      return job;
    });
  }
  /**
   * Atomic read-modify-write of one job. Terminal jobs are moved to history.
   * The mutator may mutate the job in place.
   */
  update(jobId, mutate, nowIso) {
    return this.mutex.run(async () => {
      const jobs = await this.listOpen();
      const idx = jobs.findIndex((j) => j.jobId === jobId);
      if (idx < 0) throw new AppError(ErrorCode.NOT_FOUND, `Open job ${jobId} not found`);
      const job = structuredClone(jobs[idx]);
      mutate(job);
      job.updatedAt = nowIso;
      if (TERMINAL_JOB_STATUSES.includes(job.status)) {
        job.finishedAt ??= nowIso;
        await put(STORE.jobs, job);
        jobs.splice(idx, 1);
      } else {
        jobs[idx] = job;
      }
      await chrome.storage.local.set({ [OPEN_JOBS_KEY]: jobs });
      return job;
    });
  }
  /** Moves a history (terminal) job back to the open queue (used by Retry of a FAILED job). */
  reopen(jobId, mutate, nowIso) {
    return this.mutex.run(async () => {
      const job = await get(STORE.jobs, jobId);
      if (!job) throw new AppError(ErrorCode.NOT_FOUND, `Job ${jobId} not found in history`);
      mutate(job);
      job.updatedAt = nowIso;
      delete job.finishedAt;
      const jobs = await this.listOpen();
      jobs.push(job);
      await chrome.storage.local.set({ [OPEN_JOBS_KEY]: jobs });
      return job;
    });
  }
  async pruneHistory(keep) {
    const total = await count(STORE.jobs);
    if (total <= keep) return 0;
    const newest = await queryIndexDesc(STORE.jobs, "updatedAt", keep);
    const cutoff = newest[newest.length - 1]?.updatedAt;
    return cutoff ? deleteBelow(STORE.jobs, "updatedAt", cutoff) : 0;
  }
};

// src/storage/log-repo.ts
var LogRepo = class {
  append(entry) {
    return put(STORE.logs, entry);
  }
  query(opts) {
    const min = LOG_LEVEL_ORDER[opts.minLevel ?? "DEBUG"];
    return queryIndexDesc(
      STORE.logs,
      "ts",
      opts.limit,
      (e) => LOG_LEVEL_ORDER[e.level] >= min && (opts.jobId === void 0 || e.jobId === opts.jobId)
    );
  }
  async prune(maxEntries) {
    const total = await count(STORE.logs);
    if (total <= maxEntries) return 0;
    const keep = await queryIndexDesc(STORE.logs, "ts", maxEntries);
    const cutoff = keep[keep.length - 1]?.ts;
    return cutoff ? deleteBelow(STORE.logs, "ts", cutoff) : 0;
  }
  async clear() {
    const total = await count(STORE.logs);
    await clearStore(STORE.logs);
    return total;
  }
};

// src/shared/defaults.ts
var DEFAULT_TIMEOUTS = {
  tabLoadMs: 45e3,
  bridgePingMs: 3e3,
  bridgeCommandMs: 2e4,
  textGenerationMs: 18e4,
  imageGenerationMs: 3e5,
  videoGenerationMs: 9e5,
  downloadMs: 18e4,
  uploadMs: 6e5,
  progressStallMs: 9e4,
  promptGapMs: 1e4
};
var DEFAULT_SETTINGS = {
  schemaVersion: 1,
  providerFor: {
    text: "chatgpt-web",
    image: "chatgpt-web",
    video: "meta-ai-web",
    publish: "facebook-web",
    message: "facebook-messenger-web"
  },
  requireApproval: true,
  automationWindow: "current",
  closeSendTabsAfterRun: true,
  downloadFolder: "AIContentFactory",
  logLevel: "INFO",
  timeouts: DEFAULT_TIMEOUTS,
  prompts: {
    brandVoice: "\u0E40\u0E1B\u0E47\u0E19\u0E01\u0E31\u0E19\u0E40\u0E2D\u0E07 \u0E43\u0E2B\u0E49\u0E04\u0E27\u0E32\u0E21\u0E23\u0E39\u0E49 \u0E15\u0E23\u0E07\u0E44\u0E1B\u0E15\u0E23\u0E07\u0E21\u0E32 \u0E44\u0E21\u0E48\u0E42\u0E2D\u0E49\u0E2D\u0E27\u0E14",
    language: "th",
    captionMaxChars: 1200,
    hashtagCount: 5,
    extraRules: "\u0E2B\u0E49\u0E32\u0E21\u0E23\u0E31\u0E1A\u0E1B\u0E23\u0E30\u0E01\u0E31\u0E19\u0E1C\u0E25\u0E01\u0E33\u0E44\u0E23\u0E2B\u0E23\u0E37\u0E2D\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C\u0E17\u0E32\u0E07\u0E01\u0E32\u0E23\u0E40\u0E07\u0E34\u0E19"
  },
  facebook: { pageUrl: "" },
  chatgpt: { itemsPerChat: 10, projectUrl: "" },
  productUpdate: { sendGapSec: 20, imageSettleSec: 3 },
  cleanup: { deleteBlobsAfterDays: 0 }
};
var CHATGPT_PROJECT_URL_OR_EMPTY = /^(|https:\/\/chatgpt\.com\/g\/g-p-[A-Za-z0-9-]+(\/project)?\/?)$/;

// src/shared/send-timing.ts
var validateDelayRange = (value, path) => {
  const range = object({ minSec: number({ int: true, min: 5, max: 600 }), maxSec: number({ int: true, min: 5, max: 600 }) })(value, path);
  if (range.minSec > range.maxSec) throw new AppError(ErrorCode.INVALID_INPUT, "Minimum delay exceeds maximum", { userMessage: "\u0E40\u0E27\u0E25\u0E32\u0E15\u0E48\u0E33\u0E2A\u0E38\u0E14\u0E15\u0E49\u0E2D\u0E07\u0E44\u0E21\u0E48\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32\u0E40\u0E27\u0E25\u0E32\u0E2A\u0E39\u0E07\u0E2A\u0E38\u0E14" });
  return range;
};
var validateProductUpdateSettings = object({
  sendGapSec: number({ int: true, min: 5, max: 600 }),
  imageSettleSec: number({ int: true, min: 0, max: 10 }),
  channelDelays: optional(object({ chat: optional(validateDelayRange), group: optional(validateDelayRange), feed: optional(validateDelayRange), line: optional(validateDelayRange) })),
  lineLockInput: optional(boolean)
});
function delayRange(settings, channel) {
  return settings.productUpdate.channelDelays?.[channel] ?? { minSec: settings.productUpdate.sendGapSec, maxSec: settings.productUpdate.sendGapSec };
}
function sampleDelaySec(range) {
  return range.minSec + Math.floor(Math.random() * (range.maxSec - range.minSec + 1));
}

// src/storage/settings-repo.ts
var KEY2 = STORAGE_KEYS.settings;
var MIGRATION_KEY = "migration:0.9.2-current-tab";
var timeoutMs = number({ int: true, min: 1e3, max: 36e5 });
var validateSettings = (value, path = "settings") => {
  const s = object({
    schemaVersion: literal(1),
    providerFor: object({
      text: string({ max: 64 }),
      image: string({ max: 64 }),
      video: string({ max: 64 }),
      publish: string({ max: 64 }),
      message: string({ max: 64 })
    }),
    requireApproval: boolean,
    automationWindow: literal("separate", "current"),
    closeSendTabsAfterRun: boolean,
    downloadFolder: string({ min: 1, max: 60, pattern: /^[A-Za-z0-9 _.-]+$/ }),
    logLevel: literal("DEBUG", "INFO", "WARN", "ERROR"),
    timeouts: object({
      tabLoadMs: timeoutMs,
      bridgePingMs: timeoutMs,
      bridgeCommandMs: timeoutMs,
      textGenerationMs: timeoutMs,
      imageGenerationMs: timeoutMs,
      videoGenerationMs: timeoutMs,
      downloadMs: timeoutMs,
      uploadMs: timeoutMs,
      progressStallMs: timeoutMs,
      promptGapMs: timeoutMs
    }),
    prompts: object({
      brandVoice: string({ max: 2e3 }),
      language: literal("th", "en"),
      captionMaxChars: number({ int: true, min: 50, max: 5e3 }),
      hashtagCount: number({ int: true, min: 0, max: 30 }),
      extraRules: string({ max: 4e3 })
    }),
    facebook: object({
      pageUrl: string({ max: 300, pattern: /^(|https:\/\/(www\.|business\.)?facebook\.com\/.*)$/ })
    }),
    chatgpt: object({
      itemsPerChat: number({ int: true, min: 1, max: 50 }),
      projectUrl: string({ max: 300, pattern: CHATGPT_PROJECT_URL_OR_EMPTY })
    }),
    productUpdate: validateProductUpdateSettings,
    cleanup: object({ deleteBlobsAfterDays: number({ int: true, min: 0, max: 3650 }) })
  })(value, path);
  return s;
};
function mergeWithDefaults(stored) {
  const base = structuredClone(DEFAULT_SETTINGS);
  if (typeof stored !== "object" || stored === null) return base;
  base["productUpdate"]["channelDelays"] = void 0;
  const merged = deepMerge(base, stored);
  try {
    return validateSettings(merged);
  } catch {
    return structuredClone(DEFAULT_SETTINGS);
  }
}
function deepMerge(base, over) {
  const out = { ...base };
  for (const [key, value] of Object.entries(over)) {
    const b = base[key];
    if (isPlainObject(b) && isPlainObject(value)) out[key] = deepMerge(b, value);
    else if (key in base) out[key] = value;
  }
  return out;
}
function isPlainObject(x) {
  return typeof x === "object" && x !== null && !Array.isArray(x);
}
var SettingsRepo = class {
  writes = new Mutex();
  async get() {
    const stored = await chrome.storage.local.get(KEY2);
    return mergeWithDefaults(stored[KEY2]);
  }
  save(settings) {
    return this.writes.run(() => this.persist(settings));
  }
  updateChannelDelay(channel, range) {
    return this.writes.run(async () => {
      const valid = validateDelayRange(range);
      const settings = await this.get();
      settings.productUpdate.channelDelays = { ...settings.productUpdate.channelDelays, [channel]: valid };
      return this.persist(settings);
    });
  }
  async persist(settings) {
    const valid = validateSettings(settings);
    await chrome.storage.local.set({ [KEY2]: valid });
    return valid;
  }
  /**
   * One-time migrations of stored settings. v0.9.2: automation now opens a normal tab in the
   * current window (user request) instead of a separate window.
   */
  async migrate() {
    const done = await chrome.storage.local.get(MIGRATION_KEY);
    if (done[MIGRATION_KEY] === true) return;
    const stored = await chrome.storage.local.get(KEY2);
    if (stored[KEY2] !== void 0) await this.save({ ...await this.get(), automationWindow: "current" });
    await chrome.storage.local.set({ [MIGRATION_KEY]: true });
  }
  async reset() {
    return this.save(structuredClone(DEFAULT_SETTINGS));
  }
};

// src/shared/content-plan.ts
var EMPTY_PROFILE = {
  about: "",
  audience: "",
  tone: "",
  avoid: "",
  closing: "",
  colors: [],
  aiStyle: "",
  noAiForProducts: false,
  aiImagesPerDay: 2,
  autoPillars: true,
  postsPerWeek: 5,
  pillars: [],
  destinationIds: []
};
var MAX_POSTS = 60;
var CONTENT_LIMITS = { about: 2e3, line: 400, caption: 5e3, pillars: 12, perWeekTotal: 7 };
var hex = string({ pattern: /^#[0-9a-fA-F]{6}$/ });
var validateProfile = object({
  about: string({ max: CONTENT_LIMITS.about }),
  audience: string({ max: CONTENT_LIMITS.line }),
  tone: string({ max: CONTENT_LIMITS.line }),
  avoid: string({ max: CONTENT_LIMITS.line }),
  closing: string({ max: CONTENT_LIMITS.line }),
  colors: array(hex, { max: 4 }),
  logoAssetId: optional(id),
  aiStyle: string({ max: CONTENT_LIMITS.line }),
  noAiForProducts: boolean,
  aiImagesPerDay: number({ int: true, min: 0, max: 20 }),
  autoPillars: boolean,
  postsPerWeek: number({ int: true, min: 1, max: 7 }),
  pillars: array(
    object({
      id,
      name: string({ min: 1, max: 80 }),
      about: string({ max: CONTENT_LIMITS.line }),
      perWeek: number({ int: true, min: 0, max: 7 }),
      image: literal("real", "ai", "auto")
    }),
    { max: CONTENT_LIMITS.pillars }
  ),
  destinationIds: array(id, { max: 50 })
});
var validateDayEdit = object({
  title: optional(string({ max: 200 })),
  goal: optional(string({ max: CONTENT_LIMITS.line })),
  headline: optional(string({ max: 200 })),
  caption: optional(string({ max: CONTENT_LIMITS.caption })),
  image: optional(literal("real", "ai-real", "ai", "none")),
  productId: optional(string({ max: 64 })),
  imagePrompt: optional(string({ max: 1500 })),
  assetIds: optional(array(id, { max: 10 })),
  overlayAt: optional(literal("top", "bottom")),
  destinationIds: optional(array(id, { max: 50 }))
});
function missingForPlan(p) {
  const out = [];
  if (!p.about.trim()) out.push('\u0E01\u0E23\u0E2D\u0E01 "\u0E40\u0E1E\u0E08\u0E19\u0E35\u0E49\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A\u0E2D\u0E30\u0E44\u0E23"');
  if (!p.audience.trim()) out.push('\u0E01\u0E23\u0E2D\u0E01 "\u0E04\u0E19\u0E14\u0E39 / \u0E25\u0E39\u0E01\u0E04\u0E49\u0E32\u0E2B\u0E25\u0E31\u0E01"');
  if (!p.autoPillars && !p.pillars.some((x) => x.perWeek > 0)) out.push("\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E2B\u0E21\u0E27\u0E14\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22 1 \u0E2B\u0E21\u0E27\u0E14 (\u0E25\u0E07\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22 1 \u0E04\u0E23\u0E31\u0E49\u0E07/\u0E2A\u0E31\u0E1B\u0E14\u0E32\u0E2B\u0E4C)");
  return out;
}

// src/tools/product-update/content-plan.ts
var PLAN_MARK = "PostHub Content Planner";
var REWRITE_MARK = "PostHub Content Rewrite";
function postsPerWeek(profile) {
  const n = profile.autoPillars ? profile.postsPerWeek : profile.pillars.reduce((sum, p) => sum + Math.max(0, p.perWeek), 0);
  return Math.max(0, Math.min(CONTENT_LIMITS.perWeekTotal, n));
}
var productLine = (x) => `- ${x.name} \u2014 ${x.text ? `"${x.text}"` : "(no text)"} \u2014 ${x.price || "no price"} \u2014 ${x.hasPhotos ? "yes" : "no"}`;
var NAME_RULE = `The private label is the owner's own shorthand (it may name a supplier or a person): NEVER write it in title, headline or caption. Call each product by the plain name customers know, taken from "what customers are shown" \u2014 the kind of product only (e.g. "\u0E01\u0E38\u0E49\u0E07\u0E02\u0E32\u0E27"), leaving out packaging, shipping and promo words such as \u0E1F\u0E23\u0E35\u0E42\u0E1F\u0E21, \u0E1F\u0E23\u0E35\u0E01\u0E25\u0E48\u0E2D\u0E07, \u0E2A\u0E48\u0E07\u0E1F\u0E23\u0E35, \u0E23\u0E32\u0E04\u0E32\u0E2A\u0E48\u0E07, sizes and prices. Only the JSON field "product" holds the private label, copied exactly.`;
function pageLines(p) {
  return [
    `About the page: ${p.about.trim()}`,
    `Audience: ${p.audience.trim()}`,
    p.tone.trim() ? `Tone of voice: ${p.tone.trim()}` : "",
    p.avoid.trim() ? `Never write about / never use: ${p.avoid.trim()}` : ""
  ].filter(Boolean);
}
var RULES = [
  "Write titles, goals, headlines and captions in Thai.",
  "Use ONLY the product names and prices listed. Never invent prices, numbers, discounts, reviews or customer quotes; where a number is needed but not given write [\u0E43\u0E2A\u0E48\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02].",
  "goal = one short sentence. headline = at most 8 Thai words, to be printed on the picture.",
  "caption = ready to post (2-6 short lines, emojis allowed), ending with a clear call to action."
];
function imageRule(p) {
  return [
    `image: "real" = use the product's real photos (set product to its exact name from the list), "ai" = a new illustrative picture (write imagePrompt in English, at most 30 words), "none" = text only.`,
    p.noAiForProducts ? "An AI picture must never show or stand in for a product that is sold \u2014 only covers, moods, scenes, menus or ideas." : ""
  ].filter(Boolean).join(" ");
}
function planPrompt(brief, fix) {
  const { profile } = brief;
  const pillars = profile.autoPillars ? [] : profile.pillars.filter((x) => x.perWeek > 0);
  const total = Math.min(brief.dates.length, brief.count ?? postsPerWeek(profile));
  const mode = (m) => m === "real" ? "real photo" : m === "ai" ? "AI picture" : "your choice";
  return [
    total === 1 ? `${PLAN_MARK}: think of ONE new social media post for this page.` : `${PLAN_MARK}: plan one week of social media posts for this page.`,
    "",
    ...pageLines(profile),
    "",
    ...profile.autoPillars ? [total === 1 ? 'Content category: choose one yourself (a short Thai name) that fits this page, its audience and its products \u2014 where possible a different kind of post from the recent ones. Put its name in "category".' : 'Content categories: choose 3-5 yourself (short Thai names) that fit this page, its audience and its products, and vary them over the week. Put the category name in "category".'] : ["Content categories (name \u2014 what it is about \u2014 posts per week \u2014 picture):", ...pillars.map((x) => `- ${x.name} \u2014 ${x.about.trim() || "-"} \u2014 ${x.perWeek} \u2014 ${mode(x.image)}`)],
    "",
    brief.products.length ? "Products (private label \u2014 what customers are shown \u2014 price \u2014 has real photos):" : "There is no product list.",
    ...brief.products.slice(0, 60).map(productLine),
    ...brief.products.length ? [NAME_RULE] : [],
    brief.recentTitles.length ? `
Recent posts as "category: title" (do not repeat these ideas or products where possible): ${brief.recentTitles.slice(0, 20).join(" | ")}` : "",
    "",
    `DATES: ${brief.dates.join(",")}`,
    total === 1 ? `Make exactly 1 post${brief.dates.length === 1 ? ` for ${brief.dates[0]}` : ""}.` : `Make exactly ${total} posts, at most one per date, spread over the week${profile.autoPillars ? "" : ", following each category's count"}.`,
    ...RULES,
    imageRule(profile),
    fix ? `Your previous answer could not be used (${fix}). Answer again with the JSON only.` : "",
    "",
    "Return JSON only, exactly this shape:",
    '{"posts":[{"date":"YYYY-MM-DD","category":"","title":"","goal":"","headline":"","caption":"","image":"real|ai|none","product":"","imagePrompt":""}]}'
  ].filter((l) => l !== "").join("\n");
}
function rewritePrompt(profile, day, products, note) {
  return [
    `${REWRITE_MARK}: write ONE social media post again, with a fresh idea for the same category.`,
    "",
    ...pageLines(profile),
    `Category: ${day.pillarName}`,
    `Current post (write a different one): ${day.title} \u2014 ${day.headline}`,
    note?.trim() ? `The owner asks: ${note.trim()}` : "",
    products.length ? "Products (private label \u2014 what customers are shown \u2014 price \u2014 has real photos):" : "",
    ...products.slice(0, 60).map(productLine),
    ...products.length ? [NAME_RULE] : [],
    ...RULES,
    imageRule(profile),
    "",
    "Return JSON only, exactly this shape:",
    '{"title":"","goal":"","headline":"","caption":"","image":"real|ai|none","product":"","imagePrompt":""}'
  ].filter((l) => l !== "").join("\n");
}
function aiPhotoPrompt(profile, day) {
  const headline = day.headline.trim();
  return [
    "Use the attached photo of the real product and turn it into a polished, eye-catching social media post image.",
    "Keep the product itself exactly as it is in the photo \u2014 the same item, shape, colour, size and quantity; do not replace it, add more of it or make it look better than it is. You may improve the lighting, clean up or replace the background and tidy the composition.",
    headline ? `Add this Thai headline as large, clean, easy-to-read text, spelled EXACTLY like this, character for character: "${headline}". No other text, no watermark, no logo.` : "Do not write any text in the image.",
    profile.aiStyle.trim() ? `Style: ${profile.aiStyle.trim()}.` : "",
    profile.colors.length ? `Brand colours for the text and accents: ${profile.colors.join(", ")}.` : "",
    "Square 1:1."
  ].filter(Boolean).join(" ");
}
function aiImagePrompt(profile, day) {
  return [
    `Create an image for a social media post: ${day.imagePrompt.trim() || day.title}.`,
    profile.aiStyle.trim() ? `Style: ${profile.aiStyle.trim()}.` : "",
    profile.colors.length ? `Brand colours: ${profile.colors.join(", ")}.` : "",
    day.headline.trim() ? `Leave clean space for a short headline (the text is added later \u2014 do not write any text in the image).` : "Do not write any text in the image.",
    profile.noAiForProducts ? "Do not show any product for sale; show a mood, scene or idea only." : "",
    "Square 1:1."
  ].filter(Boolean).join(" ");
}
var str3 = (v, max) => typeof v === "string" ? v.trim().slice(0, max) : "";
function jsonCandidates(reply) {
  const out = [];
  for (const raw of [...reply.codeBlocks, reply.text, /\{[\s\S]*\}/.exec(reply.text)?.[0] ?? ""]) {
    try {
      out.push(JSON.parse(raw.trim()));
    } catch {
    }
  }
  return out;
}
function withClosing(caption, closing) {
  const c = closing.trim();
  if (!c || caption.includes(c)) return caption;
  return `${caption.trimEnd()}

${c}`;
}
function fieldsOf(r, pillar, profile, products) {
  const title = str3(r.title, 200);
  const caption = str3(r.caption, CONTENT_LIMITS.caption);
  if (!title || !caption) return null;
  const name = str3(r.product, 200).toLowerCase();
  const product = name ? products.find((p) => p.name.trim().toLowerCase() === name) : void 0;
  const asked = r.image === "real" || r.image === "ai" || r.image === "none" ? r.image : "none";
  let image = pillar?.image === "real" ? "real" : pillar?.image === "ai" ? "ai" : asked;
  if (image === "real" && product && !product.hasPhotos) image = "ai";
  return {
    title,
    goal: str3(r.goal, CONTENT_LIMITS.line),
    headline: str3(r.headline, 200),
    caption: withClosing(caption, profile.closing),
    image,
    ...product ? { productId: product.id } : {},
    imagePrompt: str3(r.imagePrompt, 1500)
  };
}
function aiPillar(name) {
  const n = name.trim() || "\u0E17\u0E31\u0E48\u0E27\u0E44\u0E1B";
  return { id: `ai-${[...n].reduce((h, c) => h * 31 + c.charCodeAt(0) >>> 0, 7).toString(36)}`, name: n, about: "", perWeek: 0, image: "auto" };
}
function pillarByName(profile, name) {
  const n = name.trim().toLowerCase();
  return profile.pillars.find((p) => p.name.trim().toLowerCase() === n);
}
function parsePlanReply(reply, brief) {
  const allowed = new Set(brief.dates);
  const fallback = brief.profile.autoPillars ? void 0 : brief.profile.pillars.find((p) => p.perWeek > 0);
  for (const o of jsonCandidates(reply)) {
    const posts = o && typeof o === "object" && Array.isArray(o.posts) ? o.posts : null;
    if (!posts) continue;
    const days = [];
    for (const raw of posts) {
      if (!raw || typeof raw !== "object") continue;
      const r = raw;
      const date = brief.dates.length === 1 ? brief.dates[0] : str3(r.date, 10);
      if (!allowed.has(date) || days.some((d) => d.date === date)) continue;
      const pillar = (brief.profile.autoPillars ? aiPillar(str3(r.category, 80)) : pillarByName(brief.profile, str3(r.category, 80))) ?? fallback;
      const f = fieldsOf(r, pillar, brief.profile, brief.products);
      if (!f || !pillar) continue;
      days.push({ id: `new-${date}`, createdAt: "", date, pillarId: pillar.id, pillarName: pillar.name, ...f, assetIds: [], destinationIds: [...brief.profile.destinationIds], status: "draft" });
    }
    if (days.length) return days.sort((a, b) => a.date.localeCompare(b.date));
  }
  return null;
}
function parseRewriteReply(reply, profile, day, products) {
  const pillar = profile.pillars.find((p) => p.id === day.pillarId);
  for (const o of jsonCandidates(reply)) {
    if (!o || typeof o !== "object") continue;
    const f = fieldsOf(o, pillar, profile, products);
    if (!f) continue;
    const rest = { ...day };
    delete rest.productId;
    return { ...rest, ...f, assetIds: [], status: "draft" };
  }
  return null;
}

// src/workflows/content-plan.ts
function port(services) {
  const p = services.contentPlans;
  if (!p) throw new AppError(ErrorCode.INTERNAL, "Content planner is not wired");
  return p;
}
var TAB_WAIT_MS = 10 * 6e4;
var TRIES = 2;
var PLAN_REPLY_MS = 12 * 6e4;
var replyMs = (t) => Math.max(t.textGenerationMs, PLAN_REPLY_MS);
var planStep = {
  id: "content_plan",
  label: "AI \u0E27\u0E32\u0E07\u0E41\u0E1C\u0E19\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C (ChatGPT)",
  resumePolicy: "restart",
  maxAttempts: 1,
  timeoutMs: (t) => (replyMs(t) + t.bridgeCommandMs) * TRIES + TAB_WAIT_MS,
  async run(ctx) {
    const { mode, workspaceId: ws = "" } = ctx.input;
    const p = port(ctx.services);
    const { impl, providerId } = ctx.services.capabilities.resolve("text", ctx.settings);
    let conversationRef;
    let fix;
    if (mode === "plan") {
      const brief = await p.planBrief(ws);
      for (let attempt2 = 1; attempt2 <= TRIES; attempt2++) {
        ctx.progress(attempt2 > 1 ? "AI \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E34\u0E14\u0E43\u0E2B\u0E21\u0E48 (\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E41\u0E23\u0E01\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49)" : "AI \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E34\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48");
        ctx.log.info(`\u0E43\u0E2B\u0E49 AI \u0E04\u0E34\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48 \u0E04\u0E23\u0E31\u0E49\u0E07\u0E17\u0E35\u0E48 ${attempt2} (${providerId})`);
        const reply = await impl.generateText({ prompt: planPrompt(brief, fix), timeoutMs: replyMs(ctx.timeouts), ...conversationRef ? { conversationRef } : {} }, ctx);
        conversationRef = reply.conversationRef ?? conversationRef;
        const days = parsePlanReply(reply, brief);
        if (days) {
          await p.planGenerated(ws, days);
          return { posts: 1 };
        }
        fix = "the JSON was missing or had no usable post";
      }
      throw new AppError(ErrorCode.RESPONSE_PARSE_FAILED, "No usable post JSON", { userMessage: "AI \u0E15\u0E2D\u0E1A\u0E43\u0E19\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E25\u0E2D\u0E07\u0E01\u0E14\u0E43\u0E2B\u0E49 AI \u0E04\u0E34\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07" });
    }
    const postId = ctx.input.postId ?? "";
    const { profile, day, products } = await p.rewriteBrief(ws, postId);
    ctx.progress("AI \u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E02\u0E35\u0E22\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48");
    for (let attempt2 = 1; attempt2 <= TRIES; attempt2++) {
      const reply = await impl.generateText({ prompt: rewritePrompt(profile, day, products, ctx.input.note) + (attempt2 > 1 ? "\nYour previous answer was not the requested JSON. Answer with the JSON only." : ""), timeoutMs: replyMs(ctx.timeouts), ...conversationRef ? { conversationRef } : {} }, ctx);
      conversationRef = reply.conversationRef ?? conversationRef;
      const next = parseRewriteReply(reply, profile, day, products);
      if (next) {
        await p.rewriteDone(ws, postId, next);
        return { rewritten: postId };
      }
    }
    throw new AppError(ErrorCode.RESPONSE_PARSE_FAILED, "No usable rewrite JSON", { userMessage: "AI \u0E15\u0E2D\u0E1A\u0E43\u0E19\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E25\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07" });
  }
};
var imageStep = {
  id: "content_image",
  label: "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B AI \u0E02\u0E2D\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C (ChatGPT)",
  resumePolicy: "reattach",
  maxAttempts: 2,
  timeoutMs: (t) => t.imageGenerationMs + t.downloadMs + TAB_WAIT_MS,
  async run(ctx) {
    const { postId, workspaceId: ws = "" } = ctx.input;
    const usePhoto = ctx.input.usePhoto === true;
    const p = port(ctx.services);
    const { profile, day, photoAssetId } = await p.imageBrief(ws, postId, usePhoto);
    const { impl, providerId } = ctx.services.capabilities.resolve("image", ctx.settings);
    const what = usePhoto ? "ChatGPT \u0E01\u0E33\u0E25\u0E31\u0E07\u0E41\u0E15\u0E48\u0E07\u0E23\u0E39\u0E1B\u0E08\u0E23\u0E34\u0E07" : "\u0E23\u0E2D\u0E41\u0E17\u0E47\u0E1A ChatGPT / \u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B";
    ctx.log.info(`${usePhoto ? "\u0E43\u0E2B\u0E49 AI \u0E41\u0E15\u0E48\u0E07\u0E23\u0E39\u0E1B\u0E08\u0E23\u0E34\u0E07" : "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B AI"} \u0E02\u0E2D\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C "${day.title}" (${providerId})`);
    ctx.progress(what);
    const beat = setInterval(() => ctx.progress(what), 1e4);
    let assets;
    try {
      assets = (await impl.generateImage({ prompt: usePhoto ? aiPhotoPrompt(profile, day) : aiImagePrompt(profile, day), aspect: "1:1", ...photoAssetId ? { referenceAssetIds: [photoAssetId] } : {} }, ctx)).assets;
    } finally {
      clearInterval(beat);
    }
    const image = assets.find((a) => a.kind === "image");
    if (!image) throw new AppError(ErrorCode.GENERATION_FAILED, "No image returned", { userMessage: "ChatGPT \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07\u0E23\u0E39\u0E1B\u0E01\u0E25\u0E31\u0E1A\u0E21\u0E32" });
    await p.imageDone(ws, postId, image.id, usePhoto);
    return { assetId: image.id };
  }
};
async function onEnded(job, services) {
  if (job.status !== "FAILED" && job.status !== "CANCELLED") return;
  const ws = job.input.workspaceId ?? "";
  await services.contentPlans?.failed(ws, job.error?.userMessage ?? (job.status === "CANCELLED" ? "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E41\u0E25\u0E49\u0E27" : "AI \u0E17\u0E33\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08")).catch(() => void 0);
}
async function onDone(_job, services) {
  await services.contentPlans?.finished();
}
var contentPlanWorkflow = {
  type: "content_plan",
  label: "AI \u0E27\u0E32\u0E07\u0E41\u0E1C\u0E19\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C",
  steps: [planStep],
  onJobEnded: onEnded,
  onJobSucceeded: onDone
};
var contentImageWorkflow = {
  type: "content_image",
  label: "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B AI \u0E02\u0E2D\u0E07\u0E42\u0E1E\u0E2A\u0E15\u0E4C",
  steps: [imageStep],
  onJobEnded: onEnded,
  onJobSucceeded: onDone
};

// src/workflows/date-card.ts
function port2(services) {
  const p = services.dateCards;
  if (!p) throw new AppError(ErrorCode.INTERNAL, "Date card is not wired");
  return p;
}
var TAB_WAIT_MS2 = 15 * 6e4;
var generateStep = {
  id: "generate_card",
  label: "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 (ChatGPT)",
  resumePolicy: "reattach",
  maxAttempts: 2,
  timeoutMs: (t) => t.imageGenerationMs + t.downloadMs + TAB_WAIT_MS2,
  async run(ctx) {
    const { date, batchId, workspaceId } = ctx.input;
    const { prompt, aspect } = await port2(ctx.services).prompt(date, workspaceId);
    const { impl, providerId } = ctx.services.capabilities.resolve("image", ctx.settings);
    ctx.log.info(`\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 ${date} (${providerId})`);
    ctx.progress("\u0E23\u0E2D\u0E41\u0E17\u0E47\u0E1A ChatGPT / \u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22");
    const beat = setInterval(() => ctx.progress("\u0E23\u0E2D\u0E41\u0E17\u0E47\u0E1A ChatGPT / \u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22"), 1e4);
    let assets;
    try {
      assets = (await impl.generateImage({ prompt, aspect }, ctx)).assets;
    } finally {
      clearInterval(beat);
    }
    const image = assets.find((a) => a.kind === "image");
    if (!image) throw new AppError(ErrorCode.GENERATION_FAILED, "No image returned", { userMessage: "ChatGPT \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07\u0E23\u0E39\u0E1B\u0E1B\u0E49\u0E32\u0E22\u0E01\u0E25\u0E31\u0E1A\u0E21\u0E32" });
    await port2(ctx.services).generated({ date, assetId: image.id, ...batchId ? { batchId } : {}, ...workspaceId ? { workspaceId } : {} });
    ctx.log.info("\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E41\u0E25\u0E49\u0E27");
    return { assetId: image.id };
  }
};
var dateCardWorkflow = {
  type: "date_card",
  label: "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48",
  steps: [generateStep],
  async onJobEnded(job, services) {
    if (job.status !== "FAILED" && job.status !== "CANCELLED") return;
    const input = job.input;
    await services.dateCards?.failed({ ...input.batchId ? { batchId: input.batchId } : {}, message: job.error?.userMessage ?? (job.status === "CANCELLED" ? "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E01\u0E32\u0E23\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22" : "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1B\u0E49\u0E32\u0E22\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08"), ...input.workspaceId ? { workspaceId: input.workspaceId } : {} }).catch(() => void 0);
  }
};

// src/workflows/date-style.ts
function port3(services) {
  const p = services.dateStyles;
  if (!p) throw new AppError(ErrorCode.INTERNAL, "Daily style is not wired");
  return p;
}
var TAB_WAIT_MS3 = 10 * 6e4;
var generateStep2 = {
  id: "generate_style",
  label: "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E\u0E02\u0E2D\u0E07\u0E27\u0E31\u0E19 (ChatGPT)",
  resumePolicy: "restart",
  maxAttempts: 1,
  timeoutMs: (t) => (t.textGenerationMs + t.bridgeCommandMs) * STYLE_MAX_TRIES + TAB_WAIT_MS3,
  async run(ctx) {
    const { date, workspaceId } = ctx.input;
    const brief = await port3(ctx.services).brief(date, workspaceId);
    const { impl, providerId } = ctx.services.capabilities.resolve("text", ctx.settings);
    let best = null;
    let conversationRef;
    let avoid;
    for (let attempt2 = 1; attempt2 <= STYLE_MAX_TRIES; attempt2++) {
      ctx.progress(`\u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E34\u0E14\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E (\u0E04\u0E23\u0E31\u0E49\u0E07\u0E17\u0E35\u0E48 ${attempt2})`);
      ctx.log.info(`\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 ${date} \u0E04\u0E23\u0E31\u0E49\u0E07\u0E17\u0E35\u0E48 ${attempt2} (${providerId})`);
      const reply = await impl.generateText({ prompt: styleDirectorPrompt(brief, avoid), ...conversationRef ? { conversationRef } : {} }, ctx);
      conversationRef = reply.conversationRef ?? conversationRef;
      const proposal = parseStyleReply(reply);
      if (!proposal) {
        ctx.log.warn("\u0E04\u0E33\u0E15\u0E2D\u0E1A\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E2D\u0E48\u0E32\u0E19\u0E40\u0E1B\u0E47\u0E19 JSON \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49");
        avoid = "your answer was not the requested JSON";
        continue;
      }
      const similar = tooSimilar(proposal.styleDNA, brief.recent);
      const same = similar?.fields.length ?? 0;
      if (!best || same < best.same) best = { proposal, same, tries: attempt2 - 1 };
      if (!similar) break;
      ctx.log.info(`\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E04\u0E25\u0E49\u0E32\u0E22\u0E02\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21 ${same}/8 \u0E0A\u0E48\u0E2D\u0E07 (${similar.fields.join(", ")}) \u2014 \u0E02\u0E2D\u0E43\u0E2B\u0E21\u0E48`);
      avoid = `same ${similar.fields.join(", ")} as a recent day`;
    }
    if (!best) throw new AppError(ErrorCode.RESPONSE_PARSE_FAILED, "No usable style JSON", { userMessage: "AI \u0E15\u0E2D\u0E1A\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E43\u0E19\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E43\u0E0A\u0E49\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E40\u0E14\u0E34\u0E21\u0E44\u0E1B\u0E01\u0E48\u0E2D\u0E19" });
    if (best.same) ctx.log.warn(`\u0E43\u0E0A\u0E49\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E17\u0E35\u0E48\u0E04\u0E25\u0E49\u0E32\u0E22\u0E02\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21\u0E19\u0E49\u0E2D\u0E22\u0E17\u0E35\u0E48\u0E2A\u0E38\u0E14 (${best.same}/8 \u0E0A\u0E48\u0E2D\u0E07)`);
    await port3(ctx.services).generated({ date, proposal: best.proposal, retries: best.tries, ...workspaceId ? { workspaceId } : {} });
    ctx.log.info("\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E\u0E02\u0E2D\u0E07\u0E27\u0E31\u0E19\u0E1E\u0E23\u0E49\u0E2D\u0E21\u0E41\u0E25\u0E49\u0E27 (\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B)");
    return { retries: best.tries };
  }
};
var dateStyleWorkflow = {
  type: "date_style",
  label: "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E20\u0E32\u0E1E\u0E02\u0E2D\u0E07\u0E27\u0E31\u0E19",
  steps: [generateStep2],
  async onJobEnded(job, services) {
    if (job.status !== "FAILED" && job.status !== "CANCELLED") return;
    const input = job.input;
    await services.dateStyles?.failed({ date: input.date, message: job.error?.userMessage ?? "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E2A\u0E44\u0E15\u0E25\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08", ...input.workspaceId ? { workspaceId: input.workspaceId } : {} }).catch(() => void 0);
  }
};

// src/workflows/product-send.ts
var PROGRESS_EVERY_MS = 5e3;
function port4(services) {
  const p = services.productSends;
  if (!p) throw new AppError(ErrorCode.INTERNAL, "Product Update Bot is not wired");
  return p;
}
var paceStep = {
  id: "pace",
  label: "\u0E40\u0E27\u0E49\u0E19\u0E23\u0E30\u0E22\u0E30\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07",
  // A restart resumes the saved random deadline, rather than drawing a new delay.
  resumePolicy: "restart",
  maxAttempts: 5,
  timeoutMs: () => 11 * 6e4,
  async run(ctx) {
    const send = await port4(ctx.services).get(ctx.input.sendId);
    const channel = send.snapshot.channel ?? "chat";
    const last = await port4(ctx.services).lastAttemptAt(channel);
    if (!last) return { waitedMs: 0 };
    const saved = ctx.previousCheckpoint?.phase === "pace_deadline" ? ctx.previousCheckpoint.data : void 0;
    const reuse = saved?.["channel"] === channel && saved["lastAttemptAt"] === last && typeof saved["deadline"] === "number" && Number.isFinite(saved["deadline"]);
    const gapSec = reuse ? Number(saved?.["gapSec"]) : sampleDelaySec(delayRange(ctx.settings, channel));
    const deadline = reuse ? Number(saved?.["deadline"]) : last + gapSec * 1e3;
    if (!reuse) await ctx.checkpoint("pace_deadline", { channel, lastAttemptAt: last, gapSec, deadline });
    for (; ; ) {
      const wait = deadline - ctx.services.clock.now();
      if (wait <= 0) return { waitedMs: gapSec * 1e3 };
      ctx.progress(`\u0E40\u0E27\u0E49\u0E19\u0E23\u0E30\u0E22\u0E30\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07 \u0E2D\u0E35\u0E01 ${Math.ceil(wait / 1e3)} \u0E27\u0E34\u0E19\u0E32\u0E17\u0E35`);
      await delay(Math.min(wait, PROGRESS_EVERY_MS), ctx.signal);
    }
  }
};
var sendStep = {
  id: "send_message",
  label: "\u0E2A\u0E48\u0E07\u0E40\u0E02\u0E49\u0E32\u0E01\u0E25\u0E38\u0E48\u0E21\u0E41\u0E0A\u0E17 / \u0E42\u0E1E\u0E2A\u0E15\u0E4C",
  resumePolicy: "manual",
  maxAttempts: 2,
  // Two sends when there are images: images (upload + confirm + settle), then the text.
  timeoutMs: (t) => t.tabLoadMs * 2 + t.uploadMs * 2 + t.bridgeCommandMs * 8 + 10 * 1e4 + 9e4,
  async run(ctx) {
    const p = port4(ctx.services);
    const send = await p.get(ctx.input.sendId);
    if (send.status === "SENT" || send.status === "PENDING_APPROVAL") return { alreadySent: true };
    const s = send.snapshot;
    if (s.channel === "group") {
      if (!ctx.services.groupPosts || !p.markPendingApproval) throw new AppError(ErrorCode.PROVIDER_NOT_CONFIGURED, "Group posting not wired");
      if (!s.expectedTitle) throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Group has not been tested", { userMessage: "\u0E01\u0E14\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E01\u0E25\u0E38\u0E48\u0E21\u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01" });
      const result = await attempt(ctx, "group", () => ctx.services.groupPosts.publishGroup({ pageUrl: s.chatUrl, caption: s.message, assetIds: s.imageAssetIds, contentType: "post", acceptSubmission: true, ...ctx.settings.productUpdate.imageSettleSec > 0 ? { uploadWaitPerFileMs: ctx.settings.productUpdate.imageSettleSec * 1e3 } : {} }, ctx));
      if (result.outcome === "pending_approval") {
        await p.markPendingApproval(send.id);
        ctx.log.info(`\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27\u0E23\u0E2D\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34: ${s.productName} \u2192 ${s.destinationName}`);
        return { pendingApproval: true };
      }
      await p.markSent(send.id, "dom");
    } else if (s.channel === "feed") {
      await sendToFeed(ctx, send.id, s);
    } else if (s.channel === "line") {
      await sendToLine(ctx, send);
    } else {
      await sendToChat(ctx, send);
    }
    ctx.log.info(`\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27: ${s.productName} \u2192 ${s.destinationName}`);
    return { sent: true };
  }
};
async function attempt(ctx, channel, send) {
  const p = port4(ctx.services);
  await p.setLastAttemptAt(ctx.services.clock.now(), channel);
  try {
    return await send();
  } finally {
    if (ctx.settings.productUpdate.channelDelays?.[channel]) await p.setLastAttemptAt(ctx.services.clock.now(), channel);
  }
}
async function sendToFeed(ctx, sendId, s) {
  const p = port4(ctx.services);
  const { impl, providerId } = ctx.services.capabilities.resolve("publish", ctx.settings);
  ctx.log.info(`\u0E42\u0E1E\u0E2A\u0E15\u0E4C "${s.productName}" \u2192 ${s.destinationName} (${providerId})`, { images: s.imageAssetIds.length });
  const perPhoto = ctx.settings.productUpdate.imageSettleSec * 1e3;
  const result = await attempt(ctx, "feed", () => impl.publishNow(
    { pageUrl: s.chatUrl, caption: s.message, assetIds: s.imageAssetIds, contentType: "post", acceptSubmission: true, ...perPhoto > 0 ? { uploadWaitPerFileMs: perPhoto } : {} },
    ctx
  ));
  await p.markSent(sendId, "dom");
  if (result.postUrl) ctx.log.info(`\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E41\u0E25\u0E49\u0E27: ${result.postUrl}`);
}
async function sendToChat(ctx, send) {
  const p = port4(ctx.services);
  const s = send.snapshot;
  if (!s.expectedTitle) {
    throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Destination not verified", { userMessage: `\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07 "${s.destinationName}" \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E0A\u0E17 \u2014 \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07` });
  }
  const { impl, providerId } = ctx.services.capabilities.resolve("message", ctx.settings);
  ctx.log.info(`\u0E2A\u0E48\u0E07 "${s.productName}" \u2192 ${s.destinationName} (${providerId})`, { images: s.imageAssetIds.length });
  const skipImages = Boolean(send.imagesSentAt) && s.imageAssetIds.length > 0;
  if (skipImages) ctx.log.info("\u0E23\u0E39\u0E1B\u0E2A\u0E48\u0E07\u0E40\u0E02\u0E49\u0E32\u0E41\u0E0A\u0E17\u0E41\u0E25\u0E49\u0E27\u0E43\u0E19\u0E04\u0E23\u0E31\u0E49\u0E07\u0E01\u0E48\u0E2D\u0E19 \u2014 \u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21");
  const callCtx = {
    ...ctx,
    checkpoint: async (phase, data) => {
      if (phase === "images_sent") await p.markImagesSent(send.id);
      await ctx.checkpoint(phase, data);
    }
  };
  let result;
  try {
    result = await attempt(ctx, "chat", () => impl.sendChatMessage(
      {
        target: { url: s.chatUrl, threadId: s.threadId, expectedTitle: s.expectedTitle },
        text: s.message,
        imageAssetIds: s.imageAssetIds,
        skipImages,
        imageSettleMs: ctx.settings.productUpdate.imageSettleSec * 1e3
      },
      callCtx
    ));
  } catch (err) {
    if (err instanceof AppError && err.code === ErrorCode.ACCOUNT_RESTRICTED) await p.haltQueue(err.message);
    throw err;
  }
  await p.markSent(send.id, result.confirmedBy, result.chatTitle);
}
async function sendToLine(ctx, send) {
  const p = port4(ctx.services);
  const s = send.snapshot;
  const line = ctx.services.lineSends;
  if (!line) throw new AppError(ErrorCode.PROVIDER_NOT_CONFIGURED, "LINE OpenChat not wired");
  if (!s.expectedTitle) {
    throw new AppError(ErrorCode.DESTINATION_MISMATCH, "Room not verified", { userMessage: `\u0E2B\u0E49\u0E2D\u0E07 "${s.destinationName}" \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E17\u0E14\u0E2A\u0E2D\u0E1A \u2014 \u0E01\u0E14 "\u0E17\u0E14\u0E2A\u0E2D\u0E1A\u0E2B\u0E49\u0E2D\u0E07" \u0E01\u0E48\u0E2D\u0E19\u0E2A\u0E48\u0E07\u0E04\u0E23\u0E31\u0E49\u0E07\u0E41\u0E23\u0E01` });
  }
  ctx.log.info(`\u0E2A\u0E48\u0E07 "${s.productName}" \u2192 LINE OpenChat "${s.destinationName}"`, { images: s.imageAssetIds.length });
  const skipImages = Boolean(send.imagesSentAt) && s.imageAssetIds.length > 0;
  if (skipImages) ctx.log.info("\u0E23\u0E39\u0E1B\u0E2A\u0E48\u0E07\u0E40\u0E02\u0E49\u0E32\u0E2B\u0E49\u0E2D\u0E07\u0E41\u0E25\u0E49\u0E27\u0E43\u0E19\u0E04\u0E23\u0E31\u0E49\u0E07\u0E01\u0E48\u0E2D\u0E19 \u2014 \u0E2A\u0E48\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21");
  const callCtx = {
    ...ctx,
    checkpoint: async (phase, data) => {
      if (phase === "images_sent") await p.markImagesSent(send.id);
      await ctx.checkpoint(phase, data);
    }
  };
  const result = await attempt(ctx, "line", () => line.send(
    { roomName: s.chatUrl, ...s.threadId ? { roomUrl: s.threadId } : {}, expectedTitle: s.expectedTitle, text: s.message, imageAssetIds: s.imageAssetIds, skipImages },
    callCtx
  ));
  await p.markSent(send.id, result.confirmedBy, result.title);
}
var productSendWorkflow = {
  type: "product_send",
  label: "\u0E2A\u0E48\u0E07\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32",
  steps: [paceStep, sendStep],
  async onJobEnded(job, services) {
    const input = job.input;
    if (job.status === "FAILED" || job.status === "CANCELLED") await services.productSends?.markEnded(input.sendId, job.status, job.error).catch(() => void 0);
  }
};

// src/workflows/definitions.ts
var WORKFLOWS = [productSendWorkflow, dateCardWorkflow, dateStyleWorkflow, contentPlanWorkflow, contentImageWorkflow];

// src/platform/license.ts
var HOUR = 36e5;
var LICENSE_CHECK_INTERVAL_MS = 12 * HOUR;
var LICENSE_OFFLINE_GRACE_MS = 72 * HOUR;
var OFFLINE_SLACK_MS = HOUR;
function formatThaiDate(iso, withTime = false) {
  const d = new Date(iso);
  const opts = withTime ? { dateStyle: "medium", timeStyle: "short" } : { dateStyle: "medium" };
  return d.toLocaleString("th-TH", opts);
}
function maskLicenseKey(key) {
  const parts = key.split("-");
  return parts.map((p, i) => i === 0 || i === 1 || i === parts.length - 1 ? p : "\u2022".repeat(p.length)).join("-");
}
var EMAIL_REJECTION_MESSAGE = {
  INVALID_KEY: "\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E2D\u0E35\u0E40\u0E21\u0E25\u0E19\u0E35\u0E49\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E43\u0E2B\u0E21\u0E48\u0E14\u0E49\u0E27\u0E22 Google",
  OTHER_DEVICE: "\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E43\u0E2B\u0E21\u0E48\u0E14\u0E49\u0E27\u0E22 Google"
};
var REJECTION_MESSAGE = {
  INVALID_KEY: "License Key \u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07",
  EXPIRED: 'License \u0E2B\u0E21\u0E14\u0E2D\u0E32\u0E22\u0E38\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E15\u0E48\u0E2D\u0E2D\u0E32\u0E22\u0E38\u0E17\u0E35\u0E48 billdee.net \u203A \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32 \u203A \u0E41\u0E1E\u0E47\u0E01\u0E40\u0E01\u0E08 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 "\u0E15\u0E23\u0E27\u0E08\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49"',
  REVOKED: "License \u0E19\u0E35\u0E49\u0E16\u0E39\u0E01\u0E23\u0E30\u0E07\u0E31\u0E1A \u2014 \u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E02\u0E32\u0E22",
  OTHER_DEVICE: "Key \u0E19\u0E35\u0E49\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E2D\u0E22\u0E39\u0E48\u0E1A\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2D\u0E37\u0E48\u0E19 (1 Key \u0E43\u0E0A\u0E49\u0E44\u0E14\u0E49 1 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07) \u2014 \u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E17\u0E35\u0E48\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E40\u0E14\u0E34\u0E21\u0E01\u0E48\u0E2D\u0E19"
};
function evaluateLicense(record3, payload, nowMs, opts) {
  const base = {
    ...record3.key ? { maskedKey: maskLicenseKey(record3.key) } : {},
    ...record3.email && !record3.key ? { email: record3.email } : {},
    ...record3.lastCheckAt ? { lastCheckAt: record3.lastCheckAt } : {},
    ...record3.lastError ? { lastError: record3.lastError } : {}
  };
  const locked = (status, message2, checkDue2 = false, extra = {}) => ({
    ...base,
    ...extra,
    status,
    usable: false,
    message: message2,
    checkDue: checkDue2,
    entitlements: { granted: [], denyReason: message2 }
  });
  if (!opts.configured) return locked("NOT_CONFIGURED", "\u0E23\u0E30\u0E1A\u0E1A License \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32 (\u0E44\u0E21\u0E48\u0E21\u0E35 public key \u0E02\u0E2D\u0E07 server)");
  if (!record3.key && !record3.email) return locked("NONE", "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A");
  const rejection = (r) => (record3.key ? void 0 : EMAIL_REJECTION_MESSAGE[r]) ?? REJECTION_MESSAGE[r];
  if (record3.rejected) return locked(record3.rejected, rejection(record3.rejected));
  if (!payload) return locked("PENDING", '\u0E22\u0E31\u0E07\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19 License \u0E01\u0E31\u0E1A server \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E01\u0E14 "\u0E15\u0E23\u0E27\u0E08\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49" \u0E40\u0E21\u0E37\u0E48\u0E2D\u0E2D\u0E2D\u0E19\u0E44\u0E25\u0E19\u0E4C', true);
  if (payload.dev !== record3.deviceId) return locked("OTHER_DEVICE", rejection("OTHER_DEVICE"));
  if (payload.pin === "change") return locked("PIN_CHANGE", "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E14\u0E49\u0E27\u0E22 Google \u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E23\u0E34\u0E48\u0E21\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19", false, { plan: payload.plan, expiresAt: payload.exp });
  const now = Math.max(nowMs, record3.maxSeenAt ?? 0);
  const exp = Date.parse(payload.exp);
  const iat = Date.parse(payload.iat);
  const info = { plan: payload.plan, expiresAt: payload.exp };
  if (now >= exp) return locked("EXPIRED", `License \u0E2B\u0E21\u0E14\u0E2D\u0E32\u0E22\u0E38\u0E40\u0E21\u0E37\u0E48\u0E2D ${formatThaiDate(payload.exp)}`, true, info);
  const graceEnd = Math.min(iat + LICENSE_OFFLINE_GRACE_MS, exp);
  if (now >= iat + LICENSE_OFFLINE_GRACE_MS) {
    return locked("OFFLINE_TOO_LONG", '\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D License server \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E01\u0E34\u0E19 72 \u0E0A\u0E21. \u2014 \u0E15\u0E48\u0E2D\u0E2D\u0E34\u0E19\u0E40\u0E17\u0E2D\u0E23\u0E4C\u0E40\u0E19\u0E47\u0E15\u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 "\u0E15\u0E23\u0E27\u0E08\u0E15\u0E2D\u0E19\u0E19\u0E35\u0E49"', true, info);
  }
  const checkDue = now >= iat + LICENSE_CHECK_INTERVAL_MS;
  const entitlements = { granted: [...payload.ent] };
  if (now >= iat + LICENSE_CHECK_INTERVAL_MS + OFFLINE_SLACK_MS) {
    const graceUntil = new Date(graceEnd).toISOString();
    return { ...base, ...info, graceUntil, status: "OFFLINE_GRACE", usable: true, checkDue, entitlements, message: `\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D License server \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E43\u0E0A\u0E49\u0E15\u0E48\u0E2D\u0E44\u0E14\u0E49\u0E16\u0E36\u0E07 ${formatThaiDate(graceUntil, true)}` };
  }
  const message = payload.plan === "forever" ? "\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E44\u0E14\u0E49\u0E15\u0E25\u0E2D\u0E14\u0E0A\u0E35\u0E1E" : `\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\u0E44\u0E14\u0E49\u0E16\u0E36\u0E07 ${formatThaiDate(payload.exp)}`;
  return { ...base, ...info, status: "ACTIVE", usable: true, checkDue, entitlements, message };
}

// src/platform/google-config.ts
var GOOGLE_CLIENT_ID = "184390494731-jtq4qr66p9ahnqlln5rg834j2bapdc73.apps.googleusercontent.com";
var GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";

// src/shared/license-token.ts
var LICENSE_PLANS = ["30d", "90d", "365d", "forever"];
var KEY_RE = /^DRFX(-[0-9A-HJKMNP-TV-Z]{5}){4}$/;
function normalizeLicenseKey(input) {
  const raw = input.toUpperCase().replace(/[\s_]/g, "").replace(/^DRFX-?/, "").replace(/-/g, "").replace(/O/g, "0").replace(/[IL]/g, "1");
  const groups = raw.match(/.{1,5}/g) ?? [];
  return ["DRFX", ...groups].join("-");
}
function isLicenseKey(key) {
  return KEY_RE.test(key);
}
var ALGORITHM = { name: "ECDSA", namedCurve: "P-256" };
var SIGN = { name: "ECDSA", hash: "SHA-256" };
function base64UrlDecode(text2) {
  if (!/^[A-Za-z0-9_-]*$/.test(text2)) throw new Error("invalid base64url");
  const b64 = text2.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - text2.length % 4) % 4);
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
var utf8 = (s) => new TextEncoder().encode(s);
function importLicensePublicKey(jwk) {
  return crypto.subtle.importKey("jwk", jwk, ALGORITHM, false, ["verify"]);
}
function isPayload(p) {
  if (!p || typeof p !== "object") return false;
  const o = p;
  const str4 = (k) => typeof o[k] === "string" && o[k].length > 0 && o[k].length <= 200;
  return o.v === 1 && str4("kid") && str4("lic") && str4("dev") && LICENSE_PLANS.includes(o.plan) && Array.isArray(o.ent) && o.ent.length <= 50 && o.ent.every((e) => typeof e === "string") && str4("exp") && !Number.isNaN(Date.parse(o.exp)) && str4("iat") && !Number.isNaN(Date.parse(o.iat)) && (o.pin === void 0 || o.pin === "change");
}
async function verifyLicenseToken(token, publicKeys) {
  try {
    const [body, sig, extra] = token.split(".");
    if (!body || !sig || extra !== void 0 || token.length > 8e3) return null;
    const payload = JSON.parse(new TextDecoder().decode(base64UrlDecode(body)));
    if (!isPayload(payload)) return null;
    const jwk = Object.hasOwn(publicKeys, payload.kid) ? publicKeys[payload.kid] : void 0;
    if (!jwk) return null;
    const key = await importLicensePublicKey(jwk);
    return await crypto.subtle.verify(SIGN, key, base64UrlDecode(sig), utf8(body)) ? payload : null;
  } catch {
    return null;
  }
}

// src/background/license.ts
var LICENSE_STORAGE_KEY = "license";
var RETRY_AFTER_FAILURE_MS = 15 * 6e4;
var REQUEST_TIMEOUT_MS = 15e3;
var MAX_SEEN_PERSIST_MS = 10 * 6e4;
var identity = (r) => r?.key ?? r?.email;
var EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,24}$/;
var PIN_RE = /^\d{6}$/;
function randomToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
var LicenseService = class {
  constructor(deps) {
    this.deps = deps;
  }
  verified = null;
  checking = null;
  /** Every change of the stored record is a read-modify-write under this lock (no lost updates). */
  lock = new Mutex();
  /* --------------------------------- state -------------------------------- */
  async read() {
    const stored = (await chrome.storage.local.get(LICENSE_STORAGE_KEY))[LICENSE_STORAGE_KEY];
    return stored && typeof stored.deviceId === "string" && stored.deviceId ? stored : null;
  }
  /**
   * Changes the record: `change` gets the LATEST stored value (null = none) and returns the new one,
   * or null for "no change". Serialised, so a slow server reply never overwrites a newer record.
   */
  update(change) {
    return this.lock.run(async () => {
      const current = await this.read();
      const next = change(current);
      if (next && next !== current) await chrome.storage.local.set({ [LICENSE_STORAGE_KEY]: next });
      return next ?? current;
    });
  }
  /** This installation's random id, created on first use (activation). */
  async deviceId() {
    const r = await this.update((cur) => cur ?? { deviceId: crypto.randomUUID() });
    return r?.deviceId ?? "";
  }
  async payloadOf(token) {
    if (!token) return null;
    if (this.verified?.token !== token) this.verified = { token, payload: await verifyLicenseToken(token, this.deps.publicKeys) };
    return this.verified.payload;
  }
  configured() {
    return Object.keys(this.deps.publicKeys).length > 0;
  }
  /** The license as of now. Reading writes nothing, except advancing the clock guard now and then. */
  async view() {
    let record3 = await this.read() ?? { deviceId: "" };
    const now = this.deps.clock.now();
    if (identity(record3) && now > (record3.maxSeenAt ?? 0) + MAX_SEEN_PERSIST_MS) {
      record3 = await this.update((cur) => cur && identity(cur) ? { ...cur, maxSeenAt: Math.max(cur.maxSeenAt ?? 0, now) } : null) ?? record3;
    }
    return evaluateLicense(record3, await this.payloadOf(record3.token), now, { configured: this.configured() });
  }
  /** Only the extension's UI may request the full key, explicitly for viewing/copying. */
  async revealKey() {
    return { key: (await this.read())?.key ?? null };
  }
  /** The current usable license: its token (proves who we are to Cloud Sync) and the account id. */
  async session() {
    const record3 = await this.read();
    const v = await this.view();
    const payload = await this.payloadOf(record3?.token);
    return v.usable && record3?.token && payload ? { token: record3.token, tenantId: payload.lic } : null;
  }
  /** Why `tool` may not start new work now (null = it may) — the same answer as its Tool Hub card. */
  async denyReason(tool) {
    const card = toolCards((await this.view()).entitlements).find((c) => c.route === tool);
    return !card || card.usable ? null : card.reason ?? "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E1B\u0E34\u0E14\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19";
  }
  /* --------------------------------- server ------------------------------- */
  async call(path, body) {
    const doFetch = this.deps.fetch ?? fetch;
    let res;
    try {
      res = await doFetch(`${this.deps.apiBase}${path}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
        credentials: "omit",
        cache: "no-store"
      });
    } catch (err) {
      throw new AppError(ErrorCode.WEBSITE_UNAVAILABLE, `License server unreachable: ${String(err)}`, { userMessage: "\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D License server \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E2D\u0E34\u0E19\u0E40\u0E17\u0E2D\u0E23\u0E4C\u0E40\u0E19\u0E47\u0E15\u0E41\u0E25\u0E49\u0E27\u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48" });
    }
    const data = await res.json().catch(() => null);
    if (!data || typeof data !== "object" || typeof data.ok !== "boolean" || res.status >= 500) {
      throw new AppError(ErrorCode.WEBSITE_UNAVAILABLE, `License server error HTTP ${res.status}`, { userMessage: `License server \u0E02\u0E31\u0E14\u0E02\u0E49\u0E2D\u0E07 (HTTP ${res.status}) \u2014 \u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07` });
    }
    return data;
  }
  /** What a server reply changes in the record (applied to the latest stored record). */
  async outcome(deviceId, reply, now) {
    if (reply.ok) {
      const payload = await verifyLicenseToken(reply.token, this.deps.publicKeys);
      if (!payload || payload.dev !== deviceId) return (r) => ({ ...r, lastAttemptAt: now, lastError: "server \u0E2A\u0E48\u0E07 token \u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\u0E44\u0E21\u0E48\u0E1C\u0E48\u0E32\u0E19" });
      return (r) => {
        const next = { ...r, token: reply.token, lastCheckAt: now, lastAttemptAt: now };
        delete next.rejected;
        delete next.lastError;
        return next;
      };
    }
    const rejected = REJECTIONS[reply.code];
    if (!rejected) return (r) => ({ ...r, lastAttemptAt: now, lastError: reply.message ?? reply.code });
    return (r) => {
      const next = { ...r, rejected, lastCheckAt: now, lastAttemptAt: now };
      delete next.token;
      delete next.lastError;
      return next;
    };
  }
  failed(now, err) {
    const lastError = err instanceof AppError ? err.userMessage : String(err);
    return (r) => ({ ...r, lastAttemptAt: now, lastError });
  }
  /** Applies `change` only while the record still holds `id` (key or email; it may have been replaced meanwhile). */
  async commit(id2, change) {
    await this.update((cur) => cur && identity(cur) === id2 ? change(cur) : null);
    const v = await this.view();
    this.deps.onChanged(v);
    return v;
  }
  /** Binds `rawKey` to this device. */
  async activate(rawKey) {
    const key = normalizeLicenseKey(rawKey);
    if (!isLicenseKey(key)) throw new AppError(ErrorCode.INVALID_INPUT, "Malformed license key", { userMessage: "\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A License Key \u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07 (DRFX-XXXXX-XXXXX-XXXXX-XXXXX)" });
    const deviceId = await this.deviceId();
    await this.update((cur) => ({ deviceId, key, ...cur?.maxSeenAt ? { maxSeenAt: cur.maxSeenAt } : {} }));
    const now = this.deps.clock.iso();
    try {
      const reply = await this.call("/v1/activate", { key, deviceId, version: this.deps.version });
      const v = await this.commit(key, await this.outcome(deviceId, reply, now));
      this.deps.log.info(`License activate \u2192 ${v.status}`);
      return v;
    } catch (err) {
      await this.commit(key, this.failed(now, err));
      throw err;
    }
  }
  /**
   * Signs this device in to an email license (ADR-77). A wrong email / PIN, a locked email or a full
   * account (2 devices) is an error shown on the form — nothing is stored then.
   */
  async activateEmail(rawEmail, pin) {
    const email = rawEmail.trim().toLowerCase();
    if (!EMAIL_RE.test(email)) throw new AppError(ErrorCode.INVALID_INPUT, "Malformed email", { userMessage: "\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E2D\u0E35\u0E40\u0E21\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07" });
    if (!PIN_RE.test(pin)) throw new AppError(ErrorCode.INVALID_INPUT, "Malformed PIN", { userMessage: "PIN \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02 6 \u0E2B\u0E25\u0E31\u0E01" });
    const deviceId = await this.deviceId();
    const now = this.deps.clock.iso();
    const reply = await this.call("/v1/email/activate", { email, pin, deviceId, version: this.deps.version });
    if (!reply.ok) throw new AppError(ErrorCode.INVALID_INPUT, `Email sign-in rejected: ${reply.code}`, { userMessage: reply.message ?? "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" });
    const payload = await verifyLicenseToken(reply.token, this.deps.publicKeys);
    if (!payload || payload.dev !== deviceId) throw new AppError(ErrorCode.INVALID_STATE, "Bad token", { userMessage: "server \u0E2A\u0E48\u0E07 token \u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\u0E44\u0E21\u0E48\u0E1C\u0E48\u0E32\u0E19" });
    await this.update((cur) => ({ deviceId, email, token: reply.token, lastCheckAt: now, lastAttemptAt: now, ...cur?.maxSeenAt ? { maxSeenAt: cur.maxSeenAt } : {} }));
    const v = await this.view();
    this.deps.onChanged(v);
    this.deps.log.info(`License email sign-in \u2192 ${v.status}`);
    return v;
  }
  /**
   * "เข้าสู่ระบบด้วย Google" (v1.7.0, owner's decision: Google only). Google's window returns an ID
   * token for our client id with our nonce; the Worker verifies it and finds the customer by its email.
   * Nothing from Google is stored — only the license token, as with an email + PIN sign-in.
   */
  async activateGoogle() {
    const deviceId = await this.deviceId();
    const nonce = randomToken();
    const redirect = (globalThis.chrome?.identity?.getRedirectURL?.() ?? "").replace(/\/?$/, "/");
    const url = new URL(GOOGLE_AUTH_URL);
    url.search = new URLSearchParams({
      client_id: GOOGLE_CLIENT_ID,
      response_type: "id_token",
      scope: "openid email",
      redirect_uri: redirect,
      nonce,
      state: nonce,
      prompt: "select_account"
    }).toString();
    let back;
    try {
      back = this.deps.authFlow ? await this.deps.authFlow(url.toString()) : await chrome.identity.launchWebAuthFlow({ url: url.toString(), interactive: true });
    } catch (err) {
      throw new AppError(ErrorCode.INVALID_INPUT, `Google sign-in closed: ${String(err)}`, { userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A \u2014 \u0E1B\u0E34\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07 Google \u0E01\u0E48\u0E2D\u0E19\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1A\u0E31\u0E0D\u0E0A\u0E35" });
    }
    const params = new URLSearchParams((back ?? "").split("#")[1] ?? "");
    const idToken = params.get("id_token");
    if (!back?.startsWith(redirect) || params.get("state") !== nonce || !idToken) {
      throw new AppError(ErrorCode.INVALID_STATE, `Google sign-in: bad redirect (${params.get("error") ?? "no id_token"})`, { userMessage: "Google \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07\u0E01\u0E32\u0E23\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E25\u0E31\u0E1A\u0E21\u0E32 \u2014 \u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07" });
    }
    const now = this.deps.clock.iso();
    const reply = await this.call("/v1/email/google", { idToken, nonce, deviceId, version: this.deps.version });
    if (!reply.ok) throw new AppError(ErrorCode.INVALID_INPUT, `Google sign-in rejected: ${reply.code}`, { userMessage: reply.message ?? "\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" });
    const payload = await verifyLicenseToken(reply.token, this.deps.publicKeys);
    const email = typeof reply.email === "string" ? reply.email.trim().toLowerCase() : "";
    if (!payload || payload.dev !== deviceId || !email) throw new AppError(ErrorCode.INVALID_STATE, "Bad token", { userMessage: "server \u0E2A\u0E48\u0E07 token \u0E17\u0E35\u0E48\u0E15\u0E23\u0E27\u0E08\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\u0E44\u0E21\u0E48\u0E1C\u0E48\u0E32\u0E19" });
    await this.update((cur) => ({ deviceId, email, token: reply.token, lastCheckAt: now, lastAttemptAt: now, ...cur?.maxSeenAt ? { maxSeenAt: cur.maxSeenAt } : {} }));
    const v = await this.view();
    this.deps.onChanged(v);
    this.deps.log.info(`License Google sign-in \u2192 ${v.status}`);
    return v;
  }
  /** Replaces the PIN of the signed-in email (required after the owner's temporary PIN). */
  async changePin(pin, newPin) {
    const record3 = await this.read();
    if (!record3?.email || record3.key) throw new AppError(ErrorCode.INVALID_STATE, "No email license", { userMessage: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A\u0E14\u0E49\u0E27\u0E22\u0E2D\u0E35\u0E40\u0E21\u0E25" });
    if (!PIN_RE.test(pin) || !PIN_RE.test(newPin)) throw new AppError(ErrorCode.INVALID_INPUT, "Malformed PIN", { userMessage: "PIN \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02 6 \u0E2B\u0E25\u0E31\u0E01" });
    const email = record3.email;
    const now = this.deps.clock.iso();
    const reply = await this.call("/v1/email/change-pin", { email, pin, newPin, deviceId: record3.deviceId, version: this.deps.version });
    if (!reply.ok && !["EXPIRED", "REVOKED", "NOT_THIS_DEVICE"].includes(reply.code)) {
      throw new AppError(ErrorCode.INVALID_INPUT, `PIN change rejected: ${reply.code}`, { userMessage: reply.message ?? "\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19 PIN \u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" });
    }
    const v = await this.commit(email, await this.outcome(record3.deviceId, reply, now));
    this.deps.log.info(`License PIN changed \u2192 ${v.status}`);
    return v;
  }
  /** Re-checks with the server (de-duplicated while one is in flight). */
  refresh() {
    this.checking ??= this.doRefresh().finally(() => this.checking = null);
    return this.checking;
  }
  async doRefresh() {
    const record3 = await this.read();
    const id2 = identity(record3);
    if (!record3 || !id2) return this.view();
    const now = this.deps.clock.iso();
    let change;
    try {
      const reply = record3.key ? await this.call("/v1/check", { key: record3.key, deviceId: record3.deviceId, version: this.deps.version }) : await this.call("/v1/email/check", { email: id2, deviceId: record3.deviceId, version: this.deps.version });
      change = await this.outcome(record3.deviceId, reply, now);
    } catch (err) {
      change = this.failed(now, err);
    }
    const v = await this.commit(id2, change);
    if (v.lastError) this.deps.log.warn(`License check failed: ${v.lastError} (${v.status})`);
    else this.deps.log.info(`License check \u2192 ${v.status}`);
    return v;
  }
  /** Watchdog tick: checks with the server when a check is due (backs off after failures). */
  async tick() {
    const record3 = await this.read();
    if (!record3 || !identity(record3) || record3.rejected === "INVALID_KEY" || !this.configured()) return;
    const v = await this.view();
    const lastAttempt = record3.lastAttemptAt ? Date.parse(record3.lastAttemptAt) : 0;
    const now = this.deps.clock.now();
    const recheckRejected = record3.rejected !== void 0 && now - (record3.lastCheckAt ? Date.parse(record3.lastCheckAt) : 0) >= LICENSE_CHECK_INTERVAL_MS;
    if ((v.checkDue || v.status === "PENDING" || recheckRejected) && now - lastAttempt >= RETRY_AFTER_FAILURE_MS) await this.refresh();
  }
  /** Releases this device on the server, then forgets the key / email here (sign out). */
  async deactivate() {
    const record3 = await this.read();
    const id2 = identity(record3);
    if (!record3 || !id2) return this.view();
    const reply = record3.key ? await this.call("/v1/deactivate", { key: record3.key, deviceId: record3.deviceId, version: this.deps.version }) : await this.call("/v1/email/deactivate", { email: id2, deviceId: record3.deviceId, version: this.deps.version });
    if (!reply.ok && !REJECTIONS[reply.code]) {
      throw new AppError(ErrorCode.INVALID_STATE, `Deactivate rejected: ${reply.code}`, { userMessage: reply.message ?? "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" });
    }
    this.deps.log.info("License deactivated on this device");
    return this.commit(id2, (r) => ({ deviceId: r.deviceId, ...r.maxSeenAt ? { maxSeenAt: r.maxSeenAt } : {} }));
  }
};
var REJECTIONS = {
  INVALID_KEY: "INVALID_KEY",
  EXPIRED: "EXPIRED",
  REVOKED: "REVOKED",
  DEVICE_LIMIT: "OTHER_DEVICE",
  NOT_THIS_DEVICE: "OTHER_DEVICE",
  // Email license (ADR-77) checks: the email no longer exists.
  INVALID_LOGIN: "INVALID_KEY"
};

// src/shared/backup.ts
var BACKUP_APP = "DRFX_PRODUCT_UPDATE_BOT";
var BACKUP_VERSION = 1;
var BACKUP_PARTS = ["products", "productImages", "templates", "destinations", "dailyUpdate", "imageStyle", "styleHistory", "promptSettings", "preferences", "generatedImages"];
var DEFAULT_BACKUP_PARTS = BACKUP_PARTS.filter((p) => p !== "generatedImages");
var MIGRATIONS2 = {};
function migrateBackup(raw) {
  let b = raw;
  let version = b.backupVersion;
  if (typeof version !== "number" || !Number.isInteger(version) || version < 1) throw bad("backupVersion \u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07");
  if (version > BACKUP_VERSION) throw bad(`\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E21\u0E32\u0E08\u0E32\u0E01\u0E40\u0E27\u0E2D\u0E23\u0E4C\u0E0A\u0E31\u0E19\u0E17\u0E35\u0E48\u0E43\u0E2B\u0E21\u0E48\u0E01\u0E27\u0E48\u0E32 (backupVersion ${version}) \u2014 \u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E01\u0E48\u0E2D\u0E19`);
  while (version < BACKUP_VERSION) {
    const step = MIGRATIONS2[version];
    if (!step) throw bad(`\u0E44\u0E21\u0E48\u0E21\u0E35\u0E27\u0E34\u0E18\u0E35\u0E41\u0E1B\u0E25\u0E07\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07 backupVersion ${version}`);
    b = { ...step(b), backupVersion: version + 1 };
    version += 1;
  }
  return b;
}
function bad(message) {
  return new AppError(ErrorCode.INVALID_INPUT, `Backup: ${message}`, { userMessage: `\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E43\u0E0A\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49: ${message}` });
}
var record2 = { schemaVersion: literal(1), id, workspaceId: string({ min: 1, max: 64 }), createdAt: isoDate, updatedAt: isoDate };
var validateProduct = (value, path) => {
  const base = object({ ...record2, sortOrder: number({ min: -1e9, max: 1e9 }) })(value, path);
  return { ...base, ...validateProductInput(value, path) };
};
var validateTemplate = (value, path) => ({ ...object(record2)(value, path), ...validateTemplateInput(value, path) });
var validateDestination = object({
  ...record2,
  name: string({ min: 1, max: 100 }),
  type: literal("FACEBOOK_GROUP_CHAT", "FACEBOOK_FEED", "FACEBOOK_GROUP", "LINE_OPENCHAT"),
  chatReference: object({ url: string({ min: 1, max: 400 }), threadId: string({ max: 64 }) }),
  verifiedTitle: optional(string({ max: 200 })),
  verifiedAt: optional(isoDate),
  enabled: boolean,
  notes: string({ max: 500 }),
  lastUsedAt: optional(isoDate)
});
var dnaText = string({ max: 120 });
var validateDNA = object({ environment: dnaText, timeOfDay: dnaText, weather: dnaText, cameraAngle: dnaText, truckPosition: dnaText, signPosition: dnaText, lighting: dnaText, atmosphere: dnaText });
var short = optional(string({ max: 300 }));
var validateStyle = object({
  date: string({ pattern: /^\d{4}-\d{2}-\d{2}$/ }),
  stylePrompt: string({ max: 1500 }),
  styleDNA: optional(validateDNA),
  scene: short,
  mood: short,
  composition: short,
  camera: short,
  lighting: short,
  source: literal("ai", "edited"),
  locked: boolean,
  retries: number({ int: true, min: 0, max: 10 }),
  createdAt: isoDate,
  updatedAt: isoDate
});
var validateImageRef = object({
  id,
  path: string({ min: 1, max: 200, pattern: /^images\/(products|generated)\/[\w.-]+$/ }),
  sha256: string({ pattern: /^[0-9a-f]{64}$/ }),
  mimeType: string({ pattern: /^(image\/(png|jpeg|webp|gif)|video\/(mp4|webm|quicktime))$/ }),
  size: number({ int: true, min: 0, max: 5e7 }),
  fileName: string({ max: 200 }),
  createdAt: isoDate
});
function validateBackup(raw) {
  if (!raw || typeof raw !== "object") throw bad("backup.json \u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48 JSON object");
  const top = raw;
  if (top.app !== BACKUP_APP) throw bad("\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E44\u0E1F\u0E25\u0E4C\u0E2A\u0E33\u0E23\u0E2D\u0E07\u0E02\u0E2D\u0E07 Billdee PostHub");
  const b = migrateBackup(top);
  const d = b.data && typeof b.data === "object" ? b.data : null;
  if (!d) throw bad("\u0E44\u0E21\u0E48\u0E21\u0E35\u0E2A\u0E48\u0E27\u0E19 data");
  const list = (name, fn, max) => {
    const arr = d[name] ?? [];
    if (!Array.isArray(arr)) throw bad(`${name} \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23`);
    if (arr.length > max) throw bad(`${name} \u0E21\u0E32\u0E01\u0E40\u0E01\u0E34\u0E19 ${max} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23`);
    try {
      return arr.map((x, i) => fn(x, `${name}[${i}]`));
    } catch (err) {
      throw bad(err instanceof Error ? err.message : String(err));
    }
  };
  const opt = (name, fn) => {
    if (d[name] === void 0) return void 0;
    try {
      return fn(d[name], name);
    } catch (err) {
      throw bad(err instanceof Error ? err.message : String(err));
    }
  };
  const includes = Array.isArray(b.includes) ? b.includes.filter((p) => BACKUP_PARTS.includes(p)) : [...DEFAULT_BACKUP_PARTS];
  const dailyUpdate = opt("dailyUpdate", (x, p) => {
    const full = validateDateCardSettings({ style: "", autoStyle: false, business: "", ...x }, p);
    delete full.style;
    delete full.autoStyle;
    delete full.business;
    return full;
  });
  const imageStyleSettings = opt("imageStyleSettings", object({ style: string({ max: 600 }), autoStyle: boolean, business: string({ max: 300 }) }));
  const scheduleSettings = opt("scheduleSettings", validateProductUpdateSettings);
  const preferences = opt("preferences", object({ logLevel: literal("DEBUG", "INFO", "WARN", "ERROR") }));
  return {
    app: BACKUP_APP,
    backupVersion: BACKUP_VERSION,
    exportedAt: typeof b.exportedAt === "string" ? b.exportedAt : "",
    appVersion: typeof b.appVersion === "string" ? b.appVersion : "",
    includes,
    data: {
      products: list("products", validateProduct, 5e3),
      templates: list("templates", validateTemplate, 500),
      destinations: list("destinations", validateDestination, 1e3),
      styleHistory: list("styleHistory", validateStyle, 400),
      images: list("images", validateImageRef, 2e4),
      generated: list("generated", object({ date: string({ pattern: /^\d{4}-\d{2}-\d{2}$/ }), image: validateImageRef }), 400),
      promptSettings: {},
      ...dailyUpdate ? { dailyUpdate } : {},
      ...imageStyleSettings ? { imageStyleSettings } : {},
      ...scheduleSettings ? { scheduleSettings } : {},
      ...preferences ? { preferences } : {}
    }
  };
}
function backupCounts(b) {
  return {
    products: b.data.products.length,
    productImages: b.data.images.length,
    templates: b.data.templates.length,
    destinations: b.data.destinations.length,
    styleHistory: b.data.styleHistory.length,
    generatedImages: b.data.generated.length
  };
}
var EXT = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif", "video/mp4": "mp4", "video/webm": "webm", "video/quicktime": "mov" };
function imagePath(kind, sha256, mime) {
  return `images/${kind}/${sha256}.${EXT[mime] ?? "bin"}`;
}

// src/background/backup.ts
var zero = () => ({ products: 0, productImages: 0, templates: 0, destinations: 0, styleHistory: 0, generatedImages: 0 });
var RECORD_STORES = [STORE.products, STORE.msgTemplates, STORE.destinations];
var BackupService = class {
  constructor(deps) {
    this.deps = deps;
  }
  /* --------------------------------- export --------------------------------- */
  /** backup.json for the chosen parts; image entries name the asset to put at each path. */
  async exportManifest(parts) {
    const ws = await this.deps.workspaceId();
    const want = (p) => parts.includes(p);
    const products = want("products") ? await getAllByIndex(STORE.products, "workspaceId", ws) : [];
    const images = [];
    if (want("productImages")) {
      const seen = /* @__PURE__ */ new Set();
      for (const id2 of products.flatMap((p) => p.images)) {
        if (seen.has(id2)) continue;
        seen.add(id2);
        const asset = await this.deps.assets.get(id2).catch(() => null);
        if (!asset) continue;
        images.push({ id: id2, path: imagePath("products", asset.sha256, asset.mime), sha256: asset.sha256, mimeType: asset.mime, size: asset.size, fileName: `${asset.sha256}`, createdAt: asset.createdAt });
      }
    }
    const generated = [];
    if (want("generatedImages")) {
      const card2 = await this.deps.service.latestCardImage(ws);
      const asset = card2 ? await this.deps.assets.get(card2.assetId).catch(() => null) : null;
      if (card2 && asset) generated.push({ date: card2.date, image: { id: asset.id, path: imagePath("generated", asset.sha256, asset.mime), sha256: asset.sha256, mimeType: asset.mime, size: asset.size, fileName: `date-card-${card2.date}`, createdAt: asset.createdAt } });
    }
    const card = await this.deps.service.dateCardSettings(ws);
    const settings = await this.deps.getSettings();
    const { style, autoStyle, business, ...content } = card;
    return {
      app: BACKUP_APP,
      backupVersion: BACKUP_VERSION,
      exportedAt: this.deps.clock.iso(),
      appVersion: this.deps.appVersion,
      includes: BACKUP_PARTS.filter(want),
      data: {
        products,
        templates: want("templates") ? await getAllByIndex(STORE.msgTemplates, "workspaceId", ws) : [],
        destinations: want("destinations") ? await getAllByIndex(STORE.destinations, "workspaceId", ws) : [],
        ...want("dailyUpdate") ? { dailyUpdate: content } : {},
        ...want("imageStyle") ? { imageStyleSettings: { style, autoStyle, business } } : {},
        styleHistory: want("styleHistory") ? (await this.deps.styles.load(ws)).entries : [],
        promptSettings: {},
        ...want("preferences") ? { scheduleSettings: { ...settings.productUpdate }, preferences: { logLevel: settings.logLevel } } : {},
        images,
        generated
      }
    };
  }
  /* --------------------------------- import --------------------------------- */
  /** Validates a backup.json without writing anything (Import Preview). */
  preview(raw) {
    const b = validateBackup(raw);
    return { counts: backupCounts(b), exportedAt: b.exportedAt, appVersion: b.appVersion, includes: b.includes };
  }
  async snapshot(ws) {
    return {
      products: await getAllByIndex(STORE.products, "workspaceId", ws),
      templates: await getAllByIndex(STORE.msgTemplates, "workspaceId", ws),
      destinations: await getAllByIndex(STORE.destinations, "workspaceId", ws),
      styles: (await this.deps.styles.load(ws)).entries,
      settings: await this.deps.getSettings(),
      card: await this.deps.service.dateCardSettings(ws)
    };
  }
  /** Puts the records back exactly as in the snapshot (one transaction). */
  async rollback(ws, snap) {
    await this.replaceRecords(ws, snap.products, snap.templates, snap.destinations);
    await this.deps.styles.update(ws, (h) => h.entries = snap.styles);
    await this.deps.saveSettings(snap.settings);
    await this.deps.service.saveDateCardSettings(snap.card).catch(() => void 0);
  }
  replaceRecords(ws, products, templates, destinations) {
    return withStore([...RECORD_STORES], "readwrite", (tx) => {
      for (const name of RECORD_STORES) {
        const store = tx.objectStore(name);
        const req2 = store.index("workspaceId").getAllKeys(ws);
        req2.onsuccess = () => {
          for (const key of req2.result) store.delete(key);
          const rows = name === STORE.products ? products : name === STORE.msgTemplates ? templates : destinations;
          for (const r of rows) store.put(r);
        };
      }
    });
  }
  /**
   * Restores a validated backup. \`imageMap\`: backup asset id → asset id here (null = that image file
   * was missing/damaged: the record restores without it).
   */
  async import(raw, imageMap, mode) {
    const b = validateBackup(raw);
    const ws = await this.deps.workspaceId();
    const now = this.deps.clock.iso();
    const report = { mode, added: zero(), updated: zero(), keptLocal: 0, warnings: [] };
    const has = (p) => b.includes.includes(p);
    const missing = /* @__PURE__ */ new Set();
    const products = b.data.products.map((p) => {
      const images = p.images.flatMap((id2) => {
        const to = imageMap[id2];
        if (!to) missing.add(id2);
        return to ? [to] : [];
      });
      return { ...p, workspaceId: ws, images };
    });
    if (missing.size) report.warnings.push(`\u0E44\u0E1F\u0E25\u0E4C\u0E23\u0E39\u0E1B/\u0E04\u0E25\u0E34\u0E1B\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 ${missing.size} \u0E44\u0E1F\u0E25\u0E4C\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (\u0E44\u0E1F\u0E25\u0E4C\u0E2B\u0E32\u0E22\u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E2A\u0E35\u0E22) \u2014 \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E41\u0E25\u0E49\u0E27\u0E42\u0E14\u0E22\u0E44\u0E21\u0E48\u0E21\u0E35\u0E44\u0E1F\u0E25\u0E4C\u0E19\u0E31\u0E49\u0E19`);
    report.added.productImages = Object.values(imageMap).filter(Boolean).length;
    const templates = b.data.templates.map((t) => ({ ...t, workspaceId: ws }));
    const destinations = b.data.destinations.map((d) => ({ ...d, workspaceId: ws }));
    const snap = await this.snapshot(ws);
    try {
      if (mode === "replace") {
        await this.replaceRecords(ws, has("products") ? products : snap.products, has("templates") ? templates : snap.templates, has("destinations") ? destinations : snap.destinations);
        if (has("products")) report.added.products = products.length;
        if (has("templates")) report.added.templates = templates.length;
        if (has("destinations")) report.added.destinations = destinations.length;
      } else {
        await this.mergeRecords(ws, { products, templates, destinations }, report);
      }
      await this.restoreSettings(ws, b, mode, report, now, imageMap);
    } catch (err) {
      this.deps.log.error("Restore failed \u2014 rolling back to the safety snapshot", err instanceof Error ? err.message : String(err));
      await this.rollback(ws, snap).catch((e) => this.deps.log.error("Rollback failed", String(e)));
      throw err instanceof AppError ? err : new AppError(ErrorCode.INTERNAL, `Restore failed: ${String(err)}`, { userMessage: "\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 \u2014 \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E14\u0E34\u0E21\u0E16\u0E39\u0E01\u0E04\u0E37\u0E19\u0E01\u0E25\u0E31\u0E1A\u0E41\u0E25\u0E49\u0E27" });
    }
    this.deps.log.info(`\u0E01\u0E39\u0E49\u0E04\u0E37\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2A\u0E33\u0E23\u0E2D\u0E07 (${mode}): \u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32 +${report.added.products}/~${report.updated.products} \xB7 Template +${report.added.templates} \xB7 \u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07 +${report.added.destinations}`);
    this.deps.onChanged();
    return report;
  }
  mergeRecords(ws, rows, report) {
    const plan = [
      [STORE.products, rows.products, "products"],
      [STORE.msgTemplates, rows.templates, "templates"],
      [STORE.destinations, rows.destinations, "destinations"]
    ];
    return withStore([...RECORD_STORES], "readwrite", (tx) => {
      for (const [name, list, label] of plan) {
        const store = tx.objectStore(name);
        for (const row of list) {
          const req2 = store.get(row.id);
          req2.onsuccess = () => {
            const local = req2.result;
            if (local && local.workspaceId !== ws) {
              report.warnings.push(`\u0E02\u0E49\u0E32\u0E21 ${label} ${row.id}: \u0E40\u0E1B\u0E47\u0E19\u0E02\u0E2D\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2D\u0E37\u0E48\u0E19`);
              return;
            }
            if (local && local.updatedAt >= row.updatedAt) {
              report.keptLocal++;
              return;
            }
            store.put(row);
            report[local ? "updated" : "added"][label]++;
          };
        }
      }
    });
  }
  async restoreSettings(ws, b, mode, report, now, imageMap) {
    const d = b.data;
    if (d.dailyUpdate || d.imageStyleSettings) {
      const current = await this.deps.service.dateCardSettings(ws);
      await this.deps.service.saveDateCardSettings({ ...current, ...d.dailyUpdate ?? {}, ...d.imageStyleSettings ?? {} });
    }
    if (b.includes.includes("styleHistory")) {
      await this.deps.styles.update(ws, (h) => {
        if (mode === "replace") h.entries = [];
        for (const e of d.styleHistory) {
          const local = h.entries.find((x) => x.date === e.date);
          if (local && local.updatedAt >= e.updatedAt) continue;
          h.entries = h.entries.filter((x) => x.date !== e.date);
          h.entries.push(e);
          report[local ? "updated" : "added"].styleHistory++;
        }
      });
    }
    if (d.scheduleSettings || d.preferences) {
      const s = await this.deps.getSettings();
      await this.deps.saveSettings({ ...s, ...d.scheduleSettings ? { productUpdate: d.scheduleSettings } : {}, ...d.preferences ? { logLevel: d.preferences.logLevel } : {} });
    }
    for (const g of d.generated) {
      const assetId = imageMap[g.image.id];
      if (assetId && await this.deps.service.restoreCardImage({ date: g.date, assetId, createdAt: g.image.createdAt || now }, ws)) report.added.generatedImages++;
    }
  }
};

// src/background/group-scan.ts
var SCAN_MAX_MS = 10 * 6e4;
var GroupScanService = class {
  constructor(deps) {
    this.deps = deps;
  }
  state = { status: "idle", groups: [] };
  stopRequested = false;
  current() {
    return { ...this.state, groups: [...this.state.groups] };
  }
  /** Starts a scan (or returns the one already running). */
  start() {
    if (this.state.status !== "scanning") {
      this.state = { status: "scanning", groups: [] };
      this.stopRequested = false;
      void this.run();
    }
    return this.current();
  }
  /** Ends the running scan after its current slice, keeping the groups found so far. */
  stop() {
    if (this.state.status === "scanning") this.stopRequested = true;
    return this.current();
  }
  async run() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new AppError(ErrorCode.TIMEOUT, "Group scan took too long")), SCAN_MAX_MS);
    try {
      const ctx = { log: this.deps.log, signal: controller.signal, timeouts: await this.deps.timeouts() };
      const res = await this.deps.scan(ctx, (groups) => {
        this.state.groups = groups;
      }, () => this.stopRequested);
      this.state = { status: res.complete ? "done" : "stopped", groups: res.groups };
    } catch (err) {
      const e = toAppError(err);
      this.deps.log.warn("Group scan failed", e.toJSON());
      const groups = this.state.groups;
      this.state = groups.length ? { status: "stopped", groups, message: e.userMessage } : { status: "error", groups, message: e.userMessage };
    } finally {
      clearTimeout(timer);
    }
  }
};

// src/background/content-plan.ts
function invalid2(message) {
  return new AppError(ErrorCode.INVALID_INPUT, message, { userMessage: message });
}
var ContentPlanService = class {
  constructor(deps) {
    this.deps = deps;
  }
  lock = new Mutex();
  key(ws) {
    return `pu:content:${ws}`;
  }
  async load(ws) {
    const raw = (await chrome.storage.local.get(this.key(ws)))[this.key(ws)];
    if (!raw?.profile) return { profile: { ...EMPTY_PROFILE }, posts: [] };
    const old = (raw.plan?.days ?? []).filter((d) => d.status !== "skipped").map((d) => ({ ...d, id: d.id ?? `post_${d.date}`, createdAt: d.createdAt ?? `${d.date}T00:00:00.000Z` }));
    const rest = { ...raw };
    delete rest.plan;
    return { ...rest, profile: { ...EMPTY_PROFILE, ...raw.profile }, posts: raw.posts ?? old.reverse() };
  }
  update(ws, change) {
    return this.lock.run(async () => {
      const s = await this.load(ws);
      change(s);
      await chrome.storage.local.set({ [this.key(ws)]: s });
      return s;
    });
  }
  today() {
    return this.deps.clock.iso().slice(0, 10);
  }
  /**
   * The running AI job of this workspace. A job left PAUSED (the extension was reloaded or the
   * browser closed mid-answer) can never finish by itself and would block every button: it is
   * cancelled here, with a note to press again.
   */
  async openJob(ws) {
    const job = await this.findOpenJob(ws);
    if (job?.status !== "PAUSED") return job;
    await this.deps.engine.cancel(job.jobId).catch(() => void 0);
    await this.update(ws, (s) => s.error = "\u0E07\u0E32\u0E19\u0E02\u0E2D\u0E07 AI \u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30 (\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E16\u0E39\u0E01\u0E23\u0E35\u0E42\u0E2B\u0E25\u0E14\u0E2B\u0E23\u0E37\u0E2D\u0E1B\u0E34\u0E14\u0E40\u0E1A\u0E23\u0E32\u0E27\u0E4C\u0E40\u0E0B\u0E2D\u0E23\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E17\u0E33) \u2014 \u0E01\u0E14\u0E2A\u0E31\u0E48\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07");
    return void 0;
  }
  /** "ยกเลิก" on the status line: stop the AI job that is running now. */
  async cancelWork() {
    const ws = await this.deps.workspaceId();
    const job = await this.findOpenJob(ws);
    if (job) await this.deps.engine.cancel(job.jobId).catch(() => void 0);
    this.deps.onChanged();
    return this.state();
  }
  async findOpenJob(ws) {
    return (await this.deps.jobs.listOpen()).find((j) => (j.type === "content_plan" || j.type === "content_image") && (j.input.workspaceId ?? ws) === ws);
  }
  async state() {
    const ws = await this.deps.workspaceId();
    const job = await this.openJob(ws);
    const s = await this.load(ws);
    const out = {
      profile: s.profile,
      posts: s.posts,
      aiImagesToday: s.aiImages?.date === this.today() ? s.aiImages.count : 0,
      missing: missingForPlan(s.profile)
    };
    if (job) {
      const input = job.input;
      const progress = job.steps.find((x) => x.status === "RUNNING")?.progress?.message;
      out.working = { kind: input.kind === "content_image" ? "image" : input.mode ?? "plan", jobId: job.jobId, ...input.postId ? { postId: input.postId } : {}, ...progress ? { progress } : {} };
    } else if (s.error) out.lastError = s.error;
    return out;
  }
  async saveProfile(input) {
    const profile = validateProfile(input);
    const ids = new Set(profile.pillars.map((p) => p.id));
    if (ids.size !== profile.pillars.length) throw invalid2("\u0E2B\u0E21\u0E27\u0E14\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C\u0E0B\u0E49\u0E33\u0E01\u0E31\u0E19");
    const ws = await this.deps.workspaceId();
    await this.update(ws, (s) => s.profile = profile);
    this.deps.onChanged();
    return this.state();
  }
  async busy(ws) {
    if (await this.openJob(ws)) throw invalid2("AI \u0E01\u0E33\u0E25\u0E31\u0E07\u0E17\u0E33\u0E07\u0E32\u0E19\u0E2D\u0E37\u0E48\u0E19\u0E02\u0E2D\u0E07\u0E41\u0E1C\u0E19\u0E2D\u0E22\u0E39\u0E48 \u2014 \u0E23\u0E2D\u0E43\u0E2B\u0E49\u0E40\u0E2A\u0E23\u0E47\u0E08\u0E01\u0E48\u0E2D\u0E19");
  }
  /** "ให้ AI คิดโพสต์ใหม่": one new post, added to the top of the list. */
  async plan() {
    const ws = await this.deps.workspaceId();
    const s = await this.load(ws);
    const missing = missingForPlan(s.profile);
    if (missing.length) throw invalid2(`\u0E22\u0E31\u0E07\u0E43\u0E2B\u0E49 AI \u0E04\u0E34\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49: ${missing.join(" \xB7 ")}`);
    await this.busy(ws);
    await this.update(ws, (x) => delete x.error);
    await this.deps.engine.create("content_plan", { kind: "content_plan", title: "AI \u0E04\u0E34\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48", mode: "plan", workspaceId: ws });
    this.deps.log.info("\u0E2A\u0E31\u0E48\u0E07 AI \u0E04\u0E34\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48 1 \u0E42\u0E1E\u0E2A\u0E15\u0E4C");
    this.deps.onChanged();
    return this.state();
  }
  postOf(s, id2) {
    const post = s.posts.find((d) => d.id === id2);
    if (!post) throw invalid2("\u0E44\u0E21\u0E48\u0E1E\u0E1A\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E19\u0E35\u0E49 (\u0E2D\u0E32\u0E08\u0E16\u0E39\u0E01\u0E25\u0E1A\u0E44\u0E1B\u0E41\u0E25\u0E49\u0E27)");
    return post;
  }
  async rewrite(id2, note) {
    const ws = await this.deps.workspaceId();
    const post = this.postOf(await this.load(ws), id2);
    if (post.status === "approved") throw invalid2("\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E19\u0E35\u0E49\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E40\u0E02\u0E49\u0E32\u0E04\u0E34\u0E27\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E41\u0E01\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49");
    await this.busy(ws);
    await this.update(ws, (x) => delete x.error);
    await this.deps.engine.create("content_plan", { kind: "content_plan", title: `\u0E40\u0E02\u0E35\u0E22\u0E19\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48: ${post.title}`.slice(0, 80), mode: "rewrite", postId: id2, ...note?.trim() ? { note: note.trim().slice(0, 300) } : {}, workspaceId: ws });
    this.deps.onChanged();
    return this.state();
  }
  /** An AI picture for the post; usePhoto = ChatGPT restyles the real product photo. */
  async aiImage(id2, usePhoto = false) {
    const ws = await this.deps.workspaceId();
    const s = await this.load(ws);
    const post = this.postOf(s, id2);
    if (post.status === "approved") throw invalid2("\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E19\u0E35\u0E49\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E40\u0E02\u0E49\u0E32\u0E04\u0E34\u0E27\u0E41\u0E25\u0E49\u0E27");
    if (usePhoto && !await this.photoOf(post)) throw invalid2("\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E17\u0E35\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B\u0E01\u0E48\u0E2D\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E04\u0E48\u0E2D\u0E22\u0E43\u0E2B\u0E49 AI \u0E41\u0E15\u0E48\u0E07\u0E23\u0E39\u0E1B");
    const used = s.aiImages?.date === this.today() ? s.aiImages.count : 0;
    if (used >= s.profile.aiImagesPerDay) throw invalid2(`\u0E27\u0E31\u0E19\u0E19\u0E35\u0E49\u0E43\u0E0A\u0E49\u0E23\u0E39\u0E1B AI \u0E04\u0E23\u0E1A ${s.profile.aiImagesPerDay} \u0E23\u0E39\u0E1B\u0E41\u0E25\u0E49\u0E27 (\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E44\u0E14\u0E49\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E1E\u0E08)`);
    await this.busy(ws);
    await this.update(ws, (x) => delete x.error);
    await this.deps.engine.create("content_image", { kind: "content_image", title: `${usePhoto ? "AI \u0E41\u0E15\u0E48\u0E07\u0E23\u0E39\u0E1B\u0E08\u0E23\u0E34\u0E07" : "\u0E23\u0E39\u0E1B AI"}: ${post.title}`.slice(0, 80), postId: id2, ...usePhoto ? { usePhoto: true } : {}, workspaceId: ws });
    this.deps.onChanged();
    return this.state();
  }
  async photoOf(post) {
    return post.productId ? (await this.deps.products()).find((p) => p.id === post.productId)?.images[0] : void 0;
  }
  async editDay(id2, edit) {
    const e = validateDayEdit(edit);
    const ws = await this.deps.workspaceId();
    await this.update(ws, (s) => {
      const post = this.postOf(s, id2);
      if (post.status === "approved") throw invalid2("\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E19\u0E35\u0E49\u0E2D\u0E19\u0E38\u0E21\u0E31\u0E15\u0E34\u0E40\u0E02\u0E49\u0E32\u0E04\u0E34\u0E27\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E41\u0E01\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49");
      for (const [k, val] of Object.entries(e)) if (val !== void 0) post[k] = val;
      if (e.productId === "") delete post.productId;
    });
    this.deps.onChanged();
    return this.state();
  }
  /** Removes the post from the list (a post already in the queue stays in the queue). */
  async remove(id2) {
    const ws = await this.deps.workspaceId();
    await this.update(ws, (s) => s.posts = s.posts.filter((d) => d.id !== id2));
    this.deps.onChanged();
    return this.state();
  }
  /** "อนุมัติ → เข้าคิว": the post becomes a READY batch (the user starts it from สถานะ). */
  async approve(id2) {
    const ws = await this.deps.workspaceId();
    const s = await this.load(ws);
    const post = this.postOf(s, id2);
    if (post.status === "approved" && post.batchId) return { state: await this.state(), batchId: post.batchId };
    let assetIds = post.assetIds;
    if (!assetIds.length && post.image === "real" && post.productId) assetIds = (await this.deps.products()).find((p) => p.id === post.productId)?.images.slice(0, 10) ?? [];
    if (post.image !== "none" && !assetIds.length) throw invalid2(post.image === "ai" ? "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B AI \u2014 \u0E01\u0E14\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E23\u0E39\u0E1B \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E40\u0E1B\u0E47\u0E19\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B" : post.image === "ai-real" ? '\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48 AI \u0E41\u0E15\u0E48\u0E07 \u2014 \u0E01\u0E14 "\u0E43\u0E2B\u0E49 AI \u0E41\u0E15\u0E48\u0E07\u0E23\u0E39\u0E1B" \u0E2B\u0E23\u0E37\u0E2D\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E41\u0E1A\u0E1A\u0E23\u0E39\u0E1B' : "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E23\u0E39\u0E1B\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32");
    const batch = await this.deps.createBatch({ date: this.today(), title: post.title, message: post.caption, assetIds: post.image === "none" ? [] : assetIds, destinationIds: post.destinationIds });
    await this.update(ws, (x) => {
      const d = this.postOf(x, id2);
      d.status = "approved";
      d.batchId = batch.id;
    });
    this.deps.onChanged();
    return { state: await this.state(), batchId: batch.id };
  }
  /* --------------------------- ports for workflows --------------------------- */
  async planProducts() {
    return (await this.deps.products()).filter((p) => p.active).map((p) => ({ id: p.id, name: p.name, text: p.description.replace(/\s+/g, " ").trim().slice(0, 240), price: formatPrice2(p.price, p.currency, p.unit), hasPhotos: p.images.length > 0 }));
  }
  async planBrief(ws) {
    const s = await this.load(ws);
    return { profile: s.profile, dates: [this.today()], products: await this.planProducts(), recentTitles: s.posts.slice(0, 20).map((d) => `${d.pillarName}: ${d.title}`), count: 1 };
  }
  /** The new post goes on top of the list; the list keeps the newest MAX_POSTS. */
  async planGenerated(ws, days) {
    const now = this.deps.clock.iso();
    const fresh = days.slice(0, 1).map((d) => ({ ...d, id: newId("post_"), createdAt: now }));
    await this.update(ws, (s) => {
      s.posts = [...fresh, ...s.posts].slice(0, MAX_POSTS);
      delete s.error;
    });
    this.deps.log.info(`AI \u0E04\u0E34\u0E14\u0E42\u0E1E\u0E2A\u0E15\u0E4C\u0E43\u0E2B\u0E21\u0E48\u0E41\u0E25\u0E49\u0E27: ${fresh[0]?.title ?? "-"}`);
    this.deps.onChanged();
  }
  async rewriteBrief(ws, postId) {
    const s = await this.load(ws);
    return { profile: s.profile, day: this.postOf(s, postId), products: await this.planProducts() };
  }
  async rewriteDone(ws, postId, day) {
    await this.update(ws, (s) => {
      const i = s.posts.findIndex((d) => d.id === postId);
      if (i >= 0 && s.posts[i].status !== "approved") s.posts[i] = { ...day, id: postId, createdAt: s.posts[i].createdAt };
      delete s.error;
    });
    this.deps.onChanged();
  }
  async imageBrief(ws, postId, usePhoto) {
    const s = await this.load(ws);
    const day = this.postOf(s, postId);
    const photoAssetId = usePhoto ? await this.photoOf(day) : void 0;
    if (usePhoto && !photoAssetId) throw invalid2("\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E21\u0E35\u0E23\u0E39\u0E1B\u0E43\u0E2B\u0E49 AI \u0E41\u0E15\u0E48\u0E07");
    return { profile: s.profile, day, ...photoAssetId ? { photoAssetId } : {} };
  }
  async imageDone(ws, postId, assetId, usePhoto) {
    const today2 = this.today();
    await this.update(ws, (s) => {
      s.aiImages = { date: today2, count: (s.aiImages?.date === today2 ? s.aiImages.count : 0) + 1 };
      const post = s.posts.find((d) => d.id === postId);
      if (post && post.status !== "approved") {
        post.image = usePhoto ? "ai-real" : "ai";
        post.assetIds = [assetId];
      }
      delete s.error;
    });
    this.deps.onChanged();
  }
  async failed(ws, message) {
    await this.update(ws, (s) => s.error = message);
    this.deps.log.warn(`AI \u0E04\u0E34\u0E14\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08: ${message}`);
    this.deps.onChanged();
  }
};

// src/background/cloud-sync.ts
var EPOCH = "1970-01-01T00:00:00.000Z";
var PUSH_CHUNK = 200;
var SYNC_EVERY_MS = 5 * 6e4;
var REQUEST_TIMEOUT_MS2 = 3e4;
var CloudSyncError = class extends Error {
  constructor(message, code) {
    super(message);
    this.code = code;
  }
};
var CloudSyncService = class {
  constructor(deps) {
    this.deps = deps;
  }
  running = null;
  dirty = true;
  status = { state: "off", message: "\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E0B\u0E34\u0E07\u0E01\u0E4C" };
  lastRunAt = 0;
  key(ws) {
    return `pu:sync:${ws}`;
  }
  async loadState(ws, tenantId) {
    const raw = (await chrome.storage.local.get(this.key(ws)))[this.key(ws)];
    if (raw && raw.tenantId === tenantId) return raw;
    return { tenantId, cursor: null, pushedThrough: EPOCH, migrated: false, uploaded: [] };
  }
  saveState(ws, s) {
    return chrome.storage.local.set({ [this.key(ws)]: s });
  }
  /**
   * Deletes waiting to reach the cloud — their own key and lock, so a sync finishing meanwhile
   * never drops a delete recorded while it ran.
   */
  tombLock = new Mutex();
  tombKey(ws) {
    return `pu:sync:tombstones:${ws}`;
  }
  changeTombstones(ws, fn) {
    return this.tombLock.run(async () => {
      const key = this.tombKey(ws);
      const list = (await chrome.storage.local.get(key))[key] ?? [];
      const next = fn(list);
      await chrome.storage.local.set({ [key]: next });
      return next;
    });
  }
  /** A local record was deleted: the delete must reach the cloud too. */
  async recordDelete(kind, id2) {
    const ws = (await this.deps.workspaces.active()).id;
    const at = this.deps.clock.iso();
    await this.changeTombstones(ws, (list) => [...list.filter((t) => !(t.kind === kind && t.id === id2)), { kind, id: id2, at }]);
    this.markDirty();
  }
  markDirty() {
    this.dirty = true;
  }
  getStatus() {
    return this.status;
  }
  /** Watchdog: sync when something changed or the interval passed (never two at once). */
  async tick() {
    if (this.running) return;
    if (!this.dirty && this.deps.clock.now() - this.lastRunAt < SYNC_EVERY_MS) return;
    await this.syncNow();
  }
  syncNow() {
    this.running ??= this.run().finally(() => this.running = null);
    return this.running;
  }
  setStatus(s) {
    this.status = s;
    this.deps.onChanged(s);
    return s;
  }
  /* --------------------------------- network -------------------------------- */
  async request(token, method, path, body, type) {
    const doFetch = this.deps.fetch ?? fetch;
    let res;
    try {
      res = await doFetch(`${this.deps.apiBase}${path}`, {
        method,
        headers: { authorization: `Bearer ${token}`, ...type ? { "content-type": type } : {} },
        ...body !== void 0 ? { body } : {},
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS2),
        credentials: "omit",
        cache: "no-store"
      });
    } catch (err) {
      throw new CloudSyncError(`\u0E15\u0E34\u0E14\u0E15\u0E48\u0E2D Cloud \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (${String(err)})`, "NETWORK");
    }
    if (!res.ok) {
      const data = await res.json().catch(() => null);
      throw new CloudSyncError(data?.message ?? `Cloud \u0E15\u0E2D\u0E1A HTTP ${res.status}`, data?.code ?? `HTTP_${res.status}`);
    }
    return res;
  }
  /* ---------------------------------- sync ---------------------------------- */
  async run() {
    this.lastRunAt = this.deps.clock.now();
    let session = await this.deps.license.session();
    if (!session) return this.setStatus({ state: "off", message: "\u0E0B\u0E34\u0E07\u0E01\u0E4C\u0E44\u0E14\u0E49\u0E40\u0E21\u0E37\u0E48\u0E2D\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49 License \u0E41\u0E25\u0E49\u0E27" });
    const ws = (await this.deps.workspaces.forTenant(session.tenantId)).id;
    const state = await this.loadState(ws, session.tenantId);
    this.setStatus({ ...this.status, state: "syncing", message: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E0B\u0E34\u0E07\u0E01\u0E4C\u2026" });
    this.dirty = false;
    try {
      try {
        await this.syncOnce(session.token, ws, state);
      } catch (err) {
        if (!(err instanceof CloudSyncError) || err.code !== "TOKEN_STALE") throw err;
        await this.deps.license.refresh();
        session = await this.deps.license.session();
        if (!session) throw err;
        await this.syncOnce(session.token, ws, state);
      }
      state.lastSyncAt = this.deps.clock.iso();
      delete state.lastError;
      await this.saveState(ws, state);
      return this.setStatus({ state: "ok", message: "\u0E0B\u0E34\u0E07\u0E01\u0E4C\u0E01\u0E31\u0E1A Cloud \u0E41\u0E25\u0E49\u0E27", lastSyncAt: state.lastSyncAt });
    } catch (err) {
      this.dirty = true;
      const code = err instanceof CloudSyncError ? err.code : "ERROR";
      const message = err instanceof Error ? err.message : String(err);
      state.lastError = message;
      await this.saveState(ws, state);
      this.deps.log.warn(`Cloud sync failed: ${message}`);
      if (code === "CLOUD_NOT_CONFIGURED") return this.setStatus({ state: "not-configured", message: "Cloud \u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E40\u0E1B\u0E34\u0E14\u0E43\u0E0A\u0E49 \u2014 \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E19\u0E35\u0E49" });
      return this.setStatus({ state: "error", message: "\u0E0B\u0E34\u0E07\u0E01\u0E4C\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 \u2014 \u0E43\u0E0A\u0E49\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E44\u0E1B\u0E01\u0E48\u0E2D\u0E19", lastError: message, ...state.lastSyncAt ? { lastSyncAt: state.lastSyncAt } : {} });
    }
  }
  async syncOnce(token, ws, state) {
    await this.pull(token, ws, state);
    await this.push(token, ws, state);
    if (!state.migrated) {
      state.migrated = true;
      this.deps.log.info("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E14\u0E34\u0E21\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E16\u0E39\u0E01\u0E22\u0E49\u0E32\u0E22\u0E02\u0E36\u0E49\u0E19 Cloud \u0E41\u0E25\u0E49\u0E27 (\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E43\u0E19\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E22\u0E31\u0E07\u0E2D\u0E22\u0E39\u0E48)");
    }
  }
  async push(token, ws, state) {
    const since = state.migrated ? state.pushedThrough : EPOCH;
    const newer = (r) => r.updatedAt >= since;
    const records = [];
    let high = state.pushedThrough;
    const note = (at) => {
      if (at > high) high = at;
    };
    for (const p of (await getAllByIndex(STORE.products, "workspaceId", ws)).filter(newer)) {
      const shas = [];
      for (const id2 of p.images) {
        const asset = await this.deps.assets.get(id2).catch(() => null);
        if (!asset) continue;
        if (!state.uploaded.includes(asset.sha256)) {
          const blob = await this.deps.assets.getBlob(id2).catch(() => null);
          if (!blob) continue;
          await this.request(token, "PUT", `/v1/sync/images/${asset.sha256}`, blob, asset.mime);
          state.uploaded.push(asset.sha256);
        }
        shas.push(asset.sha256);
      }
      records.push({ kind: "product", id: p.id, data: { ...cloudCopy(p), images: [], imageSha: shas }, updatedAt: p.updatedAt, deleted: false });
      note(p.updatedAt);
    }
    for (const t of (await getAllByIndex(STORE.msgTemplates, "workspaceId", ws)).filter(newer)) {
      records.push({ kind: "template", id: t.id, data: cloudCopy(t), updatedAt: t.updatedAt, deleted: false });
      note(t.updatedAt);
    }
    for (const d of (await getAllByIndex(STORE.destinations, "workspaceId", ws)).filter(newer)) {
      records.push({ kind: "destination", id: d.id, data: cloudCopy(d), updatedAt: d.updatedAt, deleted: false });
      note(d.updatedAt);
    }
    for (const s of (await this.deps.styles.load(ws)).entries.filter(newer)) {
      records.push({ kind: "style", id: s.date, data: s, updatedAt: s.updatedAt, deleted: false });
      note(s.updatedAt);
    }
    const cardAt = await this.deps.service.dateCardUpdatedAt(ws);
    if (cardAt > since) {
      records.push({ kind: "settings", id: "dateCard", data: await this.deps.service.dateCardSettings(ws), updatedAt: cardAt, deleted: false });
      note(cardAt);
    }
    const prefsAt = await this.preferencesUpdatedAt();
    if (prefsAt > since) {
      const s = await this.deps.getSettings();
      records.push({ kind: "settings", id: "preferences", data: { productUpdate: s.productUpdate, logLevel: s.logLevel }, updatedAt: prefsAt, deleted: false });
      note(prefsAt);
    }
    const tombs = await this.changeTombstones(ws, (list) => list);
    for (const t of tombs) records.push({ kind: t.kind, id: t.id, data: {}, updatedAt: t.at, deleted: true });
    for (let i = 0; i < records.length; i += PUSH_CHUNK) {
      await this.request(token, "POST", "/v1/sync/push", JSON.stringify({ records: records.slice(i, i + PUSH_CHUNK) }), "application/json");
    }
    await this.changeTombstones(ws, (list) => list.filter((t) => !tombs.some((x) => x.kind === t.kind && x.id === t.id && x.at === t.at)));
    state.pushedThrough = high;
  }
  async pull(token, ws, state) {
    const pending = await this.changeTombstones(ws, (list) => list);
    for (let page = 0; page < 50; page++) {
      const q = state.cursor ? `?since=${encodeURIComponent(state.cursor)}` : "";
      const res = await (await this.request(token, "GET", `/v1/sync/pull${q}`)).json();
      for (const r of res.records) {
        try {
          if (!pending.some((t) => t.kind === r.kind && t.id === r.id && t.at >= r.updatedAt)) await this.apply(token, ws, r);
        } catch (err) {
          this.deps.log.warn(`\u0E02\u0E49\u0E32\u0E21 record \u0E08\u0E32\u0E01 Cloud ${r.kind}/${r.id}: ${err instanceof Error ? err.message : String(err)}`);
        }
        if (r.serverAt) state.cursor = r.serverAt;
      }
      if (!res.more) break;
    }
  }
  /** One cloud record into the local cache, if it is newer than what is here. */
  async apply(token, ws, r) {
    const store = r.kind === "product" ? STORE.products : r.kind === "template" ? STORE.msgTemplates : r.kind === "destination" ? STORE.destinations : null;
    if (store) {
      const local = await get(store, r.id);
      if (local && local.workspaceId !== ws) return;
      if (local && (local.updatedAt > r.updatedAt || local.updatedAt === r.updatedAt && !r.deleted)) return;
      if (r.deleted) {
        if (local) await del(store, r.id);
        return;
      }
      const data = { ...r.data, workspaceId: ws };
      if (r.kind === "product") {
        const shas = Array.isArray(data.imageSha) ? data.imageSha.filter((x) => typeof x === "string" && /^[0-9a-f]{64}$/.test(x)) : [];
        delete data.imageSha;
        const images = [];
        for (const sha of shas) {
          const id2 = await this.localImage(token, sha);
          if (id2) images.push(id2);
        }
        await put(store, validateProduct({ ...data, images }));
      } else if (r.kind === "template") await put(store, validateTemplate(data));
      else await put(store, validateDestination(data));
      return;
    }
    if (r.kind === "style") {
      const s = validateStyle(r.data);
      await this.deps.styles.update(ws, (h) => {
        const local = h.entries.find((x) => x.date === s.date);
        if (local && local.updatedAt >= s.updatedAt) return;
        h.entries = h.entries.filter((x) => x.date !== s.date);
        if (!r.deleted) h.entries.push(s);
      });
      return;
    }
    if (r.id === "dateCard") {
      if (await this.deps.service.dateCardUpdatedAt(ws) >= r.updatedAt) return;
      const s = validateDateCardSettings(r.data);
      await this.deps.service.saveDateCardSettings(s, { ws, updatedAt: r.updatedAt });
    } else if (r.id === "preferences") {
      if (await this.preferencesUpdatedAt() >= r.updatedAt) return;
      const p = r.data;
      const s = await this.deps.getSettings();
      await this.deps.saveSettings({ ...s, ...p.productUpdate ? { productUpdate: p.productUpdate } : {}, ...p.logLevel ? { logLevel: p.logLevel } : {} });
      await chrome.storage.local.set({ [PREFS_AT]: r.updatedAt });
    }
  }
  /** The local asset for an image of the account (downloaded once if this browser lacks it). */
  async localImage(token, sha) {
    const found = await this.deps.assets.findBySha256(sha, PRODUCT_IMAGE_SOURCE);
    if (found) return found.id;
    try {
      const res = await this.request(token, "GET", `/v1/sync/images/${sha}`);
      const blob = new Blob([await res.arrayBuffer()], { type: res.headers.get("content-type") ?? "image/png" });
      return (await this.deps.assets.ingest(blob, { kind: blob.type.startsWith("video/") ? "video" : "image", providerId: PRODUCT_IMAGE_SOURCE })).id;
    } catch (err) {
      this.deps.log.warn(`\u0E42\u0E2B\u0E25\u0E14\u0E23\u0E39\u0E1B\u0E08\u0E32\u0E01 Cloud \u0E44\u0E21\u0E48\u0E44\u0E14\u0E49 (${sha.slice(0, 8)}\u2026): ${err instanceof Error ? err.message : String(err)}`);
      return null;
    }
  }
  async preferencesUpdatedAt() {
    return (await chrome.storage.local.get(PREFS_AT))[PREFS_AT] ?? EPOCH;
  }
  /** The send settings changed on this browser (they sync as "preferences"). */
  async preferencesChanged() {
    await chrome.storage.local.set({ [PREFS_AT]: this.deps.clock.iso() });
    this.markDirty();
  }
};
var PREFS_AT = "pu:sync:preferencesAt";
function cloudCopy(r) {
  const copy = { ...r };
  delete copy.workspaceId;
  return copy;
}

// src/background/router.ts
function isExtensionPageSender(sender) {
  if (sender.id !== chrome.runtime.id) return false;
  const base = chrome.runtime.getURL("");
  return typeof sender.url === "string" && sender.url.startsWith(base);
}
var Router = class {
  entries = /* @__PURE__ */ new Map();
  register(type, validate, handler) {
    if (this.entries.has(type)) throw new AppError(ErrorCode.INTERNAL, `Handler for ${type} registered twice`);
    this.entries.set(type, {
      validate,
      handler
    });
  }
  registeredTypes() {
    return [...this.entries.keys()].sort();
  }
  /** True when this router owns the message type (so the listener must answer). */
  owns(message) {
    return isEnvelope(message) && this.entries.has(message.type);
  }
  async dispatch(message, sender) {
    try {
      if (!isEnvelope(message)) throw new AppError(ErrorCode.INVALID_INPUT, "Malformed message");
      if (!isExtensionPageSender(sender)) {
        throw new AppError(ErrorCode.INVALID_INPUT, `Command ${message.type} rejected: untrusted sender`);
      }
      const entry = this.entries.get(message.type);
      if (!entry) throw new AppError(ErrorCode.INVALID_INPUT, `Unknown command ${message.type}`);
      const req2 = entry.validate(message.payload ?? {}, message.type);
      return ok(await entry.handler(req2));
    } catch (err) {
      return failure(err);
    }
  }
};

// src/background/app.ts
var CLEANUP_KEY = "cleanup:lastRun";
var SEND_TAB_PROVIDERS = [MESSENGER_PROVIDER_ID, FACEBOOK_PROVIDER_ID, "facebook-group-web"];
var App = class {
  clock;
  settingsRepo = new SettingsRepo();
  jobRepo = new JobRepo();
  logRepo = new LogRepo();
  assetRepo;
  logger;
  registry = new ProviderRegistry();
  tabs;
  transfers = new TransferHub();
  engine;
  workspaceRepo;
  productUpdateRepo = new ProductUpdateRepo();
  productUpdate;
  groupScan;
  contentPlan;
  storyPreview;
  /** LINE OpenChat through the LINE PC native host (ADR-78). */
  lineOpenChat = new LineOpenChatAdapter();
  license;
  backup;
  sync;
  /** Style History (ADR-64) — one instance shared by the service and backups. */
  styleRepo = new LocalStyleHistoryRepo();
  uiPorts = /* @__PURE__ */ new Set();
  tabsTimer;
  tabsChain = Promise.resolve();
  constructor(opts = {}) {
    this.clock = opts.clock ?? systemClock;
    this.assetRepo = new AssetRepo(this.clock);
    this.logger = new Logger(this.logRepo, this.clock);
    this.logger.onEntry((entry) => this.broadcast({ kind: "log", entry }));
    const getSettings = () => this.settingsRepo.get();
    this.workspaceRepo = new WorkspaceRepo(
      () => this.clock.iso(),
      async () => {
        const p = (await this.settingsRepo.get()).prompts;
        return { voice: p.brandVoice, rules: p.extraRules };
      }
    );
    this.license = new LicenseService({
      clock: this.clock,
      log: this.logger.scope("license"),
      apiBase: opts.license?.apiBase ?? LICENSE_API_BASE,
      publicKeys: opts.license?.publicKeys ?? LICENSE_PUBLIC_KEYS,
      version: chrome.runtime.getManifest?.().version ?? "0.0.0",
      ...opts.license?.fetch ? { fetch: opts.license.fetch } : {},
      onChanged: () => {
        this.broadcast({ kind: "license-changed" });
        void this.engine.pump();
        this.sync.markDirty();
      }
    });
    this.tabs = new TabSessionManager({ log: this.logger.scope("tabs"), getSettings });
    const webDeps = { tabs: this.tabs, transfers: this.transfers, clock: this.clock };
    this.registry.register(new ChatGPTWebAdapter(webDeps));
    this.registry.register(new FacebookWebAdapter(webDeps));
    const groupPosts = new FacebookGroupWebAdapter(webDeps);
    this.groupScan = new GroupScanService({
      scan: (ctx, onSlice, shouldStop) => groupPosts.scanJoinedGroups(ctx, onSlice, shouldStop),
      timeouts: async () => (await this.settingsRepo.get()).timeouts,
      log: this.logger.scope("group-scan")
    });
    this.storyPreview = new FacebookStoryAdapter(webDeps);
    this.registry.register(new MessengerWebAdapter(webDeps));
    for (const extra of opts.extraProviders?.(webDeps) ?? []) this.registry.register(extra);
    const services = {
      capabilities: {
        resolve: (capability, settings) => {
          const { adapter, impl } = this.registry.resolve(capability, settings);
          return { impl, providerId: adapter.info.id };
        }
      },
      clock: this.clock,
      groupPosts,
      lineSends: { send: async (req2, ctx) => this.lineOpenChat.send({ ...req2, lockInput: (await this.settingsRepo.get()).productUpdate.lineLockInput === true }, ctx) },
      // Late-bound: the Product Update Bot service is created after the engine.
      productSends: {
        get: (id2) => this.productUpdate.getSend(id2),
        markSent: (id2, by, title) => this.productUpdate.markSent(id2, by, title),
        markPendingApproval: (id2) => this.productUpdate.markPendingApproval(id2),
        markImagesSent: (id2) => this.productUpdate.markImagesSent(id2),
        markEnded: (id2, status, error) => this.productUpdate.markEnded(id2, status, error),
        lastAttemptAt: (channel) => this.productUpdate.lastAttemptAt(channel),
        setLastAttemptAt: (ms, channel) => this.productUpdate.setLastAttemptAt(ms, channel),
        haltQueue: (reason) => this.productUpdate.haltQueue(reason)
      },
      dateCards: {
        prompt: (date, ws) => this.productUpdate.dateCardPrompt(date, ws),
        generated: (input) => this.productUpdate.dateCardGenerated(input),
        failed: (input) => this.productUpdate.dateCardFailed(input)
      },
      dateStyles: {
        brief: (date, ws) => this.productUpdate.dateStyleBrief(date, ws),
        generated: (input) => this.productUpdate.dateStyleGenerated(input),
        failed: (input) => this.productUpdate.dateStyleFailed(input)
      },
      // Late-bound like productSends: the content planner is created after the engine.
      contentPlans: {
        planBrief: (ws) => this.contentPlan.planBrief(ws),
        planGenerated: (ws, days) => this.contentPlan.planGenerated(ws, days),
        rewriteBrief: (ws, postId) => this.contentPlan.rewriteBrief(ws, postId),
        rewriteDone: (ws, postId, day) => this.contentPlan.rewriteDone(ws, postId, day),
        imageBrief: (ws, postId, usePhoto) => this.contentPlan.imageBrief(ws, postId, usePhoto),
        imageDone: (ws, postId, assetId, usePhoto) => this.contentPlan.imageDone(ws, postId, assetId, usePhoto),
        failed: (ws, message) => this.contentPlan.failed(ws, message),
        // User's rule (2026-11-13): once the answer is in, close the ChatGPT tab (a failed job keeps it for a look).
        finished: () => this.tabs.closeProviderTabs(CHATGPT_PROVIDER_ID)
      }
    };
    this.engine = new JobEngine({
      repo: this.jobRepo,
      logger: this.logger,
      clock: this.clock,
      assets: this.assetRepo,
      services,
      getSettings,
      laneOf: (job) => "kind" in job.input && job.input.kind === "product_send" ? `product-send:${job.input.channel ?? "chat"}` : toolOfJobType(job.type),
      // License gate (ADR-60): without a valid license no new job starts.
      canStart: (job) => {
        const tool = toolOfJobType(job.type);
        return tool === "system" ? Promise.resolve(null) : this.license.denyReason(tool);
      }
    });
    for (const wf of WORKFLOWS) this.engine.register(wf);
    this.productUpdate = new ProductUpdateService({
      repo: this.productUpdateRepo,
      assets: this.assetRepo,
      jobs: this.jobRepo,
      engine: this.engine,
      clock: this.clock,
      log: this.logger.scope("product-update"),
      workspaceId: async () => (await this.workspaceRepo.active()).id,
      inspectChat: async (target, ctx) => this.registry.resolve("message", await this.settingsRepo.get()).impl.inspectChat(target, ctx),
      inspectGroup: (url, ctx) => groupPosts.inspectGroup(url, ctx),
      inspectLine: async (room, ctx) => this.lineOpenChat.inspectRoom(room, ctx, (await this.settingsRepo.get()).productUpdate.lineLockInput === true),
      probeContext: (source) => this.probeContext(source),
      onChanged: () => {
        this.sync.markDirty();
        this.broadcast({ kind: "product-update-changed" });
        this.followQueueInTabGroup();
      },
      styles: this.styleRepo,
      onDeleted: (kind, id2) => this.sync.recordDelete(kind, id2)
    });
    this.contentPlan = new ContentPlanService({
      engine: this.engine,
      jobs: this.jobRepo,
      clock: this.clock,
      log: this.logger.scope("product-update"),
      workspaceId: async () => (await this.workspaceRepo.active()).id,
      products: () => this.productUpdate.listProducts(),
      destinations: () => this.productUpdate.listDestinations(),
      createBatch: (input) => this.productUpdate.createContentBatch(input),
      onChanged: () => this.broadcast({ kind: "product-update-changed" })
    });
    this.sync = new CloudSyncService({
      apiBase: opts.license?.apiBase ?? LICENSE_API_BASE,
      license: this.license,
      workspaces: this.workspaceRepo,
      service: this.productUpdate,
      assets: this.assetRepo,
      styles: this.styleRepo,
      getSettings,
      saveSettings: async (s) => {
        const saved = await this.settingsRepo.save(s);
        this.applySettings(saved);
        return saved;
      },
      clock: this.clock,
      log: this.logger.scope("product-update/sync"),
      ...opts.license?.fetch ? { fetch: opts.license.fetch } : {},
      onChanged: (status) => {
        this.broadcast({ kind: "sync-changed", status });
        if (status.state === "ok") this.broadcast({ kind: "product-update-changed" });
      }
    });
    this.backup = new BackupService({
      service: this.productUpdate,
      assets: this.assetRepo,
      styles: this.styleRepo,
      getSettings,
      saveSettings: async (s) => {
        const saved = await this.settingsRepo.save(s);
        this.applySettings(saved);
        return saved;
      },
      workspaceId: async () => (await this.workspaceRepo.active()).id,
      clock: this.clock,
      log: this.logger.scope("product-update/backup"),
      appVersion: chrome.runtime.getManifest?.().version ?? "0.0.0",
      onChanged: () => this.broadcast({ kind: "product-update-changed" })
    });
  }
  /**
   * Keeps the PostHub tab group in step with the product-send queue: progress in its title while sends
   * run, and closing the cleanly finished send tabs when the run ends. Debounced; never awaited by the
   * caller (it may wait for a provider lock the caller is still holding).
   */
  followQueueInTabGroup() {
    if (this.tabsTimer !== void 0) return;
    this.tabsTimer = setTimeout(() => {
      this.tabsTimer = void 0;
      this.tabsChain = this.tabsChain.then(async () => {
        const running = (await this.productUpdate.listBatches(10)).filter((b) => b.state === "RUNNING");
        let current = 0;
        let total = 0;
        for (const b of running) {
          const queued = b.sends.length - b.counts.READY;
          total += queued;
          current += queued - b.counts.QUEUED;
        }
        await this.tabs.noteQueue({ running: running.length > 0, current, total }, SEND_TAB_PROVIDERS);
      }).catch((err) => this.logger.scope("tabs").warn("PostHub tab group update failed", { message: String(err) }));
    }, 500);
  }
  /** A bounded context for a provider check outside a job (destination tests, diagnostics). */
  async probeContext(source) {
    const timeouts = (await this.settingsRepo.get()).timeouts;
    const controller = new AbortController();
    setTimeout(() => controller.abort(new AppError(ErrorCode.TIMEOUT, `${source} timed out`)), timeouts.tabLoadMs * 2 + timeouts.bridgeCommandMs * 2);
    return { log: this.logger.scope(source), signal: controller.signal, timeouts };
  }
  /** Housekeeping: prune job history. Throttled via storage so SW restarts don't repeat it. */
  async cleanup() {
    const stored = await chrome.storage.local.get(CLEANUP_KEY);
    const last = typeof stored[CLEANUP_KEY] === "number" ? stored[CLEANUP_KEY] : 0;
    const now = this.clock.now();
    if (now - last < CLEANUP_INTERVAL_MS) return;
    await chrome.storage.local.set({ [CLEANUP_KEY]: now });
    const pruned = await this.jobRepo.pruneHistory(JOB_HISTORY_LIMIT);
    if (pruned) this.logger.scope("cleanup").info(`Pruned ${pruned} old jobs from history`);
  }
  applySettings(settings) {
    this.logger.setLevel(settings.logLevel);
  }
  attachUiPort(port5) {
    this.uiPorts.add(port5);
    port5.onDisconnect.addListener(() => this.uiPorts.delete(port5));
  }
  isUiPort(port5) {
    return port5.name === PORT_UI_EVENTS && port5.sender !== void 0 && isExtensionPageSender(port5.sender);
  }
  broadcast(event) {
    for (const port5 of this.uiPorts) {
      try {
        port5.postMessage(event);
      } catch {
        this.uiPorts.delete(port5);
      }
    }
  }
};

// src/background/story-batch.ts
var StoryBatchService = class {
  constructor(app) {
    this.app = app;
  }
  control = new Mutex();
  running = null;
  key(ws) {
    return `storyBatch:${ws}`;
  }
  async workspace() {
    return (await this.app.workspaceRepo.active()).id;
  }
  async save(batch) {
    await chrome.storage.local.set({ [this.key(batch.workspaceId)]: structuredClone(batch) });
  }
  async requireLicense() {
    const denial = await this.app.license.denyReason("product-update");
    if (denial) throw new AppError(ErrorCode.LICENSE_REQUIRED, denial, { userMessage: denial });
  }
  async validate(choice) {
    const product = (await this.app.productUpdate.listProducts()).find((p) => p.id === choice.productId);
    if (!product || !product.images.includes(choice.assetId)) throw new AppError(ErrorCode.INVALID_INPUT, "Selected Story photo no longer belongs to the product");
    const asset = await this.app.assetRepo.get(choice.assetId);
    if (asset.kind !== "image" || !/^image\/(png|jpeg|webp)$/.test(asset.mime)) throw new AppError(ErrorCode.INVALID_INPUT, "Story requires a supported photo");
    return { name: product.name, imageNumber: product.images.indexOf(choice.assetId) + 1 };
  }
  async call(fn) {
    const { timeouts } = await this.app.settingsRepo.get();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new AppError(ErrorCode.TIMEOUT, "Story operation timed out")), timeouts.tabLoadMs * 2 + timeouts.uploadMs * 2 + timeouts.bridgeCommandMs * 6);
    try {
      return await fn({
        jobId: "story-batch",
        stepId: "story",
        log: this.app.logger.scope("product-update/story-batch"),
        signal: controller.signal,
        timeouts,
        assets: this.app.assetRepo,
        previousCheckpoint: void 0,
        inputFor: () => void 0,
        checkpoint: async () => {
        },
        progress: () => {
        }
      });
    } finally {
      clearTimeout(timer);
    }
  }
  async latest() {
    return this.control.run(async () => {
      const ws = await this.workspace();
      if (this.running?.workspaceId === ws) return structuredClone(this.running);
      const raw = (await chrome.storage.local.get(this.key(ws)))[this.key(ws)];
      if (!raw) return null;
      if (raw.status === "RUNNING") {
        raw.status = "STOPPED";
        raw.message = "\u0E42\u0E1B\u0E23\u0E41\u0E01\u0E23\u0E21\u0E16\u0E39\u0E01\u0E02\u0E31\u0E14\u0E08\u0E31\u0E07\u0E2B\u0E27\u0E30 \u2014 \u0E15\u0E23\u0E27\u0E08\u0E1C\u0E25\u0E43\u0E19 Facebook \u0E01\u0E48\u0E2D\u0E19 \u0E44\u0E21\u0E48\u0E21\u0E35\u0E01\u0E32\u0E23\u0E2A\u0E48\u0E07\u0E0A\u0E38\u0E14\u0E40\u0E14\u0E34\u0E21\u0E0B\u0E49\u0E33\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34";
        for (const item of raw.items) {
          if (item.status === "PUBLISHING") item.status = "UNCONFIRMED";
          else if (item.status === "PREPARING") item.status = "FAILED";
        }
        await this.save(raw);
      }
      return raw;
    });
  }
  async create(choices) {
    return this.control.run(async () => {
      if (this.running) throw new AppError(ErrorCode.INVALID_STATE, "A Story batch is running");
      await this.requireLicense();
      const workspaceId = await this.workspace();
      const items = [];
      const seen = /* @__PURE__ */ new Set();
      for (const choice of choices) {
        const product = await this.validate(choice);
        if (seen.has(choice.assetId)) continue;
        seen.add(choice.assetId);
        items.push({ ...choice, productName: product.name, imageNumber: product.imageNumber, status: "WAITING" });
      }
      const owner = await this.call((ctx) => this.app.storyPreview.inspectOwner(ctx));
      if (await this.workspace() !== workspaceId) throw new AppError(ErrorCode.INVALID_STATE, "Workspace changed during review");
      const batch = { id: newId("stb_"), workspaceId, owner, createdAt: this.app.clock.iso(), status: "REVIEW", stopRequested: false, message: "\u0E15\u0E23\u0E27\u0E08\u0E23\u0E39\u0E1B\u0E41\u0E25\u0E30\u0E1A\u0E31\u0E0D\u0E0A\u0E35\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14", items };
      await this.save(batch);
      return batch;
    });
  }
  async start(id2) {
    return this.control.run(async () => {
      if (this.running) throw new AppError(ErrorCode.INVALID_STATE, "A Story batch is already running");
      await this.requireLicense();
      const ws = await this.workspace();
      const batch = (await chrome.storage.local.get(this.key(ws)))[this.key(ws)];
      if (!batch || batch.id !== id2 || batch.status !== "REVIEW") throw new AppError(ErrorCode.INVALID_STATE, "Story batch is not awaiting approval");
      for (const item of batch.items) await this.validate(item);
      batch.status = "RUNNING";
      batch.message = "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48\u0E15\u0E32\u0E21\u0E25\u0E33\u0E14\u0E31\u0E1A";
      this.running = batch;
      try {
        await this.save(batch);
      } catch (err) {
        this.running = null;
        throw err;
      }
      void this.run(batch).catch(async (err) => {
        batch.status = "STOPPED";
        batch.message = toAppError(err).userMessage;
        for (const item of batch.items) {
          if (item.status === "PUBLISHING") item.status = "UNCONFIRMED";
          else if (item.status === "PREPARING") item.status = "FAILED";
        }
        await this.save(batch);
      }).finally(() => {
        this.running = null;
      });
      return structuredClone(batch);
    });
  }
  async stop(id2) {
    return this.control.run(async () => {
      if (!this.running || this.running.status !== "RUNNING" || this.running.id !== id2 || this.running.workspaceId !== await this.workspace()) throw new AppError(ErrorCode.INVALID_STATE, "This Story batch is not running");
      this.running.stopRequested = true;
      this.running.message = "\u0E08\u0E30\u0E2B\u0E22\u0E38\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E23\u0E39\u0E1B\u0E16\u0E31\u0E14\u0E44\u0E1B \u2014 \u0E23\u0E2D\u0E1C\u0E25\u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E01\u0E33\u0E25\u0E31\u0E07\u0E17\u0E33";
      await this.save(this.running);
      return structuredClone(this.running);
    });
  }
  async run(batch) {
    for (const item of batch.items) {
      if (batch.stopRequested) break;
      if (await this.workspace() !== batch.workspaceId) throw new AppError(ErrorCode.INVALID_STATE, "Workspace changed during Story batch");
      await this.requireLicense();
      await this.validate(item);
      item.status = "PREPARING";
      await this.save(batch);
      let clickIntent = false;
      try {
        await this.call((ctx) => this.app.storyPreview.publishPhoto(item.assetId, batch.owner, ctx, async () => {
          if (batch.stopRequested) throw new AppError(ErrorCode.CANCELLED, "Stopped before Share", { userMessage: "\u0E2B\u0E22\u0E38\u0E14\u0E01\u0E48\u0E2D\u0E19\u0E01\u0E14\u0E41\u0E0A\u0E23\u0E4C \u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E44\u0E27\u0E49\u0E22\u0E31\u0E07\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19 Facebook" });
          if (await this.workspace() !== batch.workspaceId) throw new AppError(ErrorCode.INVALID_STATE, "Workspace changed before Story Share");
          item.status = "PUBLISHING";
          clickIntent = true;
          await this.save(batch);
        }));
        item.status = "PUBLISHED";
        await this.save(batch);
      } catch (err) {
        item.status = clickIntent ? "UNCONFIRMED" : "FAILED";
        item.message = toAppError(err).userMessage;
        batch.status = "STOPPED";
        batch.message = item.message;
        await this.save(batch);
        return;
      }
      if (!batch.stopRequested && batch.items.indexOf(item) < batch.items.length - 1) {
        const gap = (await this.app.settingsRepo.get()).productUpdate.sendGapSec * 1e3;
        const until = this.app.clock.now() + gap;
        while (!batch.stopRequested && this.app.clock.now() < until) await delay(Math.min(1e3, until - this.app.clock.now()));
      }
    }
    batch.status = batch.items.every((item) => item.status === "PUBLISHED") ? "COMPLETE" : "STOPPED";
    batch.message = batch.status === "COMPLETE" ? "\u0E40\u0E1C\u0E22\u0E41\u0E1E\u0E23\u0E48\u0E04\u0E23\u0E1A\u0E17\u0E31\u0E49\u0E07\u0E0A\u0E38\u0E14\u0E41\u0E25\u0E49\u0E27" : "\u0E2B\u0E22\u0E38\u0E14\u0E0A\u0E38\u0E14\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2A\u0E48\u0E07";
    await this.save(batch);
  }
};

// src/background/handlers.ts
var empty2 = empty;
var jobIdReq = object({ jobId: id });
var PROBE_TIMEOUT_FACTOR = 2;
function probeContext(app, timeouts, source) {
  const controller = new AbortController();
  const ms = timeouts.tabLoadMs * PROBE_TIMEOUT_FACTOR;
  setTimeout(() => controller.abort(new AppError(ErrorCode.TIMEOUT, `${source} timed out`)), ms);
  return { log: app.logger.scope(source), signal: controller.signal, timeouts };
}
function registerHandlers(router, app) {
  const { engine } = app;
  router.register("app.ping", empty2, async () => {
    await chrome.action.setBadgeText({ text: "" });
    return { version: chrome.runtime.getManifest().version };
  });
  const toolField = optional(literal("content-factory", "product-update"));
  router.register("job.listOpen", object({ tool: toolField }), async ({ tool }) => {
    const open = await app.jobRepo.listOpen();
    return tool ? open.filter((j) => toolOfJobType(j.type) === tool) : open;
  });
  router.register("job.history", object({ limit: optional(number({ int: true, min: 1, max: JOB_HISTORY_LIMIT })), tool: toolField }), async (req2) => {
    const limit = req2.limit ?? 50;
    if (!req2.tool) return app.jobRepo.history(limit);
    const all = await app.jobRepo.history(JOB_HISTORY_LIMIT);
    return all.filter((j) => toolOfJobType(j.type) === req2.tool).slice(0, limit);
  });
  router.register("job.get", jobIdReq, ({ jobId }) => app.jobRepo.get(jobId));
  router.register("job.pause", jobIdReq, ({ jobId }) => engine.pause(jobId));
  router.register("job.resume", jobIdReq, ({ jobId }) => engine.resume(jobId));
  router.register("job.cancel", jobIdReq, ({ jobId }) => engine.cancel(jobId));
  router.register("job.retry", jobIdReq, ({ jobId }) => engine.retry(jobId));
  router.register("job.approve", jobIdReq, ({ jobId }) => engine.approve(jobId));
  router.register(
    "job.provideInput",
    object({ jobId: id, stepId: id, text: string({ min: 1, max: 1e5 }) }),
    ({ jobId, stepId, text: text2 }) => engine.provideInput(jobId, stepId, text2)
  );
  router.register("settings.get", empty2, () => app.settingsRepo.get());
  router.register("settings.update", object({ settings: validateSettings }), async ({ settings }) => {
    const saved = await app.settingsRepo.save(settings);
    await app.sync.preferencesChanged();
    app.applySettings(saved);
    return saved;
  });
  router.register("settings.sendTiming.update", object({ channel: literal("chat", "group", "feed", "line"), range: validateDelayRange }), async ({ channel, range }) => {
    const saved = await app.settingsRepo.updateChannelDelay(channel, range);
    await app.sync.preferencesChanged();
    app.applySettings(saved);
    return saved;
  });
  router.register("settings.reset", empty2, async () => {
    const saved = await app.settingsRepo.reset();
    app.applySettings(saved);
    return saved;
  });
  router.register("license.get", empty2, () => app.license.view());
  router.register("license.reveal", empty2, () => app.license.revealKey());
  router.register("license.activate", object({ key: string({ min: 10, max: 64 }) }), ({ key }) => app.license.activate(key));
  router.register("license.activateGoogle", empty2, () => app.license.activateGoogle());
  router.register("license.activateEmail", object({ email: string({ min: 3, max: 254 }), pin: string({ min: 6, max: 6 }) }), ({ email, pin }) => app.license.activateEmail(email, pin));
  router.register("license.changePin", object({ pin: string({ min: 6, max: 6 }), newPin: string({ min: 6, max: 6 }) }), ({ pin, newPin }) => app.license.changePin(pin, newPin));
  router.register("license.refresh", empty2, () => app.license.refresh());
  router.register("license.deactivate", empty2, () => app.license.deactivate());
  router.register("workspace.active", empty2, () => app.workspaceRepo.active());
  router.register(
    "workspace.update",
    object({ id, name: optional(string({ min: 1, max: 80 })), dna: optional(validateContentDNA) }),
    ({ id: id2, name, dna }) => app.workspaceRepo.update(id2, { ...name !== void 0 ? { name } : {}, ...dna ? { dna } : {} })
  );
  router.register(
    "log.query",
    object({
      jobId: optional(id),
      minLevel: optional(literal("DEBUG", "INFO", "WARN", "ERROR")),
      limit: optional(number({ int: true, min: 1, max: 2e3 })),
      tool: toolField
    }),
    async (req2) => {
      const limit = req2.limit ?? 300;
      const q = { limit: req2.tool ? 2e3 : limit };
      if (req2.jobId) q.jobId = req2.jobId;
      if (req2.minLevel) q.minLevel = req2.minLevel;
      const entries = await app.logRepo.query(q);
      const tool = req2.tool;
      return tool ? entries.filter((e) => logBelongsTo(e, tool)).slice(0, limit) : entries;
    }
  );
  router.register("log.clear", empty2, async () => ({ cleared: await app.logRepo.clear() }));
  router.register("providers.list", empty2, () => Promise.resolve(app.registry.list()));
  router.register("providers.check", object({ providerId: id }), async ({ providerId }) => {
    const settings = await app.settingsRepo.get();
    return app.registry.get(providerId).checkReady(probeContext(app, settings.timeouts, `check/${providerId}`));
  });
  router.register("providers.diagnose", object({ providerId: id }), async ({ providerId }) => {
    const adapter = app.registry.get(providerId);
    if (!adapter.diagnose) return [];
    const settings = await app.settingsRepo.get();
    return adapter.diagnose(probeContext(app, settings.timeouts, `diagnose/${providerId}`));
  });
  registerProductUpdate(router, app);
}
function registerProductUpdate(router, app) {
  const pu = app.productUpdate;
  const id2 = object({ id });
  const batchId = object({ batchId: id });
  const ids = array(id, { max: 200 });
  const date = string({ pattern: /^\d{4}-\d{2}-\d{2}$/ });
  router.register("pu.products.list", empty2, () => pu.listProducts());
  const stories = new StoryBatchService(app);
  router.register("pu.story.batch.create", object({ items: array(object({ productId: id, assetId: id }), { min: 1, max: 200 }) }), ({ items }) => stories.create(items));
  router.register("pu.story.batch.get", empty2, () => stories.latest());
  router.register("pu.story.batch.start", batchId, ({ batchId: sid }) => stories.start(sid));
  router.register("pu.story.batch.stop", batchId, ({ batchId: sid }) => stories.stop(sid));
  router.register("pu.story.prepare", object({ productId: id, assetId: id }), async ({ productId, assetId }) => {
    const denial = await app.license.denyReason("product-update");
    if (denial) throw new AppError(ErrorCode.LICENSE_REQUIRED, denial, { userMessage: denial });
    const product = (await pu.listProducts()).find((p) => p.id === productId);
    if (!product || !product.images.includes(assetId)) {
      throw new AppError(ErrorCode.INVALID_INPUT, "Selected Story photo does not belong to this product", { userMessage: "\u0E23\u0E39\u0E1B\u0E17\u0E35\u0E48\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E19\u0E35\u0E49\u0E41\u0E25\u0E49\u0E27 \u2014 \u0E40\u0E25\u0E37\u0E2D\u0E01\u0E23\u0E39\u0E1B\u0E43\u0E2B\u0E21\u0E48" });
    }
    const asset = await app.assetRepo.get(assetId);
    if (asset.kind !== "image" || !/^image\/(png|jpeg|webp)$/.test(asset.mime)) throw new AppError(ErrorCode.INVALID_INPUT, "Story requires a supported image");
    const settings = await app.settingsRepo.get();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new AppError(ErrorCode.TIMEOUT, "Story preview timed out")), settings.timeouts.tabLoadMs + settings.timeouts.uploadMs + settings.timeouts.bridgeCommandMs * 4);
    try {
      return await app.storyPreview.prepare(assetId, {
        jobId: "story-preview",
        stepId: "prepare",
        log: app.logger.scope("product-update/story-preview"),
        signal: controller.signal,
        timeouts: settings.timeouts,
        assets: app.assetRepo,
        previousCheckpoint: void 0,
        inputFor: () => void 0,
        checkpoint: async () => {
        },
        progress: () => {
        }
      });
    } finally {
      clearTimeout(timer);
    }
  });
  router.register("pu.product.save", object({ id: optional(id), input: validateProductInput }), ({ id: pid, input }) => pu.saveProduct(pid ?? null, input));
  router.register("pu.product.duplicate", id2, ({ id: pid }) => pu.duplicateProduct(pid));
  router.register("pu.product.setActive", object({ id, active: boolean }), ({ id: pid, active }) => pu.setProductActive(pid, active));
  router.register("pu.product.reorder", object({ ids }), ({ ids: list }) => pu.reorderProducts(list));
  router.register("pu.product.delete", id2, async ({ id: pid }) => {
    await pu.deleteProduct(pid);
    return { deleted: true };
  });
  router.register(
    "pu.image.add",
    object({ base64: string({ min: 4, max: Math.ceil(PRODUCT_LIMITS.imageBytesMax * 4 / 3) + 8 }), mime: string({ max: 40 }) }),
    ({ base64, mime }) => pu.addImage(base64, mime)
  );
  router.register(
    "pu.media.add",
    object({ base64: string({ min: 4, max: Math.ceil(PRODUCT_LIMITS.videoBytesMax * 4 / 3) + 8 }), mime: string({ max: 40 }) }),
    ({ base64, mime }) => pu.addMedia(base64, mime)
  );
  router.register("pu.templates.list", empty2, () => pu.listTemplates());
  router.register("pu.template.save", object({ id: optional(id), input: validateTemplateInput }), ({ id: tid, input }) => pu.saveTemplate(tid ?? null, input));
  router.register("pu.template.duplicate", id2, ({ id: tid }) => pu.duplicateTemplate(tid));
  router.register("pu.template.delete", object({ id, reassignTo: optional(id) }), ({ id: tid, reassignTo }) => pu.deleteTemplate(tid, reassignTo));
  router.register("pu.destinations.list", empty2, () => pu.listDestinations());
  router.register("pu.destination.save", object({ id: optional(id), input: validateDestinationInput }), ({ id: did, input }) => pu.saveDestination(did ?? null, input));
  router.register("pu.destination.delete", id2, async ({ id: did }) => {
    await pu.deleteDestination(did);
    return { deleted: true };
  });
  router.register("pu.destination.confirmLine", id2, ({ id: did }) => pu.confirmLineDestination(did));
  router.register("pu.line.status", empty2, () => app.lineOpenChat.status());
  router.register("pu.line.diagnose", empty2, async () => app.lineOpenChat.diagnose(await app.probeContext("product-update/line-diagnose")));
  router.register("pu.destination.verify", id2, async ({ id: did }) => {
    const r = await pu.verifyDestination(did);
    return { destination: r.destination, title: r.inspection.title, ...r.pending ? { pending: r.pending } : {} };
  });
  router.register("pu.daily.context", empty2, () => pu.dailyContext());
  router.register("pu.batch.preview", object({ productIds: ids, destinationIds: ids, date, dateCard: optional(boolean) }), ({ productIds, destinationIds, date: d, dateCard }) => pu.previewBatch(productIds, destinationIds, d, dateCard === true));
  router.register(
    "pu.batch.create",
    object({ name: optional(string({ max: 80 })), date, productIds: ids, destinationIds: ids, dateCard: optional(boolean) }),
    (req2) => pu.createBatch({ date: req2.date, productIds: req2.productIds, destinationIds: req2.destinationIds, dateCard: req2.dateCard === true, ...req2.name ? { name: req2.name } : {} })
  );
  const content = app.contentPlan;
  router.register("pu.content.get", empty2, () => content.state());
  router.register("pu.content.profile.save", object({ profile: unknownValue }), ({ profile }) => content.saveProfile(profile));
  router.register("pu.content.cancel", empty2, () => content.cancelWork());
  router.register("pu.content.plan", empty2, () => content.plan());
  router.register("pu.content.rewrite", object({ id, note: optional(string({ max: 300 })) }), ({ id: id3, note }) => content.rewrite(id3, note));
  router.register("pu.content.aiImage", object({ id, usePhoto: optional(boolean) }), ({ id: id3, usePhoto }) => content.aiImage(id3, usePhoto));
  router.register("pu.content.post.save", object({ id, edit: unknownValue }), ({ id: id3, edit }) => content.editDay(id3, edit));
  router.register("pu.content.post.delete", object({ id }), ({ id: id3 }) => content.remove(id3));
  router.register("pu.content.post.approve", object({ id }), ({ id: id3 }) => content.approve(id3));
  router.register("pu.dateStyle.get", object({ date }), ({ date: d }) => pu.dailyStyleState(d));
  router.register("pu.dateStyle.ensure", object({ date }), ({ date: d }) => pu.ensureDailyStyle(d));
  router.register("pu.dateStyle.generate", object({ date }), ({ date: d }) => pu.generateDailyStyle(d));
  router.register("pu.dateStyle.save", object({ date, text: string({ max: 1500 }) }), ({ date: d, text: text2 }) => pu.saveDailyStyleText(d, text2));
  router.register("pu.dateStyle.lock", object({ date, locked: boolean }), ({ date: d, locked }) => pu.setDailyStyleLock(d, locked));
  router.register("pu.backup.export", object({ parts: array(literal(...BACKUP_PARTS), { max: BACKUP_PARTS.length }) }), ({ parts }) => app.backup.exportManifest(parts));
  router.register("pu.backup.preview", object({ backup: unknownValue }), ({ backup }) => Promise.resolve(app.backup.preview(backup)));
  router.register(
    "pu.backup.import",
    object({ backup: unknownValue, imageMap: record((x, path) => x === null ? null : id(x, path), { maxKeys: 2e4 }), mode: literal("merge", "replace") }),
    ({ backup, imageMap, mode }) => app.backup.import(backup, imageMap, mode)
  );
  router.register("sync.status", empty2, () => Promise.resolve(app.sync.getStatus()));
  router.register("sync.now", empty2, () => app.sync.syncNow());
  router.register("pu.dateCard.get", object({ date }), ({ date: d }) => pu.dateCardState(d));
  router.register("pu.dateCard.save", object({ settings: validateDateCardSettings }), ({ settings }) => pu.saveDateCardSettings(settings));
  router.register("pu.dateCard.generate", object({ date }), ({ date: d }) => pu.generateDateCard(d));
  router.register("pu.batch.skipCard", batchId, ({ batchId: b }) => pu.skipDateCard(b));
  router.register("pu.batch.list", empty2, () => pu.listBatches());
  router.register("pu.batch.get", batchId, ({ batchId: b }) => pu.batchView(b));
  router.register("pu.batch.start", batchId, ({ batchId: b }) => pu.startBatch(b));
  router.register("pu.batch.pause", batchId, ({ batchId: b }) => pu.pauseBatch(b));
  router.register("pu.batch.resume", batchId, ({ batchId: b }) => pu.resumeBatch(b));
  router.register("pu.batch.cancel", batchId, ({ batchId: b }) => pu.cancelBatch(b));
  router.register("pu.batch.delete", batchId, async ({ batchId: b }) => {
    await pu.deleteBatch(b);
    return { deleted: true };
  });
  router.register("pu.send.retry", object({ sendId: id }), ({ sendId }) => pu.retrySend(sendId));
  router.register("pu.send.resolve", object({ sendId: id, outcome: literal("sent", "pending_approval", "not_sent", "images_only") }), async ({ sendId, outcome }) => {
    const jobId = (await pu.getSend(sendId)).jobId;
    const view = await pu.resolveUnconfirmed(sendId, outcome);
    if (jobId) void app.tabs.releaseHeld(jobId).catch((err) => app.logger.scope("tabs").warn("Cannot close review tab", { message: String(err) }));
    return view;
  });
  const withAdded = async (s) => {
    const byUrl = new Map((await pu.listDestinations()).filter((d) => d.type === "FACEBOOK_GROUP").map((d) => [parseGroupUrl(d.chatReference.url) ?? "", d.id]));
    return { ...s, groups: s.groups.map((g) => {
      const id3 = byUrl.get(g.url);
      return id3 ? { ...g, destinationId: id3 } : g;
    }) };
  };
  router.register("pu.groups.scan.start", empty2, () => withAdded(app.groupScan.start()));
  router.register("pu.groups.scan.state", empty2, () => withAdded(app.groupScan.current()));
  router.register("pu.groups.scan.stop", empty2, () => withAdded(app.groupScan.stop()));
  router.register("pu.send.showTab", object({ sendId: id }), async ({ sendId }) => {
    const jobId = (await pu.getSend(sendId)).jobId;
    const tabId = jobId ? await app.tabs.heldTabFor(jobId) : void 0;
    if (tabId === void 0) return { shown: false };
    await app.tabs.showTab(tabId);
    return { shown: true };
  });
  router.register("pu.history", object({ limit: optional(number({ int: true, min: 1, max: 1e3 })) }), ({ limit }) => pu.history(limit));
}

// src/background/listeners.ts
var validateProgress = object({
  requestId: string({ min: 1, max: 100 }),
  message: string({ max: 500 }),
  data: optional(record(unknownValue, { maxKeys: 20 }))
});
function registerListeners(app) {
  const router = new Router();
  registerHandlers(router, app);
  const log = app.logger.scope("sw");
  const bridgeOrigins = app.registry.list().flatMap((p) => p.origins);
  const fromProviderTab = (sender) => sender.id === chrome.runtime.id && sender.tab !== void 0 && typeof sender.url === "string" && bridgeOrigins.some((pattern) => matchesPattern(sender.url, pattern));
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!isEnvelope(message) || message.target !== void 0) return false;
    if (message.type === BRIDGE_PROGRESS) {
      if (fromProviderTab(sender)) {
        try {
          app.tabs.handleProgress(validateProgress(message.payload));
        } catch (err) {
          log.debug("Ignored malformed progress", toAppError(err).message);
        }
      }
      return false;
    }
    if (!router.owns(message)) return false;
    void router.dispatch(message, sender).then(sendResponse);
    return true;
  });
  chrome.runtime.onConnect.addListener((port5) => {
    if (app.transfers.handleConnect(port5)) return;
    if (app.isUiPort(port5)) app.attachUiPort(port5);
    else port5.disconnect();
  });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === WATCHDOG_ALARM) {
      void runWatchdog(app);
    }
  });
  chrome.action.onClicked.addListener(() => void openAppTab());
  chrome.runtime.onInstalled.addListener(() => void startup(app));
  chrome.runtime.onStartup.addListener(() => void startup(app));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes["settings"]) void app.settingsRepo.get().then((s) => app.applySettings(s));
    if (area === "local" && changes[STORAGE_KEYS.openJobs]) app.followQueueInTabGroup();
  });
  void startup(app);
  return router;
}
async function openAppTab() {
  const url = chrome.runtime.getURL("app/index.html");
  const open = (await chrome.tabs.query({}).catch(() => [])).find((t) => t.url?.startsWith(url));
  if (open?.id !== void 0) {
    await chrome.tabs.update(open.id, { active: true });
    await chrome.windows.update(open.windowId, { focused: true });
    return;
  }
  await chrome.tabs.create({ url });
}
async function runWatchdog(app) {
  try {
    await app.license.tick().catch((err) => app.logger.scope("license").warn("License tick failed", toAppError(err).toJSON()));
    await app.engine.watchdog();
    await app.sync.tick().catch((err) => app.logger.scope("sync").warn("Sync tick failed", toAppError(err).toJSON()));
    await app.cleanup();
  } catch (err) {
    app.logger.scope("sw").error("Watchdog failed", toAppError(err).toJSON());
  }
}
async function startup(app) {
  try {
    await app.settingsRepo.migrate();
    for (const job of await app.jobRepo.listOpen()) {
      if (!("kind" in job.input) || job.input.kind !== "product_send" || job.input.channel) continue;
      const send = await app.productUpdate.getSend(job.input.sendId).catch(() => null);
      if (send) await app.jobRepo.update(job.jobId, (j) => {
        if ("kind" in j.input && j.input.kind === "product_send") j.input.channel = send.snapshot.channel ?? "chat";
      }, app.clock.iso());
    }
    const existing = await chrome.alarms.get(WATCHDOG_ALARM);
    if (!existing) await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: WATCHDOG_PERIOD_MIN });
    app.applySettings(await app.settingsRepo.get());
  } catch (err) {
    app.logger.scope("sw").error("Startup failed", toAppError(err).toJSON());
  }
  await runWatchdog(app);
}

// src/background/service-worker.ts
registerListeners(new App());
